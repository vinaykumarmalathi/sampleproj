package com.rnaipl.wms.service;

import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.log4j.Logger;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.rnaipl.wms.bean.TagSheet;
import com.rnaipl.wms.bean.ran.RanUpload;
import com.rnaipl.wms.dto.TagSheetDTO;
import com.rnaipl.wms.util.WMSConstants;


@Path("/tagSheet")

public class TagSheetService {

	private static final Logger LOGGER = Logger.getLogger(TagSheetService.class);
	 @Inject
	 TagSheet tagSheet;

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/tagSheetPdf")
	 public void getFile(List<TagSheetDTO> tagSheetDTO) throws IOException, DocumentException { 
		LOGGER.debug("**IN Class->getTagSheetDetails()"+tagSheetDTO.size());
		String tagSheetPath = tagSheet.getTagSheetPath();
		
        File file = new File(tagSheetPath);
        file.getParentFile().mkdirs();
        Date date = new Date();
	 	SimpleDateFormat dt = new SimpleDateFormat("dd-MMM-yy"); 
	 	LOGGER.debug("**IN Class->getTagSheetDetails()"+dt.format(date));
        Document document = new Document(PageSize.A4.rotate(),30.0f,30.0f,50.0f,30.0f);
       /* document.left(500);
        document.top(1000);*/
        PdfWriter.getInstance(document, new FileOutputStream(file));
        document.open();
        Paragraph paragraph = new Paragraph();
        PdfPTable mainTable = new PdfPTable(2);
	    mainTable.setWidthPercentage(96);
		    for(TagSheetDTO tagSheet : tagSheetDTO){
		    	
			    for(int i=0;i<1;i++){
				    String formattedPartNumber="";
				    formattedPartNumber=tagSheet.getPartNumber().replaceAll("=","");
					formattedPartNumber=formattedPartNumber.replaceAll("\"","");
			        PdfPCell firstTableCell = new PdfPCell();
			        firstTableCell.setBorder(PdfPCell.NO_BORDER);
			        PdfPTable table = new PdfPTable(3);
			        table.setWidths(new int[]{2,2,2});
			        table.setWidthPercentage(87);
			        table.setSplitLate(false);
			        //table.setSpacingBefore(50);
			        table.setSpacingAfter(35);
			        //1st row
			        Font f1 = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10);
			        f1.setColor(Color.BLACK);
			        Font f2 = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 17);
			        f2.setColor(Color.black);
			        Font f3 = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 13);
			        f1.setColor(Color.BLACK);
			        PdfPCell cell = new PdfPCell(new Phrase("RNAIPL PIT",f3));
			        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			        cell.setFixedHeight(30);
			        cell.setPadding(11);
			        cell.setColspan(2);
			        table.addCell(cell);
			        cell = new PdfPCell(new Phrase("Date   "+dt.format(date),f1));
			        cell.setFixedHeight(30);
			        cell.setPadding(11);
			        table.addCell(cell);
			        
			        //2ND row
			        cell = new PdfPCell(new Phrase("Part Number",f1));
			        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			        cell.setFixedHeight(45);
			        cell.setPadding(15);
			        table.addCell(cell);
			        
			       
			        cell = new PdfPCell(new Phrase(formattedPartNumber,f2));
			        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			        cell.setFixedHeight(45);
			        cell.setPadding(15);
			        cell.setColspan(2);
			        table.addCell(cell);
			        
			        //3rd row
			        cell = new PdfPCell(new Phrase("Location ID",f1));
			        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			        cell.setFixedHeight(45);
			        cell.setPadding(15);
			        table.addCell(cell);
			        cell = new PdfPCell(new Phrase(tagSheet.getLocation(),f2));
			        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			        cell.setFixedHeight(45);
			        cell.setPadding(15);
			        cell.setColspan(2);
			        table.addCell(cell);
			        
			        //4th row
			        cell = new PdfPCell(new Phrase("Device ID",f1));
			        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			       // cell.setFixedHeight(10);
			        cell.setPadding(15);
			        cell.setRowspan(2);
			        table.addCell(cell);
			        cell = new PdfPCell(new Phrase(tagSheet.getDeviceId(),f1));
			        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			       // cell.setFixedHeight(10);
			        cell.setPadding(15);
			        cell.setRowspan(2);
			        table.addCell(cell);
			        cell = new PdfPCell(new Phrase("SNP",f1));
			        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			        cell.setPadding(3);
			        table.addCell(cell);
			        cell = new PdfPCell(new Phrase(tagSheet.getSnp(),f1));
			        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			        cell.setPadding(9);
			        table.addCell(cell);
			        
			        //5th row
			        cell = new PdfPCell(new Phrase("No of Boxes",f1));
			        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			        cell.setPadding(3);
			        table.addCell(cell);
			        cell = new PdfPCell(new Phrase("Open Quantity",f1));
			        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			        cell.setPadding(3);
			        table.addCell(cell);
			        cell = new PdfPCell(new Phrase("Total Quantity",f1));
			        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			        cell.setPadding(3);
			        table.addCell(cell);
			        
			        //6th row
			        cell = new PdfPCell(new Phrase(tagSheet.getNoOfBoxes(),f1));
			        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			        cell.setFixedHeight(25);
			        cell.setPadding(9);
			        table.addCell(cell);
			        cell = new PdfPCell(new Phrase(tagSheet.getOpenQty(),f1));
			        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			        cell.setFixedHeight(25);
			        cell.setPadding(9);
			        table.addCell(cell);
			        cell = new PdfPCell(new Phrase(tagSheet.getTotalQty(),f1));
			        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			        cell.setFixedHeight(25);
			        cell.setPadding(9);
			        table.addCell(cell);
			        firstTableCell.addElement(table);
			        mainTable.addCell(firstTableCell);
		        }
		    }
	    mainTable.getDefaultCell().setBorder(0);
	    mainTable.completeRow();
        paragraph.add(mainTable);
        document.add(mainTable);
        document.close();
       // new TagSheetService().createPdf(WMSConstants.TAGSHEET, tagSheetDTO);
        /*ResponseBuilder response = Response.ok((Object) file);  
        response.header("Content-Disposition","attachment; filename=\"TagSheet.pdf\"");
        response.build();*/
        
     
    }  
	
		@GET  
	    @Path("/txt")  
	    @Produces("text/plain")  
	    public Response getFile() { 
			String tagSheetPath = tagSheet.getTagSheetPath();
	        File file = new File(tagSheetPath);
	        ResponseBuilder response = Response.ok((Object) file);  
	        response.header("Content-Disposition","attachment; filename=\"TagSheet.pdf\"");  
	        return response.build();  
	   
	    }  
}