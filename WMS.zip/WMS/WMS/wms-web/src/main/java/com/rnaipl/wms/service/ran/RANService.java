package com.rnaipl.wms.service.ran;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.ran.RANBean;
import com.rnaipl.wms.dto.PartLocationSynchroInputDTO;
import com.rnaipl.wms.dto.PartNumberDTO;
import com.rnaipl.wms.dto.ran.RANDTO;
import com.rnaipl.wms.dto.ran.RANPickDateDTO;
import com.rnaipl.wms.dto.ran.RANSuggestionDTO;
import com.rnaipl.wms.dto.ran.SuggestedRANLocationForPartNoDTO;
import com.rnaipl.wms.dto.ran.SuggestedRanLocationDTO;
import com.rnaipl.wms.dto.reports.FIFOSuggestionOverrideDTO;
import com.rnaipl.wms.dto.reports.FIFOSuggestionOverrideInputDTO;
import com.rnaipl.wms.dto.reports.FIFOSuggestionOverrideValidationDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;
import com.rnaipl.wms.dto.ran.WhMovementRanValidationInDTO;
import com.rnaipl.wms.dto.ran.WhMovementRanValidationOutDTO;

/**
 * This Restful service class to process the requests from html and call the
 * respective EJB methods of Parts
 * 
 * 
 * @CreatedBy TechM
 * @CreatedOn 08-Apr-2016 10:25:44 am
 */
@Path("/ran")
@RequestScoped
public class RANService {

    private static final Logger LOGGER = Logger.getLogger(RANService.class);

    @Inject
    RANBean ranBean;

    /**
     * This method is used to fetch the all plant details from the table
     * 
     * @return List of Part
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getRan")
    public ServiceResponse getRan(RANSuggestionDTO ran) {
        ServiceResponse serviceReponse = null;
        Set<RANSuggestionDTO> rans = null;
        try {
        	rans = ranBean.getRan(ran.getRanId());
            if(rans!=null && rans.size()>0){
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, rans);
            }
            else{
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND, rans);
            }
        } catch (Exception e) {
        	LOGGER.error("Get RAN: ",e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
        }
        return serviceReponse;
    }
    
    /**
     * This method is used to fetch the all plant details from the table
     * 
     * @return List of Part
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getRanFmRANTbl")
    public ServiceResponse getRanFmRANTbl(RANSuggestionDTO ran) {
        ServiceResponse serviceReponse = null;
        Set<RANSuggestionDTO> rans = null;
        try {
        	rans = ranBean.getRanFmRANTbl(ran.getRanId());
            if(rans!=null && rans.size()>0){
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, rans);
            }
            else{
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND, rans);
            }
        } catch (Exception e) {
        	LOGGER.error("/getRanFmRANTbl method : ",e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
        }
        return serviceReponse;
    }
    
    /**
     * This method is used to fetch the all plant details from the table
     * 
     * @return List of Part
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getRanList")
    public ServiceResponse getRanList(RANDTO ranDTO) {
    	
    	
        ServiceResponse serviceReponse = null;
        List<RANDTO> rans = null;
        try {
        	if(ranDTO!=null && ranDTO.getPartNo()!=null && !ranDTO.getPartNo().trim().equals(""))
        	{        		
        		List<String> partList = Arrays.asList(ranDTO.getPartNo().split(","));
        		ranDTO.setPartList(partList);
        	}
        	if(ranDTO!=null && ranDTO.getRanId()!=null && !ranDTO.getRanId().trim().equals(""))
        	{        		
        		List<String> ranList = Arrays.asList(ranDTO.getRanId().split(","));
        		ranDTO.setRanList(ranList);
        	}
        	rans = ranBean.getRanList(ranDTO);
            if(rans!=null && rans.size()>0){
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, rans);
            }
            else{
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND, rans);
            }
        } catch (Exception e) {
        	LOGGER.error("Get RAN List : ",e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
        }
        return serviceReponse;
    }
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getRanListCount")
    public ServiceResponse getRanListCount(RANDTO ranDTO) {
        ServiceResponse serviceReponse = null;
        List<RANDTO> rans = null;
        try {
        	if(ranDTO!=null && ranDTO.getPartNo()!=null && !ranDTO.getPartNo().trim().equals(""))
        	{   LOGGER.debug("**PART NO NOT NULL" + ranDTO.getPartNo()+"**");     		
        		List<String> partList = Arrays.asList(ranDTO.getPartNo().trim().split(","));
        		ranDTO.setPartList(partList);
        	}
        	if(ranDTO!=null && ranDTO.getRanId()!=null && !ranDTO.getRanId().trim().equals(""))
        	{        		
        		List<String> ranList = Arrays.asList(ranDTO.getRanId().split(","));
        		ranDTO.setRanList(ranList);
        	}
        	ranDTO.setIsForCount(1);
        	rans = ranBean.getRanList(ranDTO);
            if(rans!=null && rans.size()>0){
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS,  rans.size());
            }
            else{
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND, rans);
            }
        } catch (Exception e) {
        	LOGGER.error("Get RAN List : ",e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
        }
        return serviceReponse;
    }
    
    
    
	@GET
	@Produces(MediaType.APPLICATION_XML)
	@Path("/getAllRANLastPickDate")
	public List<RANPickDateDTO> getAllRANLastPickDate(PartLocationSynchroInputDTO inputDto) {
		List<RANPickDateDTO> rans = new ArrayList<RANPickDateDTO>();
		try {
			rans = ranBean.getAllRANLastPickDate(inputDto);
		} catch (Exception e) {
			LOGGER.debug("**Error in getAllRANLastPickDate ", e);
		}
		return rans;
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getAllRANLastPickDateAndroid")
	public List<RANPickDateDTO> getAllRANLastPickDateAndroid(PartLocationSynchroInputDTO inputDto) {
		List<RANPickDateDTO> rans = new ArrayList<RANPickDateDTO>();
		try {
			rans = ranBean.getAllRANLastPickDate(inputDto);
		} catch (Exception e) {
			LOGGER.debug("**Error in getAllRANLastPickDate ", e);
		}
		return rans;
	}
    
	@POST
	@Produces(MediaType.APPLICATION_XML)
	@Path("/getAllRANLastPickDatePT")
	public List<RANPickDateDTO> getAllRANLastPickDatePT(PartLocationSynchroInputDTO inputDto) {
		List<RANPickDateDTO> rans = new ArrayList<RANPickDateDTO>();
		try {
			rans = ranBean.getAllRANLastPickDate(inputDto);
		} catch (Exception e) {
			LOGGER.debug("**Error in getAllRANLastPickDate ", e);

		}
		return rans;
	}
    

    /**
     * This method is used to fetch the all plant details from the table
     * 
     * @return List of Part
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/checkAgedRAN")
    public ServiceResponse checkAgedRAN(List<String> ranList) {
    	
  /*  	String ran="";
    	
    	LOGGER.debug("***Check Aged RAN " +ran );
    	LOGGER.debug("***Check Aged RAN inputList " +ranInputList.get(0).toString() );
        ServiceResponse serviceReponse = null;    
        String agedRans=null;
        List<String> ranList=null;
        if(ran!=null){
        	ranList = Arrays.asList(ran.split(","));
        }*/
    	ServiceResponse serviceReponse = null;  
    	  String agedRans=null;
    	  List<String> modRanList= new ArrayList<String>();;
        try {
        	LOGGER.debug("ranList print in service : " +ranList);
        for(int i = 0; i<ranList.size();i++){
        	String rans = ranList.get(i).toString().substring(0,7);        	
        	modRanList.add(rans);
        }
        
        LOGGER.debug("modRanList print in service : " +modRanList);
        	
        	/*agedRans = ranBean.checkAgedRAN(ranList);*/
            agedRans = ranBean.checkAgedRAN(modRanList);
            if(agedRans!=null && agedRans.length()>0){
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, agedRans);
            }
            else{
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND, agedRans);
            }
        } catch (Exception e) {
        	LOGGER.error("RAN Service : ",e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
        }
        return serviceReponse;
    }
    
    @POST
    @Produces(MediaType.APPLICATION_XML)
    @Path("/getSuggestedRANandLocationForPartNumberWHOut")
    public SuggestedRANLocationForPartNoDTO getSuggestedRANandLocationForPartNumberWHOut(SuggestedRanLocationDTO suggestedRanLocationPartNo){
    	LOGGER.debug("Plant in suggested Ran "+suggestedRanLocationPartNo.getPlant());
    	LOGGER.debug("Shop in suggested Ran "+suggestedRanLocationPartNo.getShop());    	
    	return ranBean.getSuggestedRANandLocationForPartNumberWHOut(suggestedRanLocationPartNo);
    }
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getSuggestedRANandLocationForPartNumberWHOutAndroid")
    public SuggestedRANLocationForPartNoDTO getSuggestedRANandLocationForPartNumberWHOutAndroid(SuggestedRanLocationDTO suggestedRanLocationPartNo){
    	LOGGER.debug("Plant in suggested Ran "+suggestedRanLocationPartNo.getPlant());
    	LOGGER.debug("Shop in suggested Ran "+suggestedRanLocationPartNo.getShop());    	
    	return ranBean.getSuggestedRANandLocationForPartNumberWHOut(suggestedRanLocationPartNo);
    }
    
    @POST
    @Produces(MediaType.APPLICATION_XML)
    @Path("/getSuggestedRANsFIFO")
    public List<SuggestedRANLocationForPartNoDTO> getSuggestedRANandLocationForPartNumberWHOutTC(SuggestedRanLocationDTO suggestedRanLocationPartNo){
    	LOGGER.debug("Plant in suggested Ran "+suggestedRanLocationPartNo.getPlant());
    	LOGGER.debug("Shop in suggested Ran "+suggestedRanLocationPartNo.getShop());    	
    	return ranBean.getSuggestedRANandLocationForPartNumberWHOutTC(suggestedRanLocationPartNo);
    }
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getSuggestedRANsFIFOAndroid")
    public List<SuggestedRANLocationForPartNoDTO> getSuggestedRANandLocationForPartNumberWHOutTCAndroid(SuggestedRanLocationDTO suggestedRanLocationPartNo){
    	LOGGER.debug("Plant in suggested Ran "+suggestedRanLocationPartNo.getPlant());
    	LOGGER.debug("Shop in suggested Ran "+suggestedRanLocationPartNo.getShop());    	
    	return ranBean.getSuggestedRANandLocationForPartNumberWHOutTC(suggestedRanLocationPartNo);
    }
    
    
    //Added for fifo suggestion override validation
    @POST
    @Produces(MediaType.APPLICATION_XML)
    @Path("/getFifoSuggestionValidation")
    public FIFOSuggestionOverrideValidationDTO getFifoSuggestionValidation(FIFOSuggestionOverrideInputDTO fIFOSuggestionOverrideDTO){
    		LOGGER.debug("FIFO Suggestion Validation");
			return ranBean.getFIFOSuggestionOverrideValidation(fIFOSuggestionOverrideDTO);
    }
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getFifoSuggestionValidationAndroid")
    public FIFOSuggestionOverrideValidationDTO getFifoSuggestionValidationAndroid(FIFOSuggestionOverrideInputDTO fIFOSuggestionOverrideDTO){
    		LOGGER.debug("FIFO Suggestion Validation");
			return ranBean.getFIFOSuggestionOverrideValidation(fIFOSuggestionOverrideDTO);
    }
    
  //Added for FIFO changes by arun
    
    @POST
    @Produces(MediaType.APPLICATION_XML)
    @Path("/whMovementRanValidation")
    public WhMovementRanValidationOutDTO getWhMovementRanValidation(WhMovementRanValidationInDTO whMovementRanValidationInDTO) {
    	LOGGER.debug("whMovementRanValidation");
    	return ranBean.getWhMovementRanValidation(whMovementRanValidationInDTO);
    }
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/whMovementRanValidationAndroid")
    public WhMovementRanValidationOutDTO getWhMovementRanValidationAndroid(WhMovementRanValidationInDTO whMovementRanValidationInDTO) {
    	LOGGER.debug("whMovementRanValidation");
    	return ranBean.getWhMovementRanValidation(whMovementRanValidationInDTO);
    }
    	
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getRanListByPlant")
    public ServiceResponse getRanListByPlant(RANDTO dto) {
        ServiceResponse serviceReponse = null;
        Set<RANSuggestionDTO> rans = null;
        RANSuggestionDTO input = dto.getInput();
        try {
        	rans = ranBean.getRanListByPlant(input.getRanId(),dto);
            if(rans!=null && rans.size()>0){
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, rans);
            }
            else{
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND, rans);
            }
        } catch (Exception e) {
        	LOGGER.error("Get RAN: ",e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
        }
        return serviceReponse;
    }
    
}
