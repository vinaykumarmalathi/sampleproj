package com.rnaipl.wms.service;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.stockcorrection.StockCorrectionAdd;
import com.rnaipl.wms.dto.StockCorrectionAddDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

/**
 * This Restful service class to process the requests from html and call the
 * respective EJB methods of Parts
 * 
 * 
 * @CreatedBy TechM
 * @CreatedOn 08-Apr-2016 10:25:44 am
 */
@Path("/stockcorrection")
@RequestScoped
public class StockCorrectionAddService {

	private static final Logger LOGGER = Logger.getLogger(StockCorrectionAddService.class);

	@Inject
	StockCorrectionAdd stockCorrection;

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/add-correction")
	public ServiceResponse addStockCorrection(List<StockCorrectionAddDTO> stockCorrectionDTO) {
		LOGGER.debug("getCorrectionDetails - Starts");
		ServiceResponse serviceReponse = null;

		try {
			List<StockCorrectionAddDTO> stockCorrectionDTOResponse = stockCorrection
					.addStockCorrection(stockCorrectionDTO);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
					ServiceConstants.STOCK_LOC_CORR_ADD_SUCCESS, stockCorrectionDTOResponse);
		} catch (Exception e) {
			LOGGER.error("StockLocationCorrectionService -- > updateStockLocation  Exception : ", e);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.STOCK_LOC_CORR_ADD_ERROR, e);
		}
		LOGGER.debug("getCorrectionDetails - Ends");
		return serviceReponse;

	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/delete-correction")
	public ServiceResponse deleteStockCorrection(List<StockCorrectionAddDTO> stockCorrectionDTO) {
		LOGGER.debug("getCorrectionDetails - Starts");
		ServiceResponse serviceReponse = null;

		try {
			stockCorrection.deleteStockCorrection(stockCorrectionDTO);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
					ServiceConstants.STOCK_LOC_CORR_DEL_SUCCESS);
		} catch (Exception e) {
			LOGGER.error("StockLocationCorrectionService -- > updateStockLocation  Exception : ", e);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.STOCK_LOC_CORR_DEL_ERROR, e);
		}
		LOGGER.debug("getCorrectionDetails - Ends");
		return serviceReponse;

	}

}
