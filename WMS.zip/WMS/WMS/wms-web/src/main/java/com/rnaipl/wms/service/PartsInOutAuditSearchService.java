package com.rnaipl.wms.service;

import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.PartsInOutAuditSearch;
import com.rnaipl.wms.bean.common.CommonParameter;
import com.rnaipl.wms.dto.PartsInOutAuditSearchDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;
import com.rnaipl.wms.util.WMSConstants;

@Path("/search")
public class PartsInOutAuditSearchService {

	private static final Logger LOGGER = Logger.getLogger(PartsInOutAuditSearchService.class);
	
	 @Inject
	 PartsInOutAuditSearch partsInOutAuditSearch;
	 @Inject
	 CommonParameter commonParamBean;
	 
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/partsInOutAuditSearch")
    @SuppressWarnings("null")
	public ServiceResponse getPartsAuditDetails(PartsInOutAuditSearchDTO partsInOutAuditSearchDTO){
		
		ServiceResponse serviceResponse = null;
		LOGGER.debug("**IN Class->getPartsAuditDetails() entry");
		LOGGER.debug("** Device ID --"+partsInOutAuditSearchDTO.getDeviceId());
		
		try {
		//	serviceResponse.getStatusCode();
			
			if(partsInOutAuditSearchDTO.getPartNumber() != null) {
        		List<String> partList = Arrays.asList(partsInOutAuditSearchDTO.getPartNumber().split(","));
        		partsInOutAuditSearchDTO.setPartList(partList);
        	}
        	if(partsInOutAuditSearchDTO.getLocation() != null) {
        		List<String> locationList = Arrays.asList(partsInOutAuditSearchDTO.getLocation().split(","));
        		partsInOutAuditSearchDTO.setLocationList(locationList);
        	}
        	
        	if(partsInOutAuditSearchDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(partsInOutAuditSearchDTO.getRan().split(","));        	
        		partsInOutAuditSearchDTO.setRanList(ranList);
        	}
        	
        	if(partsInOutAuditSearchDTO.getIsFullDownload()==1 ){
        		LOGGER.debug("**Full Download");
        		int noOfRecords = partsInOutAuditSearch.getPartInOutAuditSearchCount(partsInOutAuditSearchDTO);
        		int maxRecordsAllowed=getMaxRecordsAllowed();
        		LOGGER.debug("*MAX Records Allowed" + maxRecordsAllowed);
        		if((noOfRecords>=maxRecordsAllowed)){
        				String errorMessage = noOfRecords+ " record(s) returned. Max records allowed to download is "+ maxRecordsAllowed;
        				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.AUDIT_DOWNLOAD_TOO_MANY_RECORDS,errorMessage);
        				return serviceResponse;
        		}
        	}
			List<PartsInOutAuditSearchDTO> PartsInOutAuditSearchDTOs = partsInOutAuditSearch
					.getPartsAuditSearch(partsInOutAuditSearchDTO);
			if (!PartsInOutAuditSearchDTOs.isEmpty()
					|| PartsInOutAuditSearchDTOs.size() > 0) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.PARTS_FETCH_SUCCESS,
						PartsInOutAuditSearchDTOs);
			} else {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			}
		

		} catch (Exception ex) {
			LOGGER.error("PartsInOutSearchService -- > getPartsInOutAuditByLocation()  Exception : " , ex);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.PARTS_FETCH_ERROR, ex);
		}
		LOGGER.debug("**IN Class->getPartsAuditDetails() Exit");
		return serviceResponse;
	}



		
		@POST
	    @Produces(MediaType.APPLICATION_JSON)
	    @Path("/partsInOutAuditCount")
	    @SuppressWarnings("null")
		public ServiceResponse getPartsAuditCount(PartsInOutAuditSearchDTO partsInOutAuditSearchDTO){
			
			ServiceResponse serviceResponse = null;
			LOGGER.debug("**IN Class->getPartsAuditCount() entry");
			LOGGER.debug("** Device ID --"+partsInOutAuditSearchDTO.getDeviceId());
			try {
				LOGGER.debug("IN getPartsAuditCount ENTRY");
				if(partsInOutAuditSearchDTO.getPartNumber() != null) {
	        		List<String> partList = Arrays.asList(partsInOutAuditSearchDTO.getPartNumber().split(","));
	        		partsInOutAuditSearchDTO.setPartList(partList);
	        	}
	        	if(partsInOutAuditSearchDTO.getLocation() != null) {
	        		List<String> locationList = Arrays.asList(partsInOutAuditSearchDTO.getLocation().split(","));
	        		partsInOutAuditSearchDTO.setLocationList(locationList);
	        	}
	        	if(partsInOutAuditSearchDTO.getRan() != null) {
	        		List<String> ranList = Arrays.asList(partsInOutAuditSearchDTO.getRan().split(","));
	        		partsInOutAuditSearchDTO.setRanList(ranList);
	        	}
				int noOfRecords = partsInOutAuditSearch
						.getPartInOutAuditSearchCount(partsInOutAuditSearchDTO);
				if (noOfRecords > 0) {
					serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
							ServiceConstants.PARTS_FETCH_SUCCESS,
							noOfRecords);
				} else {
					serviceResponse = ServiceResponseHandler
							.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
				}
				LOGGER.debug("IN getPartsAuditSearch EXIT");

			} catch (Exception ex) {
				LOGGER.error("PartsInOutSearchService -- > getPartsInOutAuditByLocation()  Exception : " , ex);
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
						ServiceConstants.PARTS_FETCH_ERROR, ex);
			}
			LOGGER.debug("**IN Class->getPartsAuditDetails() Exit");
			return serviceResponse;
			
		}
		
		private int getMaxRecordsAllowed() {
			String recordsAllowedtoDownload = commonParamBean.getParamValueById(WMSConstants.AUDIT_MAXRECORDS_DOWNLOAD_ID);
			int recordsAllowedtoDownloadInt=0;
			if(recordsAllowedtoDownload!=null && !recordsAllowedtoDownload.trim().equals(""))
			{
				recordsAllowedtoDownloadInt=Integer.parseInt(recordsAllowedtoDownload);
			}
			else{
				recordsAllowedtoDownloadInt=WMSConstants.AUDIT_MAXRECORDS_DOWNLOAD_DEFAULT;
			}
			return recordsAllowedtoDownloadInt;
		}	
			
}
