package com.rnaipl.wms.service;

import javax.ejb.EJBException;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.security.auth.login.FailedLoginException;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.mindrot.jbcrypt.BCrypt;

import com.rnaipl.wms.bean.LoginAuthentication;
import com.rnaipl.wms.dto.LoginDTO;
import com.rnaipl.wms.entities.Login;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

@Path("/user")
@RequestScoped
public class LoginAuthenticationService {

	private static final Logger LOGGER = Logger
			.getLogger(LoginAuthenticationService.class);

	@Inject
	LoginAuthentication userBean;
	@Inject
	Login login;

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/login")
	public ServiceResponse loginuser(LoginDTO loginDTO) {

		LOGGER.debug("Restful Service - Login User");
		int result = 0;
		ServiceResponse serviceResponse = null;
		try {

			result = userBean.loginuser(loginDTO.getUsername(),loginDTO.getPassword());

			if (result == -1) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.LOGIN_USER_NOT_EXIST);
			} else if (result == 0) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.LOGIN_PASSWORD_INCORRECT);
			} else {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.LOGIN_SUCCESS);
			}

		} catch (Exception e) {
			LOGGER.error("LoginAuthenticationService - > loginuser() Exception : " ,e);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
			
		}
		return serviceResponse;
	}

}
