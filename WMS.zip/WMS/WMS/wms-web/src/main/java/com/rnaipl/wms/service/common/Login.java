package com.rnaipl.wms.service.common;

import java.util.Calendar;

import javax.enterprise.context.RequestScoped;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.common.LoginDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;
import com.rnaipl.wms.util.CryptoUtil;

@Path("/login")
@RequestScoped
public class Login {
	 private static final Logger LOGGER = Logger.getLogger(Login.class);
	 
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/validate")
    public ServiceResponse validateUser(LoginDTO loginDTO) throws Exception {
		ServiceResponse serviceReponse = null; 
		
		LOGGER.debug("*** User ID " + loginDTO.getUserId());
		LOGGER.debug("***Valid Until " + loginDTO.getValidUntil());
		LOGGER.debug("***Input Key " + loginDTO.getEncryptedKey());
		String key = CryptoUtil.encrypt(loginDTO.getUserId()+loginDTO.getValidUntil());
		
		LOGGER.debug("***Encrypted Key " + key);
		if(key.equals(loginDTO.getEncryptedKey()) && isKeyNotExpired(loginDTO.getValidUntil()))
		{
			LOGGER.debug("Key Valid");
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.BLANK_STATUS_MESSAGE, loginDTO.getUserId());	
		}
		else
		{
			LOGGER.debug("Key Invalid");
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.BLANK_STATUS_MESSAGE, loginDTO.getUserId());
		}		 
		return serviceReponse;
		
	}
	
	private boolean isKeyNotExpired(long validPeriod)
	{
		if(validPeriod==0)
			return false;
		else{
			Calendar currentDateTime = Calendar.getInstance();
			Calendar expiryDateTime = Calendar.getInstance();
			expiryDateTime.setTimeInMillis(validPeriod);
			if(currentDateTime.before(expiryDateTime))
			{
				return true;
			}
			else
			{
				LOGGER.debug("Key Expired");
				return false;
			}
			
		}
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/redirectToHome")
	public ServiceResponse redirectToHome(String userId) throws Exception {
		ServiceResponse serviceReponse = null;
		LoginDTO loginDTO = null;
		try {
			loginDTO = new LoginDTO();
			LOGGER.debug("*** User ID " + userId);
			long keyValidPeriod = CryptoUtil.getKeyValidPeriod();
			LOGGER.debug("***Valid Until " + keyValidPeriod);
			String key = CryptoUtil.encrypt(userId + keyValidPeriod);
			LOGGER.debug("***Encrypted Key " + key);
			loginDTO.setUserId(userId);
			loginDTO.setValidUntil(keyValidPeriod);
			loginDTO.setEncryptedKey(key);
			serviceReponse = ServiceResponseHandler.prepareMessage(	ServiceConstants.SERVICE_RESPONSE_SUCCESS,
					ServiceConstants.BLANK_STATUS_MESSAGE, loginDTO);
		} catch (Exception ex) {
			serviceReponse = ServiceResponseHandler.prepareMessage(
					ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, loginDTO);
		}
		return serviceReponse;
	}
}
