/**
 * 
 */
package com.rnaipl.wms.service.util;

import java.text.MessageFormat;
import java.util.List;
import java.util.ResourceBundle;

import javax.ejb.EJBException;

/**
 * <Comments Here>
 * 
 * @CreatedBy TechM
 * @CreatedOn 07-Oct-2015 10:34:28 am
 */
public final class ServiceResponseHandler {

    /**
     * Member variable MESSAGE_BUNDLE
     */
    public static final ResourceBundle MESSAGE_BUNDLE = ResourceBundle.getBundle("wms-service-responseMessages");

    /**
     * private constructor
     */
    private ServiceResponseHandler() {

    }

    public static <E> ServiceResponse prepareMessage(final String statusType, final String statusCode) {
        ServiceResponse serviceMessage = new ServiceResponse(statusType, statusCode, MESSAGE_BUNDLE.getString(statusCode));       
        return serviceMessage;
    }
    public static <E> ServiceResponse prepareMessage(final String statusType, final String statusCode, final E object) {
        ServiceResponse serviceMessage = new ServiceResponse(statusType, statusCode, MESSAGE_BUNDLE.getString(statusCode),object);        
        return serviceMessage;
    }
    public static <E> ServiceResponse prepareMessage(final String statusType, final String statusCode,final List<E> objectList) {
        ServiceResponse serviceMessage = new ServiceResponse(statusType, statusCode, MESSAGE_BUNDLE.getString(statusCode),objectList);
        return serviceMessage;
    }
    
    public static <E> ServiceResponse prepareMessage(final String statusType, final String statusCode,final String statusMessage) {
        ServiceResponse serviceMessage = new ServiceResponse(statusType, statusCode,statusMessage);       
        return serviceMessage;
        
    }
    
  
    
    
    
    


}
