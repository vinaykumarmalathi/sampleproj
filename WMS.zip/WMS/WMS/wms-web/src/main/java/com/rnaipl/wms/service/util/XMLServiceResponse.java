package com.rnaipl.wms.service.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class is for creating service message and will send to presentation
 * layer
 * 
 * @param <E>
 * @CreatedBy TechM
 * @CreatedOn 19-Apr-2016 10:49:31 am
 */
@XmlRootElement(name="Response")
@XmlAccessorType(XmlAccessType.FIELD)
public class XMLServiceResponse {

    private static final Logger LOGGER = LoggerFactory.getLogger(XMLServiceResponse.class);
    
    /**
     * Member variable statusCode for message code
     */
    @XmlElement(name="statusType")   
    private String statusType;

    /**
     * Member variable statusCode for message code
     */
    @XmlElement(name="statuscode")   
    private String statusCode;
    /**
     * Member variable statusMessage for message description
     */
    
    @XmlElement(name="statusMessage")   
    
    private String statusMessage;
    
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public String getStatusType() {
		return statusType;
	}
	public void setStatusType(String statusType) {
		this.statusType = statusType;
	}

    

   

}
