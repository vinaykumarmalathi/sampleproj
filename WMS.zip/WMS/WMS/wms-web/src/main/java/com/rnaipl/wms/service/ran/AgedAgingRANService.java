package com.rnaipl.wms.service.ran;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.ran.AgedRAN;
import com.rnaipl.wms.bean.ran.RANBean;
import com.rnaipl.wms.dto.ran.AgedAgingRanDTO;
import com.rnaipl.wms.dto.ran.AgedAgingRanInputDTO;
import com.rnaipl.wms.dto.ran.RANSuggestionDTO;
import com.rnaipl.wms.dto.ran.RANPickDateDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

/**
 * This Restful service class to process the requests from html and call the
 * respective EJB methods of Parts
 * 
 * 
 * @CreatedBy TechM
 * @CreatedOn 08-Apr-2016 10:25:44 am
 */
@Path("/agedRan")
@RequestScoped
public class AgedAgingRANService {

    private static final Logger LOGGER = Logger.getLogger(AgedAgingRANService.class);

    @Inject
    AgedRAN agedRanBean;

    /**
     * This method is used to fetch the all plant details from the table
     * 
     * @return List of Part
     */
    @SuppressWarnings("null")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
  //  @Consumes(MediaType.APPLICATION_JSON)
    @Path("/getAgedAgingRAN")
    public ServiceResponse getAgingAgedRAN(AgedAgingRanInputDTO agedAgingRanInputDTO) {
    	
    	
        ServiceResponse serviceReponse = null;
        List<AgedAgingRanDTO> agedAgingRANs = null;
        try {
        	if(agedAgingRanInputDTO.getPartNo() != null) {
        		List<String> partList = Arrays.asList(agedAgingRanInputDTO.getPartNo().split(","));
        		agedAgingRanInputDTO.setPartList(partList);
        	}
        	if(agedAgingRanInputDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(agedAgingRanInputDTO.getRan().split(","));
        		agedAgingRanInputDTO.setRanList(ranList);
        	}
        	if(agedAgingRanInputDTO.getLocation() != null) {
        		List<String> locationList = Arrays.asList(agedAgingRanInputDTO.getLocation().split(","));
        		agedAgingRanInputDTO.setLocationList(locationList);
        	}
        	
        	
        	if(agedAgingRanInputDTO.getFromDate()!=null)
        	{        		
        		agedAgingRanInputDTO.setFromDate(agedAgingRanInputDTO.getFromDate().replaceAll("-","/"));        		
        	}
        	if(agedAgingRanInputDTO.getToDate()!=null)
        	{        		
        		agedAgingRanInputDTO.setToDate(agedAgingRanInputDTO.getToDate().replaceAll("-","/"));        		
        	}
        //	agedAgingRanInputDTO.setRequestForCount(false);
        	agedAgingRANs = agedRanBean.getAgedAgingRAN(agedAgingRanInputDTO);
        	
            if(agedAgingRANs!=null && agedAgingRANs.size()>0){
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, agedAgingRANs);
            }
            else{
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND, agedAgingRANs);
            }
        } catch (Exception e) {
        	LOGGER.error("LineService -- > getAllShops() Exception : ",e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
        }
        return serviceReponse;
    }
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getAgedAgingRANCount")
    public ServiceResponse getAgingAgedRANCount(AgedAgingRanInputDTO agedAgingRanInputDTO) {
    	
    	
        ServiceResponse serviceReponse = null;
        int totalNoOfRecords =0;
        List<AgedAgingRanDTO> agedAgingRANs = null;
        try {
        	if(agedAgingRanInputDTO.getPartNo() != null) {
        		List<String> partList = Arrays.asList(agedAgingRanInputDTO.getPartNo().split(","));
        		agedAgingRanInputDTO.setPartList(partList);
        	}
        	if(agedAgingRanInputDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(agedAgingRanInputDTO.getRan().split(","));
        		agedAgingRanInputDTO.setRanList(ranList);
        	}
        	if(agedAgingRanInputDTO.getFromDate()!=null)
        	{        		
        		agedAgingRanInputDTO.setFromDate(agedAgingRanInputDTO.getFromDate().replaceAll("-","/"));        		
        	}
        	if(agedAgingRanInputDTO.getToDate()!=null)
        	{        		
        		agedAgingRanInputDTO.setToDate(agedAgingRanInputDTO.getToDate().replaceAll("-","/"));        		
        	}
        	agedAgingRanInputDTO.setRequestForCount(true);
        	agedAgingRANs = agedRanBean.getAgedAgingRAN(agedAgingRanInputDTO);
            if(agedAgingRANs!=null ){
            	totalNoOfRecords=agedAgingRANs.size();
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, totalNoOfRecords);
            }
            else{
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND, totalNoOfRecords);
            }
        } catch (Exception e) {
        	LOGGER.error("LineService -- > getAllShops() Exception : ",e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
        }
        return serviceReponse;
    }
    
    @SuppressWarnings("null")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
  //  @Consumes(MediaType.APPLICATION_JSON)
    @Path("/getAgedAgingRANDownload")
    public ServiceResponse getAgingAgedRANDownload(AgedAgingRanInputDTO agedAgingRanInputDTO) {
    	
    	
        ServiceResponse serviceReponse = null;
        List<AgedAgingRanDTO> agedAgingRANs = null;
        try {
        	if(agedAgingRanInputDTO.getPartNo() != null) {
        		List<String> partList = Arrays.asList(agedAgingRanInputDTO.getPartNo().split(","));
        		agedAgingRanInputDTO.setPartList(partList);
        	}
        	if(agedAgingRanInputDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(agedAgingRanInputDTO.getRan().split(","));
        		agedAgingRanInputDTO.setRanList(ranList);
        	}
        	if(agedAgingRanInputDTO.getFromDate()!=null)
        	{        		
        		agedAgingRanInputDTO.setFromDate(agedAgingRanInputDTO.getFromDate().replaceAll("-","/"));        		
        	}
        	if(agedAgingRanInputDTO.getToDate()!=null)
        	{        		
        		agedAgingRanInputDTO.setToDate(agedAgingRanInputDTO.getToDate().replaceAll("-","/"));        		
        	}
        	agedAgingRanInputDTO.setDownload(true);
        	agedAgingRANs = agedRanBean.getAgedAgingRAN(agedAgingRanInputDTO);
        	
            if(agedAgingRANs!=null && agedAgingRANs.size()>0){
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, agedAgingRANs);
            }
            else{
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND, agedAgingRANs);
            }
        } catch (Exception e) {
        	LOGGER.error("LineService -- > getAllShops() Exception : ",e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
        }
        return serviceReponse;
    }
    
    
}
