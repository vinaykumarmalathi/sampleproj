package com.rnaipl.wms.service;

import java.util.List;

import javax.ejb.EJBException;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.UserMenu;
import com.rnaipl.wms.dto.MenuDTO;
import com.rnaipl.wms.dto.UserDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

@Path("/user")
@RequestScoped
public class UserMenuService {

	private static final Logger LOGGER = Logger.getLogger(UserMenuService.class);
	
	@Inject
	UserMenu userBean;
	
	/**
     * This method is used to fetch the all plant details from the table
     * 
     * @return List of Part
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/userMenus")
    public ServiceResponse getUserMenus(UserDTO user) {
		ServiceResponse serviceReponse = null;
		List<MenuDTO> userMenus = null;
		try {
			if (user.getUserId() == null || "".equals(user.getUserId())) {
				serviceReponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.WRONG_INPUT);
			} else {
				userMenus = userBean.getUserMenus(user);
				LOGGER.debug("Fetching all the User Menu details");
				if (!userMenus.isEmpty() || userMenus.size() > 0) {
					serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
							ServiceConstants.USER_MENU_FETCH_SUCCESS, userMenus);
				} else {
					serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
							ServiceConstants.NO_DATA_FOUND, userMenus);
				}
			}
		} catch (EJBException ejbe) {
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.USER_MENU_FETCH_FAILURE, ejbe);
		}
		LOGGER.debug("Fetching all the shop details");
		return serviceReponse;
    }
    
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/rolesPrivilege")
	public ServiceResponse rolesPrivilege() {

		LOGGER.debug("Restful Service - Login User");
		List<String> roles = null;
		ServiceResponse serviceResponse = null;
		try {

			roles = userBean.rolesPrivilege();

			if (roles!=null && roles.size()>0) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS,roles);
			} else {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND,roles);
			}

		} catch (Exception e) {
			LOGGER.error("LoginAuthenticationService - > rolesPrivilege() Exception : " ,e);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
			
		}
		return serviceResponse;
	}
}
