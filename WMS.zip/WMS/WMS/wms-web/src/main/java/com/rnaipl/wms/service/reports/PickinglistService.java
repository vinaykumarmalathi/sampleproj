package com.rnaipl.wms.service.reports;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.rnaipl.wms.bean.PickingList;
import com.rnaipl.wms.bean.reports.IPickingList;
import com.rnaipl.wms.dto.PickListAndroidDTO;
import com.rnaipl.wms.dto.PickinglistDetailsDTO;
import com.rnaipl.wms.dto.reports.LineAllocationDTO;
import com.rnaipl.wms.dto.reports.PickinglistDTO;
import com.rnaipl.wms.dto.reports.PickinglistResultsDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;
import com.rnaipl.wms.util.WMSConstants;

@Path("/pickinglist")
@RequestScoped
public class PickinglistService {
	private static final Logger LOGGER = Logger.getLogger(PickinglistService.class);

	private static String FILE_PATH = null;

	@Inject
	IPickingList pickingList;

	@Inject
	PickingList pickingPath;

	@Context
	static HttpServletRequest request;

	@Context
	HttpServletResponse response;

	@SuppressWarnings("unchecked")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/search")
	public ServiceResponse<PickinglistResultsDTO> getPickingList(PickinglistDTO pickinglistDTO) {
		LOGGER.debug("Entering getPickingList:: " + pickinglistDTO.getShop());
		ServiceResponse<PickinglistResultsDTO> serviceResponse = null;
		List<PickinglistResultsDTO> pickinglistResultsDTOList = pickingList.getPickingList(pickinglistDTO);
		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
				ServiceConstants.PICKINGLIST_FETCH_SUCCESS, pickinglistResultsDTOList);
		LOGGER.debug("Exiting getPickingList:: " + pickinglistDTO.getShop());
		return serviceResponse;
	}
	
	@SuppressWarnings("unchecked")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/countPickingList")
	public ServiceResponse getPickingListCount(PickinglistDTO pickinglistDTO) {
		LOGGER.debug("Entering getPickingList:: " + pickinglistDTO.getShop());
		ServiceResponse serviceResponse = null;
		int noOfRecords = pickingList.getPickingListCount(pickinglistDTO);
		LOGGER.debug("noOfRecords in Service class : "+noOfRecords);
		if (noOfRecords > 0) {
			/*serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
					ServiceConstants.PICKINGLIST_FETCH_SUCCESS, noOfRecords);*/
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
					ServiceConstants.PICKINGLIST_FETCH_SUCCESS,	noOfRecords);
		} else {
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
					ServiceConstants.NO_DATA_FOUND);
		}
		LOGGER.debug("Exiting getPickingListCount:: " + pickinglistDTO.getShop());
		return serviceResponse;
	}

	@SuppressWarnings("unchecked")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/closurePickingList")
	public int getClosurePickingDetails(@QueryParam("deviceTranId") String deviceTranId,
			@QueryParam("partNumber") String partNumber, @QueryParam("userId") String userId) {
		LOGGER.debug("Entering ClosurePickingDetails:: " + deviceTranId +" : "+partNumber);
		System.out.println("Entered");
		ServiceResponse serviceResponse = null;
		int rowsAffected = pickingList.getClosurePickingListDetail(deviceTranId,partNumber,userId);
		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
				ServiceConstants.PICKINGLIST_FETCH_SUCCESS, rowsAffected);
		LOGGER.debug("Exiting ClosurePickingDetails:: " + deviceTranId +" : "+partNumber);
		return rowsAffected;
	}
	
	@SuppressWarnings("unchecked")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/pickinglist")
	public ServiceResponse<PickinglistResultsDTO> getPickingDetails(@QueryParam("deviceTranId") String deviceTranId) {
		LOGGER.debug("Entering getPickingDetails:: " + deviceTranId);
		ServiceResponse<PickinglistResultsDTO> serviceResponse = null;
		PickinglistResultsDTO pickinglistResultsDTO = pickingList.getPickingListDetail(deviceTranId);
		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
				ServiceConstants.PICKINGLIST_FETCH_SUCCESS, pickinglistResultsDTO);
		LOGGER.debug("Exiting getPickingDetails:: " + deviceTranId);
		return serviceResponse;
	}
	
	//ADDED FOR UAT REQ TO PROVIDE SAVE AS OPTION FOR DOWNLOAD -START
	@POST
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	@Path("/downloadPickingList")
	public void downloadPickingList(List<PickinglistDetailsDTO> pickingListDetailsDTO)
			throws IOException, DocumentException {
		ServiceResponse serviceResponse = null;
		try {
			LOGGER.debug("Entering downloadPickingList:: " + pickingListDetailsDTO);
			// String pickingListPath = pickingPath.getPickingListPath();
			// String filename="PIList.pdf";
			String fileName = WMSConstants.SERVICE_FILE_DOWNLOAD_NAME;
			LOGGER.debug("downloadPickingList fileName : " + fileName);
			if (fileName != null) {
				response.addHeader("x-filename", fileName);
				response.setContentType("application/octet-stream");
				response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
				
				String imgPathName = pickingList.getImageLogoPath();
				LOGGER.debug("imgPathName : "+imgPathName);
				/*Document document = new Document(PageSize.A4, 30.0f, 30.0f, 50.0f, 30.0f);*/
				/*Added by Meena to reduce the font size and column size - start*/
				/*Document document = new Document(PageSize.A4, -20,-20, 30.0f, 20.0f);*/
				Document document = new Document(PageSize.A4, -25,-25, 30.0f, 20.0f);
				PdfWriter.getInstance(document, response.getOutputStream());
				document.open();
				
				 //File file = new File(imgPathName); 

			    File file = new File("M:/WMS_BATCH_FILES/QA/IMG/rnaipl_logo.png");
				//File file = new File("D://Public//Meena//rnaipl_logo.png");
				PdfPTable imageTable = new PdfPTable(1);

				imageTable.addCell(createImageCell(file.getAbsolutePath()));

				document.add(imageTable);

				Paragraph paragraph = new Paragraph("RENAULT NISSAN AUTOMATIVE INDIA PRIVATE LIMITED");
				paragraph.setAlignment(Element.ALIGN_CENTER);
				document.add(paragraph);

				paragraph = new Paragraph("LINE FEEDING PART DETAILS");
				paragraph.setAlignment(Element.ALIGN_CENTER);
				document.add(paragraph);
				
				Font headerFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 6);
				headerFont.setColor(BaseColor.BLACK);

				Font cellFont = FontFactory.getFont(FontFactory.HELVETICA, 6);
				cellFont.setColor(BaseColor.BLACK);

				/*PdfPTable table = new PdfPTable(7);*/
				PdfPTable table = new PdfPTable(22);
				table.setSpacingBefore(10);
				table.setSpacingAfter(10);
				
/*				PdfPCell cell = new PdfPCell(new Phrase("Part Number",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(2);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase("Location",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(9);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase("No Of Boxes",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(1);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase("SNP",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(1);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase("Qty",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(1);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase("Device",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(3);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase("Scan date & Time",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(3);
				table.addCell(cell);*/
				
				PdfPCell cell = new PdfPCell(new Phrase("Part Type",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(1);
				table.addCell(cell);
				
				cell = new PdfPCell(new Phrase("Part Number",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(2);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase("Location",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(3);
				table.addCell(cell);

				/*cell = new PdfPCell(new Phrase("No Of Boxes",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(1);
				table.addCell(cell);*/
				
				cell = new PdfPCell(new Phrase("Open Boxes",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(1);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase("SNP",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(1);
				table.addCell(cell);

				/*cell = new PdfPCell(new Phrase("Qty",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(1);
				table.addCell(cell);*/
				
				cell = new PdfPCell(new Phrase("Open Qty",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(1);
				table.addCell(cell);

				cell = new PdfPCell(new Phrase("Last Upd By",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(2);
				table.addCell(cell);
				
				cell = new PdfPCell(new Phrase("WIP",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(1);
				table.addCell(cell);
				
				cell = new PdfPCell(new Phrase("Remaining Actual",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(1);
				table.addCell(cell);
				
				cell = new PdfPCell(new Phrase("EOP Mark",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(1);
				table.addCell(cell);
				
				cell = new PdfPCell(new Phrase("Status",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(1);
				table.addCell(cell);
				
				cell = new PdfPCell(new Phrase("Model",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(2);
				table.addCell(cell);
				
				cell = new PdfPCell(new Phrase("Allocation",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(1);
				table.addCell(cell);
				
				cell = new PdfPCell(new Phrase("Supplier",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(2);
				table.addCell(cell);
				
				cell = new PdfPCell(new Phrase("Line Stock",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(1);
				table.addCell(cell);
				
				cell = new PdfPCell(new Phrase("Line Loc",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(1);
				table.addCell(cell);

				/*cell = new PdfPCell(new Phrase("Scan date & Time",headerFont));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setColspan(3);
				table.addCell(cell);*/

				for (PickinglistDetailsDTO pickingListDetailDTO : pickingListDetailsDTO) {

					/*LOGGER.debug("---------------------------------------------------------");

					LOGGER.debug("part number" + pickingListDetailDTO.getPartNumber());
					LOGGER.debug("location" + pickingListDetailDTO.getLocation());
					LOGGER.debug("quantity" + pickingListDetailDTO.getQuantity());
					LOGGER.debug("device" + pickingListDetailDTO.getDevice());*/
				//	LOGGER.debug("scan time" + pickingListDetailDTO.getFormattedScanTime());

					table.setSpacingBefore(10);
					table.setSpacingAfter(10);
					
					cell = new PdfPCell(new Phrase(pickingListDetailDTO.getPartType(),cellFont));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(1);
					table.addCell(cell);

					cell = new PdfPCell(new Phrase(pickingListDetailDTO.getPartNumber(),cellFont));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(2);
					table.addCell(cell);

					cell = new PdfPCell(new Phrase(pickingListDetailDTO.getLocation(),cellFont));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(3);
					table.addCell(cell);

					/*cell = new PdfPCell(new Phrase(pickingListDetailDTO.getNoOfBoxes() + "",cellFont));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(1);
					table.addCell(cell);*/
					
					cell = new PdfPCell(new Phrase(pickingListDetailDTO.getNoOfOpenBoxes() + "",cellFont));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(1);
					table.addCell(cell);

					cell = new PdfPCell(new Phrase(pickingListDetailDTO.getSnp() + "",cellFont));
					LOGGER.debug("snp" + pickingListDetailDTO.getSnp());
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(1);
					table.addCell(cell);

					/*cell = new PdfPCell(new Phrase(pickingListDetailDTO.getQuantity() + "",cellFont));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(1);
					table.addCell(cell);*/
					
					cell = new PdfPCell(new Phrase(pickingListDetailDTO.getNoOfOpenQty() + "",cellFont));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(1);
					table.addCell(cell);

					cell = new PdfPCell(new Phrase(pickingListDetailDTO.getDevice(),cellFont));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(2);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase(pickingListDetailDTO.getWip() + "",cellFont));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(1);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase(pickingListDetailDTO.getRemainingActualQty() + "",cellFont));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(1);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase(pickingListDetailDTO.getEopMark(),cellFont));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(1);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase(pickingListDetailDTO.getStatus(),cellFont));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(1);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase(pickingListDetailDTO.getModel(),cellFont));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(2);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase(pickingListDetailDTO.getAllocation(),cellFont));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(1);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase(pickingListDetailDTO.getSupplierMethod(),cellFont));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(2);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase(pickingListDetailDTO.getLineStk(),cellFont));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(1);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase(pickingListDetailDTO.getLineLoc(),cellFont));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(1);
					table.addCell(cell);
					

					/*//cell = new PdfPCell(new Phrase(pickingListDetailDTO.getFormattedScanTime(),cellFont));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(3);
					table.addCell(cell);*/
					/*Added by Meena to reduce the font size and column size - end*/

				}
				paragraph.add(table);
				document.add(table);
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.PICKINGLIST_FETCH_SUCCESS, pickingListDetailsDTO);
				document.close();
			} else {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
						ServiceConstants.PICKINGLIST_FETCH_FAILURE, pickingListDetailsDTO);
			}
		} catch (Exception e) {
			LOGGER.error("Error when downloading PickingList: " + e.getMessage());
		}
		LOGGER.debug("Exiting downloadPickingList");
	}
	 //ADDED FOR UAT REQ TO PROVIDE SAVE AS OPTION FOR DOWNLOAD -END 

	public static PdfPCell createImageCell(String path) throws DocumentException, IOException {
		Image img = Image.getInstance(path);
		PdfPCell cell = new PdfPCell(img, true);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setFixedHeight(30);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		return cell;
	}

	/*
	 * Zone list
	 */
	/*@SuppressWarnings("unchecked")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/zones")
	public ServiceResponse<ZoneDTO> getZoneLists() {
		LOGGER.debug("Entering getZoneLists:: ");
		ServiceResponse<ZoneDTO> serviceResponse = null;
		List<ZoneDTO> zonesDTO = pickingList.getZoneList();
		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
				ServiceConstants.PICKINGLIST_FETCH_SUCCESS, zonesDTO);
		LOGGER.debug("Exiting getZoneLists:: ");
		return serviceResponse;
	}*/

	//ADDED FOR UAT REQ TO MERGE T&K SHOP DROP DOWN -START
		 @POST
		    @Produces(MediaType.APPLICATION_JSON)
		    @Path("/shopsByPlantId")
		    public ServiceResponse getShopsByPlant(String plantId) {
		        ServiceResponse serviceReponse = null;
		        List<PickinglistDTO> shops = null;
		        try {
		            shops = pickingList.getShopByPlantId(plantId);
		            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SHOP_FETCH_SUCCESS, shops);
		        } catch (Exception e) { 
		        	LOGGER.error("ShopService -- > getShopsByPlant  Exception : " , e);
		            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
		        }
		        LOGGER.debug("Fetching all the shop details");
		        return serviceReponse;
		    }
		 
		//ADDED FOR UAT REQ TO MERGE T&K SHOP DROP DOWN -END

		 @POST
		    @Produces(MediaType.APPLICATION_JSON)
		    @Path("/allocationByZone")
		    public ServiceResponse getAllocationList(String zone) {
		        ServiceResponse serviceReponse = null;
		        List<PickinglistDTO> shops = null;
		        try {
		            shops = pickingList.getAllocationByZone(zone);
		            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SHOP_FETCH_SUCCESS, shops);
		        } catch (Exception e) { 
	 	LOGGER.error("ShopService -- > getAllocationList  Exception : " , e);
		            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
		        }
		        LOGGER.debug("Fetching all the allocation details");
		        return serviceReponse;
		    }
		 
		 @POST
		    @Produces(MediaType.APPLICATION_JSON)
		    @Path("/zoneList")
		    public ServiceResponse getZoneList() {
		        ServiceResponse serviceReponse = null;
		        List<PickinglistDTO> zones = null;
		        try {
		        	zones = pickingList.getZoneList();
		            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SHOP_FETCH_SUCCESS, zones);
		        } catch (Exception e) { 
		        	LOGGER.error("ShopService -- > getZoneList  Exception : " , e);
		            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
		        }
		        LOGGER.debug("Fetching all the zone details");
		        return serviceReponse;
		    }
	
    //service to handy - start
	@SuppressWarnings("unchecked")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getLineAllocationAndroid")
	public ServiceResponse getLineAllocationAndroid(@QueryParam("plant") String plant,
			@QueryParam("shop") String shop) {
		LOGGER.debug("Entering getLineAllocationAndroid:: " + plant + " : " + shop);
		ServiceResponse serviceReponse = null;
		List<LineAllocationDTO> lineAllocationList = null;
		if (shop == null) {
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_PARAM_SHOP_MESSAGE);
			LOGGER.debug("Shop parameter is null");
		} else {
			lineAllocationList = pickingList.getLineAllocation(plant, shop);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
					ServiceConstants.SERVICE_RESPONSE_SUCCESS, lineAllocationList);
		}
		return serviceReponse;
	}
	
	@SuppressWarnings("unchecked")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getPickListDtlsAndroid")
	public PickListAndroidDTO getPickListDtlsAndroid(@QueryParam("plant") String plant,
			@QueryParam("line") String line, @QueryParam("shop") String shop,
			@QueryParam("allocation") String allocation, @QueryParam("pickingList") String pickList,
			@QueryParam("deviceID") String deviceID) {
		LOGGER.debug("Entering getPickListDtlsAndroid:: " + plant + " : " + shop);
		PickListAndroidDTO pickinglistResultsDTOList = new PickListAndroidDTO();
		if (shop != null) {
			pickinglistResultsDTOList = pickingList.getPickListDtlsAndroid(plant, line, shop, allocation, pickList,deviceID);
		}
		return pickinglistResultsDTOList;
	}
}
