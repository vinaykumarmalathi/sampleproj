package com.rnaipl.wms.service;

import java.util.List;

import javax.ejb.EJBException;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.Line;
import com.rnaipl.wms.dto.LineDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

/**
 * This Restful service class to process the requests from html and call the
 * respective EJB methods of Parts
 * 
 * 
 * @CreatedBy TechM
 * @CreatedOn 08-Apr-2016 10:25:44 am
 */
@Path("/lines")
@RequestScoped
public class LineService {

    private static final Logger LOGGER = Logger.getLogger(LineService.class);

    @Inject
    Line lineBean;

    /**
     * This method is used to fetch the all plant details from the table
     * 
     * @return List of Part
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/alllines")
    public ServiceResponse getAllShops() {
    	
        ServiceResponse serviceReponse = null;        
        List<LineDTO> lines = null;
        try {
            lines = lineBean.getAllLines();
            if(lines!=null && lines.size()>0){
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.BLANK_STATUS_MESSAGE, lines);
            }
            else{
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SHOP_FETCH_SUCCESS, lines);
            }
        } catch (Exception e) {
        	LOGGER.error("LineService -- > getAllShops() Exception : ",e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
        }
        return serviceReponse;
    }
    
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/linesByPlantId")
    public ServiceResponse getlinesByPlantId(String plantId) {
    	
        ServiceResponse serviceReponse = null;        
        List<LineDTO> lines = null;
        try {
        	lines = lineBean.getLineByPlantId(plantId);
            if(lines!=null && lines.size()>0){
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.BLANK_STATUS_MESSAGE, lines);
            }
            else{
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SHOP_FETCH_SUCCESS, lines);
            }
        } catch (Exception e) {
        	LOGGER.error("LineService -- > getAllShops() Exception : ",e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
        }
        return serviceReponse;
    }
}
