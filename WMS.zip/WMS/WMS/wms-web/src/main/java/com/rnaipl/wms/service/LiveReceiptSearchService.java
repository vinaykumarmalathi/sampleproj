package com.rnaipl.wms.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.LiveReceiptSearchBean;
import com.rnaipl.wms.dto.LiveReceiptInputDTO;
import com.rnaipl.wms.dto.LiveReceiptQtyMismatchDTO;
import com.rnaipl.wms.dto.LiveReceiptsSearchDTO;
/*AJ00482484 : LIVE Receipt Change : START*/
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

@Path("/liveReceipt")
public class LiveReceiptSearchService {
	private static final Logger LOGGER = Logger.getLogger(LiveReceiptSearchService.class);
	
	@Inject
	LiveReceiptSearchBean liveReceiptSearch;	
		
	@POST
    @Produces(MediaType.APPLICATION_XML)
    @Path("/getAllLiveReceipts")
	public List<LiveReceiptsSearchDTO> getAllLiveReceipts(){
		LOGGER.debug("In LiveReceiptSearchService service entry");
		List<LiveReceiptsSearchDTO> liveReceiptSearchList = new ArrayList<LiveReceiptsSearchDTO>();
		try {			
			liveReceiptSearchList = liveReceiptSearch.getAllLiveReceipts();			
			if(!liveReceiptSearchList.isEmpty()	|| liveReceiptSearchList.size() > 0){
				LOGGER.debug("Live Receipt List Data == "+liveReceiptSearchList);				
			}else{
				LOGGER.debug("**** No Data Found ****");
			}
			LOGGER.debug("*In LiveReceiptSearchService service exit");
			
		}catch (Exception ex) {
			LOGGER.error("LiveReceiptSearchService -- > getAllLiveReceipts()  Exception : " , ex);
		}		
		return liveReceiptSearchList;
	}
	
	
	/*@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getAllLiveReceiptsAndroid")
	public List<LiveReceiptsSearchDTO> getAllLiveReceiptsAndroid(){
		LOGGER.debug("In LiveReceiptSearchService service entry");
		List<LiveReceiptsSearchDTO> liveReceiptSearchList = new ArrayList<LiveReceiptsSearchDTO>();
		try {			
			liveReceiptSearchList = liveReceiptSearch.getAllLiveReceipts();			
			if(!liveReceiptSearchList.isEmpty()	|| liveReceiptSearchList.size() > 0){
				LOGGER.debug("Live Receipt List Data == "+liveReceiptSearchList);				
			}else{
				LOGGER.debug("**** No Data Found ****");
			}
			LOGGER.debug("*In LiveReceiptSearchService service exit");
			
		}catch (Exception ex) {
			LOGGER.error("LiveReceiptSearchService -- > getAllLiveReceipts()  Exception : " , ex);
		}		
		return liveReceiptSearchList;
	}*/

	
	@POST
    @Produces(MediaType.APPLICATION_XML)
	@Consumes(MediaType.APPLICATION_XML)
    @Path("/getLiveReceiptsByRan")
	public List<LiveReceiptsSearchDTO> getLiveReceiptByRAN(LiveReceiptInputDTO inputDto){
		LOGGER.debug("In LiveReceiptSearchService getLiveReceiptByRAN service entry");
		LOGGER.debug("Live Receipt Search Parameter == "+inputDto);
		LOGGER.debug("Live Receipt Search Parameter RAN == "+inputDto.getRan());
		LOGGER.debug("Live Receipt Search Parameter SHOP == "+inputDto.getShop());
		LOGGER.debug("Live Receipt Search Parameter PLANT == "+inputDto.getPlant());		
		List<LiveReceiptsSearchDTO> liveReceiptSearchList = new ArrayList<LiveReceiptsSearchDTO>();
		try {			
			liveReceiptSearchList = liveReceiptSearch.getLiveReceiptsByRAN(inputDto);			
			if(!liveReceiptSearchList.isEmpty()	|| liveReceiptSearchList.size() > 0){
				LOGGER.debug("getLiveReceiptByRAN Live Receipt List Data == "+liveReceiptSearchList);
			}else{
				LOGGER.debug("**** No Data Found ****");
			}
			LOGGER.debug("*In LiveReceiptSearchService getLiveReceiptByRAN service exit");			
		}catch (Exception ex) {
			LOGGER.error("LiveReceiptSearchService -- > getLiveReceiptByRAN()  Exception : " , ex);
		}		
		return liveReceiptSearchList;
	}
	
	
	@POST
    @Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
    @Path("/getLiveReceiptsByRanAndroid")
	public List<LiveReceiptsSearchDTO> getLiveReceiptByRANAndroid(LiveReceiptInputDTO inputDto){
		LOGGER.debug("In LiveReceiptSearchService getLiveReceiptByRAN service entry");
		LOGGER.debug("Live Receipt Search Parameter == "+inputDto);
		LOGGER.debug("Live Receipt Search Parameter RAN == "+inputDto.getRan());
		LOGGER.debug("Live Receipt Search Parameter SHOP == "+inputDto.getShop());
		LOGGER.debug("Live Receipt Search Parameter PLANT == "+inputDto.getPlant());		
		List<LiveReceiptsSearchDTO> liveReceiptSearchList = new ArrayList<LiveReceiptsSearchDTO>();
		try {			
			liveReceiptSearchList = liveReceiptSearch.getLiveReceiptsByRAN(inputDto);			
			if(!liveReceiptSearchList.isEmpty()	|| liveReceiptSearchList.size() > 0){
				LOGGER.debug("getLiveReceiptByRAN Live Receipt List Data == "+liveReceiptSearchList);
			}else{
				LOGGER.debug("**** No Data Found ****");
			}
			LOGGER.debug("*In LiveReceiptSearchService getLiveReceiptByRAN service exit");			
		}catch (Exception ex) {
			LOGGER.error("LiveReceiptSearchService -- > getLiveReceiptByRAN()  Exception : " , ex);
		}		
		return liveReceiptSearchList;
	}
	
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getLiveReceiptQtyMismatchList")
    public ServiceResponse getLiveReceiptQtyMismatchList(LiveReceiptQtyMismatchDTO lrQtyMismatchDto) {
    	
		LOGGER.debug("**IN voking Service ->getLiveReceiptQtyMismatchList() --> entry");
        ServiceResponse serviceReponse = null;
        List<LiveReceiptQtyMismatchDTO> lrQtyMismatch = null;
        try {
        	if(lrQtyMismatchDto!=null && lrQtyMismatchDto.getPartNumber()!=null && !lrQtyMismatchDto.getPartNumber().trim().equals("")){        		
        		List<String> partList = Arrays.asList(lrQtyMismatchDto.getPartNumber().split(","));
        		lrQtyMismatchDto.setPartList(partList);
        	}
        	LOGGER.debug("getLiveReceiptQtyMismatchList == Part Number Search List == "+lrQtyMismatchDto.getPartList());
        	if(lrQtyMismatchDto!=null && lrQtyMismatchDto.getRan()!=null && !lrQtyMismatchDto.getRan().trim().equals("")){        		
        		List<String> ranList = Arrays.asList(lrQtyMismatchDto.getRan().split(","));
        		lrQtyMismatchDto.setRanList(ranList);
        	}
        	LOGGER.debug("getLiveReceiptQtyMismatchList == RAN Search List == "+lrQtyMismatchDto.getRanList());
        	
        	lrQtyMismatch = liveReceiptSearch.getLiveReceiptQtyMismatchSearch(lrQtyMismatchDto);
            if(lrQtyMismatch!=null && lrQtyMismatch.size()>0){
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, lrQtyMismatch);
            }
            else{
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND, lrQtyMismatch);
            }
        } catch (Exception e) {
        	LOGGER.error("Get RAN List : ",e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
        }
        return serviceReponse;
    }
	
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getLiveReceiptQtyMismatchListCount")
    public ServiceResponse getLiveReceiptQtyMismatchListCount(LiveReceiptQtyMismatchDTO lrQtyMismatchDto) {
    	
		LOGGER.debug("**Invoking Service ->getLiveReceiptQtyMismatchListCount() --> entry");
        ServiceResponse serviceReponse = null;
        List<LiveReceiptQtyMismatchDTO> lrQtyMismatch = null;
        try {
        	if(lrQtyMismatchDto!=null && lrQtyMismatchDto.getPartNumber()!=null && !lrQtyMismatchDto.getPartNumber().trim().equals("")){        		
        		List<String> partList = Arrays.asList(lrQtyMismatchDto.getPartNumber().split(","));
        		lrQtyMismatchDto.setPartList(partList);
        	}
        	LOGGER.debug("getLiveReceiptQtyMismatchList == Part Number Search List == "+lrQtyMismatchDto.getPartList());
        	if(lrQtyMismatchDto!=null && lrQtyMismatchDto.getRan()!=null && !lrQtyMismatchDto.getRan().trim().equals("")){        		
        		List<String> ranList = Arrays.asList(lrQtyMismatchDto.getRan().split(","));
        		lrQtyMismatchDto.setRanList(ranList);
        	}
        	LOGGER.debug("getLiveReceiptQtyMismatchList == RAN Search List == "+lrQtyMismatchDto.getRanList());
        	
        	//lrQtyMismatch = liveReceiptSearch.getLiveReceiptQtyMismatchSearch(lrQtyMismatchDto);
        	
        	int noOfRecords = liveReceiptSearch.getLiveReceiptQtyMismatchListCount(lrQtyMismatchDto);
        	
        	if (noOfRecords > 0) {
        		serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.PARTS_FETCH_SUCCESS,
						noOfRecords);
			} else {
				serviceReponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			}
        	LOGGER.debug("**Service ->getLiveReceiptQtyMismatchListCount() --> exit");
        } catch (Exception e) {
        	LOGGER.error("Get RAN List : ",e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
        }
        return serviceReponse;
    }
	
	
}
/*AJ00482484 : LIVE Receipt Change : END*/
