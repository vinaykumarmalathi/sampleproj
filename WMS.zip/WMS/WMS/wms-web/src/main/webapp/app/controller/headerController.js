wmsApp.controller('headerController', [ '$scope', '$location', '$routeParams','$window','$rootScope','commonService',
        function($scope,$location,$routeParams,$window,$rootScope,commonService) {
	$scope.wmsUser = $window.sessionStorage.getItem('wmsUser');
	$(document).ready(function(){
	    $('[data-toggle="popover"]').popover({html:true,placement:'bottom',trigger: "focus"});
	    
	    $(document).click(function(e){
	    	if(e.target.id == "signOut")
	    	logOut();
	    });
	});
	
	$scope.backToHome = function(){
		$scope.loggedUserId = $window.sessionStorage.getItem('loggedUserId');		
		$scope.loggedUserName = $window.sessionStorage.getItem('loggedUserName');
		
		commonService.redirectToHome($scope.loggedUserId).then(function(response){
			
			if(response.data.statusType=='success')
		  	{
				$rootScope.isEnableStockCorrection=false;
				$rootScope.isAuthendicated=false;
				localStorage.clear();
				sessionStorage.clear();
				$scope.userId = unescape(response.data.object.userId);
				$scope.userName = $scope.loggedUserName;
				$scope.validUntil = response.data.object.validUntil;
				$scope.key = response.data.object.encryptedKey;
				$window.sessionStorage.setItem('permitToLog','Yes');
				$window.open('/pcs/#/home?userId='+$scope.userId+'&userName='+$scope.userName+'&validUntil='+$scope.validUntil+'&key='+$scope.key,'_self');
		  	}
		});
	};
    
    function logOut(){
	   localStorage.clear();
	   sessionStorage.clear();
 	   $window.open('/pcs/#/login','_self');
    };
	
} ]);