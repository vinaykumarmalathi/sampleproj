var wmsApp = angular.module('wmsApp', ['ngSanitize', 'ngCsv','ngRoute','ui.grid', 'ui.grid.selection', 'ui.grid.treeView', 'ui.grid.exporter', 'ui.grid.pagination', 'ngResource', 'ui.bootstrap','ui.grid.importer','LocalStorageModule','ngTagsInput','directives','ui.grid.autoResize', 'ui.grid.pinning','ui.grid.resizeColumns','ui.grid.edit','ui.grid.cellNav','autocomplete']);
//var wmsApp = angular.module('wmsApp', ['ngRoute','ui.grid', 'ui.grid.selection', 'ui.grid.treeView', 'ui.grid.exporter', 'ui.grid.pagination', 'ngResource', 'ui.bootstrap','ui.grid.importer','LocalStorageModule','ngTagsInput','directives','ui.grid.autoResize','ui.grid.cellNav', 'ui.grid.pinning', 'ui.grid.moveColumns']);

wmsApp.config([ '$routeProvider', '$httpProvider','$locationProvider','validateLoginProvider', function($routeProvider, $httpProvider,$locationProvider,validateLoginProvider) {
    $httpProvider.defaults.cache = false;
    if (!$httpProvider.defaults.headers.get) {
        $httpProvider.defaults.headers.get = {};
    }
    var version='2.0';
   // var home='app/partials/home.html?version='+version;
    var check  =  true;
    // disable IE ajax request caching
    $httpProvider.defaults.headers.get['If-Modified-Since'] = '0';
    
    $routeProvider.when('/home', {
    	templateUrl : function(){
        	if(validateLoginProvider.checkLoginStatus() == "success"){
        		return 'app/partials/home.html?version='+version;
        	}
        }
    }).when('/partLocation', {
        templateUrl : function(){
        	if(validateLoginProvider.checkLoginStatus() == "success" && validateLoginProvider.checkMenuStatus('#/partLocation') == true){
        		return 'app/partials/partsLocationTracker.html?version='+version;
        	} 
        },
       	 resolve : {
          	"checkRedirect":function(checkRedirect){
          		if(validateLoginProvider.checkMenuStatus('#/partLocation') == false){
          			checkRedirect.menuRedirect();
         		}
          	}
        },
        controller : 'partLocationTrackerController'
    }).when('/login', {
        template : '',
        controller : 'loginController',
        resolve :{
        	"checkRedirect":function(checkRedirect){
        		checkRedirect.loginRedirect();
        	}
        }
    }) .when('/fileUpload', {
    	templateUrl : function(){
        	if(validateLoginProvider.checkLoginStatus() == "success" && validateLoginProvider.checkMenuStatus('#/fileUpload') == true){
        		return 'app/partials/partsInOutUpload.html?version='+version;
        	}
    	},
      	 resolve : {
         	"checkRedirect":function(checkRedirect){
         		if(validateLoginProvider.checkMenuStatus('#/fileUpload') == false){
         			checkRedirect.menuRedirect();
        		}
         	}
        },
        controller : 'partsInOutUploadController'
    }).when('/stockCorrection', {
    	templateUrl : function(){
        	if(validateLoginProvider.checkLoginStatus() == "success" && validateLoginProvider.checkMenuStatus('#/stockCorrection') == true){
        		return 'app/partials/stockCorrection.html?version='+version;
        	}
    	},
     	 resolve : {
        	"checkRedirect":function(checkRedirect){
        		if(validateLoginProvider.checkMenuStatus('#/stockCorrection') == false){
        			checkRedirect.menuRedirect();
        		}
        	} 
        },
        controller : 'stockCorrectionController'
    }).when('/auditByLocation', {
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success"){
        		return 'app/partials/parts-audit-by-location.html?version='+version;
        	}
    	},
        controller : 'partsAuditByLocationController'
    }).when('/partInOutError', {
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success" && validateLoginProvider.checkMenuStatus('#/partInOutError') == true){
        		return 'app/partials/part-in-out-error.html?version='+version;
        	}
    	},
	    resolve : {
	   		 "checkRedirect":function(checkRedirect){
	       		if(validateLoginProvider.checkMenuStatus('#/partInOutError') == false){
	       			checkRedirect.menuRedirect();
	       		}
	   		 } 
    	
        },
        controller : 'partInOutErrorController',
    }).when('/partsMaster', {
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success" ){
        		return 'app/partials/parts-master.html?version='+version;
        	}
        },
        controller : 'partsMasterController',
    }).when('/auditTrialDetails', {
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success" && validateLoginProvider.checkMenuStatus('#/auditTrialDetails') == true){
        		return 'app/partials/audit-trial-details.html?version='+version;
        	}
    	},
    	 resolve : {
	   		 "checkRedirect":function(checkRedirect){
	       		if(validateLoginProvider.checkMenuStatus('#/auditTrialDetails') == false){
	       			checkRedirect.menuRedirect();
	       		}
	   		 }
        },
        controller : 'auditTrialDetailsController',
    }).when('/locationMaster', {
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success" && validateLoginProvider.checkMenuStatus('#/locationMaster') == true){
        		return 'app/partials/location-master.html?version='+version;
        	}
    	},
    	 resolve : {
	   		 "checkRedirect":function(checkRedirect){
	       		if(validateLoginProvider.checkMenuStatus('#/locationMaster') == false){
	       			checkRedirect.menuRedirect();
	       		}
	   		 }
        },
        controller : 'locationMasterController',
    }).when('/linefeedingdetails', {
    	 templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success"){
    		     		return 'app/partials/LineFeedingDetails.html?version='+version;
    		    	}
    		     },
         controller : 'LineFeedingDetailsController',
    }).when('/masterlinefeeding', {
   	 templateUrl : function(){
   		if(validateLoginProvider.checkLoginStatus() == "success"){
   		     		return 'app/partials/MasterScreenDetails.html?version='+version;
   		    	}
   		     },
        controller : 'MasterScreenDetailsController',
    }).when('/testModule', {
      	 templateUrl : function(){
        		if(validateLoginProvider.checkLoginStatus() == "success"){
        		     		return 'app/partials/StockCorrectionAdd.html?version='+version;
        		    	}
        		     },
             controller : 'StockCorrectionAddController',
    }).when('/zonewiseConsumption', {
    	 templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success"){
    		     		return 'app/partials/ZonewiseConsumption.html?version='+version;
    		    	}
    		     },
         controller : 'ZonewiseConsumptionController',
    }).when('/partsMasterData', {
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success" && validateLoginProvider.checkMenuStatus('#/partsMasterData') == true){
        		return 'app/partials/partsMasterData.html?version='+version;
        	}
    	},
    	 resolve : {
	   		 "checkRedirect":function(checkRedirect){
	       		if(validateLoginProvider.checkMenuStatus('#/partsMasterData') == false){
	       			checkRedirect.menuRedirect();
	       		}
	   		 }
        },
        controller : 'partsMasterDataController',
    })
    .when('/agingRAN', {
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success" && validateLoginProvider.checkMenuStatus('#/agingRAN') == true){
        		return 'app/partials/AgingAndAgedRan.html?version='+version;
        	}
    	},
    	 resolve : {
	   		 "checkRedirect":function(checkRedirect){
	       		if(validateLoginProvider.checkMenuStatus('#/agingRAN') == false){
	       			checkRedirect.menuRedirect();
	       		}
	   		 }
    		
        },
        controller : 'AgingAndAgedRanController',
    })
    .when('/duplicateRAN', {
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success" && validateLoginProvider.checkMenuStatus('#/duplicateRAN') == true){
        		return 'app/partials/duplicateRAN.html?version='+version;
        	}
    	},
    	 resolve : {
	   		 "checkRedirect":function(checkRedirect){
	       		if(validateLoginProvider.checkMenuStatus('#/agingRAN') == false){
	       			checkRedirect.menuRedirect();
	       		}
	   		 }
        },
        controller : 'duplicateRANController',
    })
    .when('/Fifo', {
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success" && validateLoginProvider.checkMenuStatus('#/Fifo') == true){
        		return 'app/partials/FIFO.html?version='+version;
        	}
    	},
    	 resolve : {
	   		 "checkRedirect":function(checkRedirect){
	       		if(validateLoginProvider.checkMenuStatus('#/Fifo') == false){
	       			checkRedirect.menuRedirect();
	       		}
	   		 }
        },
        controller : 'FifoController',
    }).when('/ranUpload',{
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success" && validateLoginProvider.checkMenuStatus('#/ranUpload') == true){
    			return 'app/partials/RanUpload.html?version='+version;
    		}
    	},
	   	 resolve : {
		   		 "checkRedirect":function(checkRedirect){
		       		if(validateLoginProvider.checkMenuStatus('#/ranUpload') == false){
		       			checkRedirect.menuRedirect();
		       		}
		   		 }
    	},
    	controller : 'RanUploadController',
    })
//    .when('/masterlinefeeding',{
//    	templateUrl : function(){
//    		if(validateLoginProvider.checkLoginStatus() == "success" && validateLoginProvider.checkMenuStatus('#/masterlinefeeding') == true){
//    			return 'app/partials/MasterScreenDetails.html?version='+version;
//    		}
//    	},
//	   	 resolve : {
//		   		 "checkRedirect":function(checkRedirect){
//		       		if(validateLoginProvider.checkMenuStatus('#/masterlinefeeding') == false){
//		       			checkRedirect.menuRedirect();
//		       		}
//		   		 }
//    	},
//    	controller : 'MasterScreenDetailsController',
//    })
    /*.when('/ranData',{
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus()==true){
    			return 'app/partials/ranData.html';
    		}
    	},
    	controller : 'ranController',
    })
	*/.when('/agedAudit',{
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success" && validateLoginProvider.checkMenuStatus('#/agedAudit') == true){
    			return 'app/partials/agedAudit.html?version='+version;
    		}    	
    	},
   	   	 resolve : {
	   		 "checkRedirect":function(checkRedirect){
	       		if(validateLoginProvider.checkMenuStatus('#/agedAudit') == false){
	       			checkRedirect.menuRedirect();
	       		}
	   		 }
    	},
    	controller : 'agedAuditController',
    }).when('/tagSheet',{
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success" && validateLoginProvider.checkMenuStatus('#/tagSheet') == true){
    			return 'app/partials/TagSheet.html?version='+version;
    		}
    	 },
         resolve : {
         	"checkRedirect":function(checkRedirect){
         		if(validateLoginProvider.checkMenuStatus('#/tagSheet') == false){
         			checkRedirect.menuRedirect();
        		}
         	}
    	},
    	controller : 'tagSheetController',
    }).when('/menu',{
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success" && validateLoginProvider.checkMenuStatus('#/menu') == true){
    			return 'app/partials/userMenu.html?version='+version;
    		}
    	 },
    	 resolve : {
         	"checkRedirect":function(checkRedirect){
         		if(validateLoginProvider.checkMenuStatus('#/menu') == false){
         			checkRedirect.menuRedirect();
        		}
         	}
    	},
    	controller : 'userMenuController',
    }).when('/FIFOSuggestionOverride',{
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success" && validateLoginProvider.checkMenuStatus('#/FIFOSuggestionOverride') == true){
    			return 'app/partials/FIFOSuggestionOverride.html?version='+version;
    		}
    	},
      	   	 resolve : {
    	   		 "checkRedirect":function(checkRedirect){
    	       		if(validateLoginProvider.checkMenuStatus('#/FIFOSuggestionOverride') == false){
    	       			checkRedirect.menuRedirect();
    	       		}
    	   		 }
    	},
    	controller : 'FIFOSuggestionOverrideController',
    })
    .when('/ranMaster',{
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success" && validateLoginProvider.checkMenuStatus('#/ranMaster') == true){
    			return 'app/partials/ranmaster.html?version='+version;
    		}
    	},
      	   	 resolve : {
    	   		 "checkRedirect":function(checkRedirect){
    	       		if(validateLoginProvider.checkMenuStatus('#/ranMaster') == false){
    	       			checkRedirect.menuRedirect();
    	       		}
    	   		 }
    	},
    	controller : 'ranMasterController',
    	
    }).when('/liveReceiptQuantityMismatch',{
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success" && validateLoginProvider.checkMenuStatus('#/liveReceiptQuantityMismatch') == true){
    			return 'app/partials/liveReceiptQuantityMismatch.html?version='+version;
    		}
    	},
      	   	 resolve : {
    	   		 "checkRedirect":function(checkRedirect){
    	       		if(validateLoginProvider.checkMenuStatus('#/liveReceiptQuantityMismatch') == false){
    	       			checkRedirect.menuRedirect();
    	       		}
    	   		 }
    	},
    	controller : 'liveReceiptQuantityMismatchController',
    }).when('/reviewerList',{
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success") {
    			return 'app/partials/reviewerList.html?version='+version;
    		}
    	},
    	controller : 'reviewerListController',
    }).when('/creationPage',{
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success"){
    			return 'app/partials/formRequirementCreate.jsp?version='+version;
    		}
    	},
    	controller : 'formRequirementCreateController',
    }).when('/searchPage',{
    	templateUrl : function(){
    		console.log(validateLoginProvider.checkLoginStatus())
    		console.log(validateLoginProvider.checkMenuStatus('#/searchPage'))
    		if(validateLoginProvider.checkLoginStatus() == "success"){
    			return 'app/partials/formRequirementSearch.html?version='+version;
    		}
    	},
    	controller : 'formRequirementSearchController',
    })
    .when('/missingPart',{
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus() == "success" && validateLoginProvider.checkMenuStatus('#/missingPart') == true){
    			return 'app/partials/missingParts.html?version='+version;
    		}
    	},
      	   	 resolve : {
    	   		 "checkRedirect":function(checkRedirect){
    	       		if(validateLoginProvider.checkMenuStatus('#/missingPart') == false){
    	       			checkRedirect.menuRedirect();
    	       		}
    	   		 }
    	},
    	controller : 'missingPartsController',
    })
    .when('/pitTransactionReport',{
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus()=="success"){
    			return 'app/partials/pitTransactionReport.html?version='+version;
    		}
    	},
    	controller : 'pitTransactionReportController',
    })
    .when('/pitCumulativeReport',{
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus()=="success"){
    			return 'app/partials/pitCumulativeReport.html?version='+version;
    		}
    	},
    	controller : 'pitCumulativeReportController',
    })
    .otherwise({
        redirectTo : '/home'
    })
    
    
    //wms shortage alarm start
     .when('/shortageAlarm',{
    	templateUrl : function(){
    		if(validateLoginProvider.checkLoginStatus()=="success"){
    			return 'app/partials/shortageAlarm.html?version='+version;
    		}
    	},
    	controller : 'shortageAlarmController',
    })
    .otherwise({
        redirectTo : '/home'
    });
    //wms shortage alarm end
    
}]);


wmsApp.controller('wmsRootController',[ '$scope','$window', '$location', '$http','commonService','$rootScope',
		       function($scope,$window, $location, $http,commonService,$rootScope) {
	
		$rootScope.$on('$routeChangeStart', function() {
			if($window.sessionStorage.getItem('appLoggedIn') =='success'){
				$rootScope.isAuthendicated=true;
			}
        });	
		$scope.isActive = function(route) {
		       return route === $location.path();
		   };
		$scope.blockUI = function() { 
		$.blockUI({ message: '<h2>In progress please wait .. </h2><img src="app/assets/img/loading.gif" style="height:auto;width:auto;"/>',
		  centerX: true,
		   centerY: true,
		   css: {
		       width: '300px',
		       height: '300px',
		       border: 'none',
		       backgroundColor: 'none',
		       color: '#fff',
		       top:'30%',
		   }
		});
		                
		   };
		   
	   $scope.stockCorrectionReasons='';	   
}]);

wmsApp.factory('checkRedirect', function($location,$window,$rootScope,appLoginService,redirectToParent) {
    return {
    	loginRedirect : function() {
    		
    		var searchObject = $location.search();
    		
    		if(searchObject.userId != "null" && searchObject.key != "null" && searchObject.userId != undefined && searchObject.key != undefined ){
	    	    var loginCredential = {"userId":searchObject.userId,"encryptedKey":searchObject.key,"validUntil":searchObject.validUntil};
	    	    var rolesPrivilegeArray = [];
	    	    $window.sessionStorage.setItem('loggedUserId',searchObject.userId.toUpperCase()); 
	    	    // Getting role privilege list from external Json file 
	    	    appLoginService.rolesPrivilegeService().success(function(response){
	    	    	console.log("list");
	    	    	console.log(response.objectList);
	    	    	if(response.objectList !== null){
	    	    		rolesPrivilegeArray = response.objectList;
	    	    		/*angular.forEach(response.objectList,function(key,value){*/
	    	    			//rolesPrivilegeArray.push(response.objectList);
	    	    			//console.log(rolesPrivilegeArray);
	    	    		//});
	    	    	}
	    	    	
	    	    	// User Authentication check
	    	    	appLoginService.loginToApp(loginCredential).success(function(response){					 
	    	    		
	    	    		if(response.statusType == "success"){
	    	    			$window.sessionStorage.setItem('loggedUserId',searchObject.userId.toUpperCase());
	    	    			$window.sessionStorage.setItem('loggedUserName',searchObject.userName);
	    	    			$rootScope.isAuthendicated=true;
	    	    			if ($.inArray(searchObject.userId.toUpperCase(), rolesPrivilegeArray) > -1)
	    	    			{			
	    	    				$rootScope.isEnableStockCorrection=true;
	    	    				$window.sessionStorage.setItem('isEnableStockCorrection','yes');
	    	    				//$window.location.reload();
	    	    				
	    	    			}
	    	    			$window.sessionStorage.setItem('appLoggedIn',"success");
	    	    			$window.sessionStorage.setItem('wmsUser',searchObject.userName);
	    	    			$location.path('/home/');	
	    	    		}else{
	    	    			redirectToParent.url();
	    	    		}
	    	    	}).error(function(err) {
	    	    		console.log("Error in WMS APP Login",err);
	    	    		redirectToParent.url();
	    	    	});	
	    	    	
	    	    }).error(function(err) {
					  console.log("Error in Role Privilege service",err);
					  redirectToParent.url();
			    }); 
    		}else{
    			redirectToParent.url();
    		}
        },
    menuRedirect : function() {
    	$location.path('/home/');
    }
    };
});

wmsApp.service('redirectToParent',function($window,$rootScope){
	this.url = function(){
		$window.sessionStorage.setItem('appLoggedIn',null);
		$rootScope.isEnableStockCorrection=false;
		$rootScope.isAuthendicated=false;
		localStorage.clear();
		sessionStorage.clear();
		$window.open('/pcs/#/login?appName=WMS','_self');
	};
});

wmsApp.provider('validateLogin',function($windowProvider){
	 var loginMsg;
	 var userMenu;
	 var userMenuArr = [];
	 return {
	       checkLoginStatus : function() {
	    	   var $window = $windowProvider.$get();
	    	  
	    	   loginMsg = $window.sessionStorage.getItem('appLoggedIn');
			   if($window.sessionStorage.getItem('appLoggedIn') !='success'){   
					$window.sessionStorage.setItem('appLoggedIn',null);
					$window.open('/pcs/#/login?appName=WMS','_self');
			   }
			   return loginMsg;
			 
	       },
	       checkMenuStatus : function(data){
	    	   var count = 0;
	    	   var $window = $windowProvider.$get();
	    	   userMenu = $window.sessionStorage.getItem('userMenu');
	    	   if(data != '#/home' && userMenu != null){
	    		   userMenuArr = userMenu.split(',');
	    	   }
	    	   
	    	   if(data == '#/home'){
	    		   return true;
	    	   }else if(userMenu != null){
		    	   for (var i = 0; i < userMenuArr.length; i++) {
		    		   console.log("userMenu ",userMenuArr);
		    	        if (userMenuArr[i] === data) {
		    	        	count++;
		    	        	console.log("count ",count);
		    	        }
		    	    }
		    	   if(count == 0){
		    		   console.log("false");
		    		   return false;
		    	   }else{
		    		   console.log("true");
		    		   return true;
		    	   }
	    	   }else{
	    		   console.log("final else");
				   return false;
			   }
	       },
		   $get: function () {
			   
		   }
	    };
	    
});