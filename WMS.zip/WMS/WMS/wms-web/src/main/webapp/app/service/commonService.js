var wmsApp = angular.module('wmsApp');

wmsApp.factory('commonService',function($http){
	
	var commonService = {};
	commonService.callRestService= function(methodType, methodUrl, params)
	{
		return $http({
			method : methodType,
			url : methodUrl,
			data : JSON.stringify(params),
			headers: {'Content-Type': 'application/json'}
		});
	};
	
	commonService.getAllShop= function()
	{
		var serviceURL = 'rest/shops/allshops';
		var serviceType ='GET';
		var params='';
		
		return $http({
			method : serviceType,
			url : serviceURL,
			data : JSON.stringify(params),
			headers: {'Content-Type': 'application/json'}
		});
	};
	
	commonService.getShopList = function(param){
		 return $http({
				method : 'POST',
				url : 'rest/shops/shopsByPlantId',			
				data : param,
				headers: {'Content-Type': 'application/json'}
		 }).success(function (data) {
				return data;
		 });
	};
	
	
	commonService.getLineList = function(param){
		 return $http({
				method : 'POST',
				url : 'rest/lines/linesByPlantId',			
				data : param,
				headers: {'Content-Type': 'application/json'}
		 }).success(function (data) {
				return data;
		 });
	};
	
	commonService.getAllPlants= function()
	{
		var serviceURL = 'rest/plants/allplants';
		var serviceType ='GET';
		var params='';
		
		return $http({
			method : serviceType,
			url : serviceURL,
			data : JSON.stringify(params),
			headers: {'Content-Type': 'application/json'}
		});
	};
	
	commonService.getAllSections= function()
	{
		var serviceURL = 'rest/sections/allsections';
		var serviceType ='GET';
		var params='';
		
		return $http({
			method : serviceType,
			url : serviceURL,
			data : JSON.stringify(params),
			headers: {'Content-Type': 'application/json'}
		});
	};
	
	
	commonService.getAllLines= function()
	{
		var serviceURL = 'rest/lines/alllines';
		var serviceType ='GET';
		var params='';
		
		return $http({
			method : serviceType,
			url : serviceURL,
			data : JSON.stringify(params),
			headers: {'Content-Type': 'application/json'}
		});
	};
	
	commonService.redirectToHome = function(param){
		 return $http({
				method : 'POST',
				url : 'rest/login/redirectToHome',			
				data : param,
				headers: {'Content-Type': 'application/json'}
		 }).success(function (data) {
				return data;
		 });
	};
	
	return commonService;
});
wmsApp.factory('Location', function(){
    return { location: '',
    		 partNumber:'',
    		 mappedLocations:''	 
    	   };
});
wmsApp.factory('PartNumberInterService', function(){
    return { partNumber: '' };
});
wmsApp.factory('RemarksInterService', function(){
    return { partNumber: '',
    	     remarks:''
    };
});
