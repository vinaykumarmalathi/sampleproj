var wmsApp = angular.module('wmsApp');

wmsApp.factory('userMenuService',['$http',function($http){
    var fact={};
    
    fact.getUserMenus=function(data)
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/userMenu/getUserMenus',	
			data : data,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function () {				
		});
	};
	
	fact.addUserMenu=function(data){
		console.log("service",data)
		return $http({
			method : 'POST',
			url : 'rest/userMenu/mapUserMenu',	
			data : data,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function () {
			
		});
	};
	 return fact;
}]);