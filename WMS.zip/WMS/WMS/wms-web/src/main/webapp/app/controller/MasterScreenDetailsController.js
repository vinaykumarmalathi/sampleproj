wmsApp.controller('MasterScreenDetailsController', [ '$scope', '$window', '$filter', '$location', '$q', 'masterScreenDetailsService', 'uiGridTreeViewConstants', '$http', 
	'commonService', function($scope, $window, $filter, $location, $q, masterScreenDetailsService, uiGridTreeViewConstants, $http, commonService) {
	
	$scope.searchDataEror = "Click search to fetch records.";
	$scope.beginDate = new Date();
	$scope.endDate = new Date();
	$scope.dateCurr = new Date();
	$scope.pickListnumberSelected = null;
	$scope.printableList = [];
	$scope.selectedValue = [];
	$scope.refresh = true;
	$scope.masterScreenDetailsDetailsDTO = [];
	$scope.isBeginDateChanged = false;
	$scope.snpTotal = 0;
	$scope.qtyTotal = 0;
	$scope.boxTotal = 0;
	$scope.fromMaxDate = new Date();
	$scope.shiftDropdown = false;
	$scope.todayDate = new Date();
	$scope.transactionList = [ "In", "Out" ];
	$scope.shiftList = [ "A", "B", "C" ];
	$scope.beginDatePickerOpen = false;
	$scope.endDatePickerOpen = false;
	$scope.endTimePickerOpen = false;
	$scope.beginTimePickerOpen = false;
	$scope.openBeginDatePicker = function($event) {
		$event.preventDefault();
		$event.stopPropagation();
		$scope.isBeginDateChanged = true;
		$scope.beginDatePickerOpen = !$scope.beginDatePickerOpen;
	};
	$scope.openEndDatePicker = function($event) {
		$event.preventDefault();
		$event.stopPropagation();
		$scope.endDatePickerOpen = !$scope.endDatePickerOpen;
	};
	
	
	// ---------dropdown start
	
	if($window.sessionStorage.getItem('locationDPCollection') == null || $window.sessionStorage.getItem('locationDPCollection')=='undefined' || $window.sessionStorage.getItem('locationDPCollection')==undefined){
		
		console.log("calling all palnts()");
		commonService.getAllPlants().success(function(response){					 
			  $scope.locations = response.objectList;				
			  $window.sessionStorage.setItem('locationDPCollection',JSON.stringify($scope.locations));
			 
			  console.log($scope.locations);
			  console.log("got all palnts locations object");
			  
		}).error(function(response){
			console.log("error while call all plants");
			console.log(response);
		});
		
	}else{
	  $scope.locations = JSON.parse(sessionStorage.locationDPCollection);
	}
	
	
	//load zone drop down on change event of plant
	$scope.getAllZones = function(){
		  console.log("calling getAllZones()");
		  
		  masterScreenDetailsService.getAllZones().success(function(response){
			  $scope.zones = response.objectList;
			  console.log($scope.zones);
			  console.log("got Zones list");
		  })
		  .error(function(response){
			  console.log("error while call all plants");
			  console.log(response);	  
		  });
	  };
	  
	  //loading all allocations
	  $scope.getAllAllocation = function(){
		  console.log("calling getAllAllocation()");
		  
		  masterScreenDetailsService.getAllocationList().success(function(response) {
			$scope.allocations = response.objectList;
			console.log($scope.allocations);
			  console.log("got Zones list");
		  }).error(function(response) {
			  console.log("error while call getAllAllocation");
			  console.log(response);
		  });  
	  };
	  
	//loading all allocations
	  $scope.getAllLines = function(){
		  console.log("calling getAllLines()");
		  
		  commonService.getAllLines().success(function(response){
			  
	   		 	$scope.lines = response.objectList;	
				console.log($scope.lines);
				  console.log("got lines object");
		   	 }).error(function(response){
					  console.log("error while calling all lines");
					  console.log(response);
		   	 }); 
	  };
	  
	  $scope.getAllShops = function(){
		  console.log("calling getAllShops()");
		  
		  commonService.getAllShop().success(function(response){
			  $scope.shops = response.objectList;
			  console.log($scope.shops);
			  console.log("got shops object");
		  }).error(function(response){
			  console.log("error while calling all shopslist");
			  console.log(response);
		  }); 
	  };
	  
	  $scope.getSuppliers = function(){
		  console.log("calling getSuppliers()");
		  $scope.supplier = ['KITTING','DIRECT','BULK'];
		  
		  //uncomment to load it from backend check properly
		  /*masterScreenDetailsService.getSupplier().success(function(response){
			  $scope.supplier = response.objectList;
			  console.log($scope.supplier);
			  console.log("got supplier object");
		  }).error(function(response){
			  console.log("error while calling all supplier");
			  console.log(response);
		  });
		  */
		  
	  };  
	  
	  $scope.getSubZones = function(){
		  console.log("calling getSubZones()");
		  $scope.subZone = ['KITTING','SYNCRO','DIRECT','FASTNER'];		  
	  };
	  
	  $scope.getStatus = function(){
		  console.log("calling getSuppliers()");
		  $scope.status = ['Open','Partial','Closed'];
	  };
	  
	  
	  // ---------dropdown end
	  $scope.partNumber="";
	  $scope.tags=[];
	    $scope.location = "";
		$scope.locationIdData = [];
		$scope.locationAdded = function(tag) {
			$scope.locationArray = [];
			for (var j = 0; j < $scope.locationIdData.length; j++) {
				$scope.locationArray.push($scope.locationIdData[j].text);
			}
			$scope.location = $scope.locationArray.join(',');
			$(".appViewDiv").css({
			    "height" : $(window).height() - 130,
			    "overflow" : "auto"
			});
		};
		/* ON REMOVE ADDED LOCATION TAG */
		$scope.locationRemoved = function(tag) {
			$scope.locationArray = [];
			for (var j = 0; j < $scope.locationIdData.length; j++) {
				$scope.locationArray.push($scope.locationIdData[j].text);
			}
			$scope.location = $scope.locationArray.join(',');
			$(".appViewDiv").css({
			    "height" : $(window).height() - 130,
			    "overflow" : "auto"
			});
		};
		
		$scope.loadLocation = function(query) {
	    	
	    	var locationInputObj = {"locationId": query};			    	
	    	return masterScreenDetailsService.locationList(locationInputObj).then(function(response){	
	    		 if(response.data.statusType=='success'){
	        		 if(response.data.object!='null' && response.data.object!=null){				        		
	        			  return response.data.object;                           
	        		 }
	        	 }else{
	        		
	        	 }			    		
	    	});			    				         
	    };
	  
	    $scope.loadParts = function(query) {
			var partInputObj = {
				"partNumber" : query
			};
			return masterScreenDetailsService.partNumberList(partInputObj).then(function(response) {
				if (response.data.statusType == 'success') {
					if (response.data.object != 'null' && response.data.object != null) {
						return response.data.object;
					}
				} else {
				}
			});
		};
		
		$scope.partNumber='';
		$scope.tags=[];
		$scope.tagAdded = function(tag) {
			  $scope.partArray = [];
			     for (var j=0; j < $scope.tags.length; j++) {
			    	 $scope.partArray.push($scope.tags[j].text);
			    	 console.log("Part Array",$scope.partArray);
			      }
			     $scope.partNumber=$scope.partArray.join(',');
			     console.log("Part Number",$scope.partNumber);
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
	    
	    $scope.addingTag = function(tag) {
			console.log("Tag.text", tag.text);
			tag.text = tag.text.replace(/ /g, ',');
			console.log("Tag.text 2", tag.text);
			return tag;
		};
		/* ON REMOVE ADDED PART TAG */
		$scope.tagRemoved = function(tag) {
			$scope.partArray = [];
			for (var j = 0; j < $scope.tags.length; j++) {
				$scope.partArray.push($scope.tags[j].text);
			}
			$scope.partNumber = $scope.partArray.join(',');
			$(".appViewDiv").css({
			    "height" : $(window).height() - 130,
			    "overflow" : "auto"
			});
		};
	  // ---------- grid start ------------
	  
	  $scope.master = {
			    partNumber : $scope.partNumber,
			    beginDate : $scope.beginDate,
			    endDate : $scope.endDate,
			    fromTime : $scope.beginTime,
			    toTime : $scope.endTime,
			    startIndex : 0,
			    endIndex : 0
		};
		
		var paginationOptions = {
		    startIndex : 0,
		    endIndex : 0,
		    pageNumber : 1,
		    pageSize : 100,
		    sort : null
		};
		// Grid
		$scope.gridOptions = {
		    enablePaginationControls : false,
		    enableGridMenu : true,
		    enableFiltering : true,
		    enableColumnResize : true,
		    paginationPageSizes : [ 100, 250, 500, 750, 1000 ],
		    paginationPageSize : 100,
		    useExternalPagination : true,
		    autoResize : true,
		    enableSorting : true,
		    enableColumnMenus : false,
		    enablePinning : true,
		    columnDefs : [ {
		        field : 'partNo',
		        displayName : 'Part Number',
		        cellTemplate: '<div class="ui-grid-cell-contents"><span class="details-link" data-toggle="modal" data-target="#printDetailsModal" ng-click="grid.appScope.openModalTable(row.entity,row.entity.partNo)">{{row.entity.partNo}}</span></div>',
		        minWidth: 130, 
		        width: 160, 
		        enableColumnResizing: true 
		    }, {
		        field : 'partType',
		        displayName : 'KD/LP',
		        minWidth: 56, 
		        width: 60, 
		        enableColumnResizing: true 
		    },{
		        field : 'supplier',
		        displayName : 'Supplier Name',
		        minWidth: 70, 
		        width: 80, 
		        enableColumnResizing: true
		    },{
		        field : 'model',
		        displayName : 'Model',
		        minWidth: 70, 
		        width: 80, 
		        enableColumnResizing: true
		    },{
		        field : 'usageCar',
		        displayName : 'Usage/Car',
		        minWidth: 70, 
		        width: 80, 
		        enableColumnResizing: true
		    },{
		        field : 'description',
		        displayName : 'Description',
		        minWidth: 70, 
		        width: 80, 
		        enableColumnResizing: true
		    },{
		        field : 'snip',
		        displayName : 'SNIP',
		        minWidth: 70, 
		        width: 80, 
		        enableColumnResizing: true
		    }, {
		        field : 'zone',
		        displayName : 'Zone',
		        minWidth: 66, 
		        width: 70, 
		        enableColumnResizing: true
		    }, 
		    {
		        field : 'subzone',
		        displayName : 'Sub Zone',
		        minWidth: 84, 
		        width: 90, 
		        enableColumnResizing: true
		    }, 
		    {
		        field : 'frequency',
		        displayName : 'Frequency (in Hours)',
		        minWidth: 84, 
		        width: 90, 
		        enableColumnResizing: true
		    }, 
		    {
		        field : 'whLoc',
		        displayName : 'WH Location(Major Zone)',
		        minWidth: 84, 
		        width: 90, 
		        enableColumnResizing: true
		    }, 
		    {
		        field : 'lineLoc',
		        displayName : 'Line Location',
		        minWidth: 84, 
		        width: 90, 
		        enableColumnResizing: true
		    }, 
		    {
		        field : 'lineCapacity',
		        displayName : 'Line Capacity',
		        minWidth: 84, 
		        width: 90, 
		        enableColumnResizing: true
		    }, 
		    {
		        field : 'minFeed',
		        displayName : 'Min Feeding Required',
		        minWidth: 84, 
		        width: 90, 
		        enableColumnResizing: true
		    }, 
		    {
		        field : 'supplierMethod',
		        displayName : 'Supply Method',
		        minWidth: 84, 
		        width: 90, 
		        enableColumnResizing: true
		    }, 
		    {
		        field : 'safetyStock',
		        displayName : 'Safety Stock in Qty',
		        minWidth: 84, 
		        width: 90, 
		        enableColumnResizing: true
		    }, 
		    {
		        field : 'allocation',
		        displayName : 'Allocation',
		        minWidth: 84, 
		        width: 90, 
		        enableColumnResizing: true
		    }, 
		    {
		        field : 'distance',
		        displayName : 'Distance',
		        minWidth: 70, 
		        width: 80, 
		        enableColumnResizing: true
		    }, 
		    {
		        field : 'time',
		        displayName : 'Time',
		        minWidth: 70, 
		        width: 80, 
		        enableColumnResizing: true
		    },  
		    {
		        field : 'systemStock',
		        displayName : 'System Stock',
		        minWidth: 84, 
		        width: 90, 
		        enableColumnResizing: true
		    }, 
		    {
		        field : 'wip',
		        displayName : 'WIP (T&C)',
		        minWidth: 70, 
		        width: 80, 
		        enableColumnResizing: true
		    }, 
		    {
		        field : 'wipPaint',
		        displayName : 'WIP Paint',
		        minWidth: 70, 
		        width: 80, 
		        enableColumnResizing: true
		    } , 
		    {
		        field : 'wipTotal',
		        displayName : 'WIP Total',
		        minWidth: 70, 
		        width: 80, 
		        enableColumnResizing: true
		    }, 
		    {
		        field : 'shiftConsumption',
		        displayName : 'Shift Consumption',
		        minWidth: 70, 
		        width: 80, 
		        enableColumnResizing: true
		    } ],
		    exporterPdfAlign : 'left',
		    exporterCsvFilename : 'MasterScreenDetailsReport.csv',
		    exporterMenuVisibleData : false,
		    exporterPdfDefaultStyle : {
			    fontSize : 9
		    },
		    exporterPdfTableStyle : {
			    margin : [ 70, 5, 0, 5 ]
		    },
		    exporterPdfTableHeaderStyle : {
		        fontSize : 10,
		        bold : true,
		        italics : true,
		        color : 'red'
		    },
		    exporterPdfHeader : {
		        text : "FIFO Report",
		        style : 'headerStyle'
		    },
		    exporterPdfFooter : function(currentPage, pageCount) {
			    return {
			        text : currentPage.toString() + ' of ' + pageCount.toString(),
			        style : 'footerStyle'
			    };
		    },
		    exporterPdfCustomFormatter : function(docDefinition) {
			    docDefinition.styles.headerStyle = {
			        fontSize : 20,
			        bold : true,
			        alignment : 'center',
			        margin : [ 0, 0, 20, 0 ]
			    };
			    docDefinition.styles.footerStyle = {
			        fontSize : 10,
			        bold : true,
			        alignment : 'center',
			        margin : [ 5, 0, 20, 0 ]
			    };
			    return docDefinition;
		    },
		    exporterPdfOrientation : 'landscape',
		    exporterPdfPageSize : 'LETTER',
		    exporterPdfMaxGridWidth : 500,
		    exporterPdfFilename : 'MasterScreenDetailsReport.pdf',
		    exporterCsvLinkElement : angular.element(document.querySelectorAll(".custom-csv-link-location")),
		    onRegisterApi : function(gridApi) {
			    $scope.gridApi = gridApi;
			    // Pagination
			    gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
				    $scope.blockUI();
				    paginationOptions.pageNumber = newPage;
				    paginationOptions.pageSize = pageSize;
				    paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
				    paginationOptions.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
				   // paginationOptions.endIndex   = paginationOptions.pageSize;
				    $scope.load();
			    });
		    }
		};	
		
		$scope.masterScreenDetailsGridOptions = {
			    enablePaginationControls : false,
			    enableGridMenu : true,
			    enableFiltering : true,
			    enableColumnResize : true,
			    paginationPageSizes : [ 100, 250, 500, 750, 1000 ],
			    paginationPageSize : 100,
			    useExternalPagination : true,
			    autoResize : true,
			    enableSorting : true,
			    enableColumnMenus : false,
			    enablePinning : true,
			  /*  enableRowSelection = true,
			    enableSelectAll = true,*/
			    columnDefs : [ {
			        field : 'partNo',
			        displayName : 'Part Number',
			        cellTemplate: '<div class="ui-grid-cell-contents"><span class="details-link" data-toggle="modal" data-target="#printDetailsModal" ng-click="grid.appScope.openModalTable(row.entity,row.entity.partNo)">{{row.entity.partNo}}</span></div>',
			        minWidth: 130, 
			        width: 160, 
			        enableColumnResizing: true 
			    }, {
			        field : 'partType',
			        displayName : 'KD/LP',
			        minWidth: 56, 
			        width: 60, 
			        enableColumnResizing: true 
			    },{
			        field : 'supplier',
			        displayName : 'Supplier Name',
			        minWidth: 70, 
			        width: 80, 
			        enableColumnResizing: true
			    },{
			        field : 'model',
			        displayName : 'Model',
			        minWidth: 70, 
			        width: 80, 
			        enableColumnResizing: true
			    },{
			        field : 'usageCar',
			        displayName : 'Usage/Car',
			        minWidth: 70, 
			        width: 80, 
			        enableColumnResizing: true
			    },{
			        field : 'description',
			        displayName : 'Description',
			        minWidth: 70, 
			        width: 80, 
			        enableColumnResizing: true
			    },{
			        field : 'snip',
			        displayName : 'SNIP',
			        minWidth: 70, 
			        width: 80, 
			        enableColumnResizing: true
			    }, {
			        field : 'zone',
			        displayName : 'Zone',
			        minWidth: 66, 
			        width: 70, 
			        enableColumnResizing: true
			    }, 
			    {
			        field : 'subzone',
			        displayName : 'Sub Zone',
			        minWidth: 84, 
			        width: 90, 
			        enableColumnResizing: true
			    }, 
			    {
			        field : 'frequency',
			        displayName : 'Frequency (in Hours)',
			        minWidth: 84, 
			        width: 90, 
			        enableColumnResizing: true
			    }, 
			    {
			        field : 'whLoc',
			        displayName : 'WH Location(Major Zone)',
			        minWidth: 84, 
			        width: 90, 
			        enableColumnResizing: true
			    }, 
			    {
			        field : 'lineLoc',
			        displayName : 'Line Location',
			        minWidth: 84, 
			        width: 90, 
			        enableColumnResizing: true
			    }, 
			    {
			        field : 'lineCapacity',
			        displayName : 'Line Capacity',
			        minWidth: 84, 
			        width: 90, 
			        enableColumnResizing: true
			    }, 
			    {
			        field : 'minFeed',
			        displayName : 'Min Feeding Required',
			        minWidth: 84, 
			        width: 90, 
			        enableColumnResizing: true
			    }, 
			    {
			        field : 'supplierMethod',
			        displayName : 'Supply Method',
			        minWidth: 84, 
			        width: 90, 
			        enableColumnResizing: true
			    }, 
			    {
			        field : 'safetyStock',
			        displayName : 'Safety Stock in Qty',
			        minWidth: 84, 
			        width: 90, 
			        enableColumnResizing: true
			    }, 
			    {
			        field : 'allocation',
			        displayName : 'Allocation',
			        minWidth: 84, 
			        width: 90, 
			        enableColumnResizing: true
			    }, 
			    {
			        field : 'distance',
			        displayName : 'Distance',
			        minWidth: 70, 
			        width: 80, 
			        enableColumnResizing: true
			    }, 
			    {
			        field : 'time',
			        displayName : 'Time',
			        minWidth: 70, 
			        width: 80, 
			        enableColumnResizing: true
			    },  
			    {
			        field : 'systemStock',
			        displayName : 'System Stock',
			        minWidth: 84, 
			        width: 90, 
			        enableColumnResizing: true
			    }, 
			    {
			        field : 'wip',
			        displayName : 'WIP (T&C)',
			        minWidth: 70, 
			        width: 80, 
			        enableColumnResizing: true
			    }, 
			    {
			        field : 'wipPaint',
			        displayName : 'WIP Paint',
			        minWidth: 70, 
			        width: 80, 
			        enableColumnResizing: true
			    } , 
			    {
			        field : 'wipTotal',
			        displayName : 'WIP Total',
			        minWidth: 70, 
			        width: 80, 
			        enableColumnResizing: true
			    }, 
			    {
			        field : 'shiftConsumption',
			        displayName : 'Shift Consumption',
			        minWidth: 70, 
			        width: 80, 
			        enableColumnResizing: true
			    } ],
			    exporterPdfAlign : 'left',
			    exporterCsvFilename : 'MasterScreenDetailsReport.csv',
			    exporterMenuVisibleData : false,
			    exporterPdfDefaultStyle : {
				    fontSize : 9
			    },
			    exporterPdfTableStyle : {
				    margin : [ 70, 5, 0, 5 ]
			    },
			    exporterPdfTableHeaderStyle : {
			        fontSize : 10,
			        bold : true,
			        italics : true,
			        color : 'red'
			    },
			    exporterPdfHeader : {
			        text : "Master Details Report",
			        style : 'headerStyle'
			    },
			    exporterPdfFooter : function(currentPage, pageCount) {
				    return {
				        text : currentPage.toString() + ' of ' + pageCount.toString(),
				        style : 'footerStyle'
				    };
			    },
			    exporterPdfCustomFormatter : function(docDefinition) {
				    docDefinition.styles.headerStyle = {
				        fontSize : 20,
				        bold : true,
				        alignment : 'center',
				        margin : [ 0, 0, 20, 0 ]
				    };
				    docDefinition.styles.footerStyle = {
				        fontSize : 10,
				        bold : true,
				        alignment : 'center',
				        margin : [ 5, 0, 20, 0 ]
				    };
				    return docDefinition;
			    },
			    exporterPdfOrientation : 'landscape',
			    exporterPdfPageSize : 'LETTER',
			    exporterPdfMaxGridWidth : 500,
			    exporterPdfFilename : 'MasterScreenDetailsReport.pdf',
			    exporterCsvLinkElement : angular.element(document.querySelectorAll(".custom-csv-link-location")),
			    onRegisterApi : function(gridApi) {
				    $scope.gridApi = gridApi;
				    // Pagination
				    gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
					    $scope.blockUI();
					    paginationOptions.pageNumber = newPage;
					    paginationOptions.pageSize = pageSize;
					    paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
					    paginationOptions.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
					    //paginationOptions.endIndex   = paginationOptions.pageSize;
					    $scope.load();
					    
				    });
				    
				    $scope.selectedRow = $scope.gridApi.selection.on.rowSelectionChanged($scope,function(row){
	                    $scope.selectedValue.push(row.entity.partNumber);
				    	
				      });
			    }
			};
		
		
		$scope.masterScreenDetailsGridOptions.exporterFieldCallback = function(grid, row, col, value) {
			if (col.name === 'partInOutTime' || col.name === 'scanTime') {
				value = $filter('date')(value, 'dd/MM/yyyy HH:mm:ss');
			}
			return value;
		};
		// Clear the filter
		$scope.clearFilters = function() {
			$scope.gridApi.core.clearAllFilters();
		};
			
		$scope.openModalTable=function(ent,pickingListNum){
			console.log("sdfsd")
			$scope.printedHeader = ent;
			$scope.deviceTranId = pickingListNum;
			$scope.boxTotal = 0;
			masterScreenDetailsDetailsService.masterScreenDetailsDetailsModal(pickingListNum).then(function(response) {
				$scope.masterScreenDetailsGridOptions.totalItems = response.object.detailsDTOList.length;
				$scope.recordCount = response.object.detailsDTOList.length;
				$scope.pickListnumberSelected = response.object.pickListnumber;
				$scope.printableList = response.object.detailsDTOList;
				$scope.printableList.map(function(item) {
					if(item) {
						$scope.boxTotal += item.noOfBoxes;
						$scope.snpTotal += item.snp;
						$scope.qtyTotal += item.quantity;
					}
				});
				var resTemp={};
				resTemp.data= angular.copy(response);
				$scope.masterScreenDetailsDetailsModelGridData(resTemp);
			});
		}
		var w= null;
		$scope.printDetails = function(){
			$scope.dateCurr = new Date();
			 var printContents = document.getElementById("printableArea").innerHTML;
		     var originalContents = document.body.innerHTML;
		     w=window.open();
		     w.document.write($('.printableArea').html());
		     w.document.close();
		     w.focus();
		     w.print();
		     w.close();
		     
		     //w.close();
		     //w= null;
		};
		
		
		$scope.masterScreenDetailsGridData = function(response) {
			$scope.gridOptions.data = [];
			if (response.data.objectList !== undefined && response.data.objectList !== null) {
				if (response.data.statusType === 'success') {
					$scope.gridOptions.enablePaginationControls = true;
					response.data.objectList.forEach(function(row) {
						$scope.gridOptions.data = response.data.objectList;
					});
				} else {
					$scope.gridOptions.enablePaginationControls = false;
					$scope.alerts = [];
					$scope.alerts.push({
					    type : response.data.statusType,
					    msg : response.data.statusMessage,
					    error : response.data.exceptionStackTrace,
					    errorClsName : response.data.exceptionClassName,
					    errorMsg : response.data.exceptionMessage
					});
				}
				$.unblockUI();
			} else {
				$scope.searchDataEror = response.data.statusMessage;
				$.unblockUI();
			}
		};
		
		
		/* Load data in grid */
		$scope.load = function() {
			console.log("entered 13");
			$scope.master.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

	    	if(paginationOptions.endIndex === 0){
	    		$scope.master.endIndex = $scope.gridOptions.paginationPageSize;
	    	}
	    	$scope.master.startIndex = paginationOptions.startIndex;
	    	$scope.master.endIndex = paginationOptions.pageSize;
			$scope.master.beginDate = $scope.fromDate;
			$scope.master.endDate = $scope.toDate;
//			if($scope.master.shop!==undefined)
//			{
//				$scope.master.shopId = $scope.master.shop.shopId;
//				console.log("$scope.master.shopId "+$scope.master.shopId);
//				
//			}
//			if($scope.master.line!==undefined)
//			{
//				$scope.master.lineId = $scope.master.line.lineId;
//				console.log("$scope.master.lineId "+$scope.master.lineId);
//			}
			
			$scope.master.partNumber = $scope.partNumber;
	    	$scope.master.location = $scope.location;
	    	console.log("partNumber request");
	    	console.log($scope.master.partNumber);
	    	console.log("location request");
	    	console.log($scope.master)
	    	console.log("entered 14");
			$scope.getTime();
			
			var parameterTemp = $scope.removeAllExras();
			console.log("calling 15");
			masterScreenDetailsService.searchMasterDetailsCount(parameterTemp).then(function(response) {
				console.log("calling 16==="+$scope.master.supplier);
				console.log("calling 16");
				$scope.gridOptions.totalItems = response.data.object;
				$scope.recordCount = response.data.object;
				if($scope.recordCount > 0){
					console.log("calling 17");
					masterScreenDetailsService.searchMasterDetailsCheckCount(parameterTemp).then(function(response) {
						console.log("calling 18");
						var resTemp={};
						resTemp.data= angular.copy(response);
						$scope.masterScreenDetailsGridData(resTemp);
					});
				}
			});
		};
		
		
		$scope.searchMasterDetails = function() {
			
			if ($scope.validateFilter() == true) {
				$scope.blockUI();			
				$scope.alerts = [];
				console.log("entered 11");
//				$scope.gridOptions.data = [];			
				//$scope.fromDate = $filter('date')($scope.beginDate, 'yyyy-MM-dd');
				//$scope.toDate = $filter('date')($scope.endDate, 'yyyy-MM-dd');			
			
			    $scope.master.isFullDownload=0;
				paginationOptions.startIndex = 0;
				paginationOptions.endIndex = 0;
				paginationOptions.pageNumber = 1;
				paginationOptions.pageSize = 100;
				$scope.gridOptions.paginationCurrentPage = 1;
				$scope.gridOptions.paginationPageSize = 100;
				/*$scope.fifo.startIndex=0;
				$scope.fifo.endIndex=0;*/
				$scope.searchClicked = true;
//				$scope.clearFilters();
				console.log("entered 12");
				$scope.load();
				$(".appViewDiv").css({
				    "height" : $(window).height() - 130,
				    "overflow" : "auto"
				});
				$.unblockUI();
	   			$scope.gridOptions.enablePaginationControls=false;
				$scope.gridOptions.data = [];
				return;
			} else {
				$scope.alerts = [];
				$scope.alerts.push({
				    type : 'danger',
				    msg : 'Plant/Shop is mandatory'
				});
				$.unblockUI();
	   			$scope.gridOptions.enablePaginationControls=false;
				$scope.gridOptions.data = [];
				return;
			}
		};
		
		$scope.validateFilter = function() {
			if($scope.master.plant !== "" && $scope.master.plant !== null && $scope.master.plant !== undefined 
					&& $scope.master.shop !== "" && $scope.master.shop !== null && $scope.master.shop !== undefined)
			 {
				 return true;
			 }
	    	 //else if($scope.tags.length>0 || $scope.locationIdData.length>0){
	    	//	 return true;
	    	 //}
	    	 else{
				 return false;
			 }
		};
		
		$scope.getTime = function(){
			var datesFrom = new Date($scope.fromDate);
			if(!$scope.fromTime1){
				$scope.fromTime1 = 0;
			}
			if(!$scope.fromTime2){
				$scope.fromTime2 = 0;
			}
			if(!$scope.fromTime3){
				$scope.fromTime3 = 0;
			}
			
			datesFrom.setHours($scope.fromTime1);
			datesFrom.setMinutes($scope.fromTime2);
			datesFrom.setSeconds(0);
			
			var datesTo = new Date($scope.toDate);
			
			if(!$scope.toTime1){
				$scope.toTime1 = 23;
			}
			if(!$scope.toTime2){
				$scope.toTime2 = 59;
			}
			if(!$scope.toTime3){
				$scope.toTime3 = 59;
			}
			
			datesTo.setHours($scope.toTime1);
			datesTo.setMinutes($scope.toTime2);
			datesTo.setSeconds(0);
			
			$scope.master.beginDate = datesFrom;
			$scope.master.endDate = datesTo;
		};
		
		//-----------Remove empty attributes--------------
		$scope.removeAllExras = function(){
			var parameter = angular.copy($scope.master);
			/*delete parameter["endIndex"];
			delete parameter["startIndex"];
			delete parameter["fromTime"];
			delete parameter["toTime"];
			delete parameter["partNumber"];
			delete parameter["plant"];
			delete parameter["shift"];
			if(parameter.line == ""){
				delete parameter["line"];
			}
			if(parameter.device == ""){
				delete parameter["device"];
			}
			if(parameter.location == ""){
				delete parameter["location"];
			}*/
			return parameter;
		}
	// ---------- grid end -----------
	  
		$scope.downloadMasterDetails =function(){
        	$scope.blockUI();
        	//$scope.master.fromDate=$filter('date')($scope.beginDate, 'yyyy-MM-dd');;
	    	//$scope.master.toDate=$filter('date')($scope.endDate, 'yyyy-MM-dd');
	    	
        	$scope.master.partNumber=$scope.partNumber;
        	$scope.master.location=$scope.location;
        	
        	return masterScreenDetailsService.checkDownload($scope.master).then(function(response){
        		if(response.objectList != null){
        			for (var i = 0; i < response.objectList.length; i++) {
        				response.objectList[i].partNumber = '="'+response.objectList[i].partNumber+'"';
        				//response.objectList[i].partInOutTime =$filter('date')(response.objectList[i].partInOutTime, 'dd/MM/yyyy HH:mm:ss');
        				//response.objectList[i].scanTime =$filter('date')(response.objectList[i].scanTime, 'dd/MM/yyyy HH:mm:ss');
        				//response.objectList[i].pickedRanInTime =$filter('date')(response.objectList[i].pickedRanInTime, 'dd/MM/yyyy');
        				//response.objectList[i].correctRanInTime =$filter('date')(response.objectList[i].correctRanInTime, 'dd/MM/yyyy');
        			}
        			$.unblockUI();
        			return response.objectList;
        		}else{
        			$scope.alerts = [];
	       			$scope.alerts.push({
	       				 type : 'danger',
	       				 msg : 'Data is not available'
	       			});
        		}
        		$.unblockUI();
        	});
    
        };
        
		$scope.resetFifo = function() {
			$scope.shops = "";
			$scope.lines = "";
			$scope.beginDate = new Date();
			$scope.endDate = new Date();
			$scope.beginTime = new Date();
			$scope.endTime = new Date();
			$scope.getTime();
			$scope.gridOptions.data = [];
			$scope.lineFeedingGridOptions.data = [];
			$scope.clearFilters();
			$scope.master = {};
			$scope.partNumber = "";
			$scope.fifo.startIndex = 0;
			$scope.fifo.endIndex = 0;
			$scope.gridOptions.totalItems = 0;
			$scope.partNumber = "";
			$scope.tags=[];
			$scope.gridOptions.enablePaginationControls = false;
			$(".appViewDiv").css({
			    "height" : $(window).height() - 130,
			    "overflow" : "auto"
			});
			$scope.shiftDropdown = false;
			
		};


        $scope.getDownloadMasterDetailsReportHeader = function () {
        	return ["Part Number","KD/LP","Supplier Name","Model","Usage/Car","Description","SNIP","Zone","Sub Zone","Frequency (in Hours)","WH Location(Major Zone)",
        		"Line Location","Line Capacity","Min Feeding Required","Supply Method","Safety Stock in Qty","Allocation","Distance","Time","System Stock",
        		"WIP (T&C)","WIP Paint","WIP Total","Shift Consumption"];
       };
       $scope.csvColumnOrder=['partNo','partType','supplier','model','usageCar','description','snip','zone','subzone','frequency','whLoc',
    	   'lineLoc','lineCapacity','minFeed','supplierMethod','safetyStock','allocation','distance','time','systemStock','wip','wipPaint','wipTotal','shiftConsumption'];

	
} ]);
// end of controller  MasterScreenDetailsController


//start of service masterScreenDetailsService
wmsApp.factory('masterScreenDetailsService', [ 'commonService', '$http', '$q', '$window', function(commonService, $http, $q,$window) {
	 var fact={};
	
	fact.getAllZones= function()
	{
		var serviceURL = 'rest/shortageAlarm/allzones';
		var serviceType ='GET';
		var params='';
		
		return $http({
			method : serviceType,
			url : serviceURL,
			data : JSON.stringify(params),
			headers: {'Content-Type': 'application/json'}
		}).success(function (data) {
			return data;
		 });
	};

	fact.getAllocationList = function(){
		 return $http({
				method : 'POST',
				url : 'rest/pickinglist/allocationByZone',			
				headers: {'Content-Type': 'application/json'}
		 }).success(function (data) {
				return data;
		 });
	};
	
	fact.searchMasterDetailsCount=function(param)
    {
    	return $http({
			method : 'POST',
			url : 'rest/masterscreen/masterdetailslistcount',		
			data : param,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			return data;
		});	
	};
	
	fact.searchMasterDetailsCheckCount = function(param) {
		var deferred = $q.defer();
		$http({
		    method : 'POST',
		    url : 'rest/masterscreen/search',
		    data : param,
		    headers : {
			    'Content-Type' : 'application/json'
		    }
		}).success(function(data) {
			deferred.resolve(data);
		});
		return deferred.promise;
	};
	
	fact.getSupplier= function()
	{
		var serviceURL = 'rest/supplier/allsuppliers';
		var serviceType ='GET';
		
		return $http({
			method : serviceType,
			url : serviceURL,
			headers: {'Content-Type': 'application/json'}
		}).success(function (data) {
			return data;
		 });;
	};
	
    fact.locationList=function(locationInputObj)
    {
    	return $http({
			method : 'POST',
			url : 'rest/location/locationByLocationID',		
			data : JSON.stringify(locationInputObj),
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {		
			return data;
			
		});				
	};
	
	fact.partNumberList=function(partInputObj)
    {
    	return $http({
			method : 'POST',
			url : 'rest/parts/partsByPartNumber',		
			data : JSON.stringify(partInputObj),
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {		
			return data;
			
		});
				
	};
	
	fact.checkDownload=function(param)
    {    
    	var deferred = $q.defer();
        $http({
			method : 'POST',
			url : 'rest/masterscreen/download',	
			data : param,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			 deferred.resolve(data);
			
		});
        return deferred.promise;
				
	};
	
	return fact;
	
} ]);
