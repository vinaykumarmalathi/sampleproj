var wmsApp = angular.module('wmsApp');

wmsApp.factory('formRequirementCreateService', ['commonService','$http','$q',function(commonService,$http,$q){
	 var fact={};
	 
		
	 return fact;
}
]);