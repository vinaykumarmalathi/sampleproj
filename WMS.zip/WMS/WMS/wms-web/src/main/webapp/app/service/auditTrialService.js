
var wmsApp = angular.module('wmsApp');

wmsApp.factory('auditTrialService',['commonService','$http','$q',function(commonService,$http,$q){
    var fact={};
    
    fact.auditReport=function(part)
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/search/partsInOutAuditSearch',	
			data : part,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});
				
	};
	
    fact.auditDownload=function(part)
    {    
    	var deferred = $q.defer();
        $http({
			method : 'POST',
			url : 'rest/search/partsInOutAuditSearch',	
			data : part,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			 deferred.resolve(data);
			
		});
        return deferred.promise;
				
	};
	
    fact.auditReportCount=function(part)
    {
	
    	return $http({
			method : 'POST',
			url : 'rest/search/partsInOutAuditCount',		
			data : part,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			return data;
			
		});
				
	};

	
	return fact;
	
	
}]);