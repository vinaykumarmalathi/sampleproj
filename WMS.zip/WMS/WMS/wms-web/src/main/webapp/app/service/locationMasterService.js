
var wmsApp = angular.module('wmsApp');

wmsApp.factory('locationMasterService',['commonService','$http','$q',function(commonService,$http,$q){
    var fact={};
    
    fact.location=function(location)
    {
    	console.log("Location Service:");
    	
    	return $http({
			method : 'POST',
			url : 'rest/manageLocation/locationSearch',	
			data : location,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});
				
	};
		
	  fact.locationCount=function(location)
	    {
    	
	    	return $http({
				method : 'POST',
				url : 'rest/manageLocation/locationCount',			
				data : location,
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {				
				return data;
				
			});
					
		};
		
		
		 fact.populateLocationInfo=function(location)
		    {
	    	
		    	return $http({
					method : 'POST',
					url : 'rest/manageLocation/manageLocationByLocationId',			
					data : location,
					headers: {'Content-Type': 'application/json'}
				})
				.success(function (data) {				
					return data;
					
				});
						
			};
			
			fact.saveLocationMapDetails=function(location)
		    {
	    	
		    	return $http({
					method : 'POST',
					url : 'rest/manageLocation/updateLocation',			
					data : location,
					headers: {'Content-Type': 'application/json'}
				})
				.success(function (data) {				
					return data;
					
				});
						
			};
			
			fact.addLocationsMapDetails=function(location)
		    {
	    	
		    	return $http({
					method : 'POST',
					url : 'rest/manageLocation/insertLocation',			
					data : location,
					headers: {'Content-Type': 'application/json'}
				})
				.success(function (data) {				
					return data;
					
				});
						
			};
			fact.deleteMaster=function(location)
		    {
	    	
		    	return $http({
					method : 'POST',
					url : 'rest/manageLocation/deleteLocation',			
					data : location,
					headers: {'Content-Type': 'application/json'}
				})
				.success(function (data) {				
					return data;
					
				});
						
			};
			
			 fact.locationDownload=function(location)
			    {    
			    	var deferred = $q.defer();
			        $http({
						method : 'POST',
						url : 'rest/manageLocation/locationSearch',	
						data : location,
						headers: {'Content-Type': 'application/json'}
					})
					.success(function (data) {
						 deferred.resolve(data);
						
					});
			        return deferred.promise;
							
				};

	
	return fact;
	
	
}]);