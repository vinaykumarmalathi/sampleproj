var directives = angular.module('directives', []).directive('numbersOnly', function() {
    return {
        require : 'ngModel',
        link : function(scope, element, attrs, modelCtrl) {
            modelCtrl.$parsers.push(function(inputValue) {
                if (inputValue === undefined) {
                    return '';
                }
                var transformedInput = inputValue.replace(/[^0-9\\.]/g, '');
                if (transformedInput !== inputValue) {
                    modelCtrl.$setViewValue(transformedInput);
                    modelCtrl.$render();
                }

                return transformedInput;
            });
        }
    };
}).directive(
        'partSearchHeader',
        function() {
            return {
                restrict : 'E',
                templateUrl : 'app/shared/PartSearchHeader.html'
            };
}).directive('nksOnlyNumber', function () {
    return {
        restrict: 'EA',
        require: 'ngModel',
        link: function (scope, element, attrs, ngModel) {   
             scope.$watch(attrs.ngModel, function(newValue, oldValue) {
                  var spiltArray = String(newValue).split("");

                  if(attrs.allowNegative == "false") {
                    if(spiltArray[0] == '-') {
                      newValue = newValue.replace("-", "");
                      ngModel.$setViewValue(newValue);
                      ngModel.$render();
                    }
                  }

                  if(attrs.allowDecimal == "false") {
                      newValue = parseInt(newValue);
                      ngModel.$setViewValue(newValue);
                      ngModel.$render();
                  }

                  if(attrs.allowDecimal != "false") {
                    if(attrs.decimalUpto) {
                       var n = String(newValue).split(".");
                       if(n[1]) {
                          var n2 = n[1].slice(0, attrs.decimalUpto);
                          newValue = [n[0], n2].join(".");
                          ngModel.$setViewValue(newValue);
                          ngModel.$render();
                       }
                    }
                  }
                  if (spiltArray.length === 0) return;
                  if (spiltArray.length === 1 && (spiltArray[0] == '-' || spiltArray[0] === '.' )) return;
                  if (spiltArray.length === 2 && newValue === '-.') return;

                /*Check it is number or not.*/
                if (isNaN(newValue) || spiltArray[spiltArray.length-1] === '.') {
                  ngModel.$setViewValue(oldValue);
                  ngModel.$render();
                }
            });
        }
    };
}).directive('alphaNumeric', function() {
	  return {
		    require: 'ngModel',
		    link: function(scope, element, attr, ngModelCtrl) {
		      function fromUser(text) {
		        //var transformedInput = text.replace(/[^0-9a-zA-Z\,\s]/g, '');	allow comma also in alpha numeric
		        var transformedInput = text.replace(/[^0-9a-zA-Z]/g, '');	
		        if (transformedInput !== text) {
		          ngModelCtrl.$setViewValue(transformedInput);
		          ngModelCtrl.$render();
		        }
		        return transformedInput; // or return Number(transformedInput)
		      }
		      ngModelCtrl.$parsers.push(fromUser);
		    }
		  };
}).directive('alphaOnly', function() {
			  return {
				    require: 'ngModel',
				    link: function(scope, element, attr, ngModelCtrl) {
				      function fromUser(text) {				     
				        var transformedInput = text.replace(/[^a-zA-Z]/g, '');	
				        if (transformedInput !== text) {
				          ngModelCtrl.$setViewValue(transformedInput);
				          ngModelCtrl.$render();
				        }
				        return transformedInput; // or return Number(transformedInput)
				      }
				      ngModelCtrl.$parsers.push(fromUser);
				    }
				  };
}).directive("fileModel",function() {
	return {
		restrict: 'EA',
		scope: {
			setFileData: "&"
		},
		link: function(scope, ele, attrs) {
			ele.on('change', function() {
				scope.$apply(function() {
					var val = ele[0].files[0];
					scope.setFileData({ value: val });
				});
			});
		}
	};
}).directive("datePicker", function ($timeout,uiGridSelectionService) {
	console.log("Hello");
    return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, elem, attrs, ngModelCtrl,row) {
                elem.datepicker({
                    dateFormat: 'yy-mm-dd',
                    //showStatus: true,
                    //showWeeks: true,
                    //highlightWeek: true,
                    minDate: 0,
                    //numberOfMonths: 1,
                    //showAnim: "scale",
                   // showOptions: { origin: ["bottom", "right"] },
                    onSelect: function (date) {
                    	if(attrs.class == "editInput editAdoptDate"){
                    		ngModelCtrl.$setViewValue(date);
                            scope.$apply();
                            //scope.row.entity.editAbolishDate = date;
                            var abolishDate = elem.datepicker('getDate');
                            abolishDate.setDate(abolishDate.getDate()+1);
                            elem.parent().parent().next().children().children().datepicker("option", "minDate", abolishDate);
                    	}
                    	else {
                    		ngModelCtrl.$setViewValue(date);
                            scope.$apply();
                            var adoptDate = elem.datepicker('getDate');
                            adoptDate.setDate(adoptDate.getDate()-1);
                            elem.parent().parent().prev().children().children().datepicker("option", "maxDate", adoptDate);
                    	}                    
                    }
                });

      
        }
    };
}).directive("buildMenu",function(){
	return {
		restrict : 'E',
		template : '<ul id="menuid">'+
            			'<li ng-repeat="parent in buildMenu | filter:{checked:true}"><a ng-href="{{parent.path}}">{{parent.menuName}}</a>'+
            				'<ul style=" list-style-type: none;">'+
            					'<li ng-repeat="child in parent.childMenu | filter:{checked:true}"><a ng-href="{{child.path}}">{{child.menuName}}</a>'+
            						'<ul style=" list-style-type: none;">'+
            							'<li ng-repeat="subChild in child.childMenu | filter:{checked:true}"><a ng-href="{{subChild.path}}">{{subChild.menuName}}</a>'+
            							'</li>'+
            						'</ul>'+
            					'</li>'+
            				'</ul>'+
            			'</li>'+  
            		'</ul>',
        
		scope : {
			buildMenu : "=data"
		},
	};
});