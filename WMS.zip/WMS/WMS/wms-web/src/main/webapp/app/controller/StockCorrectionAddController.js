wmsApp.controller('StockCorrectionAddController', ['$scope', '$location', '$routeParams',
	'$window', 'commonService', 'stockCorrectionAddService', 'Location', '$rootScope',
	function($scope, $location, $routeParams, $window, commonService, stockCorrectionAddService, Location, $rootScope) {


		$scope.data = [{
			partId: '',
			partNo: '',
			partName: '',
			zone: '',
			subzone: '',
			lineStock: '',
			correction: '',
			consideration: '',
			reason: '',
			shift: '',
			userId: '',
			remarks: ''
		}];


		$scope.addRow = function(){
			console.log("saving ");
			console.log($scope.data);
			$scope.data.push({
								partId: '',
								partNo: '',
								partName: '',
								zone: '',
								subzone: '',
								lineStock: '',
								correction: '',
								consideration: '',
								reason: '',
								shift: '',
								userId: '',
								remarks: ''
							});
			};



		$scope.popupGridOptions = {

			//enablePaginationControls:false,
			//enableGridMenu: true,
			//enableFiltering: true,
			//enableSorting: true,
			enableColumnResize: true,
			enableCellEditOnFocus: true,
			enableCellEdit: true,
			//paginationPageSizes: [100,250,500,750,1000],
			//paginationPageSize: 100,
			treeRowHeaderAlwaysVisible: true,
			showTreeExpandNoChildren: false,
			useExternalPagination: true,
			autoResize: true,
			enablePinning: true,
			data: $scope.data,
			columnDefs: [
				{ field: 'partNo', name: 'Part Number', width: '15%' },
				{ field: 'partName', name: 'Part Name', width: '15%' },
				{ field: 'zone', name: 'Zone', width: '15%' },
				{ field: 'subzone', name: 'Sub Zone', width: '15%' },
				{ field: 'lineStock', name: 'Line Stock', width: '15%' },
				{ field: 'correction', name: 'Correction', width: '15%' },
				{ field: 'remarks', name: 'Remarks', width: '15%' },
				{ field: 'consideration', name: 'Consideration', width: '15%' },
				{ field: 'reason', name: 'Reason', width: '15%' },
				{ field: 'shift', name: 'Shift', width: '15%' },
				{ field: 'userId', name: 'User ID', width: '15%' },
				{ field: 'remarks', name: 'Remarks', width: '15%' }
				
			],

			onRegisterApi: function(gridApi) {
				$scope.gridApi = gridApi;
			}
		};



		$scope.saveData = function() {
			console.log("clicked save start");
			console.log($scope.data);

			stockCorrectionAddService.addStockCorrection($scope.data).then(function(response) {
				console.log("adding start");
				console.log(response.objectList);
				$scope.data = response.objectList;
				
				$scope.alerts = [];
				$scope.alerts.push({
					type: response.statusType,
					msg: response.statusMessage,
					error: response.exceptionStackTrace,
					errorClsName: response.exceptionClassName,
					errorMsg: response.exceptionMessage
				});
				console.log("adding end");
			});

			console.log("clicked save end");
		};
		
		$scope.deleteRowData = function() {
			console.log("deleteRowData method called");
		}

		
		
		$scope.deleteData = function() {
			console.log("clicked delete start");
			console.log($scope.data);

			stockCorrectionAddService.deleteStockCorrection($scope.data).then(function(response) {
				console.log("deleting start");
				console.log(response.objectList);
				$scope.data = [];
//				$scope.addRow();
				
				$scope.data.push({
				
				               partId : '',
							   partNo : '',
							   partName : '',
							   zone : '',
							   subzone : '',
							   lineStock : '',
							   correction : '',
							   consideration : '',
							   reason : '',
							   shift : '',
							   userId : '',
							   remarks : ''

				    });

				  $scope.popupGridOptions.data = $scope.myData;
				
				$scope.alerts = [];
				$scope.alerts.push({
					type: response.statusType,
					msg: response.statusMessage,
					error: response.exceptionStackTrace,
					errorClsName: response.exceptionClassName,
					errorMsg: response.exceptionMessage
				});
				console.log("deleting end");
			});

			console.log("clicked delete end");
		};
		

	}]);


wmsApp.factory('stockCorrectionAddService', ['$http','$q', function($http,$q) {
	var fact = {};


	fact.addStockCorrection = function(param) {
		var deferred = $q.defer();
		$http({
			method: 'POST',
			url: 'rest/stockcorrection/add-correction',
			data: param,
			headers: {
				'Content-Type': 'application/json'
			}
		}).success(function(data) {
			deferred.resolve(data);
		});
		return deferred.promise;
	};
	
	fact.deleteStockCorrection = function(param) {
		var deferred = $q.defer();
		$http({
			method: 'POST',
			url: 'rest/stockcorrection/delete-correction',
			data: param,
			headers: {
				'Content-Type': 'application/json'
			}
		}).success(function(data) {
			deferred.resolve(data);
		});
		return deferred.promise;
	};


	return fact;
}]);