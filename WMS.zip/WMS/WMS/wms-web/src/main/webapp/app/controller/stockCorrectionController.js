wmsApp.controller('stockCorrectionController', [ '$scope', '$location', '$routeParams',
		'$window','partLocationService','locationService','commonService','partNumberService','localStorageService','stockCorrectionService','ranService','Location','$rootScope','agedRanForStockCorrection',
		function($scope, $location, $routeParams, $window,partLocationService,locationService,commonService,partNumberService,localStorageService,stockCorrectionService,ranService,Location,$rootScope,agedRanForStockCorrection) {

	// --------- Part Number List ---------
	$scope.isLocNeed = false;
	$scope.partNumber='';
	$scope.searchClicked=false;
	$scope.showInst = false;
	//$scope.stockCorrectionReasons = false;
	$scope.tags=[];	 
	
	$scope.findDuplicate= function(arra1) {
		  var i,len=arra1.length,result = [],obj = {};
		  for (i=0; i<len; i++) {
		    obj[arra1[i]]=0;
		  }
		  for (i in obj) {
		    result.push(i);
		  }
		  return result;
    };
  
	$scope.tagAdded = function(tag) {
		
	$scope.partArray = [];
	     for (var j=0; j < $scope.tags.length; j++) {
	    	 $scope.partArray.push($scope.tags[j].text);
	      }
	     $scope.partNumber=$scope.partArray.join(',');
	     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
    };
    $scope.tagRemoved = function(tag) {			   
    	 $scope.partArray = [];
	     for (var j=0; j < $scope.tags.length; j++) {

	    	 $scope.partArray.push($scope.tags[j].text);
	      }
	     $scope.partNumber=$scope.partArray.join(',');
	     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
    };
	    			  
    $scope.loadParts = function(query) {
    	var partInputObj = {"partNumber": query};			    	
    	return partNumberService.partNumberList(partInputObj).then(function(response){	
    		
    		 if(response.data.statusType=='success'){
        		 if(response.data.object!='null' && response.data.object!=null){				        		
        			  return response.data.object; 
        		 }
        	 }		    		
	    	});			    				         
      };
      
      
      
      
      $scope.location="";
	    $scope.locationIdData=[];	 
		  $scope.locationAdded = function(tag) {
			  /*$scope.part.plant = "";
		    	$scope.part.shop = "";
		    	$scope.part.line = "";
		    	$scope.part.section = "";*/
		    	$scope.part.locationId = "";
			  $scope.locationArray = [];
			     for (var j=0; j < $scope.locationIdData.length; j++) {
			    	 $scope.locationArray.push($scope.locationIdData[j].text);
			      }
			     $scope.location=$scope.locationArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    $scope.locationRemoved = function(tag) {			   
		    	 $scope.locationArray = [];
			     for (var j=0; j < $scope.locationIdData.length; j++) {

			    	 $scope.locationArray.push($scope.locationIdData[j].text);
			      }
			     $scope.location=$scope.locationArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    			  
		    $scope.loadLocation = function(query) {
		    	
		    	var locationInputObj = {"locationId": query};			    	
		    	return locationService.locationList(locationInputObj).then(function(response){	
		    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    	});			    				         
		    };
		    
		    /* RAN Auto Completion - Start */
		    $scope.ranData=[];	
		    
		    $scope.ranAdded = function(tag) {			
				console.log("tagAdded:",tag);
				  $scope.ranArray = [];
				     for (var j=0; j < $scope.ranData.length; j++) {
				    	 $scope.ranArray.push($scope.ranData[j].text);
				      }
				     $scope.part.ran=$scope.ranArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			};
		    
		    $scope.ranRemoved = function(tag) {			   
		    	 $scope.ranArray = [];
			     for (var j=0; j < $scope.ranData.length; j++) {

			    	 $scope.ranArray.push($scope.ranData[j].text);
			      }
			     $scope.part.ran=$scope.ranArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    $scope.loadRan = function(query) {
		    	var partInputObj = {"ranId": query};
		    	return ranService.ranList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){	
		        			 console.log(response.data.object);
		        			  return response.data.object;                           
		        		 }
		        	 }		    		
			    });	
		    };
		    
		   /* $scope.pasteRanTags = function(event){
				  event.preventDefault();
				  
				  //For IE
				  if ($window.clipboardData && $window.clipboardData.getData) {
					  $scope.tagsCopies = $window.clipboardData.getData('Text').split(/[,\n\t\s]+/);
					  console.log("IE");
					  console.log("$scope.tagsCopies",$scope.tagsCopies);
				  }
				  // Other Browsers
				  else if (event.originalEvent.clipboardData && event.originalEvent.clipboardData.getData) { 
					  $scope.tagsCopies = event.originalEvent.clipboardData.getData('text/plain').split(/[,\n\t\s]+/);
					  console.log("Other Browser");
					  console.log("$scope.tagsCopies",$scope.tagsCopies);
				  }
			      
			      $scope.tagsCopies = $scope.findDuplicate($scope.tagsCopies);
			      $scope.partNumberArray = [];
			      if($scope.part.ran != undefined){
			    	  $scope.partNumberArray = $scope.part.ran.split(',');
			      }
			      for (var j=0; j < $scope.tagsCopies.length; j++) {
			    	      var obj = {};
			    	      // Condition to check if string is not empty and whitespace
			    	      $scope.tagsCopies[j] = $scope.tagsCopies[j].trim();
			    	      // Checking duplication for copy content with existing tags
			    	      var Index = $scope.partNumberArray.indexOf($scope.tagsCopies[j]);
			    	      if($scope.tagsCopies[j] != "" && Index == -1){
			    	    	  obj['text'] = $scope.tagsCopies[j];
			    	    	  $scope.ranData.push(obj);
			    	    	  $scope.ranAdded(obj);
			    	      }
				  }
			      setTimeout(function(){
			    	    $scope.$digest();
			      }, 100);
			     
			};*/
		    /*RAN Auto Completion - End */
		// --------- Shops drop down list ---------
		    
		    $scope.loadShopLine = function(){
		    	 $scope.part.line = '';
		    	 $scope.part.shop = '';
		    	 commonService.getLineList($scope.part.plant)
				  .success(function(response){
					  console.log(response.objectList);
					  $scope.lines = response.objectList;				
				  })
				  .error(function(response){
				  });
		    	 commonService.getShopList($scope.part.plant)
				  .success(function(response){
					  console.log(response.objectList);
					  $scope.shops = response.objectList;				
				  })
				  .error(function(response){
				  });

		    }
		   
/*		  if($window.sessionStorage.getItem('shopDPCollection') == null || $window.sessionStorage.getItem('shopDPCollection')=='undefined' || $window.sessionStorage.getItem('shopDPCollection')==undefined){
			  commonService.getAllShop()
			  .success(function(response){						  
				  $scope.shops = response.objectList;				
				  $window.sessionStorage.setItem('shopDPCollection',JSON.stringify($scope.shops));
			  })
			  .error(function(response){
			  });
		  }else{
			  $scope.shops = JSON.parse(sessionStorage.shopDPCollection);
		  }
		  */
		 // --------- Location drop down list -------

		  if($window.sessionStorage.getItem('locationDPCollection') == null || $window.sessionStorage.getItem('locationDPCollection')=='undefined' || $window.sessionStorage.getItem('locationDPCollection')==undefined){
			  commonService.getAllPlants()
			  .success(function(response){					 
				  $scope.locations = response.objectList;				
				  $window.sessionStorage.setItem('locationDPCollection',JSON.stringify($scope.locations));
			  })
			  .error(function(response){
			  });
		  }else{
			  $scope.locations = JSON.parse(sessionStorage.locationDPCollection);
		  }
		  
		  // --------- Section drop down list ---------

		  if($window.sessionStorage.getItem('sectionDPCollection') == null || $window.sessionStorage.getItem('sectionDPCollection')=='undefined' || $window.sessionStorage.getItem('sectionDPCollection')==undefined){
			  commonService.getAllSections()
			  .success(function(response){					 
				  $scope.sections = response.objectList;	
				  $window.sessionStorage.setItem('sectionDPCollection',JSON.stringify($scope.sections));
			  })
			  .error(function(response){
			  });
		  }else{
			  $scope.sections = JSON.parse(sessionStorage.sectionDPCollection);
		  }
		  
		 // --------- Line drop down list ---------
/*
		  if($window.sessionStorage.getItem('linesDPCollection') == null || $window.sessionStorage.getItem('linesDPCollection')=='undefined' || $window.sessionStorage.getItem('linesDPCollection')==undefined){
			  commonService.getAllLines()
			  .success(function(response){					 
				  $scope.lines = response.objectList;
				  $window.sessionStorage.setItem('linesDPCollection',JSON.stringify($scope.lines));
			  })
			  .error(function(response){
			  });
		  }else{
			  $scope.lines = JSON.parse(sessionStorage.linesDPCollection);
		  }*/
		  
     var sourceLocTemplate = '<div><a href="" data-toggle="modal" data-target="#sourceLocationModal"  ng-click=grid.appScope.setLocationId(row.entity.partId,row.entity.locationId);>{{COL_FIELD}}</a></div>';
     var moveLocationTemplate = '<div><a href="" data-toggle="modal" data-target="#moveAllRanToDifferentLocationModal" ng-show="row.entity.partNo == null" ng-click=grid.appScope.setLocationId(row.entity.partId,row.entity.locationId,row.entity.newLocations);>MOVE</a></div>';
	 
     var paginationOptions = {
		 	startIndex : 0,
		 	endIndex : 0,
		    pageNumber: 1,
		    pageSize: 5,
		    sort: null
     };
	 $scope.part = {
			  plant : '',
			  shop : '',
             line : '',
             section : '',
             partNo : '',
             ran:'',
             locationId :'',
             startIndex : 0,
             endIndex : 0            
     };
	 var paginationOptions = {
			 	startIndex : 0,
			 	endIndex : 0,
			    pageNumber: 1,
			    pageSize: 100,
			    sort: null
	 };
	 $scope.scockData = [];
	 $scope.gridOptions = {
			 enablePaginationControls:false,
			 enableGridMenu: true,
             enableFiltering: true,
             enableSorting: true,
             enableColumnResize: true,
             enableCellEditOnFocus: true,
             enableCellEdit: true,
             paginationPageSizes: [100,250,500,750,1000],
     	     paginationPageSize: 100,
             treeRowHeaderAlwaysVisible: true,
             showTreeExpandNoChildren: false,
             useExternalPagination: true,
             autoResize:true,
             enablePinning: true,
             columnDefs: [
							{ field: 'partNo',name: 'Part No', width: '15%' ,enableFiltering: false},
							{ field: 'locationId',name: 'Source Location', width: '15%',cellTemplate:sourceLocTemplate},
							{ field: 'currentQty',name: 'Source Quantity', width: '15%' },
							{ field: 'ran',name: 'Source RAN', width: '10%' },
							/*{ field: 'ran',name: 'Source RAN', width: '10%' },*/
							{ field: '',name: 'Move', width: '10%',cellTemplate:moveLocationTemplate },
							{ field: 'newLocations',name: 'New Location', width: '15%',
								cellTemplate:'<select class="uiGridDP col-md-10" ng-model="row.entity.selectedLoc" ng-show="row.entity.partNo == null" ng-options="p as p for p in row.entity.newLocations"><option value="">--Select Location--</option></select>'
							},
							{ name: 'New Quantity', width: '10%',
								cellTemplate:'<input type="text" class="uiGridInput col-md-10" ng-model="row.entity.newQuan" ng-show="row.entity.partNo == null" nks-Only-Number allow-negative="true" maxlength="7">'
							},
							{ name: 'Reason', width: '15%',
								//cellTemplate:'<input type="text" class="uiGridInput col-md-10" ng-model="row.entity.comments" ng-show="row.entity.partNo == null" maxlength="100">'
								cellTemplate:'<select class="uiGridDP col-md-10" ng-model="row.entity.comments"  ng-show="row.entity.partNo == null" ng-options="p.reasonName as p.reasonName   for p in grid.appScope.stockCorrectionReasons"><option value="">--Select Reason--</option></select>'
									/*ng-options=" s.shopId as s.shopId  + ' - ' + s.shopName for s in shops | orderBy:'shopId'"*/
							}
                        ],
                        exporterCsvFilename: 'myFile.csv',
                        exporterMenuVisibleData: false,
                        exporterPdfDefaultStyle: {fontSize: 9},
                        exporterPdfTableStyle: {margin: [30, 30, 30, 30]},
                        exporterPdfTableHeaderStyle: {fontSize: 10, bold: true, italics: true, color: 'red'},
                        exporterPdfHeader: { text: "My Header", style: 'headerStyle' },
                        exporterPdfFooter: function ( currentPage, pageCount ) {
                          return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
                        },
                        exporterPdfCustomFormatter: function ( docDefinition ) {
                          docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
                          docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
                          return docDefinition;
                        },
                        exporterPdfOrientation: 'portrait',
                        exporterPdfPageSize: 'LETTER',
                        exporterPdfMaxGridWidth: 500,
                        exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
                       
                        onRegisterApi: function( gridApi ) {
                        	 $scope.gridApi = gridApi;
                        	 var totalItems = gridApi.grid.options.totalItems;
                        	 
                        	 gridApi.selection.on.rowSelectionChanged($scope,function(row){
                        		 
                        	        if(row.isSelected==true){
                        	            var childRows   = row.treeNode.children;
                        	            for (var j = 0, length = childRows.length; j < length; j++) {
                        	                var rowEntity   = childRows[j].row.entity;
                        	                childRows[j].row.entity.enableSubmit = true;
                        	                $scope.gridApi.selection.selectRow(rowEntity);
                        	            }
                        	            if(childRows.length == 0){
                        	            	row.entity.enableSubmit = true;
                        	            }
                        	        }

                        	        if(row.isSelected==false){
                        	            var childRows   = row.treeNode.children;
                        	            for (var j = 0, length = childRows.length; j < length; j++) {
                        	                var rowEntity   = childRows[j].row.entity;
                        	                childRows[j].row.entity.enableSubmit = false;
                        	                $scope.gridApi.selection.unSelectRow(rowEntity);
                        	            }
                        	            if(childRows.length == 0){
                        	            	row.entity.enableSubmit = false;
                        	            }
                        	        }
                        	        
                        	 });
                        	 
                        	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                        		 $scope.blockUI();
                        		 paginationOptions.pageNumber = newPage;
                        		 paginationOptions.pageSize = pageSize;
                        		 paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
                        		 paginationOptions.endIndex   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < totalItems) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : gridApi.grid.options.totalItems);
                        		 $scope.load();
             		        });
                	    }
		    };

	 		/* Load data in grid */
		    $scope.load = function () {
		    	if(paginationOptions.endIndex === 0){
		    		paginationOptions.endIndex = $scope.gridOptions.paginationPageSize;
		    	}
		    	
		    	$scope.part.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

		    	if(paginationOptions.endIndex === 0){
		    		$scope.part.endIndex = $scope.gridOptions.paginationPageSize;
		    	}
		    	$scope.part.startIndex = paginationOptions.startIndex;
		    	$scope.part.endIndex = paginationOptions.pageSize;
		    	$scope.part.partNo=$scope.partNumber;
		    	$scope.part.locationId=$scope.location;
		    	
		    	if($scope.validateFilter() == true){
		    		stockCorrectionService.stockLocationReportCount($scope.part).then(function(response){
		    			$scope.gridOptions.totalItems = response.data.object;
		    			$scope.gridOptions.totalServerItems = response.data.object;
		    			$scope.recordCount = response.data.object;
		    			$scope.stockCorrectionDataService();
		    			
		    		});
		    	}else{
		    		 $scope.alerts = [];
					 $scope.alerts.push({
						 type : 'danger',
						 msg : 'Plant/Shop or Part or RAN or Location is/are mandatory'
					 });
					 $.unblockUI();
		    	} 
			    // --End
		    };
		    
		    $scope.stockCorrectionDataService = function(){
		    	
	    		$scope.blockUI();
	    		$scope.part.partNo=$scope.partNumber;
	    		//Service call For Search - Start
	    		
	    	//	stockCorrectionService.searchPartNumber($scope.part)
	    		//q all service change
	    		
	    		stockCorrectionService.stockCorrectionReport($scope.part)
	    		  .then(function(response){
	    		
	    			    $scope.showInst = true;
		    			$scope.scockData = response[0].data.objectList;
		    			$scope.gridOptions.enablePaginationControls=true;		    			
		    			$scope.stockCorrectionReasons=response[1].data.objectList;	
		    			//$scope.stockCorrectionReasons
		    			$rootScope.stockCorrectionReasons=response[1].data.objectList;
		    			
		    			$scope.setupDataForGrid();
		    			$.unblockUI();
		    	  });
	    		/*.success(function(response){	
	    			console.log("Response from Q ALL sucess", response);
	    			$scope.showInst = true;
	    			$scope.scockData = response.objectList;
	    			$scope.gridOptions.enablePaginationControls=true;
	    			$scope.setupDataForGrid();
	    			$.unblockUI();
	    		})
	    		.error(function(response){
	    			console.log("Response from Q ALL fail", response);
	    			$scope.showInst = false;
	    			$scope.alerts = [];
	    			$scope.alerts.push({
	    				type : "danger",
	    				msg : "service failed"
	    			});
	    			$.unblockUI();
	    		});*/ 
		    };
		    
		    //------ UI Purpose----
		    $scope.setupDataForGrid = function(){
		    	
		    	angular.forEach($scope.scockData, function(stockObj, stockObjKey) {
		    		$scope.locCollection = stockObj.newLocations;
		    		angular.forEach(stockObj.locations, function(partLocObj, PartLocKey) {
		    			partLocObj["partId"] = stockObj.partNo;
		    			partLocObj["selectedLoc"] = null;
		    			partLocObj["newQuan"] = "";
		    			partLocObj["comments"] = "";
		    			$scope.LocObj = [];
		    			angular.forEach($scope.locCollection,function(locObj,locKey){
		    				if(partLocObj.locationId !== locObj){
		    					$scope.LocObj.push(locObj);
		    				}
					    });
		    			partLocObj["newLocations"] = $scope.LocObj;
		    		});
		    	});
		    	
		    	$scope.gridOptions.data = [];

		    	//Group creation in data table   
	    		writeoutNode( $scope.scockData, 0, $scope.gridOptions.data );

		    };
		    // --------- search button ---------
		    $rootScope.searchParts = function() {
            	console.log("Search");
            	$scope.alerts = [];
            	$scope.gridOptions.data = [];
            	$scope.part.partNo=$scope.partNumber;
            	$scope.part.locationId=$scope.location;
            	paginationOptions.startIndex= 0;
            	paginationOptions.endIndex= 0;
            	paginationOptions.pageNumber= 1;
            	paginationOptions.pageSize= 100; 
            	$scope.gridOptions.paginationCurrentPage=1;
            	$scope.gridOptions.paginationPageSize=100;
            	$scope.load();
            	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"});
            };
            
            $scope.checkAgedRan = function() {
            	$scope.blockUI();
            	$scope.selectedRows = $scope.gridApi.selection.getSelectedRows();
            	if($scope.selectedRows.length != 0){
	            	$scope.selectedRan = [];
	            	angular.forEach($scope.selectedRows,function(Obj,Key){
	            		if(Obj.locations == null){
	            			$scope.selectedRan.push(Obj.ran);
	            			
	            		}
	            	});
	            	
	            	//Service for Aged Ran check -Start
	            	agedRanForStockCorrection.validateRan($scope.selectedRan).success(function(response){
	            		
	            		if(response.object !== null && response.object!=''){
	            			
	            			//if(response.object.agedRAN == true){
	            				$scope.agedRans=response.object;
	            				$('#agedRanConfirmation').modal('show'); 
	            			//}
	            		}
	            		else
	            		{
	            			$scope.submitParts();
	            		}
	            	});
	            	//End
            	}else{
            		 $scope.alerts = [];
	                 $scope.alerts.push({
	                     type : "danger",
	                     msg : "Please select atleast one row in datatable"
	                });
            	}
            	$.unblockUI();
            };
            
            $scope.submitParts = function() {
            	$('#agedRanConfirmation').modal('hide'); 
            	$scope.outputData = $scope.gridApi.selection.getSelectedRows();
            	$scope.mainObj = [];
            	
            	angular.forEach($scope.outputData,function(Obj,Key){
    				if(Obj.locations == null){
    					var outputToServer = {};
    					outputToServer["partNo"] = Obj.partId;
    					outputToServer["sourceLocation"] = Obj.locationId;
    					outputToServer["correctedLocation"] = Obj.selectedLoc;
    					outputToServer["ran"] = Obj.ran;
    					outputToServer["sourceQty"] = Obj.currentQty;    					
    					outputToServer["correctQty"] = Obj.newQuan;
    					outputToServer["comments"] = Obj.comments;
    					outputToServer["userId"]=$window.sessionStorage.getItem('loggedUserId');
    					$scope.mainObj.push(outputToServer);
    				}
			    });
            	
	            //Validation section
            	$scope.isNotValid = false;
            	$scope.reasonNotSelected=false;
	        	angular.forEach($scope.mainObj,function(Obj,Key){
	        		
	        		if($scope.isNotValid){
						return;
					}
					if(Obj.correctedLocation != null){
						$scope.isNotValid = Number(Obj.correctQty) < 0 || Number(Obj.correctQty) > Number(Obj.sourceQty) ? true : false;
						//$scope.isNotValid = Number(Obj.sourceQty) - Number(Obj.correctQty) < 0 ? true : false;
					}else{
						$scope.isNotValid = Number(Obj.sourceQty) + Number(Obj.correctQty) < 0 ? true : false;
					}
					if(Obj.comments==null || Obj.comments=='')
					{
						$scope.isNotValid=true;
						$scope.reasonNotSelected=true;
						
					}
					
					
			    });
            	
            if($scope.mainObj.length != 0){
            	
            	if(!$scope.isNotValid){
            		//Submit call For Search - Start
            		stockCorrectionService.updateStockCorrection($scope.mainObj)
            		.success(function(msg){					 
            			$scope.alerts = [];
            			$scope.alerts.push({
            				type : msg.statusType,
            				msg : msg.statusMessage,
            				error : msg.exceptionStackTrace,
            				errorClsName : msg.exceptionClassName,
            				errorMsg : msg.exceptionMessage
            			});
            			//Reload the grid
            			$scope.load(); 
            		})
            		.error(function(response){
            			$scope.alerts = [];
            			$scope.alerts.push({
            				type : "danger",
            				msg : "Service failed"
            			});
            		});
            		
            		// --End
            	}else{
            		var errorMessage='';
            		if($scope.reasonNotSelected==true)
            		 {
            			errorMessage = "Please select the reason";
            		 }
            		else{
            			errorMessage = "Source Qty should not become negative";
            			
            		}
            		
            		$scope.alerts = [];
        			$scope.alerts.push({
        				type : 'danger',
        				msg : errorMessage
        			});
            	}
            	  
            	  
            }else{
            		$scope.alerts = [];
	                 $scope.alerts.push({
	                     type : "danger",
	                     msg : "Please select atleast one row in datatable"
	                });

            	}
            $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"});
            };
		    
		    /* Tree view */
            var writeoutNode = function( childArray, currentLevel, dataArray ){
				if (typeof childArray !== 'undefined') {
				      childArray.forEach(function(childNode) {
				        if (typeof childNode.locations !== 'undefined') {
				          if (childNode.locations.length >= 0) {
				            childNode.$$treeLevel = currentLevel;
				          }
				        }
				        dataArray.push(childNode);
				        writeoutNode(childNode.locations, currentLevel + 1, dataArray);
				      });
				    }
			};
			
			$scope.resetParts = function(){
				$scope.shops = "";
		    	$scope.lines = "";
		    	$scope.gridOptions.data = [];
		    	$scope.part = {};
		    	$scope.part.startIndex = 0;
		    	$scope.part.endIndex = 0;
		    	$scope.tags=[];
		    	$scope.ranData=[];
		    	$scope.locationIdData=[];	
		    	$scope.gridOptions.totalItems=0;
		    	$scope.location="";
		    	$scope.partNumber="";
		    	$scope.searchDataEror="Click search to fetch records.";
		    	$scope.showInst = false;
		    	$scope.closeAlert();
		    	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
		    	
	        	$scope.gridOptions.enablePaginationControls=false;
	        	      	
		    };	
			
		   $scope.closeAlert = function(index) {
		        $scope.alerts.splice(index, 1);
		   };
		   
		   $scope.validateFilter = function(){
		    	 if($scope.part.plant !== "" && $scope.part.plant !== null && $scope.part.plant !== undefined && $scope.part.shop !== "" && $scope.part.shop !== null && $scope.part.shop !== undefined)
				 {
					 return true;
				 }
		    	 else if($scope.ranData.length>0 || $scope.tags.length>0 || $scope.locationIdData.length>0){
		    		 return true;
		    	 }
		    	 
		    	 else{
					 return false;
				 }
		   };
		   
		   $scope.setLocationId = function(partNumber,LocId,mappedLocationsArg) {
			  // console.log("Mapped Locations", mappedLocationsArg);
			    Location.partNumber=partNumber;
		    	Location.location=LocId;
		    	Location.mappedLocations=mappedLocationsArg;
		    	//console.log("Mapped Locations1", Location.mappedLocations);
		    	$scope.partHeaderName=LocId;
		    	
		   };
	

} ]);

/*  ******************** Pop up for Add New RAN Controller Starts */
wmsApp.controller('sourceLocationPopupController', [ '$scope','Location','stockCorrectionService','$rootScope','agedRanForStockCorrection',function($scope,Location,stockCorrectionService,$rootScope,agedRanForStockCorrection) {
	
	console.log("sourceLocationPopupController");
	
	$('#sourceLocationModal').on('show.bs.modal', function () {
		$scope.AddSourceLoc = {
				partNo:'',
				locationId:'',
				ran:'',
				currentQty:''
		};
		$scope.alerts = [];
		$scope.enableAdd = false;
		$scope.AddSourceLoc.partNo = Location.partNumber;
		$scope.AddSourceLoc.locationId = Location.location;
		$scope.$digest();
    });
	
	$scope.addValidation = function(){
		if($scope.AddSourceLoc.ran != "" && $scope.AddSourceLoc.ran != null && ($scope.AddSourceLoc.ran.length == 7 || $scope.AddSourceLoc.ran.length == 10) &&
				$scope.AddSourceLoc.currentQty != "" && $scope.AddSourceLoc.currentQty !=null){
			if($scope.AddSourceLoc.ran.length == 7){
				$scope.enableAdd = true;
			}else if($scope.AddSourceLoc.ran.length == 10 && $scope.AddSourceLoc.ran.charAt(7) == '-'){
				$scope.enableAdd = true;
			}else{
				$scope.enableAdd = false;
			}
		}else{
			$scope.enableAdd = false;
		}
	};
	
	$rootScope.addLocation = function(){
		$('#agedRanConfirmation_AddNew').modal('hide');
		stockCorrectionService.addRAN($scope.AddSourceLoc).then(function(response){
			if(response.data != null){
				$scope.alerts = [];
	            $scope.alerts.push({
	                type : response.data.statusType,
	                msg : response.data.statusMessage
	            });
	           /* $scope.AddSourceLoc.ran="";
	            $scope.AddSourceLoc.currentQty="";*/
	            $rootScope.searchParts();
			}
		});	
	};
	
	$scope.checkAgedRan = function() {
     	$scope.blockUI();
     	$scope.selectedRan = [];
     	$scope.selectedRan.push($scope.AddSourceLoc.ran);
     	
     	//Service for Aged Ran check -Start
     	agedRanForStockCorrection.validateRan($scope.selectedRan).success(function(response){
     		if(response.object !== null && response.object!=''){
 				$rootScope.agedRans=response.object;
 				$('#agedRanConfirmation_AddNew').modal('show'); 
     		}
     		else{
     			$rootScope.addLocation();
     		}
     	});
     	$.unblockUI();
     };
	
	//Close the alert msg
    $scope.closeAlert = function(index) {
        $scope.alerts.splice(index, 1);
    };
	
}]);

/* ********************Pop up for Add New RAN Controller Ends */

/*  ******************** Pop up for Add New RAN Controller Starts */
wmsApp.controller('moveAllRanToDifferentLocationPopupController', [ '$scope','Location','stockCorrectionService','$rootScope',function($scope,Location,stockCorrectionService,$rootScope) {
	
	console.log("moveAllRanToDifferentLocationPopupController");
	$scope.mappedLocations='';
	
	$('#moveAllRanToDifferentLocationModal').on('show.bs.modal', function () {
		$scope.MoveAllRanData = {
				partNo:'',
				sourceLocation:'',
				correctedLocation:'',
				
				
		};
		$scope.alerts = [];
		$scope.MoveAllRanData.partNo = Location.partNumber;
		$scope.MoveAllRanData.sourceLocation = Location.location;
		$scope.mappedLocations = Location.mappedLocations;
		
		//Reset the corrected location while pop-up open
		$scope.locationIdData='';
		console.log("In Move location correction reasons root",$scope.stockCorrectionReasons);
		$scope.$digest();
    });
	
	
	$rootScope.moveAllRanToDifferentLoc = function(){
		
		$scope.alerts = [];
		//console.log("Selected Location",$scope.locationIdData[0].text);
		//console.log("Index of ",$scope.MoveAllRanData.mappedLocations.indexOf($scope.locationIdData[0].text));
		if($scope.locationIdData.length!=1){
	        $scope.alerts.push({
	            type : 'danger',
	            msg : 'Please select one destination location'
	        });
		}
		else if($scope.MoveAllRanData.comments==null || $scope.MoveAllRanData.comments==''){
	        $scope.alerts.push({
	            type : 'danger',
	            msg : 'Please select the reason'
	        });
		}
		else if($scope.locationIdData[0].text.charAt(3)=='W' && $scope.mappedLocations.indexOf($scope.locationIdData[0].text)==-1)
		{
			   $scope.alerts.push({
		            type : 'danger',
		            msg : 'The selected location is not mapped to the part number'
		        });
		}
		else{
			$scope.MoveAllRanData.correctedLocation =$scope.locationIdData[0].text;
			console.log("Corrected Location",$scope.locationIdData);
			console.log("Corrected Location 0 ",$scope.locationIdData[0].text);
			//console.log("Corrected Location 1 ",$scope.locationIdData[1]);
			stockCorrectionService.moveAllRanToDifferentLoc($scope.MoveAllRanData).then(function(response){
				if(response.data != null){
					$scope.alerts = [];
		            $scope.alerts.push({
		                type : response.data.statusType,
		                msg : response.data.statusMessage
		            });
		          //  $rootScope.searchParts();
				}
			});
			
		}
        
	/*	$('#agedRanConfirmation_AddNew').modal('hide');
		stockCorrectionService.addRAN($scope.AddSourceLoc).then(function(response){
			if(response.data != null){
				$scope.alerts = [];
	            $scope.alerts.push({
	                type : response.data.statusType,
	                msg : response.data.statusMessage
	            });
	            $rootScope.searchParts();
			}
		});	*/
	};
	
	
/*	$scope.addValidation = function(){
		if($scope.AddSourceLoc.ran != "" && $scope.AddSourceLoc.ran != null && $scope.AddSourceLoc.ran.length == 7 &&
				$scope.AddSourceLoc.currentQty != "" && $scope.AddSourceLoc.currentQty !=null){
			$scope.enableAdd = true;
		}else{
			$scope.enableAdd = false;
		}
	};
	
	$rootScope.addLocation = function(){
		$('#agedRanConfirmation_AddNew').modal('hide');
		stockCorrectionService.addRAN($scope.AddSourceLoc).then(function(response){
			if(response.data != null){
				$scope.alerts = [];
	            $scope.alerts.push({
	                type : response.data.statusType,
	                msg : response.data.statusMessage
	            });
	            $rootScope.searchParts();
			}
		});	
	};
	
	$scope.checkAgedRan = function() {
     	$scope.blockUI();
     	$scope.selectedRan = [];
     	$scope.selectedRan.push($scope.AddSourceLoc.ran);
     	
     	//Service for Aged Ran check -Start
     	agedRanForStockCorrection.validateRan($scope.selectedRan).success(function(response){
     		if(response.object !== null && response.object!=''){
 				$rootScope.agedRans=response.object;
 				$('#agedRanConfirmation_AddNew').modal('show'); 
     		}
     		else{
     			$rootScope.addLocation();
     		}
     	});
     	$.unblockUI();
     };*/
	
	//Close the alert msg
    $scope.closeAlert = function(index) {
        $scope.alerts.splice(index, 1);
    };
	
}]);

/* ********************Pop up for Add New RAN Controller Ends */




wmsApp.factory('agedRanForStockCorrection',['$http',function($http){
    var agedRanForStockCorrection={};
	
    agedRanForStockCorrection.validateRan = function(param)
    {
    	return $http({
			method : 'POST',
			url : 'rest/ran/checkAgedRAN',
			data : JSON.stringify(param),
			headers: {'Content-Type': 'application/json'}
		});
	};
	
	return agedRanForStockCorrection;
}]);