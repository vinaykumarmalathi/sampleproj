wmsApp.controller('partsAuditByLocationController', 
		[ '$scope','$window','$filter', '$location', '$routeParams', 'partsAuditByLocationService', '$http','commonService','Location',		  
        function($scope,$window,$filter, $location, $routeParams, partsAuditByLocationService, $http,commonService,Location) {	
			$scope.searchModelDataEror="";
			    $scope.searchClicked=false;			
			    $scope.resetSearch= function() {
			    	  $scope.location.location='';
			    	  /*$scope.location.startIndex=0;
			    	  $scope.location.endIndex=0;*/			    	  
			    };		
			    			 
			 var paginationOptions = {
					 	startIndex : 0,
					 	endIndex : 0,
					    pageNumber: 1,
					    pageSize: 5,
					    sort: null
					  };			 
			 $('#locationTrackerModal').on('show.bs.modal', function () {
				
			    	Location.location=Location.location.split('-');
			    	Location.location=Location.location[0];
			    	Location.location=Location.location.replace(/[\s]/g, '');				    	
			    	 $scope.location = {
							 location : Location.location
		                   /*  startIndex : 0,
		                     endIndex : 0*/
		                 };			    	 			    	 
			            	$scope.searchClicked=true;
			            	$scope.clearFilters();
			            	//$scope.gridOptions.enableFiltering =  true;
			            	$scope.load();		          
			    	});
			 
	 $scope.gridOptions = {
			 enableGridMenu: true,
             enableFiltering: true,
             //useExternalFiltering: true,
             enableColumnResize: true,
             paginationPageSizes: [5,10,15,20,25, 50, 75],
     	     paginationPageSize: 5,          
             useExternalPagination: true,
             autoResize:true,  
             enablePinning: true,     
             exporterMenuVisibleData: false,
             enableColumnResizing: true,
             columnDefs: [
                               
					       	{ field: 'partNumber', displayName: 'Part Number', width:"10%"},
					       	{ field: 'location', displayName: 'Location', width:"10%"},
					       	{ field: 'ran', displayName: 'RAN', width:"10%"},
					       	{ field: 'transactionType', displayName: 'Txn Type', width:"8%"},
					       	{ field: 'count', displayName: 'Count', width:"7%"},
					        { field: 'ran', displayName: 'RAN',visible: false,width:"5%"},
					       	{ field: 'userId', displayName: 'User', width:"5%"},
					       	{ field: 'deviceId', displayName: 'Device', width:"10%"},
					       	{ field: 'partInOutTime', displayName: 'Date Time' ,type: 'date', cellFilter: 'date:"medium"', width:"17%"},
					       	{ field: 'reasonCode', displayName: 'Reason', width:"10%"},
					       	{ field: 'comments', displayName: 'Comments', width:"18%"}
					       	  
					       	      
                        ],
                        exporterCsvFilename: 'locationTracker.csv',                       
                        exporterPdfDefaultStyle: {fontSize: 9},
                        exporterPdfTableStyle: {margin: [30, 30, 30, 30]},
                        exporterPdfTableHeaderStyle: {fontSize: 10, bold: true, italics: true, color: 'red'},
                        exporterPdfHeader: { text: "My Header", style: 'headerStyle' },
                        exporterPdfFooter: function ( currentPage, pageCount ) {
                          return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
                        },
                        exporterPdfCustomFormatter: function ( docDefinition ) {
                          docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
                          docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
                          return docDefinition;
                        },
                        exporterPdfOrientation: 'portrait',
                        exporterPdfPageSize: 'LETTER',
                        exporterPdfMaxGridWidth: 500,
                        exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
                       
                        onRegisterApi: function( gridApi ) {
                        	 $scope.gridApi = gridApi;
                        	/* var totalItems = gridApi.grid.options.totalItems;*/
                        	 $scope.load();
                        	/* gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
             		          paginationOptions.pageNumber = newPage;
             		          paginationOptions.pageSize = pageSize;
             		         //paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
             		        //paginationOptions.endIndex   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < totalItems) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : gridApi.grid.options.totalItems);
             		        $scope.load();
             		        });*/
                       	
                	    }
		    };
 
	 $scope.clearFilters = function() {
		 $scope.gridApi.core.clearAllFilters();
     };
   
	 		/* Load data in grid */
		    $scope.load = function () {
		    	if(paginationOptions.endIndex === 0){
		    		paginationOptions.endIndex = $scope.gridOptions.paginationPageSize;
		    	}
		    	//$scope.location.startIndex = paginationOptions.startIndex;
		    	//$scope.location.endIndex = paginationOptions.endIndex;
		    	if($scope.location!=''){
		    	partsAuditByLocationService.locationreport($scope.location).then(function(response){
		    	
		    		$scope.gridOptions.data = [];
		    		
		    		if(response.data.objectList !== undefined){
		    			/*$scope.gridOptions.totalItems = response.data.objectList[0].recordCount;*/
		    			/*$scope.gridOptions.data = response.data.objectList;*/
		    			
		    			 response.data.objectList.forEach(function(row){	    	    	                   
	    	    	           row.partInOutTime =$filter('date')(row.partInOutTime, 'MMM d, yyyy HH:mm:ss a')
	    	    	           $scope.gridOptions.data = response.data.objectList;	 
	    	    	          });
		    			
		    			
			    		$scope.alerts = [];
			            $scope.alerts.push({
			                type : response.data.statusType,
			                msg : response.data.statusMessage,
			                error : response.data.exceptionStackTrace,
			                errorClsName : response.data.exceptionClassName,
			                errorMsg : response.data.exceptionMessage
			            });
			    		
		    		} else {
		    			$scope.searchModelDataEror=response.data.statusMessage;
		    			/*$scope.alerts = [];
			            $scope.alerts.push({
			                type : 'danger',
			                msg : 'No records available'
			            });*/
			            console.log('else  -------------> ',$scope.alerts);
		    		}
		    	
		    	});
		    	}
		    };
		    
		    // --------- search button ---------
            $scope.searchParts = function() {
            	$scope.searchClicked=true;
            	$scope.clearFilters();
            	$scope.gridOptions.enableFiltering =  true;
            	 $scope.load();
            };
		    
		
		    $scope.closeAlert = function(index) {
		        $scope.alerts.splice(index, 1);
		    };
		   
		
} ]);