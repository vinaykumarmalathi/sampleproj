wmsApp.controller('partsMasterDataController', 			
			[ '$scope','$window','$filter','$location', 'partsMasterService','locationService','uiGridTreeViewConstants', '$http','commonService','partNumberService','PartNumberInterService','RemarksInterService','partLocationService',
		        function($scope,$window,$filter,$location, partsMasterService,locationService,uiGridTreeViewConstants, $http,commonService,partNumberService,PartNumberInterService,RemarksInterService,partLocationService) {
					
			$scope.searchDataEror="Click search to fetch records.";

			$scope.populateClicked=false;
			$scope.addNewButton=true;
			$scope.enableAdd = false;
			 $scope.part = {
					  partNumber:"",
					  plant:"",
					  shop:"",
					  line:"",
					  category:"",
					  partType:"",
					  supplierCode:"",
					  locations:"",
					  unreleasedParts:"",
					  supplierCode:"",
	                  startIndex : 0,
	                  endIndex : 0
	          };
			  
			  $scope.map = {							    	 
					  partNumber : '',
					  partName : '',
					  partType:'',
					  snp:'',
					  category:'',
					  safetyStock:'',
					  supplierCode:'',
					  depoCode:'',
					  rePackingFlag:'',
					  comments : '',
					  locations : ''
	              };
			     
			    $scope.addPart = {
			    		  adoptDate : '',
			    		  category:'',
			    		  depoCode:'',
			    		  dolFlag:'',
			    		  dtlFlag:'',
			    		  mixedModule:'',
			    		  partName:'',
			    		  partNumber:'',
			    		  partType:'',
			    		  rePackingFlag:'',
			    		  receivingPort:'',
			    		  remarks:'',
			    		  repackSNP:'',
			    		  shelfLifePeriod:'',
			    		  shelfLifePart:'', 
			    		  snip:'',
			    		  snp:'',
			    		  shelfLifeAging:'', //Added For aging calculation
			    		  partCategory:'' // adding part type like rubber
			    }; 
			    
			    $scope.categoryModel = [
			                            {"categoryId":"D","categoryName":"D - Direct parts"},
			                            {"categoryId":"R","categoryName":"R - Re-packing parts"},
			                            {"categoryId":"B","categoryName":"B - Bulk Parts"},
			                            {"categoryId":"C","categoryName":"C - Consignee"}
			                           ];

				 var paginationOptions = {
					 	startIndex : 0,
					 	endIndex : 0,
					    pageNumber: 0,
					    pageSize: 100,
					    sort: null
					  };
			  
			
			
			// --------- Part Number List ---------			
			$scope.tags=[];	 
			/*ON ADD NEW PART TAG*/
			
			/*$scope.pasteTags = function(event){
				  event.preventDefault();
				  
				  //For IE
				  if ($window.clipboardData && $window.clipboardData.getData) {
					  $scope.tagsCopies = $window.clipboardData.getData('Text').split(/[\n\t\s]+/);
					  console.log("IE");
					  console.log("$scope.tagsCopies",$scope.tagsCopies);
				  }
				  // Other Browsers
				  else if (event.originalEvent.clipboardData && event.originalEvent.clipboardData.getData) { 
					  $scope.tagsCopies = event.originalEvent.clipboardData.getData('text/plain').split(/[\n\t\s]+/);
					  console.log("Other Browser");
					  console.log("$scope.tagsCopies",$scope.tagsCopies);
				  }
			      
			      $scope.tagsCopies = $scope.findDuplicate($scope.tagsCopies);
			      $scope.partNumberArray = [];
			      if($scope.partNumber != undefined){
			    	  $scope.partNumberArray = $scope.partNumber.split(',');
			      }
			      for (var j=0; j < $scope.tagsCopies.length; j++) {
			    	      var obj = {};
			    	      // Condition to check if string is not empty and whitespace
			    	      $scope.tagsCopies[j] = $scope.tagsCopies[j].trim();
			    	      // Checking duplication for copy content with existing tags
			    	      var Index = $scope.partNumberArray.indexOf($scope.tagsCopies[j]);
			    	      if($scope.tagsCopies[j] != "" && Index == -1){
			    	    	  obj['text'] = $scope.tagsCopies[j];
			    	    	  $scope.tags.push(obj);
			    	    	  $scope.tagAdded(obj);
			    	      }
				  }
			      setTimeout(function(){
			    	    $scope.$digest();
			      }, 100);
			     
			};*/
			
			$scope.findDuplicate= function(arra1) {
				  var i,len=arra1.length,result = [],obj = {};
				  for (i=0; i<len; i++) {
				    obj[arra1[i]]=0;
				  }
				  for (i in obj) {
				    result.push(i);
				  }
				  return result;
		    };
			
			$scope.tagAdded = function(tag) {	
				
				  $scope.partArray = [];
				     for (var j=0; j < $scope.tags.length; j++) {
				    	 $scope.partArray.push($scope.tags[j].text);
				      }
				     $scope.partNumber=$scope.partArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
				    
			};
			/*ON REMOVE ADDED PART TAG*/
			    
		    $scope.tagRemoved = function(tag) {	
		    	 $scope.partArray = [];
			     for (var j=0; j < $scope.tags.length; j++) {

			    	 $scope.partArray.push($scope.tags[j].text);
			      }
			     $scope.partNumber=$scope.partArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
			
		    /*AUTOCOMPLE PART ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadParts = function(query) {	
		    	var partInputObj = {"partNumber": query};			    	
		    	return partNumberService.partNumberList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    });			    				         
		    };
		    
		 // --------- Shops drop down list ---------
		    
		    $scope.loadShopLine = function(){
		    	 $scope.part.line = '';
		    	 $scope.part.shop = '';
		    	 commonService.getLineList($scope.part.plant)
				  .success(function(response){
					  $scope.lines = response.objectList;				
				  })
				  .error(function(response){
				  });
		    	 commonService.getShopList($scope.part.plant)
				  .success(function(response){
					  $scope.shops = response.objectList;				
				  })
				  .error(function(response){
				  });

		    }
			   
			 /* if($window.sessionStorage.getItem('shopDPCollection') == null || $window.sessionStorage.getItem('shopDPCollection')=='undefined' || $window.sessionStorage.getItem('shopDPCollection')==undefined){
				  commonService.getAllShop()
				  .success(function(response){						  
					  $scope.shops = response.objectList;				
					  $window.sessionStorage.setItem('shopDPCollection',JSON.stringify($scope.shops));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.shops = JSON.parse(sessionStorage.shopDPCollection);
			  }*/
			  
			// --------- Location drop down list -------

			  if($window.sessionStorage.getItem('locationDPCollection') == null || $window.sessionStorage.getItem('locationDPCollection')=='undefined' || $window.sessionStorage.getItem('locationDPCollection')==undefined){
				  commonService.getAllPlants()
				  .success(function(response){	
					  $scope.locations = response.objectList;				
					  $window.sessionStorage.setItem('locationDPCollection',JSON.stringify($scope.locations));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.locations = JSON.parse(sessionStorage.locationDPCollection);
			  }
			  
			 // --------- Line drop down list ---------

			  /*if($window.sessionStorage.getItem('linesDPCollection') == null || $window.sessionStorage.getItem('linesDPCollection')=='undefined' || $window.sessionStorage.getItem('linesDPCollection')==undefined){
				  commonService.getAllLines()
				  .success(function(response){					 
					  $scope.lines = response.objectList;
					  $window.sessionStorage.setItem('linesDPCollection',JSON.stringify($scope.lines));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.lines = JSON.parse(sessionStorage.linesDPCollection);
			  }*/
		    
		 // --------- SUPPLIER CODE LIST ---------			
		    $scope.supplierTags=[];	 
			/*ON ADD NEW Supplier TAG*/
			
			$scope.supplierTagsAdded = function(tag) {				
				  $scope.supplierArray = [];
				     for (var j=0; j < $scope.supplierTags.length; j++) {
				    	 $scope.supplierArray.push($scope.supplierTags[j].text);
				      }
				     $scope.searchSupplierCode=$scope.supplierArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			/*ON REMOVE ADDED Supplier TAG*/
			    
		    $scope.supplierTagsRemoved = function(tag) {			   
		    	 $scope.supplierArray = [];
			     for (var j=0; j < $scope.supplierTags.length; j++) {
			    	 $scope.supplierArray.push($scope.supplierTags[j].text);
			      }
			     $scope.searchSupplierCode=$scope.supplierArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
			
			
		    // --------- LOCATION LIST ---------	
		    /*ON ADD NEW LOCATION TAG*/
		    
			$scope.location="";
			$scope.locationIdData=[];	 
		    $scope.locationAdded = function(tag) {					
		    $scope.locationArray = [];
			    for (var j=0; j < $scope.locationIdData.length; j++) {
			    	$scope.locationArray.push($scope.locationIdData[j].text);
			    }
			    $scope.location=$scope.locationArray.join(',');
			    $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    /*ON REMOVE ADDED LOCATION TAG*/
		    
		    $scope.locationRemoved = function(tag) {			   
		    	 $scope.locationArray = [];
			     for (var j=0; j < $scope.locationIdData.length; j++) {
			    	 $scope.locationArray.push($scope.locationIdData[j].text);
			     }
			     $scope.location=$scope.locationArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    		    
		    $scope.locationRemoving = function(tag) {		   
		    	if(tag.count!=0){
		    	return false;
		    	}		    	 
		    };
				    
		    /*AUTOCOMPLE LOCATION ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadLocation = function(query) {
		    	
		    	var locationInputObj = {"locationId": query};			    	
		    	return locationService.locationList(locationInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){			        					        			 		        			
		        			 var ary = [];							    										    		
		    				   angular.forEach(response.data.object, function(value, key){			    					  
		    					  var obj = {};	
		    					   obj['text'] = value.text;
		    					   obj['count'] = 0;
			    				   ary.push(obj);
		    					   });
		    				   return JSON.parse(JSON.stringify(ary));		        			 
		        		 }
		        	 }		    		
			    	});			    				         
		    };
			    			    
			/*RESET WHOLE SCREEN*/  
			  $scope.resetParts = function(){
				  $('div').removeClass('has-error');
				  $scope.shops = "";
			      $scope.lines = "";
				  $scope.part = {		
						  partNumber:"",
						  plant:"",
						  shop:"",
						  line:"",
						  partType:"",
						  supplierCode:"",
						  locations:"",
						  unreleasedParts:false,
						  supplierCode:"",
		                  startIndex : 0,
		                  endIndex : 0
		          };
				  // shelfLifeAging - Added For aging calculation
				  $scope.addPart = {
	            		  adoptDate : '',category:'',depoCode:'',dolFlag:'',dtlFlag:'',eopMark:'',mixedModule:'',partName:'',partNumber:'',partType:'',rePackingFlag:'',
			    		  receivingPort:'',remarks:'',repackSNP:'',shelfLifePeriod:'',shelfLifePart:'',shelfLifeAging:'',snip:'',snp:''
			    }; 
				  $scope.enableAdd = false;
			    	$scope.gridOptions.data = [];
			    	$scope.clearFilters();
			    	$scope.searchSupplierCode="";
			    	$scope.partNumber="";
			    	$scope.gridOptions.enablePaginationControls=false;			
			    	$scope.gridOptions.totalItems=0;		    	
			    	$scope.tags=[];
			    	$scope.supplierTags=[];		
			    	$scope.searchDataEror="Click search to fetch records.";
			    	$scope.map.locations = "";
			    	$scope.locationIdData=[];							    	
			    	$scope.location="";	
			    	$scope.map = {};
			    	$scope.populateClicked=false;
    				$scope.addNewButton=true;
    				$scope.enableRemark=false;
			    	$scope.closeAlert();
			    	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			    
			    /*Reset search */  
				  $scope.resetSearch = function(){
					  $scope.part = {		
							  partNumber:"",
							  plant:"",
							  shop:"",
							  line:"",
							  partType:"",
							  supplierCode:"",
							  locations:"",
							  unreleasedParts:false,
							  supplierCode:"",
			                  startIndex : 0,
			                  endIndex : 0
			          };
				    	$scope.clearFilters();
				    	$scope.searchSupplierCode="";
				    	$scope.partNumber="";
				    	$scope.tags=[];
				    	$scope.supplierTags=[];		
				    	$scope.map.locations = "";
				    	$scope.locationIdData=[];							    	
				    	$scope.location="";	
				    	$scope.map = {};				    	
				   };
			    
			    var data = [];
			    $scope.data = [];
			    
			   /* $scope.changeDate = function(row){
			    	console.log("Row inside ChangeDate");
			    	console.log(row);
			    	var date = $('.editAdoptDate').datepicker('getDate');
			    	console.log(date);
			    	var dateValue = date.getDate();
			    	var monthValue = date.getMonth();
			    	var yearValue = date.getYear();
			    	var newDateValue = yearValue + '-' + monthValue + '-' + dateValue;
			    	row.entity.editAbolishDate = newDateValue;
			    };*/
			    
			    
			    
				$scope.gridOptions = {						
						 enablePaginationControls:false,
						 enableGridMenu: true,
			             enableFiltering: false,            
			             enableColumnResize: true,
			             paginationPageSizes: [100,250,500,750,1000],
			     	     paginationPageSize: 100,         
			             useExternalPagination: true,
			             autoResize:true,
			             enableSorting: true,
			             enableColumnMenus :true,
			             enablePinning: true,    
			             enableRowSelection: true,
			             enableSelectAll: true,
			             enableRowHeaderSelection: true,
			             showColumnFooter: true,
			             columnDefs:[
									{
				                    	field: 'partType',type: 'object',headerCellClass: 'center editableField',displayName: 'A/B',width:50, pinnedLeft:true,cellTemplate:'<div class="dataCenter">{{row.entity.partType}}</div>',
				                    	footerCellTemplate: '<div style="margin: 4% 30%;"><select class="slectboxAlign" ng-model="grid.appScope.addPart.partType" ng-change="grid.appScope.addBtnValidation()">'+
			                    		   '<option value="A">A</option>'+
			                    		   '<option value="B">B</option>'+
			                    		   '</select></div>',
				                    },
				                    {
				                    	field: 'partNumber',type: 'object',displayName: 'R', pinnedLeft:true,width:30, headerCellClass: 'center nonEditableField',cellTemplate:'<div style="text-align: center;" ng-show="row.entity.noOfLocations > 0">*</div>',
				                    },
				                    {
				                    	field: 'partNumber',type: 'object',displayName: 'Part No', pinnedLeft:true,width:90, headerCellClass: 'center editableField',cellTemplate:'<div title="Not Updated" ng-class="{partUpdate: (row.entity.noOfLocations > 0)}">{{row.entity.partNumber}}</div>',
				                    	footerCellTemplate: '<div><input type="text" class="form-control input-sm" placeholder="Part Number" maxlength="10" ng-model="grid.appScope.addPart.partNumber" alpha-Numeric rel="txtTooltip" title="Click Add button to save your data" data-toggle="tooltip" ng-change="grid.appScope.addBtnValidation()"></div>',
				                    },
				                    {
				                    	field: 'partName',type: 'object',displayName: 'Part Name', width:80, headerCellClass: 'center nonEditableField',cellTemplate:'<div class="dataCenter">{{row.entity.partName}}</div>',
				                    	footerCellTemplate: '<div><input type="text" class="form-control input-sm" placeholder="Part Name" maxlength="50" ng-model="grid.appScope.addPart.partName" alpha-Numeric rel="txtTooltip" title="Click Add button to save your data" data-toggle="tooltip" ng-change="grid.appScope.addBtnValidation()"></div>',
				                    },
				                    {
				                    	field: 'supplierCode',type: 'object',displayName: 'Sup Code',headerCellClass: 'center nonEditableField',width:70, cellTemplate:'<div class="dataCenter">{{row.entity.supplierCode}}</div>',
				                    	footerCellTemplate: '<div><input placeholder="Supplier Code" maxlength="15" ng-model="grid.appScope.addPart.supplierCode" type="text" class="form-control input-sm" rel="txtTooltip" title="Click Add button to save your data" data-toggle="tooltip" ng-change="grid.appScope.addBtnValidation()"></div>',
				                    },
				                    {
				                    	field: 'depoCode',type: 'object',displayName: 'Depo',width:50, headerCellClass: 'center nonEditableField',cellTemplate:'<div class="dataCenter">{{row.entity.depoCode}}</div>',
				                    	footerCellTemplate: '<div><input placeholder="Depo Code" maxlength="15" ng-model="grid.appScope.addPart.depoCode" type="text" class="form-control input-sm" rel="txtTooltip" title="Click Add button to save your data" data-toggle="tooltip" ng-change="grid.appScope.addBtnValidation()"></div>',
				                    },
				                    {
				                    	field: 'snp',type: 'object', displayName: 'SNEP', width:60, headerCellClass: 'center editableField',cellTemplate:'<div><input ng-class="{editInputVal: row.entity.editsnp != row.entity.snp, editInput: row.entity.editsnp == row.entity.snp }" numbers-only maxlength="5" ng-show="row.isSelected" type="text" ng-model="row.entity.editsnp"></input></div><div ng-show="!row.isSelected" class="dataCenter">{{row.entity.snp}}</div>',
				                    	footerCellTemplate: '<div><input placeholder="SNEP" ng-model="grid.appScope.addPart.snp" maxlength="5" type="text" numbers-Only class="form-control input-sm" rel="txtTooltip" title="Click Add button to save your data" data-toggle="tooltip" ng-change="grid.appScope.addBtnValidation()"></div>',
				                    },
				                    {
				                    	field: 'snip',type: 'object', displayName: 'SNIP', width:50, headerCellClass: 'center nonEditableField', cellTemplate:'<div><input ng-class="{editInputVal: row.entity.editsnip != row.entity.snip, editInput: row.entity.editsnip == row.entity.snip }" numbers-only maxlength="5" type="text" ng-show="row.isSelected" ng-model="row.entity.editsnip"></input></div><div ng-show="!row.isSelected" class="dataCenter">{{row.entity.snip}}</div>',
				                    	footerCellTemplate: '<div><input placeholder="SNIP" numbers-Only ng-model="grid.appScope.addPart.snip" maxlength="5" type="text" class="form-control input-sm" rel="txtTooltip" title="Click Add button to save your data" data-toggle="tooltip" ng-change="grid.appScope.addBtnValidation()"></div>',
				                    },
				                    {
				                    	field: 'receivingPort',type: 'object',displayName: 'Rec.Port',headerCellClass: 'center nonEditableField',width:60, cellTemplate:'<div class="dataCenter">{{row.entity.receivingPort}}</div>',
				                    	footerCellTemplate: '<div><input placeholder="Receiving Port" ng-model="grid.appScope.addPart.receivingPort" maxlength="30" type="text" class="form-control input-sm" rel="txtTooltip" title="Click Add button to save your data" data-toggle="tooltip" ng-change="grid.appScope.addBtnValidation()"></div>',
				                    },
				                    {
				                    	field: 'eopMark',type: 'object',displayName: 'EOP',width:50, headerCellClass: 'center nonEditableField',cellTemplate:'<div class="dataCenter">{{row.entity.eopMark}}</div>',
				                    	footerCellTemplate: '<div><input placeholder="EOP" ng-model="grid.appScope.addPart.eopMark" maxlength="5" type="text" class="form-control input-sm" rel="txtTooltip" title="Click Add button to save your data" data-toggle="tooltip" ng-change="grid.appScope.addBtnValidation()"></div>',	
				                    },
				                      // New Fields - Start				                    
				                    {
				                    	field: 'adoptDate',displayName: 'Adopt Date',width:80, type: 'object',headerCellClass: 'center nonEditableField', cellFilter:'date:"yyyy-MM-dd"',cellTemplate: '<div ng-show="row.isSelected"><input class="editInput editAdoptDate" type="text" ng-model="row.entity.editAdoptDate" date-Picker /></div><div ng-show="!row.isSelected">{{MODEL_COL_FIELD}}</div>',
				                    	footerCellTemplate:'<input type="text" class="inPboxAlign" ng-model="grid.appScope.addPart.adoptDate" date-Picker ng-change="grid.appScope.addBtnValidation()"/>',
				                    },
				                    
				                   
				                    {
				                    	field: 'abolishDate',displayName: 'Abolish Date',width:80, type: 'object',headerCellClass: 'center nonEditableField',cellFilter:'date:"yyyy-MM-dd"',cellTemplate: '<div ng-show="row.isSelected"><input class="editInput editAbolishDate" type="text" ng-model="row.entity.editAbolishDate" date-Picker /></div><div ng-show="!row.isSelected">{{MODEL_COL_FIELD}}</div>',
				                    	footerCellTemplate:'<input type="text" class="inPboxAlign" ng-model="grid.appScope.addPart.abolishDate" date-Picker ng-change="grid.appScope.addBtnValidation()"/>',
				                    },
				                    // New Field added		
				                    {
				                    	field: 'partCategory',type: 'object',enableCellEdit: false,displayName: 'Part Type',width:75, headerCellClass: 'center editableField',cellTemplate:'<div><div ng-show="row.isSelected" class="cellAdjust text-center"><select ng-model="row.entity.editPartCategory"><option value="Metal">Metal</option><option value="Rubber">Rubber</option><option value="Plastic">Plastic</option><option value="Adhesive">Adhesive</option></select></div></div><div ng-show="!row.isSelected" class="text-center">{{row.entity.partCategory}}</div>',
				                    	footerCellTemplate: '<div style="margin: 4% 30%;"><select class="slectboxAlign" ng-model="grid.appScope.addPart.partCategory" ng-change="grid.appScope.addBtnValidation()">'+
				                    	'<option value="">--Select--</option>'+
				                    	'<option value="Metal">Metal</option>'+
				                    	'<option value="Rubber">Rubber</option>'+
				                    	'<option value="Plastic">Plastic</option>'+
				                    	'<option value="Adhesive">Adhesive</option>' +
				              
			                    		   '</select></div>',
				                    },
				             				                    	
				                    {
				                    	field: 'category',type: 'object',displayName: 'Category',width:70, headerCellClass: 'center nonEditableField',cellTemplate:'<div><div style="margin: 4% 30%;" ng-show="row.isSelected"><select class="footerDropboxAlign" ng-options="p.categoryId as p.categoryName for p in grid.appScope.categoryModel" ng-model="row.entity.editCategory"><option value="">--Select--</option></select></div><div ng-show="!row.isSelected" class="dataCenter">{{row.entity.categoryDesc}}</div></div>',
				                    	//field: 'category',type: 'object',displayName: 'Category',width:70, headerCellClass: 'center editableField',cellTemplate:'<div><div style="margin: 4% 30%;" ng-show="row.isSelected"><select class="footerDropboxAlign" ng-model="row.entity.editCategory"><option ng-repeat="option in grid.appScope.categoryModel" ng-value="option.categoryId">{{option.categoryName}}</option></select></div><div ng-show="!row.isSelected" class="dataCenter">{{row.entity.category}}</div></div>',
				                    	/*field: 'category',type: 'object',displayName: 'Category',width:70, headerCellClass: 'center editableField',cellTemplate:'<div><div style="margin: 4% 30%;" ng-show="row.isSelected"><select class="footerDropboxAlign" ng-model="row.entity.editCategory"><option value="Repack">R - Re-packing parts</option><option value="Direct">D - Direct parts</option><option value="Bulk">B - Bulk Parts</option><option value="Consignee">C - Consignee</option></select></div><div ng-show="!row.isSelected" class="dataCenter">{{row.entity.category}}</div></div>',*/
				                    	footerCellTemplate: '<div style="margin: 4% 30%;"><select class="footerDropboxAlign" ng-options="p.categoryId as p.categoryName for p in grid.appScope.categoryModel" ng-model="grid.appScope.addPart.category" ng-change="grid.appScope.addBtnValidation()">'+
			                    		   '<option value="">--Select--</option>'+
			                    		   '</select></div>',
				                    },
       				                    //shelfLifeAging - Added For aging calculation
				                    {
				                    	field: 'shelfLifeAging',type: 'object',enableCellEdit: false,displayName: 'Shelf Part',width:75, headerCellClass: 'center editableField',cellTemplate:'<div><div ng-show="row.isSelected" class="cellAdjust text-center"><select ng-model="row.entity.editShelfLifeAging"><option value="Yes">Yes</option><option value="No">No</option></select></div></div><div ng-show="!row.isSelected" class="text-center">{{row.entity.shelfLifeAging}}</div>',
				                    	footerCellTemplate: '<div style="margin: 4% 30%;"><select class="slectboxAlign" ng-model="grid.appScope.addPart.shelfLifeAging" ng-change="grid.appScope.addBtnValidation()">'+
			                    		   '<option value="Yes">Yes</option>'+
			                    		   '<option value="No">No</option>'+
			                    		   '</select></div>',
				                    },
				                    {
				                    	field: 'shelfLifePart',type: 'object',enableCellEdit: false,displayName: 'FIFO Available',width:75, headerCellClass: 'center editableField',cellTemplate:'<div><div ng-show="row.isSelected" class="cellAdjust text-center"><select ng-model="row.entity.editShelfLifePart"><option value="Yes">Yes</option><option value="No">No</option></select></div></div><div ng-show="!row.isSelected" class="text-center">{{row.entity.shelfLifePart}}</div>',
				                    	footerCellTemplate: '<div style="margin: 4% 30%;"><select class="slectboxAlign" ng-model="grid.appScope.addPart.shelfLifePart" ng-change="grid.appScope.addBtnValidation()">'+
			                    		   '<option value="Yes">Yes</option>'+
			                    		   '<option value="No">No</option>'+
			                    		   '</select></div>',
				                    },
				                    {
				                    	field: 'shelfLifePeriod',type: 'object',displayName: 'Shelf Period',enableCellEdit: false,width:75, headerCellClass: 'center editableField',cellTemplate:'<div><input ng-class="{editInputVal: row.entity.editShelfLifePeriod != row.entity.shelfLifePeriod, editInput: row.entity.editShelfLifePeriod == row.entity.shelfLifePeriod }" numbers-only maxlength="3" ng-show="row.isSelected" type="text" ng-model="row.entity.editShelfLifePeriod"></input></div><div ng-show="!row.isSelected" class="dataCenter">{{row.entity.shelfLifePeriod}}</div>',
				                    	footerCellTemplate: '<div><input placeholder="Shelf Period" maxlength="3" ng-model="grid.appScope.addPart.shelfLifePeriod" numbers-Only type="text" class="form-control input-sm" rel="txtTooltip" title="Click Add button to save your data" data-toggle="tooltip" ng-change="grid.appScope.addBtnValidation()"></div>',
				                    },
				                      // New Fields - End	
				                    
				                    {
				                    	field: 'mixedModule',type: 'object',displayName: 'Mixed Mod',headerCellClass: 'center nonEditableField',width:90, cellTemplate:'<div><div ng-show="row.isSelected" class="cellAdjust text-center"><select ng-model="row.entity.editMixedModule"><option value="Yes">Yes</option><option value="No">No</option></select></div></div><div ng-show="!row.isSelected" class="text-center">{{row.entity.mixedModule}}</div>',
				                    	footerCellTemplate: '<div style="margin: 4% 30%;"><select ng-model="grid.appScope.addPart.mixedModule" class="slectboxAlign" ng-change="grid.appScope.addBtnValidation()">'+
			                    		   '<option value="Yes">Yes</option>'+
			                    		   '<option value="No">No</option>'+
			                    		   '</select></div>',
				                    },
				                    {
				                    	field: 'rePackingFlag',type: 'object',displayName: 'Repacking',headerCellClass: 'center nonEditableField',width:80, cellTemplate:'<div><div ng-show="row.isSelected" class="cellAdjust text-center"><select ng-model="row.entity.editRePackingFlag"><option value="Yes">Yes</option><option value="No">No</option></select></div></div><div ng-show="!row.isSelected" class="text-center">{{row.entity.rePackingFlag}}</div>',
				                    	footerCellTemplate: '<div style="margin: 4% 30%;"><select ng-model="grid.appScope.addPart.rePackingFlag" class="slectboxAlign" ng-change="grid.appScope.addBtnValidation()">'+
			                    		   '<option value="Yes">Yes</option>'+
			                    		   '<option value="No">No</option>'+
			                    		   '</select></div>',
				                    },
				                    {
				                    	field: 'repackSNP',type: 'object',displayName: 'Repack SNP',headerCellClass: 'center nonEditableField',width:80, cellTemplate:'<div><input ng-class="{editInputVal: row.entity.editRepackSNP != row.entity.repackSNP, editInput: row.entity.editRepackSNP == row.entity.repackSNP }" ng-show="row.isSelected" numbers-only maxlength="4" type="text" ng-model="row.entity.editRepackSNP"></input></div><div ng-show="!row.isSelected" class="dataCenter">{{row.entity.repackSNP}}</div>',
				                    	footerCellTemplate: '<div><input placeholder="Repack SNP" maxlength="4" ng-model="grid.appScope.addPart.repackSNP" numbers-Only type="text" class="form-control input-sm" rel="txtTooltip" title="Click Add button to save your data" data-toggle="tooltip" ng-change="grid.appScope.addBtnValidation()"></div>'
				                    },
				                    {
				                    	field: 'dolFlag',type: 'object',displayName: 'DOL',headerCellClass: 'center nonEditableField',width:50, cellTemplate:'<div><div ng-show="row.isSelected" class="cellAdjust"><select ng-model="row.entity.editDolFlag"><option value="Yes">Yes</option><option value="No">No</option></select></div></div><div ng-show="!row.isSelected" class="text-center">{{row.entity.dolFlag}}</div>',
				                    	footerCellTemplate: '<div style="margin: 4% 30%;"><select ng-model="grid.appScope.addPart.dolFlag" class="slectboxAlign" ng-change="grid.appScope.addBtnValidation()">'+
			                    		   '<option value="Yes">Yes</option>'+
			                    		   '<option value="No">No</option>'+
			                    		   '</select></div>',
				                    },
				                    {
				                    	field: 'dtlFlag',type: 'object',displayName: 'DTL',headerCellClass: 'center nonEditableField',width:50, cellTemplate:'<div><div ng-show="row.isSelected" class="cellAdjust"><select ng-model="row.entity.editDtlFlag"><option value="Yes">Yes</option><option value="No">No</option></select></div></div><div ng-show="!row.isSelected" class="text-center">{{row.entity.dtlFlag}}</div>',
				                    	footerCellTemplate: '<div style="margin: 4% 30%;"><select ng-model="grid.appScope.addPart.dtlFlag" class="slectboxAlign" ng-change="grid.appScope.addBtnValidation()">'+
			                    		   '<option value="Yes">Yes</option>'+
			                    		   '<option value="No">No</option>'+
			                    		   '</select></div>',
				                    },
				                    {
				                    	field:'remarks',type: 'object',displayName: 'Remarks',headerCellClass: 'center nonEditableField',width:120, cellTemplate:'<div><button title="Previous Remarks" type="button" style="margin-top: 4px;margin-left: 3px;" class="btn btn-default btn-sm" data-toggle="modal" data-target="#previousRemarks" ng-click="grid.appScope.openRemarkModel(row.entity.partNumber,row.entity.previousRemarks)"><span class="glyphicon glyphicon-list-alt"></span></button><div class="remarksfieldinp"><input ng-disabled="!row.isSelected" class="editInput" type="text" ng-model="row.entity.remarks"></input></div></div>',
				                    	footerCellTemplate: '<div><input placeholder="Remarks" ng-model="grid.appScope.addPart.remarks" type="text" class="form-control input-sm" rel="txtTooltip" title="Click Add button to save your data" data-toggle="tooltip" ng-change="grid.appScope.addBtnValidation()"></div>',
				                    },
				                    {
				                    	field:'locations',type: 'object',displayName: 'Loc ID',headerCellClass: 'center nonEditableField', width:80, cellTemplate:'<div><button type="button" class="btn btn-default btn-sm" data-toggle="modal" data-target="#manageLocationModal" ng-click="grid.appScope.openModel(row.entity.partNumber)"><span class="glyphicon glyphicon-list-alt"></span> Location</button></div>',
				                    	footerCellTemplate: '<div style="width: 100%;"><div style="float: left;padding-right: 5px;"><button class="btn btn-success btn-sm" type="button"ng-click="grid.appScope.addNewParts();" ng-disabled="!grid.appScope.enableAdd"><i class="fa fa-plus" aria-hidden="true"></i> Add</button></div>'				                    }
				                    
				                ],
				                data: data,
			                        onRegisterApi: function( gridApi ) {
			                        	
			                        	 $scope.gridApi = gridApi;
			                        	 //Pagination
			                        	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			                        		 $scope.blockUI();
			             		          paginationOptions.pageNumber = newPage;
			             		          paginationOptions.pageSize = pageSize;
			             		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
			             		        paginationOptions.endIndex   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
			             		        $scope.load();
			             		        });
			                        	 
			                        	 gridApi.selection.on.rowSelectionChanged($scope, function(row){ 
			                        	        $scope.countRows = $scope.gridApi.selection.getSelectedRows().length;
			                        	 }); 
			                        	 
			                	    }
					    };

				 $scope.gridOptions.data = [];
				 
				 /* Load data in grid */
				    $scope.load = function () {
				    	$scope.part.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

				    	if(paginationOptions.endIndex === 0){
				    		$scope.part.endIndex = $scope.gridOptions.paginationPageSize;
				    	}
				    	$scope.part.startIndex = paginationOptions.startIndex;
				    	$scope.part.endIndex = paginationOptions.pageSize;	
				    	$scope.part.partNumber=$scope.partNumber;
				    	$scope.part.locations=$scope.location;
				    	partsMasterService.partsCount($scope.part).then(function(response){
				    		$scope.gridOptions.totalItems = response.data.object;		    		
				    		$scope.recordCount = response.data.object;		    		
				    		$scope.partMasterData();
				    		
				    	});
				    	
				    };
				    
				    
				    $scope.partMasterData = function(){  
				    	$scope.blockUI();
				    	$scope.part.partNumber=$scope.partNumber;
				    	$scope.enableAdd = false;
				    	partsMasterService.parts($scope.part).then(function(response){	
				    		
					    		$scope.gridOptions.data = [];
					    		if(response.data!== undefined && response.data.objectList!== undefined && response.data.objectList!=null){					    		
					    			if(response.data.statusType === 'success' && response.data.objectList.length>0){
					    				$scope.gridOptions.enablePaginationControls=true;
					    				angular.forEach(response.data.objectList, function(partObj, PartKey) {
					    					
					    					partObj["editMixedModule"] = partObj.mixedModule;
					    					partObj["editRePackingFlag"] = partObj.rePackingFlag;
					    					partObj["editDolFlag"] = partObj.dolFlag;
					    					partObj["editDtlFlag"] = partObj.dtlFlag;
					    					partObj["editRepackSNP"] = partObj.repackSNP;
					    					partObj["editCategory"] = partObj.category;
					    					//partObj["adoptDate"] = partObj.adoptDate !== null ? new Date(partObj.adoptDate): partObj.adoptDate;
					    					if(partObj.adoptDate !== null){
					    						partObj["adoptDate"] = $filter('date')(new Date(partObj.adoptDate),'yyyy-MM-dd');
					    					}else{
					    						partObj["adoptDate"] = null;
					    					}
					    					
					    					if(partObj.abolishDate !== null){
					    						partObj["abolishDate"] = $filter('date')(new Date(partObj.abolishDate),'yyyy-MM-dd');
					    					}else{
					    						partObj["abolishDate"] = null;
					    					}
					    					
					    					partObj["editAdoptDate"] = partObj.adoptDate;
					    					partObj["editAbolishDate"] = partObj.abolishDate;
					    					
					    					//partObj["abolishDate"] = partObj.abolishDate !== null ? new Date(partObj.abolishDate):partObj.abolishDate;
					    					partObj["editShelfLifeAging"] = partObj.shelfLifeAging; //shelfLifeAging - Added For aging calculation
					    					partObj["editShelfLifePart"] = partObj.shelfLifePart;
					    					partObj["editShelfLifePeriod"] = partObj.shelfLifePeriod;
					    					
					    					partObj["editsnp"] = partObj.snp;
					    					partObj["editsnip"] = partObj.snip;

					    					//Hard Coded
					    					//partObj["noOfLocations"] = 1;
					    					
					    					//Remarks
					    					
						    				if(partObj.changeLog != null && partObj.changeLog != 'null' && partObj.changeLog != ''){
						    					
						    					 var logArray = partObj.changeLog.split('^^');
						    					 var remarkArray = [];							    										    		
							    				 angular.forEach(logArray, function(value, key){
							    					   if(value != "" && value != " " && value != null){
							    						   var splitData=value.split('##');	
						    							   var obj = {};	
						    							   if(splitData[1] != undefined){
						    								   splitData[1]=splitData[1].replace("/","-");
						    								   splitData[1]=splitData[1].replace("/","-");
						    								   dateTime=splitData[1].split(' ');
						    								   obj['user'] = splitData[0];
						    								   obj['commentedOn'] = $filter('date')(dateTime[0], 'MMM d, yyyy')+' '+dateTime[1];
						    								   obj['comments'] = splitData[2];
						    								   remarkArray.push(obj);
						    							   }
							    					   }
							    					  
							    				 });
							    		         partObj["previousRemarks"]=remarkArray.reverse();
							    		         
						    				}								    				   
						    					
					    				});
					    				$scope.gridOptions.data = response.data.objectList;
					    				console.log("Category selected " + $scope.gridOptions.data[0].editCategory);
					    				
					    			} else {
					    				$scope.searchDataEror=response.data.statusMessage;
					    				$scope.gridOptions.enablePaginationControls=false;					    				
					    			}
					    			$.unblockUI();					    			
					    		} else {
					    			$scope.searchDataEror=response.data.statusMessage;					    			
						            $.unblockUI();
					    		}
					    		//$scope.resetSearch();
					    	});
				     };
				     
				     
				     
				     // --------- search button ---------
			            $scope.searchParts = function() {	
			            	
			            	$scope.alerts = [];
			            	$scope.gridOptions.data = [];			            	
			            	paginationOptions.startIndex= 0;
			            	paginationOptions.endIndex= 0;
			            	paginationOptions.pageNumber= 1;
			            	paginationOptions.pageSize= 100; 
			            	$scope.gridOptions.paginationCurrentPage=1;
			            	$scope.gridOptions.paginationPageSize=100;			            				            	
			            	$scope.clearFilters();                	
			            	$scope.load();			 
			            	 $scope.clearPartsMap();
			            	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
			            };	
			            
			            $scope.clearFilters = function() {
			       		 $scope.gridApi.core.clearAllFilters();
			            };
			            
					    $scope.clearPartsMap = function() {
					    		$scope.map = {};
						    	$scope.populateClicked=false;
			    				$scope.addNewButton=true;
			    				$scope.enableRemark=false;
			    				$('div').removeClass('has-error');
						    	 $scope.submitError='';	
					    };
					    
					    $scope.savePartsData = function(){
					    	$scope.selectedData = $scope.gridApi.selection.getSelectedRows();
					    	$scope.partDataSave = [];
					    	$scope.isValidSave = true;
					    	angular.forEach($scope.selectedData, function(partObj, PartKey) {
					    		$scope.partData = {
					    				partNumber : "",
					    				dolFlag:"",
					    				dtlFlag:"",
					    				mixedModule:"",
					    				rePackingFlag:"",
					    				repackSNP:"",
					    				userId:"",
					    				abolishDate:"",
					    				adoptDate:"",
					    				snp:"",
					    				snip:"",
					    				partCategory:""
					    				
					    		};					    				
					    	
					    		//Meena - Added snip mandatory field validation & shelfLifeAging - Added For aging calculation
					    		if(partObj.editShelfLifeAging !== null && partObj.editShelfLifeAging !== "" && partObj.editShelfLifePart !== null && partObj.editShelfLifePart !== "" && partObj.editsnp !== null && partObj.editsnp !== "" 
					    			       && partObj.editCategory!=null && partObj.editCategory!="" && partObj.editsnp!=0
					    			       && partObj.editsnip!==null && partObj.editsnip!==""  && partObj.editsnip!=0 ){
					    			
					    			if(partObj.editShelfLifeAging=='Yes'){					    				
					    				if(partObj.editShelfLifePart==null || partObj.editShelfLifePart=='' || partObj.editShelfLifePart=='No')
					    				{
					    					$scope.isValidSave = false;
					    					$scope.alerts = [];
						    				$scope.alerts.push({
									                type : 'danger',
									                msg  : 'Please select FIFO available as Yes' 								              
									        });
					    				}
					    			 }else if(partObj.editShelfLifePart=='Yes' ){
						    				if(partObj.editShelfLifePeriod==null || partObj.editShelfLifePeriod=='' || partObj.editShelfLifePeriod=='0')
						    				{
						    					$scope.isValidSave = false;
						    					$scope.alerts = [];
							    				$scope.alerts.push({
										                type : 'danger',
										                msg  : 'Please enter Shelf Life period ' 								              
										        });
						    				}
						    			}			    			
					    			$scope.partData.partNumber = partObj.partNumber;
					    			$scope.partData.dolFlag = partObj.editDolFlag;
					    			$scope.partData.dtlFlag = partObj.editDtlFlag;
					    			$scope.partData.mixedModule = partObj.editMixedModule;
					    			$scope.partData.rePackingFlag = partObj.editRePackingFlag;
					    			$scope.partData.repackSNP = partObj.editRepackSNP;
					    			$scope.partData.category = partObj.editCategory;
					    			//New Fields
					    			$scope.partData.abolishDate = $filter('date')(partObj.editAbolishDate, 'yyyy-MM-dd');
					    			$scope.partData.adoptDate = $filter('date')(partObj.editAdoptDate, 'yyyy-MM-dd');
					    			$scope.partData.shelfLifeAging =  partObj.editShelfLifeAging;	
					    			$scope.partData.shelfLifePart =  partObj.editShelfLifePart;					    			
					    			$scope.partData.shelfLifePeriod = partObj.editShelfLifePeriod;
					    			$scope.partData.remarks = partObj.remarks;
					    			$scope.partData.snp = partObj.editsnp;
					    			$scope.partData.snip = partObj.editsnip;
					    			//added by divya ramesh to include part type
					    			$scope.partData.partCategory = partObj.editPartCategory;
					    			$scope.partData.userId = $window.sessionStorage.getItem('loggedUserId');	
					    			$scope.partDataSave.push($scope.partData);
					    			console.log("$scope.partDataSave",$scope.partDataSave);
					    		}else{
					    			$scope.isValidSave = false;
					    			$scope.alerts = [];
				    				$scope.alerts.push({
							                type : 'danger',
							                msg  : 'Please update all mandatory columns' 								              
							        });
					    		}
					    	});
					    	
					    	if($scope.partDataSave.length != 0 && $scope.isValidSave){
					    		partsMasterService.savePartsMapDetails($scope.partDataSave).then(function(response){	
					    			if(response.data.statusType === 'success' ){
					    				$scope.alerts = [];
							            $scope.alerts.push({
							                type : response.data.statusType,
							                msg : response.data.statusMessage
							            });
							            $scope.searchParts();
					    			}else {						    				
					    				$scope.alerts = [];
					    				$scope.alerts.push({
								                type : 'danger',
								                msg : response.data.statusMessage								              
								            });
					    			}
					    		});
					    	}
					    };
					    
					    $scope.addNewParts = function(){
					    	$scope.blockUI();
			            	$scope.alerts = [];		
			            	console.log("$scope.addPart:Befor",$scope.addPart);
			            	
			            	//$scope.addPart = {};
			            	console.log("$scope.addPart",$scope.addPart);
			            	$scope.addPart.userId = $window.sessionStorage.getItem('loggedUserId');
			            	partsMasterService.addPartsMapDetails($scope.addPart).then(function(response){				            					            								    		
					    			if(response.data.statusType === 'success' ){
					    				$scope.alerts = [];
							            $scope.alerts.push({
							                type : response.data.statusType,
							                msg : response.data.statusMessage
							            });							           
							            $scope.addPart = {
							            		  adoptDate : '',category:'',depoCode:'',dolFlag:'',dtlFlag:'',eopMark:'',mixedModule:'',partName:'',partNumber:'',partType:'',rePackingFlag:'',
									    		  receivingPort:'',remarks:'',repackSNP:'',shelfLifePeriod:'',shelfLifePart:'',shelfLifeAging:'',snip:'',snp:'',partCategory:''
									    }; 
							            console.log("$scope.addPart:After",$scope.addPart);
							            $scope.partMasterData();							            
							            $.unblockUI();
					    			} else {						    				
					    				$scope.alerts = [];
					    				 $scope.alerts.push({
								                type : 'danger',
								                msg : response.data.statusMessage								              
								            });	
							            $.unblockUI();
					    			}
					    	});	
					    };
					    
					  //Meena - added category validation - also added snip validation & shelfLifeAging - Added For aging calculation
					    $scope.addBtnValidation = function(){
					    	$scope.alerts = [];
					    	if($scope.addPart.partType == "" || $scope.addPart.partNumber == "" || $scope.addPart.snp == "" || $scope.addPart.snip == "" || 
					    		 $scope.addPart.snp == 0 || $scope.addPart.snip== 0 || $scope.addPart.shelfLifeAging == "" || $scope.addPart.shelfLifePart == "" ||
					    		($scope.addPart.category=="" || $scope.addPart.category==null) || 
					    		($scope.addPart.shelfLifeAging == "Yes" && ($scope.addPart.shelfLifePart == "" || $scope.addPart.shelfLifePart == "No")) || 
					    		($scope.addPart.shelfLifePart == "Yes" && $scope.addPart.shelfLifePeriod == "" ))
					    	    {
					    		if($scope.addPart.shelfLifeAging=='Yes'){					    				
				    				if(/*$scope.addPart.shelfLifePart==null || $scope.addPart.shelfLifePart=='' || */$scope.addPart.shelfLifePart=='No')
				    				{
				    					$scope.isValidSave = false;
				    					$scope.alerts = [];
					    				$scope.alerts.push({
								                type : 'danger',
								                msg  : 'Please select FIFO available as Yes' 								              
								        });
				    				}
				    			 }
					    		$scope.enableAdd = false;
					    	}else{
					    		$scope.enableAdd = true;
					    		
					    	}
					    };
					    
					    $scope.closeAlert = function(index) {
					        $scope.alerts.splice(index, 1);
					    };	
					    
					    $scope.openModel = function(partNumber){
					    	PartNumberInterService.partNumber = partNumber;
					    };
					    
					    $scope.openRemarkModel = function(partNumber,remarks){
					    	RemarksInterService.partNumber = partNumber;
					    	RemarksInterService.remarks = remarks;
					    };
					    
					 // Download report - Start		  
						$scope.downloadPartMasterData =function(){
							$scope.blockUI();
			            	return partLocationService.PartLocationDataDownload($scope.part).then(function(response){
			            		console.log("response",response);
			            		var responseList = [];
			            		if(response.objectList != null){
			            			for (var i = 0; i < response.objectList.length; i++) {
			            				var obj = {};
			            				if(response.objectList[i].locationId != null && response.objectList[i].locationId != ""){
			            					obj["PART_Updated"] = " * ";
			            				}else{
			            					obj["PART_Updated"] = " ";
			            				}
			            				obj["PART_TYPE"] = response.objectList[i].partType;
			            				obj["PART_NO"] = '="'+response.objectList[i].partNumber+'"';
			            				obj["PART_NAME"] = response.objectList[i].partName;
			            				obj["SUPPLIER_CODE"] = response.objectList[i].supplierCode;
			            				obj["DEPO_CODE"] = response.objectList[i].depoCode;			            				
			            				obj["PART_CATEGORY"] = response.objectList[i].partCategory;
			            				obj["CATEGORY"] = response.objectList[i].category;
			            				obj["SNP"] = response.objectList[i].snp;
			            				obj["SNIP"] = response.objectList[i].snip;
			            				obj["RECEIVING_PORT"] = response.objectList[i].receivingPort;
			            				obj["EOP_MARK"] = response.objectList[i].eopMark;
			            				obj["ADOPT DATE"] = response.objectList[i].adoptDateString;
			            				obj["ABOLISH DATE"] = response.objectList[i].abolishDateString;
			            				/*obj["SHELF_LIFE_PART"] = response.objectList[i].shelfLifePart;*/
			            				obj["SHELF_LIFE_AGING"] = response.objectList[i].shelfLifeAging; //shelfLifeAging - Added For aging calculation
			            				obj["SHELF_LIFE_PART"] = response.objectList[i].shelfLifePart;
			            				obj["SHELF_LIFE_PERIOD"] = response.objectList[i].shelfLifePeriod;
			            				obj["MIXED_MODULE"] = response.objectList[i].mixedModule;
			            				obj["REPACKING"] = response.objectList[i].rePackingFlag;
			            				obj["REPACK_SNP"] = response.objectList[i].repackSNP;
			            				obj["DOL"] = response.objectList[i].dolFlag;
			            				obj["DTL"] = response.objectList[i].dtlFlag;
			            				obj["LOCATION_ID"] = response.objectList[i].locationId;
			            				/*obj["REMARKS"] = response.objectList[i].remarks;*/
			            				//obj["RAN"] = response.objectList[i].ran;
			            				obj["CURRENT QTY"] = response.objectList[i].currentQty;
			            				//obj["TOTAL CAPACITY"] = response.objectList[i].totalCapacity;
			            				responseList.push(obj);
			            			}
			            		}else{
			            			$scope.alerts = [];
			    	       			$scope.alerts.push({
			    	       				 type : 'danger',
			    	       				 msg : 'Data is not available'
			    	       			});
			            		}
			            		$.unblockUI();
								return responseList;
			            	});
				        };
				        $scope.getDownloadReportHeader = function () {
			            	return ["R","PART TYPE","PART NO","PART NAME","SUPPLIER CODE","DEPO CODE","PART CATEGORY","CATEGORY","SNP","SNIP","RECEIVING PORT","EOP MARK","ADOPT DATE","ABOLISH DATE","SHELF LIFE PART","FIFO AVAILABLE","SHELF LIFE PERIOD","MIXED MODULE","REPACKING","REPACK SNP","DOL","DTL","LOCATION ID","CURRENT QTY"];
			            };
			            //Download report - End
					    
					    $(document).ready(function(){
					        $('input[rel="txtTooltip"]').tooltip();
					        $('[data-toggle="tooltip"]').tooltip(); 
					    });
} ]);