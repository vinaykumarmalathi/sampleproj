wmsApp.controller('LineFeedingDetailsController', [ '$scope', '$window', '$filter', '$location', '$q', 'lineFeedingDetailsService', 'locationService', 'uiGridTreeViewConstants', '$http', 'commonService', 'localStorageService', 'partNumberService', 'ranService','shortageAlarmService', function($scope, $window, $filter, $location, $q, lineFeedingDetailsService, locationService, uiGridTreeViewConstants, $http, commonService, localStorageService, partNumberService, ranService,shortageAlarmService) {
	$scope.searchDataEror = "Click search to fetch records.";
	$scope.beginDate = new Date();
	$scope.endDate = new Date();
	$scope.dateCurr = new Date();
	$scope.pickListnumberSelected = null;
	$scope.printableList = [];
	$scope.selectedValue = [];
	$scope.refresh = true;
	$scope.lineFeedingDetailsDTO = [];
	$scope.isBeginDateChanged = false;
	$scope.snpTotal = 0;
	$scope.qtyTotal = 0;
	$scope.boxTotal = 0;
	$scope.fromMaxDate = new Date();
	$scope.shiftDropdown = false;
	$scope.todayDate = new Date();
	$scope.transactionList = [ "In", "Out" ];
	$scope.shiftList = [ "A", "B", "C" ];
	$scope.beginDatePickerOpen = false;
	$scope.endDatePickerOpen = false;
	$scope.endTimePickerOpen = false;
	$scope.beginTimePickerOpen = false;
	$scope.openBeginDatePicker = function($event) {
		$event.preventDefault();
		$event.stopPropagation();
		$scope.isBeginDateChanged = true;
		$scope.beginDatePickerOpen = !$scope.beginDatePickerOpen;
	};
	$scope.openEndDatePicker = function($event) {
		$event.preventDefault();
		$event.stopPropagation();
		$scope.endDatePickerOpen = !$scope.endDatePickerOpen;
	};
	/*
	 * load Zone
	 */
	/*$scope.loadZones = function(){
		lineFeedingDetailsService.zonesListService().then(function(response) {
			$scope.zones = response.objectList;
		});
	}
	$scope.loadZones();*/
	
	//Added by Meena
	/*$scope.loadZones = function(){
		lineFeedingDetailsService.getAllZones()
		  .success(function(response){
			  $scope.zones = response.objectList;				
		  })
		  .error(function(response){
		  });
	  };*/
	  
	
	
	
	
	// --------- Part Number List ---------
	$scope.partNumber = '';
	$scope.searchClicked = false;
	$scope.tags = [];
	/* ON ADD NEW PART TAG */
	$scope.transactionList = [ "In", "Out" ];
	$scope.tagAdded = function(tag) {
		$scope.partArray = [];
		for (var j = 0; j < $scope.tags.length; j++) {
			$scope.partArray.push($scope.tags[j].text);
			console.log("Part Array", $scope.partArray);
		}
		$scope.partNumber = $scope.partArray.join(',');
		console.log("Part Number", $scope.partNumber);
		$(".appViewDiv").css({
		    "height" : $(window).height() - 130,
		    "overflow" : "auto"
		});
	};
	/* ON REMOVE ADDED PART TAG */
	$scope.tagRemoved = function(tag) {
		$scope.partArray = [];
		for (var j = 0; j < $scope.tags.length; j++) {
			$scope.partArray.push($scope.tags[j].text);
		}
		$scope.partNumber = $scope.partArray.join(',');
		$(".appViewDiv").css({
		    "height" : $(window).height() - 130,
		    "overflow" : "auto"
		});
	};
	$scope.addingTag = function(tag) {
		console.log("Tag.text", tag.text);
		tag.text = tag.text.replace(/ /g, ',');
		console.log("Tag.text 2", tag.text);
		return tag;
	};
	/* AUTOCOMPLE PART ON ENTER MIN 3 CHAR DATA */
	$scope.loadParts = function(query) {
		var partInputObj = {
			"partNumber" : query
		};
		return partNumberService.partNumberList(partInputObj).then(function(response) {
			if (response.data.statusType == 'success') {
				if (response.data.object != 'null' && response.data.object != null) {
					return response.data.object;
				}
			} else {
			}
		});
	};
	
	/* RAN Auto Completion - Start */
	$scope.ranData = [];
	$scope.ranAdded = function(tag) {
		console.log("tagAdded:", tag);
		$scope.ranArray = [];
		for (var j = 0; j < $scope.ranData.length; j++) {
			$scope.ranArray.push($scope.ranData[j].text);
		}
		$scope.fifo.ran = $scope.ranArray.join(',');
		$(".appViewDiv").css({
		    "height" : $(window).height() - 130,
		    "overflow" : "auto"
		});
	};
	$scope.ranRemoved = function(tag) {
		$scope.ranArray = [];
		for (var j = 0; j < $scope.ranData.length; j++) {
			$scope.ranArray.push($scope.ranData[j].text);
		}
		
		$scope.fifo.ran = $scope.ranArray.join(',');
		$(".appViewDiv").css({
		    "height" : $(window).height() - 130,
		    "overflow" : "auto"
		});
	};
	$scope.loadRan = function(query) {
		var partInputObj = {
			"ranId" : query
		};
		return ranService.ranList(partInputObj).then(function(response) {
			if (response.data.statusType == 'success') {
				if (response.data.object != 'null' && response.data.object != null) {
					console.log(response.data.object);
					return response.data.object;
				}
			}
		});
	};
	
	// --------- Location drop down list -------
	if ($window.sessionStorage.getItem('locationDPCollection') == null || $window.sessionStorage.getItem('locationDPCollection') == 'undefined' || $window.sessionStorage.getItem('locationDPCollection') == undefined) {
		commonService.getAllPlants().success(function(response) {
			$scope.locations = response.objectList;
			$window.sessionStorage.setItem('locationDPCollection', JSON.stringify($scope.locations));
		}).error(function(response) {
		});
	} else {
		$scope.locations = JSON.parse(sessionStorage.locationDPCollection);
	}
	
	// --------- Section drop down list ---------
	if ($window.sessionStorage.getItem('sectionDPCollection') == null || $window.sessionStorage.getItem('sectionDPCollection') == 'undefined' || $window.sessionStorage.getItem('sectionDPCollection') == undefined) {
		commonService.getAllSections().success(function(response) {
			$scope.sections = response.objectList;
			$window.sessionStorage.setItem('sectionDPCollection', JSON.stringify($scope.sections));
		}).error(function(response) {
		});
	} else {
		$scope.sections = JSON.parse(sessionStorage.sectionDPCollection);
	}
	
	// --------- Shops drop down list ---------
	$scope.loadShopLine = function() {
		$scope.fifo.line = '';
		$scope.fifo.shop = '';
	
		
		commonService.getLineList($scope.fifo.plant).success(function(response) {
			$scope.lines = response.objectList;
		}).error(function(response) {
		});
		
		lineFeedingDetailsService.getShopList($scope.fifo.plant).success(function(response) {
			$scope.shops = response.objectList;
		}).error(function(response) {
		});
		
		lineFeedingDetailsService.getAllZones().success(function(response){
			  $scope.zones = response.objectList;				
		  }).error(function(response){
		  });
		
		

		
		//Added to load allocation in dropDown
		lineFeedingDetailsService.getAllocationList().success(function(response) {
				$scope.allocation = response.objectList;
		}).error(function(response) {
		});
	}
	
	//Added to load allocation in dropDown
	 /* $scope.loadAllocation = function(){
		  lineFeedingDetailsService.getAllocationList($scope.fifo.zone).success(function(response) {
		  lineFeedingDetailsService.getAllocationList().success(function(response) {
				$scope.allocation = response.objectList;
			}).error(function(response) {
			});
	  };*/
	
	$scope.fifo = {
	    partNumber : $scope.partNumber,
	    beginDate : $scope.beginDate,
	    endDate : $scope.endDate,
	    fromTime : $scope.beginTime,
	    toTime : $scope.endTime,
	    startIndex : 0,
	    endIndex : 0
	};
	
	var paginationOptions = {
	    startIndex : 0,
	    endIndex : 0,
	    pageNumber : 1,
	    pageSize : 100,
	    sort : null
	};
	// Grid
	$scope.gridOptions = {
	    enablePaginationControls : false,
	    enableGridMenu : true,
	    enableFiltering : true,
	    enableColumnResize : true,
	    paginationPageSizes : [ 100, 250, 500, 750, 1000 ],
	    paginationPageSize : 100,
	    useExternalPagination : true,
	    autoResize : true,
	    enableSorting : true,
	    enableColumnMenus : false,
	    enablePinning : true,
	    columnDefs : [ {
	        field : 'pickListnumber',
	        displayName : 'Picking List Number',
	        cellTemplate: '<div class="ui-grid-cell-contents"><span class="details-link" data-toggle="modal" data-target="#printDetailsModal" ng-click="grid.appScope.openModalTable(row.entity,row.entity.pickListnumber)">{{row.entity.pickListnumber}}</span></div>',
	        minWidth: 130, 
	        width: 160, 
	        enableColumnResizing: true 
	    }, {
	        field : 'line',
	        displayName : 'Line',
	        minWidth: 56, 
	        width: 60, 
	        enableColumnResizing: true 
	    },{
	        field : 'zone',
	        displayName : 'Zone',
	        minWidth: 70, 
	        width: 80, 
	        enableColumnResizing: true
	    }, {
	        field : 'shop',
	        displayName : 'Shop',
	        minWidth: 66, 
	        width: 70, 
	        enableColumnResizing: true
	    }, 
	    {
	        field : 'allocation',
	        displayName : 'Allocation',
	        minWidth: 84, 
	        width: 90, 
	        enableColumnResizing: true
	    }, 
	    {
	        field : 'creationTime',
	        displayName : 'Creation Time',
	        cellFilter : 'date:\'yyyy MMM dd HH:mm:ss\'',
	        minWidth: 150, 
	        width: 175, 
	        enableColumnResizing: true
	        
	    }, {
	        field : 'closureTime',
	        displayName : 'Closure Time',
	        cellFilter : 'date:\'yyyy MMM dd HH:mm:ss\'',
	        minWidth: 150, 
	        width: 175, 
	        enableColumnResizing: true
	        
	    },  {
	        field : 'status',
	        displayName : 'Status',
	        minWidth: 70, 
	        width: 80, 
	        enableColumnResizing: true
	    }, {
	        field : 'totalNoOfParts',
	        displayName : 'Open Parts',
	    }, {
	        field : 'totalNoOfBox',
	        displayName : 'Open Boxes',
	    }, {
	        field : 'deviceId',
	        displayName : 'Picked/Closed Device Id',
	        cellFilter : 'date:\'yyyy MMM dd HH:mm:ss\''
	        
	    } ],
	    exporterPdfAlign : 'left',
	    exporterCsvFilename : 'PickingListReport.csv',
	    exporterMenuVisibleData : false,
	    exporterPdfDefaultStyle : {
		    fontSize : 9
	    },
	    exporterPdfTableStyle : {
		    margin : [ 70, 5, 0, 5 ]
	    },
	    exporterPdfTableHeaderStyle : {
	        fontSize : 10,
	        bold : true,
	        italics : true,
	        color : 'red'
	    },
	    exporterPdfHeader : {
	        text : "FIFO Report",
	        style : 'headerStyle'
	    },
	    exporterPdfFooter : function(currentPage, pageCount) {
		    return {
		        text : currentPage.toString() + ' of ' + pageCount.toString(),
		        style : 'footerStyle'
		    };
	    },
	    exporterPdfCustomFormatter : function(docDefinition) {
		    docDefinition.styles.headerStyle = {
		        fontSize : 20,
		        bold : true,
		        alignment : 'center',
		        margin : [ 0, 0, 20, 0 ]
		    };
		    docDefinition.styles.footerStyle = {
		        fontSize : 10,
		        bold : true,
		        alignment : 'center',
		        margin : [ 5, 0, 20, 0 ]
		    };
		    return docDefinition;
	    },
	    exporterPdfOrientation : 'landscape',
	    exporterPdfPageSize : 'LETTER',
	    exporterPdfMaxGridWidth : 500,
	    exporterPdfFilename : 'PickingListReport.pdf',
	    exporterCsvLinkElement : angular.element(document.querySelectorAll(".custom-csv-link-location")),
	    onRegisterApi : function(gridApi) {
		    $scope.gridApi = gridApi;
		    // Pagination
		    gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
			    $scope.blockUI();
			    paginationOptions.pageNumber = newPage;
			    paginationOptions.pageSize = pageSize;
			    paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
			    paginationOptions.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
			   // paginationOptions.endIndex   = paginationOptions.pageSize;
			    $scope.load();
		    });
	    }
	};	
	
	$scope.gridOptions.exporterFieldCallback = function(grid, row, col, value) {
		if (col.name === 'partInOutTime' || col.name === 'scanTime') {
			value = $filter('date')(value, 'dd/MM/yyyy HH:mm:ss');
		}
		return value;
	};
	
	var selectedValue = null;
	
	$scope.lineFeedingGridOptions = {
		    enablePaginationControls : false,
		    enableGridMenu : true,
		    enableFiltering : true,
		    enableColumnResize : true,
		    paginationPageSizes : [ 100, 250, 500, 750, 1000 ],
		    paginationPageSize : 100,
		    useExternalPagination : true,
		    autoResize : true,
		    enableSorting : true,
		    enableColumnMenus : false,
		    enablePinning : true,
		  /*  enableRowSelection = true,
		    enableSelectAll = true,*/
		    columnDefs : [
	    	{
		        field : 'partType',
		        displayName : 'Part Type',
		        headerTooltip : 'Part Type',
		        minWidth: 50, 
		        width: 59, 
		        enableColumnResizing: true 
			}, {
		        field : 'partNumber',
		        displayName : 'Part Number',
		        headerTooltip : 'Part Number',
		        minWidth: 110, 
		        width: 120, 
		        enableColumnResizing: true 
		    },{
		        field : 'location',
		        displayName : 'Location',
		        width:200,
		        headerTooltip : 'Location',
		        cellTemplate: '<div style="padding-left:5px;"><textarea rows="2" readonly="true" style="word-wrap: break-word;width:190px">{{row.entity.location}}</textarea></div>',
		        minWidth: 150, 
		        enableColumnResizing: true 
		    }, {
		        field : 'noOfBoxes',
		        displayName : 'No Of Boxes',
		        headerTooltip : 'No of Boxes',
		        minWidth: 50, 
		        width: 59, 
		        enableColumnResizing: true 
		    }, {
		        field : 'noOfOpenBoxes',
		        displayName : 'Open Boxes',
		        headerTooltip : 'Open Boxes',
		        minWidth: 50, 
		        width: 59, 
		        enableColumnResizing: true 
		    }, {
		        field : 'snp',
		        displayName : 'SNP',
		        headerTooltip : 'SNP',
		        minWidth: 50, 
		        width: 59, 
		        enableColumnResizing: true 
		    }, {
		        field : 'quantity',
		        displayName : 'Qty',
		        headerTooltip : 'Qty',
		        minWidth: 50, 
		        width: 59, 
		        enableColumnResizing: true 
		    }, {
		        field : 'noOfOpenQty',
		        displayName : 'Open Qty',
		        headerTooltip : 'Open Qty',
		        minWidth: 50, 
		        width: 59, 
		        enableColumnResizing: true 
		    },  {
		        field : 'device',
		        displayName : 'Last Upd By',
		        headerTooltip : 'Last Upd By',
		        minWidth: 50, 
		        width: 59, 
		        enableColumnResizing: true 
		    },{
		        field : 'wip',
		        displayName : 'WIP',
		        headerTooltip : 'WIP',
		        minWidth: 50, 
		        width: 59, 
		        enableColumnResizing: true 
		    }, {
		        field : 'remainingActualQty',
		        displayName : 'Remaining Actual',
		        headerTooltip : 'Remaining Actual',
		        minWidth: 50, 
		        width: 59, 
		        enableColumnResizing: true 
		    },{
		        field : 'eopMark',
		        displayName : 'EOP Mark',
		        headerTooltip : 'EOP Mark',
		        minWidth: 50, 
		        width: 59, 
		        enableColumnResizing: true 
		    },
		    /*{
		        field : 'whOut',
		        displayName : 'WH OUT',
		        headerTooltip : 'WH OUT',
		        minWidth: 50, 
		        width: 59, 
		        enableColumnResizing: true 
		    },*/
		    {
		        field : 'status',
		        displayName : 'Status',
		        headerTooltip : 'Status',
		        minWidth: 50, 
		        width: 59, 
		        enableColumnResizing: true 
		    },{
		        field : 'model',
		        displayName : 'Model',
		        headerTooltip : 'Model',
		        minWidth: 50, 
		        width: 59, 
		        enableColumnResizing: true 
		    },{
		        field : 'allocation',
		        displayName : 'Allocation',
		        headerTooltip : 'Allocation',
		        minWidth: 50, 
		        width: 59, 
		        enableColumnResizing: true 
		    },{
		        field : 'supplierMethod',
		        displayName : 'Supplier',
		        headerTooltip : 'Supplier',
		        minWidth: 50, 
		        width: 59, 
		        enableColumnResizing: true 
		    },{
		        field : 'lineStk',
		        displayName : 'Line Stock',
		        headerTooltip : 'Line Stock',
		        minWidth: 50, 
		        width: 59, 
		        enableColumnResizing: true 
		    }
		    ,{
		        field : 'lineLoc',
		        displayName : 'Line Location',
		        headerTooltip : 'Line Location',
		        minWidth: 50, 
		        width: 59, 
		        enableColumnResizing: true 
		    }],
		    exporterPdfAlign : 'left',
		    exporterCsvFilename : 'PickingListReport.csv',
		    exporterMenuVisibleData : false,
		    exporterPdfDefaultStyle : {
			    fontSize : 9
		    },
		    exporterPdfTableStyle : {
			    margin : [ 70, 5, 0, 5 ]
		    },
		    exporterPdfTableHeaderStyle : {
		        fontSize : 10,
		        bold : true,
		        italics : true,
		        color : 'red'
		    },
		    exporterPdfHeader : {
		        text : "FIFO Report",
		        style : 'headerStyle'
		    },
		    exporterPdfFooter : function(currentPage, pageCount) {
			    return {
			        text : currentPage.toString() + ' of ' + pageCount.toString(),
			        style : 'footerStyle'
			    };
		    },
		    exporterPdfCustomFormatter : function(docDefinition) {
			    docDefinition.styles.headerStyle = {
			        fontSize : 20,
			        bold : true,
			        alignment : 'center',
			        margin : [ 0, 0, 20, 0 ]
			    };
			    docDefinition.styles.footerStyle = {
			        fontSize : 10,
			        bold : true,
			        alignment : 'center',
			        margin : [ 5, 0, 20, 0 ]
			    };
			    return docDefinition;
		    },
		    exporterPdfOrientation : 'landscape',
		    exporterPdfPageSize : 'LETTER',
		    exporterPdfMaxGridWidth : 500,
		    exporterPdfFilename : 'PickingListReport.pdf',
		    exporterCsvLinkElement : angular.element(document.querySelectorAll(".custom-csv-link-location")),
		    onRegisterApi : function(gridApi) {
			    $scope.gridApi = gridApi;
			    // Pagination
			    gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
				    $scope.blockUI();
				    paginationOptions.pageNumber = newPage;
				    paginationOptions.pageSize = pageSize;
				    paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
				    paginationOptions.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
				    //paginationOptions.endIndex   = paginationOptions.pageSize;
				    $scope.load();
				    
			    });
			    
			    $scope.selectedRow = $scope.gridApi.selection.on.rowSelectionChanged($scope,function(row){
                    $scope.selectedValue.push(row.entity.partNumber);
			    	
			      });
		    }
		};
		$scope.lineFeedingGridOptions.exporterFieldCallback = function(grid, row, col, value) {
			if (col.name === 'partInOutTime' || col.name === 'scanTime') {
				value = $filter('date')(value, 'dd/MM/yyyy HH:mm:ss');
			}
			return value;
		};
	// Clear the filter
	$scope.clearFilters = function() {
		$scope.gridApi.core.clearAllFilters();
	};
	
	$scope.openModalTable=function(ent,pickingListNum){
		console.log("sdfsd")
		$scope.printedHeader = ent;
		$scope.deviceTranId = pickingListNum;
		$scope.boxTotal = 0;
		lineFeedingDetailsService.lineFeedingDetailsModal(pickingListNum).then(function(response) {
			$scope.lineFeedingGridOptions.totalItems = response.object.detailsDTOList.length;
			$scope.recordCount = response.object.detailsDTOList.length;
			$scope.pickListnumberSelected = response.object.pickListnumber;
			$scope.printableList = response.object.detailsDTOList;
			$scope.printableList.map(function(item) {
				if(item) {
					$scope.boxTotal += item.noOfBoxes;
					$scope.snpTotal += item.snp;
					$scope.qtyTotal += item.quantity;
				}
			});
			var resTemp={};
			resTemp.data= angular.copy(response);
			$scope.lineFeedingDetailsModelGridData(resTemp);
		});
	}
	var w= null;
	$scope.printDetails = function(){
		$scope.dateCurr = new Date();
		 var printContents = document.getElementById("printableArea").innerHTML;
	     var originalContents = document.body.innerHTML;
	     w=window.open();
	     w.document.write($('.printableArea').html());
	     w.document.close();
	     w.focus();
	     w.print();
	     w.close();
	     
	     //w.close();
	     //w= null;
	}
	
	/*$scope.cancel = function() {
		console.log(angular.element("#printDetailsModal"));
		angular.element("#printDetailsModal").modal('hide');
		$(".modal-backdrop fade in").hide();
	}
	*/
	// Reset the values
	$scope.resetFifo = function() {
		$scope.shops = "";
		$scope.lines = "";
		$scope.beginDate = new Date();
		$scope.endDate = new Date();
		$scope.beginTime = new Date();
		$scope.endTime = new Date();
		$scope.getTime();
		$scope.gridOptions.data = [];
		$scope.clearFilters();
		$scope.fifo = {};
		$scope.partNumber = "";
		$scope.fifo.startIndex = 0;
		$scope.fifo.endIndex = 0;
		$scope.gridOptions.totalItems = 0;
		$scope.partNumber = "";
		$scope.gridOptions.enablePaginationControls = false;
		$(".appViewDiv").css({
		    "height" : $(window).height() - 130,
		    "overflow" : "auto"
		});
		$scope.shiftDropdown = false;
		$scope.fifo.device = "";
	};
	
	$scope.lineFeedingDetailsGridData = function(response) {
		$scope.gridOptions.data = [];
		if (response.data.objectList !== undefined && response.data.objectList !== null) {
			if (response.data.statusType === 'success') {
				$scope.gridOptions.enablePaginationControls = true;
				response.data.objectList.forEach(function(row) {
					$scope.gridOptions.data = response.data.objectList;
				});
			} else {
				$scope.gridOptions.enablePaginationControls = false;
				$scope.alerts = [];
				$scope.alerts.push({
				    type : response.data.statusType,
				    msg : response.data.statusMessage,
				    error : response.data.exceptionStackTrace,
				    errorClsName : response.data.exceptionClassName,
				    errorMsg : response.data.exceptionMessage
				});
			}
			$.unblockUI();
		} else {
			$scope.searchDataEror = response.data.statusMessage;
			$.unblockUI();
		}
	};
	
	$scope.lineFeedingDetailsModelGridData = function(response) {
		$scope.lineFeedingGridOptions.data = [];
		if (response.data.object.detailsDTOList !== undefined && response.data.object.detailsDTOList !== null) {
			if (response.data.statusType === 'success') {
				$scope.lineFeedingGridOptions.enablePaginationControls = true;
				response.data.object.detailsDTOList.forEach(function(row) {
					$scope.lineFeedingDetailsDTO.push(response.data.object.detailsDTOList);
					$scope.lineFeedingGridOptions.data = response.data.object.detailsDTOList;
				});
			} else {
				$scope.lineFeedingGridOptions.enablePaginationControls = false;
				$scope.alerts = [];
				$scope.alerts.push({
				    type : response.data.statusType,
				    msg : response.data.statusMessage,
				    error : response.data.exceptionStackTrace,
				    errorClsName : response.data.exceptionClassName,
				    errorMsg : response.data.exceptionMessage
				});
			}
			$.unblockUI();
		} else {
			$scope.searchDataEror = response.data.statusMessage;
			$.unblockUI();
		}
	};
	
	$scope.getTime = function(){
		var datesFrom = new Date($scope.fromDate);
		if(!$scope.fromTime1){
			$scope.fromTime1 = 0;
		}
		if(!$scope.fromTime2){
			$scope.fromTime2 = 0;
		}
		if(!$scope.fromTime3){
			$scope.fromTime3 = 0;
		}
		
		datesFrom.setHours($scope.fromTime1);
		datesFrom.setMinutes($scope.fromTime2);
		datesFrom.setSeconds(0);
		
		var datesTo = new Date($scope.toDate);
		
		if(!$scope.toTime1){
			$scope.toTime1 = 23;
		}
		if(!$scope.toTime2){
			$scope.toTime2 = 59;
		}
		if(!$scope.toTime3){
			$scope.toTime3 = 59;
		}
		
		datesTo.setHours($scope.toTime1);
		datesTo.setMinutes($scope.toTime2);
		datesTo.setSeconds(0);
		
		$scope.fifo.beginDate = datesFrom;
		$scope.fifo.endDate = datesTo;
	};
	
	/* Load data in grid */
	$scope.load = function() {
		$scope.fifo.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

    	if(paginationOptions.endIndex === 0){
    		$scope.fifo.endIndex = $scope.gridOptions.paginationPageSize;
    	}
    	$scope.fifo.startIndex = paginationOptions.startIndex;
    	$scope.fifo.endIndex = paginationOptions.pageSize;
		$scope.fifo.partNumber = $scope.partNumber;
		$scope.fifo.beginDate = $scope.fromDate;
		$scope.fifo.endDate = $scope.toDate;
		//$scope.fifo.allocation = $scope.allocation;
		
		$scope.getTime();
		
		var parameterTemp = $scope.removeAllExras();
		/*lineFeedingDetailsService.lineFeedingDetailsCheckCount(parameterTemp).then(function(response) {*/
		lineFeedingDetailsService.pickingListCount(parameterTemp).then(function(response) {
			/*$scope.gridOptions.totalItems = response.objectList.length;
			$scope.recordCount = response.objectList.length;*/
			$scope.gridOptions.totalItems = response.data.object;
			$scope.recordCount = response.data.object;
			if($scope.recordCount > 0){
				lineFeedingDetailsService.lineFeedingDetailsCheckCount(parameterTemp).then(function(response) {
					var resTemp={};
					resTemp.data= angular.copy(response);
					$scope.lineFeedingDetailsGridData(resTemp);
				});
			}
		});
	};
	
	//-----------Remove empty attributes--------------
	$scope.removeAllExras = function(){
		var parameter = angular.copy($scope.fifo);
		/*delete parameter["endIndex"];
		delete parameter["startIndex"];
		delete parameter["fromTime"];
		delete parameter["toTime"];*/
		delete parameter["partNumber"];
		delete parameter["plant"];
		delete parameter["shift"];
		if(parameter.line == ""){
			delete parameter["line"];
		}
		if(parameter.device == ""){
			delete parameter["device"];
		}
		if(parameter.location == ""){
			delete parameter["location"];
		}
		return parameter;
	}
	// --------- search button ---------
	$scope.searchFifo = function() {
		if ($scope.validateFilter() == true) {
			$scope.blockUI();			
			$scope.alerts = [];
			$scope.gridOptions.data = [];			
			$scope.fromDate = $filter('date')($scope.beginDate, 'yyyy-MM-dd');
			$scope.toDate = $filter('date')($scope.endDate, 'yyyy-MM-dd');			
			$scope.fifo.partNumber = $scope.partNumber;			
		    $scope.fifo.isFullDownload=0;
			paginationOptions.startIndex = 0;
			paginationOptions.endIndex = 0;
			paginationOptions.pageNumber = 1;
			paginationOptions.pageSize = 100;
			$scope.gridOptions.paginationCurrentPage = 1;
			$scope.gridOptions.paginationPageSize = 100;
			/*$scope.fifo.startIndex=0;
			$scope.fifo.endIndex=0;*/
			$scope.searchClicked = true;
			$scope.clearFilters();
			$scope.load();
			$(".appViewDiv").css({
			    "height" : $(window).height() - 130,
			    "overflow" : "auto"
			});
			$.unblockUI();
   			$scope.gridOptions.enablePaginationControls=false;
			$scope.gridOptions.data = [];
			return;
		} else {
			$scope.alerts = [];
			$scope.alerts.push({
			    type : 'danger',
			    msg : 'Plant/Shop is mandatory'
			});
			$.unblockUI();
   			$scope.gridOptions.enablePaginationControls=false;
			$scope.gridOptions.data = [];
			return;
		}
	};
	/* ON ADD NEW LOCATION TAG */
	$scope.location = "";
	$scope.locationIdData = [];
	$scope.locationAdded = function(tag) {
		$scope.locationArray = [];
		for (var j = 0; j < $scope.locationIdData.length; j++) {
			$scope.locationArray.push($scope.locationIdData[j].text);
		}
		$scope.location = $scope.locationArray.join(',');
		$(".appViewDiv").css({
		    "height" : $(window).height() - 130,
		    "overflow" : "auto"
		});
	};
	/* ON REMOVE ADDED LOCATION TAG */
	$scope.locationRemoved = function(tag) {
		$scope.locationArray = [];
		for (var j = 0; j < $scope.locationIdData.length; j++) {
			$scope.locationArray.push($scope.locationIdData[j].text);
		}
		$scope.location = $scope.locationArray.join(',');
		$(".appViewDiv").css({
		    "height" : $(window).height() - 130,
		    "overflow" : "auto"
		});
	};
	
	$scope.closurePickingList = function(){
		$scope.alerts = [];
		$scope.blockUI();		
		$scope.loginUser= $window.sessionStorage.getItem('loggedUserId');
		console.log("$scope.loginUser : "+$scope.loginUser);
		/*$scope.selectedRow = $scope.gridApi.selection.on.rowSelectionChanged($scope,function(row){
            $scope.selectedValue.push(row.entity.partNumber);	    	
	      });*/
		lineFeedingDetailsService.closurePickingList($scope.deviceTranId,$scope.selectedValue,$scope.loginUser).then(function(response) {
			if(response > 0){
				$scope.selectedValue = [];
				$scope.alerts = [];
				$scope.alerts.push({
				    type : 'success',
				    msg : 'Part Number closed successfully',
				}); 
			}else{
				$scope.alerts = [];
				$scope.alerts.push({
				    type : 'danger',
				    msg : 'Please select a row to close'
				}); 
			}
			lineFeedingDetailsService.lineFeedingDetailsModal($scope.deviceTranId).then(function(response) {
				$scope.lineFeedingGridOptions.totalItems = response.object.detailsDTOList.length;
				$scope.recordCount = response.object.detailsDTOList.length;
				$scope.pickListnumberSelected = response.object.pickListnumber;
				$scope.printableList = response.object.detailsDTOList;
				$scope.printableList.map(function(item) {
					if(item) {
						$scope.boxTotal += item.noOfBoxes;
						$scope.snpTotal += item.snp;
						$scope.qtyTotal += item.quantity;
					}
				});
				var resTemp={};
				resTemp.data= angular.copy(response);
				$scope.lineFeedingDetailsModelGridData(resTemp);
			});
			$.unblockUI();
		});
	};
	
	$scope.downloadPickingList = function() {
		$scope.blockUI();
		lineFeedingDetailsService.lineFeedingDetailsModal($scope.deviceTranId).then(function(response) {
			var resTemp={};
			resTemp.data= angular.copy(response);
			$scope.lineFeedingDetailsModelGridData(resTemp);
			var lineFeedingData = $scope.lineFeedingGridOptions.data;
			lineFeedingDetailsService.downloadPickingList(lineFeedingData).then(function(response) {
				if (response.objectList != null) {
					$.unblockUI();
					return response.objectList;
				} 
				$.unblockUI();
			});
		});
	};
	$scope.getDownloadFifoReportHeader = function() {
		return [ "Part Number", "Location", "Open Boxes","SNP","Open Quantity","Device","Scan Time" ];
	};
	/*$scope.csvColumnOrder = [ 'partNumber', 'location', 'snp', 'count', 'pickedRan', 'correctRan', 'pickedRanInTime', 'correctRanInTime', 'ranDateDifference', 'userId', 'deviceId', 'partInOutTime', 'scanTime', 'shift', 'comments' ];*/
	// Close the alert msg
	$scope.closeAlert = function(index) {
		$scope.alerts.splice(index, 1);
	};
	$scope.selectEndDate = function(endDate) {
		$scope.fromMaxDate = $filter('date')(endDate, 'yyyy-MM-dd');
		$scope.fifo.shift = '';
		if ($filter('date')(endDate, 'yyyy-MM-dd') == $filter('date')($scope.beginDate, 'yyyy-MM-dd')) {
			$scope.shiftDropdown = false;
		} else {
			$scope.shiftDropdown = true;
		}
	};
	$scope.selectStartDate = function(startDate) {
		$scope.fifo.shift = '';
		if ($filter('date')(startDate, 'yyyy-MM-dd') == $filter('date')($scope.endDate, 'yyyy-MM-dd')) {
			$scope.shiftDropdown = false;
		} else {
			$scope.shiftDropdown = true;
		}
	};
	$scope.validateFilter = function() {
		if ($scope.fifo.plant !== "" && $scope.fifo.plant !== null && $scope.fifo.plant !== undefined && $scope.fifo.shop !== "" && $scope.fifo.shop !== null && $scope.fifo.shop !== undefined) {
			return true;
		} else if ($scope.ranData.length > 0 || $scope.tags.length > 0 ) {
			return true;
		} else {
			return false;
		}
	};
} ]);


wmsApp.factory('lineFeedingDetailsService', [ 'commonService', '$http', '$q', '$window', function(commonService, $http, $q,$window) {
	var fact = {};
	
	
	fact.pickingListCount=function(param)
    {
    	return $http({
			method : 'POST',
			url : 'rest/pickinglist/countPickingList',		
			data : param,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			return data;
		});	
	};

	fact.lineFeedingDetailsCheckCount = function(param) {
		var deferred = $q.defer();
		$http({
		    method : 'POST',
		    url : 'rest/pickinglist/search',
		    data : param,
		    headers : {
			    'Content-Type' : 'application/json'
		    }
		}).success(function(data) {
			deferred.resolve(data);
		});
		return deferred.promise;
	};
	
	fact.closurePickingList = function(deviceId,partNumber,userId) {
		var deferred = $q.defer();
		$http({
		    method : 'GET',
		    url : 'rest/pickinglist/closurePickingList?deviceTranId='+deviceId+'&partNumber='+partNumber+'&userId='+userId,
		    headers : {
			    'Content-Type' : 'application/json'
		    }
		}).success(function(data) {
			deferred.resolve(data);
		});
		return deferred.promise;
	};
	
	fact.lineFeedingDetailsModal = function(param) {
		var deferred = $q.defer();
		$http({
		    method : 'GET',
		    url : 'rest/pickinglist/pickinglist?deviceTranId='+param,
		    headers : {
			    'Content-Type' : 'application/json'
		    }
		}).success(function(data) {
			deferred.resolve(data);
		});
		return deferred.promise;
	};
	
	
	
	fact.zonesListService = function(param) {
		var deferred = $q.defer();
		$http({
		    method : 'GET',
		    url : 'rest/pickinglist/zones',
		    headers : {
			    'Content-Type' : 'application/json'
		    }
		}).success(function(data) {
			deferred.resolve(data);
		});
		return deferred.promise;
	};
	
	//ADDED FOR UAT REQ TO PROVIDE SAVE AS OPTION FOR DOWNLOAD -START
	fact.downloadPickingList= function(lineFeedingData)
    {    
    $http({       
     method: 'POST',        
     url: 'rest/pickinglist/downloadPickingList', 
     data: lineFeedingData,      
     responseType: 'arraybuffer'    
     }).success(function (data, status, headers) {        
     headers = headers();         
	     var filename = headers['x-filename'];        
	     var contentType = headers['content-type'];         
	     var linkElement = document.createElement('a');        
	     try {    
	     console.log("entered into try loop");        
	            var blob = new Blob([data], { type: contentType });            
	            var url = window.URL.createObjectURL(blob); 
	            linkElement.setAttribute('href', url);       
	             console.log("filename is : " +filename);        
	            linkElement.setAttribute("download", filename);	           
	            if ($window.navigator && $window.navigator.msSaveOrOpenBlob) {
	            console.log("entered into if window"); 
	           $window.navigator.msSaveOrOpenBlob(blob, filename);
	         } else{
	           var e = document.createEvent('MouseEvents');
	           e.initEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
	           linkElement.dispatchEvent(e);
	           // window.URL.revokeObjectURL(url); // clean the url.createObjectURL resource
	       }              
	       } catch (ex) {            
	             console.log("exception in catch" + ex);        
	         }    
	      }).error(function (data) {        
	              console.log("failure : " +data);   
	         });
    };    
    //ADDED FOR UAT REQ TO PROVIDE SAVE AS OPTION FOR DOWNLOAD -END 

	//ADDED FOR UAT REQ TO MERGE T&K SHOP DROP DOWN -START
	fact.getShopList = function(param){
		 return $http({
				method : 'POST',
				url : 'rest/pickinglist/shopsByPlantId',			
				data : param,
				headers: {'Content-Type': 'application/json'}
		 }).success(function (data) {
				return data;
		 });
	};
	//ADDED FOR UAT REQ TO MERGE T&K SHOP DROP DOWN -END 
    
	fact.getAllocationList = function(){
		 return $http({
				method : 'POST',
				url : 'rest/pickinglist/allocationByZone',			
				/*data : param,*/
				headers: {'Content-Type': 'application/json'}
		 }).success(function (data) {
				return data;
		 });
	};
	
	fact.getAllZones = function(param){
		 return $http({
				method : 'POST',
				url : 'rest/pickinglist/zoneList',			
				data : param,
				headers: {'Content-Type': 'application/json'}
		 }).success(function (data) {
				return data;
		 });
	};
	
	return fact;
} ]);