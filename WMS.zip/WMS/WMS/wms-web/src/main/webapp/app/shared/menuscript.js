(function($) {

  $.fn.menumaker = function(options) {
	
      var cssmenu = $(this), settings = $.extend({
        title: "Menu",
        format: "dropdown",
        sticky: false
      }, options);

      return this.each(function() {
    	
    	    multiTg = function() {          
    	          cssmenu.find(".has-sub").prepend('<span class="submenu-button"></span>');          
    	         
    	          cssmenu.find('.submenu-button').on('click', function() {
    	        	
    	            $(this).toggleClass('submenu-opened');
    	            if ($(this).siblings('ul').hasClass('open')) {
    	              $(this).siblings('ul').removeClass('open').hide();
    	            }
    	            else {
    	              $(this).siblings('ul').addClass('open').show();
    	            } 
    	          });
    	          
    	          cssmenu.find('.submenu-link').on('click', function() {
      	        	
      	            $(this).siblings('span').toggleClass('submenu-opened');
      	            if ($(this).siblings('ul').hasClass('open')) {
      	              $(this).siblings('ul').removeClass('open').hide();
      	            }
      	            else {
      	              $(this).siblings('ul').addClass('open').show();
      	            } 
      	          });
    	          
    	          cssmenu.children('ul').show();
    	     };
    	        
    	  
    
    	  cssmenu.find('li ul').parent().addClass('has-sub');
    	  cssmenu.find('li ul').siblings('a').addClass('submenu-link');
    	  
    	  if (settings.format === 'multitoggle') 
        	multiTg();
    	  else 
        	cssmenu.addClass('dropdown');

    	  if (settings.sticky === true) 
        	cssmenu.css('position', 'fixed');

      });
  };
})(jQuery);

/*
(function($){
$(document).ready(function(){
	
	
	handlemenu = function(){	
		alert("Handle Menu");
		$("#cssmenu").menumaker({
			title: "Menu",
			format: "multitoggle",
			
		});

	};



});
})(jQuery); 
*/

