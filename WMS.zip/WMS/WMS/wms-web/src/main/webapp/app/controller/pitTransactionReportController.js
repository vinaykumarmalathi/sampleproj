wmsApp.controller('pitTransactionReportController', 
		['$scope','$window','$filter', '$location', '$q', 'pitTransactionReportService','locationService','uiGridTreeViewConstants', '$http','commonService','localStorageService','partNumberService','ranService',
		 function($scope,$window,$filter, $location, $q, pitTransactionReportService,locationService,uiGridTreeViewConstants, $http,commonService,localStorageService,partNumberService,ranService){
			
			$scope.selectedErrorCode='';
			$scope.searchDataEror="Click search to fetch records.";
			
			$scope.beginDate=new Date();
		    $scope.endDate=new Date();
		    $scope.fromMaxDate=new Date();
		    
		    $scope.todayDate = new Date();
			
			$scope.recountList = ["ALL", "YES", "NO"];
			
			$scope.scannedList = ["ALL", "YES", "NO"];
			
			$scope.beginDatePickerOpen = false;
		    $scope.endDatePickerOpen = false;

		    $scope.openBeginDatePicker = function ($event) {			    	
		    $event.preventDefault();
		    $event.stopPropagation();
		    $scope.beginDatePickerOpen = !$scope.beginDatePickerOpen;
		    };

		    $scope.openEndDatePicker = function ($event) {
		    $event.preventDefault();
		    $event.stopPropagation();
		    $scope.endDatePickerOpen = !$scope.endDatePickerOpen;			  
		    };
			
			// --------- Plant drop down list -------
			if($window.sessionStorage.getItem('locationDPCollection') == null || $window.sessionStorage.getItem('locationDPCollection')=='undefined' || $window.sessionStorage.getItem('locationDPCollection')==undefined){
			  commonService.getAllPlants()
			  	.success(function(response){					 
					$scope.locations = response.objectList;				
					$window.sessionStorage.setItem('locationDPCollection',JSON.stringify($scope.locations));
				})
				.error(function(response){
				});
			}else{
				$scope.locations = JSON.parse(sessionStorage.locationDPCollection);
			}
			
			
			/*ON ADD NEW LOCATION TAG*/
			$scope.location="";
			$scope.locationIdData=[];	 
		    $scope.locationAdded = function(tag) {					
		    $scope.locationArray = [];
			    for (var j=0; j < $scope.locationIdData.length; j++) {
			    	$scope.locationArray.push($scope.locationIdData[j].text);
			    }
			    $scope.location=$scope.locationArray.join(',');
			    $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    /*ON REMOVE ADDED LOCATION TAG*/
		    $scope.locationRemoved = function(tag) {			   
		    	 $scope.locationArray = [];
			     for (var j=0; j < $scope.locationIdData.length; j++) {
			    	 $scope.locationArray.push($scope.locationIdData[j].text);
			     }
			     $scope.location=$scope.locationArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    /*AUTOCOMPLE LOCATION ON ENTER MIN 3 CHAR DATA*/
		    $scope.loadLocation = function(query) {
		    	var locationInputObj = {"locationId": query};			    	
		    	return locationService.locationList(locationInputObj).then(function(response){	
		    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    	});			    				         
		    };
		    
		    /* RAN Auto Completion - Start */
		    $scope.ranData=[];	
		    
		    $scope.ranAdded = function(tag) {			
				console.log("tagAdded:",tag);
				  $scope.ranArray = [];
				     for (var j=0; j < $scope.ranData.length; j++) {
				    	 $scope.ranArray.push($scope.ranData[j].text);
				      }
				     $scope.pit.ran=$scope.ranArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			};
		    
		    $scope.ranRemoved = function(tag) {			   
		    	 $scope.ranArray = [];
			     for (var j=0; j < $scope.ranData.length; j++) {

			    	 $scope.ranArray.push($scope.ranData[j].text);
			      }
			     $scope.pit.ran=$scope.ranArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    $scope.loadRan = function(query) {
		    	var partInputObj = {"ranId": query};
		    	return ranService.ranList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){	
		        			 console.log(response.data.object);
		        			  return response.data.object;                           
		        		 }
		        	 }		    		
			    });	
		    };
		    /*RAN Auto Completion - End */
		    
		 // --------- Part Number List ---------
			$scope.partNumber='';
			$scope.searchClicked=false;
			$scope.tags=[];	 
			/*ON ADD NEW PART TAG*/
			$scope.transactionList= ["In", "Out", "Move"];
			$scope.tagAdded = function(tag) {
				
				  $scope.partArray = [];
				  
				     for (var j=0; j < $scope.tags.length; j++) {
				    	 
				    	 $scope.partArray.push($scope.tags[j].text);
				    	 console.log("Part Array",$scope.partArray);
				      }
				     $scope.partNumber=$scope.partArray.join(',');
				     console.log("Part Number",$scope.partNumber);
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			/*ON REMOVE ADDED PART TAG*/
			    
		    $scope.tagRemoved = function(tag) {			   
		    	 $scope.partArray = [];
			     for (var j=0; j < $scope.tags.length; j++) {

			    	 $scope.partArray.push($scope.tags[j].text);
			      }
			     $scope.partNumber=$scope.partArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    $scope.addingTag = function(tag) {
		    	console.log("Tag.text",tag.text);
		    	  tag.text = tag.text.replace(/ /g, ',');
		    	  console.log("Tag.text 2",tag.text);
		    	  return tag;
		    	};
		    	
			
		    /*AUTOCOMPLE PART ON ENTER MIN 3 CHAR DATA*/
		    $scope.loadParts = function(query) {		    	
		    	var partInputObj = {"partNumber": query};			    	
		    	return partNumberService.partNumberList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    });			    				         
		    };
			
			// --------- Shops drop down list ---------
		    $scope.loadShopLine = function(){
		    	//$scope.pit.line = '';
		    	$scope.pit.shop = '';
		    	/*commonService.getLineList($scope.pit.plant)
				 .success(function(response){
					 $scope.lines = response.objectList;				
				 })
				 .error(function(response){
				 });*/
		    	commonService.getShopList($scope.pit.plant)
		    	.success(function(response){
					 $scope.shops = response.objectList;				
				 })
				 .error(function(response){
				 });

		    };
		    
		    $scope.pit = {				
			    	  partNumber : $scope.partNumber,
			    	  location : $scope.location,
			    	  fromDate : $scope.beginDate,
	                  toDate : $scope.endDate,
	                  startIndex : 0,
	                  endIndex : 0
	        };
		    
		    var paginationOptions = {
				 	startIndex : 0,
				 	endIndex : 0,
				    pageNumber: 1,
				    pageSize: 100,
				    sort: null
				  };
		    
		  //Grid
		    $scope.gridOptions = {
			enablePaginationControls:false,
			enableGridMenu: true,
            enableFiltering: true,            
            enableColumnResize: true,
            paginationPageSizes: [100,250,500,750,1000],
    	    paginationPageSize: 100,         
            useExternalPagination: true,
            autoResize:true,
            enableSorting: true,
            enableColumnMenus: false,
            enablePinning: true,            
            columnDefs: [
                          { field: 'transactionId', displayName: 'Transaction Id', width:125 }, 
			       	      { field: 'partNumber', displayName: 'Part Number', width:100},
			       	      { field: 'location', displayName: 'Location', width:100 },
			       	      { field: 'ran', displayName: 'RAN', width:80 },
			       	      { field: 'snp', displayName: 'SNP', width:50 },
			       	      { field: 'totalQuantity', displayName: 'Total Quantity', width:110},
			       	      { field: 'dateTime',type: 'date', displayName: 'Date Time', width:180,cellFilter: 'date:\'MMM d, yyyy HH:mm:ss a\'' },
			       	      { field: 'deviceId', displayName: 'Device', width:70},
			       	      { field: 'isUpdated', displayName: 'Is Updated', width:70},
			       	      { field: 'wmsStockQuantity', displayName: 'WMS Stock', width:90},
			       	      { field: 'stockDifference', displayName: 'Stock Difference', width:120},
			       	      { field: 'recount', displayName: 'ReCount', width:80},
			       	      { field: 'comments', displayName: 'Comments', width:250}
                       ],
                       exporterPdfAlign:'left',
                       exporterCsvFilename: 'PIT_TransactionReport.csv',
                       exporterMenuVisibleData: false,
                       exporterPdfDefaultStyle: {fontSize: 9},
                       exporterPdfTableStyle: {margin: [70, 5, 0, 5]},
                       exporterPdfTableHeaderStyle: {fontSize: 10, bold: true, italics: true, color: 'red'},
                       exporterPdfHeader: { text: "PIT Transaction Report", style: 'headerStyle' },
                       exporterPdfFooter: function ( currentPage, pageCount ) {
                         return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
                       },
                       exporterPdfCustomFormatter: function ( docDefinition ) {
                       	 docDefinition.styles.headerStyle = { fontSize: 20, bold: true, alignment: 'center', margin: [0, 0, 20, 0] }; 
                            docDefinition.styles.footerStyle = { fontSize: 10, bold: true, alignment: 'center',  margin: [5, 0, 20, 0] }; 
                         return docDefinition;
                       },
                       exporterPdfOrientation: 'landscape',
                       exporterPdfPageSize: 'LETTER',
                       exporterPdfMaxGridWidth: 500,
                       exporterPdfFilename: 'PIT_Transaction_Report.pdf',
                       exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
                      
                       onRegisterApi: function( gridApi ) {
                       	 $scope.gridApi = gridApi;
                       	 //Pagination
                       	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                       		 $scope.blockUI();
            		          paginationOptions.pageNumber = newPage;
            		          paginationOptions.pageSize = pageSize;
            		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
            		        paginationOptions.endIndex   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
            		        $scope.load();
            		        });
                       
               	    }
		    };
		    
		    $scope.clearFilters = function() {
				$scope.gridApi.core.clearAllFilters();
		    };
		    
		    
		    $scope.pitTransactionData = function(){    	    	 
		    	pitTransactionReportService.pitTransactionReport($scope.pit).then(function(response){
			    		$scope.gridOptions.data = [];
			    		if(response.data.objectList !== undefined && response.data.objectList !== null){
			    			
			    			if(response.data.statusType === 'success' ){
			    				$scope.gridOptions.enablePaginationControls=true;
			    				 response.data.objectList.forEach(function(row){	    	    	         	          
			    	    	           $scope.gridOptions.data = response.data.objectList;	 
			    	    	          });
			    				 
			    				 	
			    			} else {
			    				$scope.gridOptions.enablePaginationControls=false;
			    				$scope.alerts = [];
					            $scope.alerts.push({
					                type : response.data.statusType,
					                msg : response.data.statusMessage,
					                error : response.data.exceptionStackTrace,
					                errorClsName : response.data.exceptionClassName,
					                errorMsg : response.data.exceptionMessage
					            });
			    			}
			    			$.unblockUI();
			    		} else {
			    			$scope.searchDataEror=response.data.statusMessage;	    			
				            $.unblockUI();
			    		}
			    	});
		     };
		    
		    /* Load data in grid */
		    $scope.load = function () {
		    	$scope.pit.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

		    	if(paginationOptions.endIndex === 0){
		    		$scope.pit.endIndex = $scope.gridOptions.paginationPageSize;
		    	}
		    	$scope.pit.startIndex = paginationOptions.startIndex;
		    	$scope.pit.endIndex = paginationOptions.pageSize;
		    	$scope.pit.partNumber = $scope.partNumber;
		    	$scope.pit.location = $scope.location;
		    	
		    	$scope.pit.fromDate = $scope.fromDate;
		    	$scope.pit.toDate = $scope.toDate;
		    	
		    	pitTransactionReportService.pitTransactionReportCount($scope.pit).then(function(response){
		    		$scope.gridOptions.totalItems = response.data.object;		    		
		    		$scope.recordCount = response.data.object;		    		
		    		$scope.pitTransactionData();
		    	});
		    	
		    };
		    
		 // Reset the values
		    $scope.resetPitTransactionReport = function(){	
		    	$scope.shops = "";
		    	$scope.beginDate=new Date();
			    $scope.endDate=new Date();    	  
		    	$scope.gridOptions.data = [];
		    	$scope.clearFilters();	  
		    	$scope.pit = {};
		    	$scope.partNumber="";	    	
		    	$scope.pit.startIndex = 0;
		    	$scope.pit.endIndex = 0;
		    	$scope.tags=[];
		    	$scope.ranData=[];
		    	$scope.locationIdData=[];	
		    	$scope.gridOptions.totalItems=0;
		    	$scope.location="";
		    	$scope.partNumber="";
		    	$scope.gridOptions.enablePaginationControls=false;	
		    	$scope.searchDataEror="Click search to fetch records.";
		    	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    	
			    $scope.pit.deviceId="";
		    };
		    
		    $scope.downloadPitTransactionReport =function(){
            	$scope.alerts = [];
            	$scope.blockUI();
            	$scope.pit.fromDate=$filter('date')($scope.beginDate, 'yyyy-MM-dd');;
		    	$scope.pit.toDate=$filter('date')($scope.endDate, 'yyyy-MM-dd');
		    	var validateFlag =$scope.validateFilter();
		    	if( validateFlag == true){	
			    	$scope.pit.partNumber=$scope.partNumber;
	            	$scope.pit.location=$scope.location;
	            	$scope.pit.isFullDownload=1;
	            	return pitTransactionReportService.pitTransactionDownload($scope.pit).then(function(response){
	            		if(response.objectList != null){
	            			for (var i = 0; i < response.objectList.length; i++) {
	            				response.objectList[i].ran = '="'+response.objectList[i].ran+'"';
	            				response.objectList[i].partNumber = '="'+response.objectList[i].partNumber+'"';
	            				response.objectList[i].dateTime =$filter('date')(response.objectList[i].dateTime, 'dd/MM/yyyy HH:mm:ss');
	            				response.objectList[i].updatedDateTime =$filter('date')(response.objectList[i].updatedDateTime, 'dd/MM/yyyy HH:mm:ss');
	            			}
	            			$.unblockUI();
	            			return response.objectList;
	            			
	            		}else{
	            			$.unblockUI();
	            			$scope.alerts = [];
	    	       			$scope.alerts.push({
	    	       				 type : 'danger',
	    	       				msg : response.statusMessage
	    	       			});
	            		}
	            		
	            	});
		    	}
		    	else{
		    		$.unblockUI();
            		$scope.alerts = [];
	       			$scope.alerts.push({
	       				 type : 'danger',
	       				 msg : 'Plant, Shop, Recount and Scanned fields are mandatory'
	       			});
	       			//Throwing null pointer error intentionally as a temporary fix to stop downloading.
	       			var temp=null;
	       			console.log("Temp length",temp.length);	       			
            	}
		    	
            };
         
            $scope.getDownloadPitTransactionReportHeader = function () {
            	return ["Transaction Id", "Part Number","Location", "RAN", "SNP","Total Quantity","Date Time","Device", "Is Updated", "WMS Stock","Stock Difference","ReCount","Comments", "Updated Date Time"];
           };
           $scope.csvColumnOrder=['transactionId','partNumber','location', 'ran', 'snp','totalQuantity','dateTime','deviceId', 'isUpdated', 'wmsStockQuantity','stockDifference','recount','comments','updatedDateTime'];

		    
		 // --------- search button ---------
            $scope.searchPitTransactionReport = function() {
            	if( $scope.validateFilter() == true){
            		$scope.blockUI();
            		$scope.fromDate = $filter('date')($scope.beginDate, 'yyyy-MM-dd');
            		$scope.toDate = $filter('date')($scope.endDate, 'yyyy-MM-dd');
            		$scope.alerts = [];
            		$scope.gridOptions.data = [];
            		$scope.pit.partNumber=$scope.partNumber;
            		$scope.pit.location=$scope.location;
            		$scope.pit.isFullDownload=0;
            		
            		$scope.pit.fromDate = $filter('date')($scope.beginDate, 'yyyy-MM-dd');
            		$scope.pit.toDate = $filter('date')($scope.endDate, 'yyyy-MM-dd');
            		
            		paginationOptions.startIndex= 0;
            		paginationOptions.endIndex= 0;
            		paginationOptions.pageNumber= 1;
            		paginationOptions.pageSize= 100; 
            		$scope.gridOptions.paginationCurrentPage=1;
            		$scope.gridOptions.paginationPageSize=100;
            		$scope.searchClicked=true;
            		$scope.clearFilters();                	
            		$scope.load();
            		$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
            	}else{
            		$scope.alerts = [];
	       			$scope.alerts.push({
	       				 type : 'danger',
	       				 msg : 'Plant, Shop, Recount and Scanned fields are mandatory'
	       			});
            	}
            };
            
            $scope.validateFilter = function(){
		    	 if($scope.pit.plant !== "" && $scope.pit.plant !== null && $scope.pit.plant !== undefined 
		    			 && $scope.pit.shop !== "" && $scope.pit.shop !== null && $scope.pit.shop !== undefined
		    			 && $scope.pit.recount!== "" && $scope.pit.recount !== null && $scope.pit.recount !== undefined
		    			 && $scope.pit.scanned!== "" && $scope.pit.scanned !== null && $scope.pit.scanned !== undefined)
				 {
					 return true;
				 }
		    	 
		    	 else{
					 return false;
				 }
		     };
			
			
}]);