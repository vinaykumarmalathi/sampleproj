wmsApp.controller('loginController', [ '$scope','$location','$window','$rootScope','commonService','redirectToParent',
        function($scope,$location,$window,$rootScope,commonService,redirectToParent) {
		 $scope.loginData = {};
		 $scope.loginError='';		
		 $scope.loginData.rememberMe=false;	
		 $rootScope.isAuthendicated=false;		
		 if($window.sessionStorage.getItem('login')=='success'){	   
		      $location.path('/home');	
		      $rootScope.isAuthendicated=true;
		 }	 
		 
		 if($window.sessionStorage.getItem('isEnableStockCorrection')=='yes'){	   		     
		      $rootScope.isEnableStockCorrection=true;
		 }	
		 
		 if($window.localStorage.getItem('username')!='' && $window.localStorage.getItem('username')!=null && $window.localStorage.getItem('username')!='undefined' && $window.localStorage.getItem('username')!=undefined){			 
			 $scope.loginData.username=$window.localStorage.getItem('username');
			 $scope.loginData.rememberMe=true;	
		 }
		 if($window.localStorage.getItem('password')!=''  && $window.localStorage.getItem('password')!=null  && $window.localStorage.getItem('password')!='undefined' && $window.localStorage.getItem('password')!=undefined){			
			 $scope.loginData.password=$window.localStorage.getItem('password');
		 }
		 $scope.clearLogin = function () {
		    	$scope.loginData.username='';
		    	$scope.loginData.password='';
		    	$scope.loginError='';
	     };
      
	     /*SIGN IN TRIGGER*/
	     
		  $scope.doLogin = function() {	
			
		      if(!$scope.loginData.username){	    	  
		    	  $scope.loginError='Please enter the user name';
		      }else if(!$scope.loginData.password){
		    	  $scope.loginError='Please enter the password';
		      }else{		    	  
		    	  var loginObj = {'username': $scope.loginData.username,'password':$scope.loginData.password};
		          commonService.callRestService('POST','rest/user/login',loginObj).success(function(data) {	
		        	 
		        	 if(data.statusType=='success' && data.statusCode=='Login2'){			        		
		        		 $window.sessionStorage.setItem('userId',$scope.loginData.username);
			    	    if($scope.loginData.rememberMe){
			    	    	$window.localStorage.setItem('username',$scope.loginData.username);			    	    	 
				    	    $window.localStorage.setItem('password',$scope.loginData.password);				    	  
			    	    }else{
			    	    	
			    	    	$window.localStorage.setItem('username','');
				    	    $window.localStorage.setItem('password','');
			    	    }
			    	    		
			    	    $rootScope.isAuthendicated=true;
			    	    
			    	    //rolesPrivilegeArray=['ADMIN','Z005564','Z003039','Z003302','Z002939','Z004722','Z005898','Z008558','Z002442','Z006962','Z007263','Z002940','Z004769','Z006949','Z007139','Z005751','Z008810','Z006830','Z007085','Z009411','Z009412','Z011897','Z005317','Z006915','Z005747','Z005562','Z006945','Z007097','Z007090','Z007251','Z008594','Z005619','Z003154','Z002340','Z002209','Z002252','Z003864','Z010949','Z011067','Z012500','Z010982'];
			    	    rolesPrivilegeArray=['ADMIN','Z005564','Z003039','Z003302','Z002939','Z004722','Z005898','Z008558','Z002442','Z006962','Z007263','Z002940','Z004769','Z006949','Z007139','Z005751','Z008810','Z005317','Z006915','Z005562','Z006945','Z007251','Z002340','Z002209','Z002252','Z003864','Z010949','Z011067','Z012500','Z010982'];
			    	    if ($.inArray($scope.loginData.username.toUpperCase(), rolesPrivilegeArray) > -1)
			    	    {						    	   
			    	    	 $rootScope.isEnableStockCorrection=true;
			    	    	 $window.sessionStorage.setItem('isEnableStockCorrection','yes');
			    	    }
			    	    $scope.loginData = {};				    	    
			    	    $window.sessionStorage.setItem('login',data.statusType);
			    	    $window.sessionStorage.setItem('statusCode',data.statusCode);				    	
			            $location.path('/home');	
			            $window.location.reload();
		        	 }else{		        	
		        		// $rootScope.isAuthendicated=false;
		        		 $rootScope.isEnableStockCorrection=false;
		        		 $scope.loginData.username='';
					      $scope.loginData.password='';
			    		  $scope.loginError=data.statusMessage;
			    		  $window.sessionStorage.setItem('login',null);
				    	  $window.sessionStorage.setItem('statusCode',null);
				    	  $window.localStorage.setItem('username','');
				    	  $window.sessionStorage.setItem('userId','');
				    	  $window.localStorage.setItem('password','');
				    	  $window.sessionStorage.setItem('isEnableStockCorrection','');
		        	 }
			        }).error(function(err) {	
			        	console.log(err);
			        	  $scope.loginData.username='';
					      $scope.loginData.password='';
			    		  $scope.loginError='Please check your login credentials';
			        });		    	  
		      }
		   };	
		   
		   /*LOGOUT TRIGGER*/
		   
		   $scope.logOut = function () {
			 
			   //$rootScope.isAuthendicated=false;
			   //$rootScope.isEnableStockCorrection=false;
			    var username =$window.localStorage.getItem('username');
			    var password =$window.localStorage.getItem('password');			 
			   //localStorage.clear();
			   $window.localStorage.setItem('username',username);			    	    	 
	    	   $window.localStorage.setItem('password',password);	
			   //$location.path('/login');
			   //$window.sessionStorage.removeItem('login');
			   //$window.sessionStorage.removeItem('statusCode');
	    	   //$window.sessionStorage.setItem('login',null);
	    	   //$window.sessionStorage.setItem('isEnableStockCorrection','');
	    	   //$window.sessionStorage.setItem('userId','');
	    	   //redirectToParent.url();
	    	   $window.sessionStorage.setItem('appLoggedIn',null);
	   		   $rootScope.isEnableStockCorrection=false;
	   		   $rootScope.isAuthendicated=false;
	   		   localStorage.clear();
	   		   sessionStorage.clear();
	    	   $window.open('/pcs/#/login','_self');
	    	  
	     };
}]);