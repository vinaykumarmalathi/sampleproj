wmsApp.controller('manageLocationController', 
		[ '$scope','$window','$filter', '$location', '$routeParams','partsMasterService','manageLocationByPartNoService','locationMasterService','locationService','uiGridTreeViewConstants', '$http','commonService','partNumberService','PartNumberInterService',
        function($scope,$window,$filter, $location, $routeParams, partsMasterService,manageLocationByPartNoService,locationMasterService,locationService,uiGridTreeViewConstants, $http,commonService,partNumberService,PartNumberInterService) {
			$scope.searchDataEror="Click search to fetch records.";
			$scope.locationIdData=[];	 
			
			$scope.part = {
					  startIndex : 0,
	                  endIndex : 0
	              };
			
			$('#manageLocationModal').on('show.bs.modal', function () {
            	$scope.clearFilters();
            	$scope.partNo = PartNumberInterService.partNumber;
            	$scope.partHeaderName = $scope.partNo;
            	console.log("$scope.partNo:",$scope.partNo);
            	$scope.searchLocations();     
            	$scope.closeAlert();
		    });
			
			var paginationOptions = {
				 	startIndex : 0,
				 	endIndex : 0,
				    pageNumber: 1,
				    pageSize: 100,
				    sort: null
				  };
			
			var locationSearchTemplate = '<div class="col-sm-12 col-xs-12 col-md-10"><tags-input ng-model="locationIdData" add-on-paste="true"'
				+'on-tag-added="grid.appScope.locationAdded($tag)" on-tag-removed="grid.appScope.locationRemoved($tag)"'
				+'	placeholder="Enter or Choose Location Id" max-tags="10"> <auto-complete'
				+'	source="grid.appScope.loadLocation($query)" minLength="3"'
				+'	highlightMatchedText="true" maxResultsToShow="10" ></auto-complete>'
				+'</tags-input></div>';
			
			
			/*GRID DEFAULT OPTIONS*/
			//gridMenuShowHideColumns:false;
			$scope.gridOptions = {		
					 enablePaginationControls:false,
					 enableGridMenu: true,
		             enableFiltering: true,            
		             enableColumnResize: true,
		             paginationPageSizes: [100,250,500],
		     	     paginationPageSize: 100,         
		             useExternalPagination: true,
		             autoResize:true,
		             enableSorting: true,
		             enableColumnMenus :true,
		             enablePinning: true, 
		             showGridFooter: false,
		             showColumnFooter: false,
		             columnDefs: [
		                         {
				                	 field: 'locationId', displayName: 'Location Id',
				                	 enableCellEdit: false,
				                	 editableCellTemplate: '<div><form name="inputForm"><input type="text" ng-class="\'colt\' + col.uid" ui-grid-editor ng-model="MODEL_COL_FIELD"></form></div>',
				                 },				                 
				                 {
				                	 field: 'currentQty', displayName: 'Current Quantity',
				                	 enableCellEdit: false,
				                 },
				                 
				                 {
				                	 field: 'ran', displayName: 'RAN',
				                	 enableCellEdit: false,
				                 },

				                 {
				                	 field: 'totalCapacity',
				                	 displayName: 'Total Capacity',
				                	 enableCellEdit: false,
				                	 cellTemplate:'<div><label ng-show="row.isSelected" style="border:1px solid #F00;"><input type="text" ng-show="row.isSelected" ng-model="row.entity.totalCapacity"></input></label></div><div ng-show="!row.isSelected">{{row.entity.totalCapacity}}</div>',
				                		 
				                 }
				             ],
				             onRegisterApi: function( gridApi ) {
	                        	 $scope.gridApi = gridApi;
	                	    }
				           
				    };
			
			/*ON ADD NEW LOCATION TAG*/
		    
			$scope.location="";
			$scope.locationIdData=[];	 
		    $scope.locationAdded = function(tag) {					
		    $scope.locationArray = [];
			    for (var j=0; j < $scope.locationIdData.length; j++) {
			    	$scope.locationArray.push($scope.locationIdData[j].text);
			    }
			    $scope.location=$scope.locationArray.join(',');
			    $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    /*ON REMOVE ADDED LOCATION TAG*/
		    
		    $scope.locationRemoved = function(tag) {	
		    	 $scope.locationArray = [];
			     for (var j=0; j < $scope.locationIdData.length; j++) {
			    	 $scope.locationArray.push($scope.locationIdData[j].text);
			     }
			     $scope.location=$scope.locationArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
			
			/*AUTOCOMPLE LOCATION ON ENTER MIN 3 CHAR DATA*/
		    $scope.loadLocation = function(query) {
		    	var locationInputObj = {"locationId": query};			    	
		    	return locationService.locationList(locationInputObj).then(function(response){	
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){		
		        			  return response.data.object;                           
		        		 }
		        	 }			    		
			    	});			    				         
		    };
			
				/* LOAD data in grid */
			    $scope.load = function () {
			    	$scope.part.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
    		    	if(paginationOptions.endIndex === 0){
    		    		$scope.part.endIndex = $scope.gridOptions.paginationPageSize;
    		    	}
    		    	$scope.part.startIndex = paginationOptions.startIndex;
    		    	$scope.part.endIndex = paginationOptions.pageSize;	
    		    	
    		    	//$scope.gridOptions.data = response.data.objectList;		    	
    		    	manageLocationByPartNoService.locationCount($scope.part).then(function(response){
			    		$scope.gridOptions.totalItems = response.data.object;		    		
			    		$scope.recordCount = response.data.objectList.length;	
			    		$scope.searchLocations();
			    		
			    	});			    	
			    };
			    
			    //FIND locations for the part number as input.
			    $scope.searchLocations = function(){
			    	if($scope.partNo!='' && $scope.partNo!=undefined){
			    		manageLocationByPartNoService.getLocationsByPartNumber($scope.partNo).then(function(response){	
				    		$scope.gridOptions.data = [];
				    		if(response.data!== undefined && response.data.objectList!== undefined && response.data.objectList!=null){	
				    			if(response.data.statusType === 'success' && response.data.objectList.length>0){
				    				$scope.gridOptions.data = response.data.objectList;
				    				//-------------------------end load
				    			} else {
				    				$scope.searchDataEror=response.data.statusMessage;
				    			}
				    			$.unblockUI();
				    		} else {
				    			$scope.searchDataEror=response.data.statusMessage;					    			
					            $.unblockUI();
				    		}
				    	});
			    	}else{
			    		$scope.gridOptions.data =[];
	    				$scope.alerts = [];
			            $scope.alerts.push({
			                type : "danger",
			                msg : "Please enter part number."
			            });
			    	}
			    };
		     
		     
			    // SAVE location in part 
	            $scope.saveLocations = function() {
	            	$scope.outputData = $scope.gridApi.selection.getSelectedRows();
	            	$scope.updateLocObj = [];
	            	if($scope.outputData.length > 0){
		            	angular.forEach($scope.outputData,function(obj,i){
		    					obj.partNo = $scope.partNo;
		    					$scope.updateLocObj[i] = obj;
					    });		
		    			manageLocationByPartNoService.saveLocations($scope.updateLocObj).then(function(response){				            	
		    				if(response.data.statusType === 'success' ){
						           $scope.alerts = [];
						            $scope.alerts.push({
						                type : response.data.statusType,
						                msg : response.data.statusMessage
						            });
						           $scope.searchLocations();
				    			} else {						    				
				    				$scope.alerts = [];
						            $scope.alerts.push({
						                type : response.data.statusType,
						                msg : response.data.statusMessage
						            });
				    			}
				    			$.unblockUI();    			
						    									    		
						});	
		                $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"});
		            }else{
		            	$scope.alerts = [];
			            $scope.alerts.push({
			                type : "danger",
			                msg : "Please select the records to be saved."
			            });
		            }
	            };
	            
	            // DELETE location from part 
	            $scope.deleteLocations = function() {
		            	$scope.outputData = $scope.gridApi.selection.getSelectedRows();
		            	$scope.deleteLocObj = [];
		            	$scope.loginUser= $window.sessionStorage.getItem('loggedUserId');
		            	if($scope.outputData.length > 0){
		            		var cnt = 0;
		            	angular.forEach($scope.outputData,function(obj,i){
			    				if(0 === obj.currentQty){
			    					obj.partNo = $scope.partNo;
			    					obj.userId = $scope.loginUser;
			    					$scope.deleteLocObj[cnt] = obj;
			    					cnt++;
			    				}
						    });	
			            	if($scope.deleteLocObj.length > 0){			            		
			        			console.log("$scope.loginUser in delete partlocation : " +$scope.loginUser);
			    			manageLocationByPartNoService.deleteLocation($scope.deleteLocObj).then(function(response){				            	
			    				if(response.data.statusType === 'success' ){	
			    						$scope.alerts = [];
							            $scope.alerts.push({
							                type : response.data.statusType,
							                msg : response.data.statusMessage//"The locations having current quantity as 0 has been deleted."
							            });
			    						$scope.searchLocations();
					    			} else {
					    				$scope.alerts = [];
							            $scope.alerts.push({
							                type : response.data.statusType,
							                msg : response.data.statusMessage
							            });
					    				
					    			}
					    			$.unblockUI();    			
							    									    		
							});	
			    			$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"});
			            	}else{
			    				$scope.alerts = [];
					            $scope.alerts.push({
					                type : "danger",
					                msg : "Please select valid records.User can delete records which is having current quantity 0."
					            });
				            }
	            		}else{
			            	//$scope.gridOptions.enablePaginationControls=false;
		    				$scope.alerts = [];
				            $scope.alerts.push({
				                type : "danger",
				                msg : "Please select the records to be deleted."
				            });
			            }
		            };
	            
		            
		            // ADD location to part 
		            $scope.addLocation = function() {
		            	if($scope.partNo!='' && $scope.location!='' && $scope.partNo!=undefined && $scope.location!=undefined){
			            	$scope.newLoc = {							    	 
			            			partNo : $scope.partNo,	
			            			locationId : $scope.location,
			            			currentQty : $scope.currentQty,
			            			totalCapacity : $scope.totalCapacity,
			            			ran:$scope.ran
			   	              };
			            	
			    			manageLocationByPartNoService.addLocation($scope.newLoc).then(function(response){				            	
			    				if(response.data.statusType === 'success' ){					    						
			    					$scope.searchLocations();
						            $scope.location = "";
						            $scope.currentQty = "";
						            $scope.ran = "";
							        $scope.totalCapacity = "";
							        $scope.alerts = [];
						            $scope.alerts.push({
						                type : response.data.statusType,
						                msg : response.data.statusMessage
						            });
					    		} else {	
						            $scope.location = "";
						            $scope.currentQty = "";
						            $scope.ran = "";
							        $scope.totalCapacity = "";
					    			$scope.alerts = [];
						            $scope.alerts.push({
						                type : "danger",
							            msg : response.data.statusMessage
						            });
					    		}
					    		$.unblockUI();    			
							    									    		
							});	
			    			            	
			    			$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"});
			            }else{
			            	$scope.alerts = [];
				            $scope.alerts.push({
				                type : "danger",
				                msg : "Part number and Location cannot be null for adding location."
				            });
			            }
		            };
	            
	            $scope.clearFilters = function() {
	            	$scope.gridApi.core.clearAllFilters();
	            };
	            
	          //Close the alert msg
	            $scope.closeAlert = function(index) {
			        $scope.alerts.splice(index, 1);
			    };
			    
//			// --------- Location List ---------
			$scope.searchLocationsByPartId = function(){	
				$scope.alerts = [];
            	paginationOptions.startIndex= 0;
            	paginationOptions.endIndex= 0;
            	paginationOptions.pageNumber= 1;
            	$scope.gridOptions.paginationCurrentPage=1;
            	$scope.gridOptions.paginationPageSize=100;//No of records to be displayed in page	
            	$scope.gridOptions.paginationPageSizes = [100,250,500];
            	$scope.gridOptions.enableFiltering = true; 
            	$scope.gridOptions.enablePinning = true;
            	$scope.clearFilters(); 
            	$scope.searchLocations();
            	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
			};
			
			 $scope.searchLocationId = function(typedthings) {
			    $scope.names = "";
			    if(typedthings.length > 2){
			    	var locationInputObj = {"locationId": typedthings};
			    	locationService.locationList(locationInputObj).then(function(response){	
			    		if(response.data.statusType=='success'){
			    			if(response.data.object!='null' && response.data.object!=null){	
			    				$scope.resultObj=[];
			    				angular.forEach(response.data.object,function(obj){
			    					$scope.resultObj.push(obj.text);
			    				});
			    				$scope.names = $scope.resultObj;
			    			}
			    		}			    		
			    	});
			    }
			};
			
		} ]);

		 


