wmsApp.controller('previousRemarksController', [ '$scope','RemarksInterService',function($scope,RemarksInterService) {
		 
	$('#previousRemarks').on('show.bs.modal', function () {
    	$scope.partHeaderName = RemarksInterService.partNumber;
    	$scope.logs = RemarksInterService.remarks;
    });
	
}]);