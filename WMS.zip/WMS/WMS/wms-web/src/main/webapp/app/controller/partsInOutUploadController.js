wmsApp.controller('partsInOutUploadController', [ '$scope','commonService','$window','$location','$rootScope','partInOutUploadService',
		function($scope,commonService,$window,$location,$rootScope,partInOutUploadService) { 
	        $scope.validUpload = false;
			$scope.data = [];
			$scope.gridOptions = {
				enableGridMenu : false,
				data : 'data',
				importerDataAddCallback : function(grid, newObjects) {
					
					//Reset the Grid columns for new file upload - Start
					var fileHeaders=[];
					//var fileHeaders1=[];
					$scope.columnsVal = [];
					angular.forEach(newObjects[0], function(value,key) {
						var obj = {};
						obj["name"] = key;
						obj["type"] = typeof value;
						$scope.columnsVal.push(obj);
						fileHeaders.push(key);
				    });
					$scope.gridOptions.columnDefs = $scope.columnsVal;
					//- End
					
					$scope.data = $scope.data.concat(newObjects);
					
					var requiredFields=['partNumber','location','transactionType','count','ran','userId','deviceId','reasonCode'];
					//var optionalFields =['scanTime','noOfBoxes','snp','suggestedLocation','suggestedRan'];
					var allFields =['partNumber','location','transactionType','count','ran','userId','deviceId','reasonCode','scanTime','noOfBoxes','snp','suggestedLocation','suggestedRan','locationDestination'];
					
					/*for(var i in $scope.data[0]){						
						fileHeaders.push(i);
					}
					console.log("File Headers",fileHeaders);
					console.log("File Headers1",fileHeaders1);*/
					for(var i in fileHeaders)
					{
						//console.log("File Header",fileHeaders[i]);
						if($.inArray(fileHeaders[i], allFields)==-1)
						{
							 $scope.data = [];
							 $scope.validUpload = false;
							 $scope.alerts = [];
			                 $scope.alerts.push({
			                     type : "danger",
			                     msg : "Invalid file! Invalid Column " + fileHeaders[i]
			                });
			                return ; 
						}	
					}
					for(var i in requiredFields)
					{
						if($.inArray(requiredFields[i], fileHeaders)==-1)
						{
							$scope.data = [];
							 $scope.validUpload = false;
							 $scope.alerts = [];
			                 $scope.alerts.push({
			                     type : "danger",
			                     msg : "Invalid file!  Column missing " + requiredFields[i]
			                });
			                return ;
						}
					}	
				
					$scope.validUpload = true;
					$scope.$apply();
				},
				onRegisterApi : function(gridApi) {
					$scope.gridApi = gridApi;
				}
			};

			function closeWindow() {
	            netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserWrite");
	            alert("This will close the window");
	            $window.open('','_self');
	            $window.close();
	        }
			function close_window() {
				
			}
			$scope.uploadCSVFile = function(){
				
				 $scope.blockUI();
				//Removing unwanted-$$hashKey property 
			    $scope.uploadData = $scope.data;
			    angular.forEach($scope.uploadData,function(val,key){
			    	$scope.uploadData[key]["userId"]=$window.sessionStorage.getItem('userId');
			    	delete $scope.uploadData[key].$$hashKey; 
			    });

				//upload sheet service call - Start
				
				partInOutUploadService.uploadStockDetailSheet($scope.uploadData)
				  .success(function(msg){					 
					     $scope.alerts = [];
		                 $scope.alerts.push({
		                     type : msg.statusType,
		                     msg : msg.statusMessage,
		                     error : msg.exceptionStackTrace,
		                     errorClsName : msg.exceptionClassName,
		                     errorMsg : msg.exceptionMessage
		                 });
		                 $.unblockUI();
				  })
				  .error(function(response){
					  $scope.alerts = [];
		                 $scope.alerts.push({
		                     type : "danger",
		                     msg : "Service failed - Please check with admin"
		                });
		                 $.unblockUI();
				  });
			     // --End
			};
			
			var handleFileSelect = function( event ){
				$scope.gridOptions.columnDefs = [];
				$scope.data = [];
			    var target = event.srcElement || event.target;
			    
			    if (target && target.files && target.files.length === 1) {
			    	 $scope.blockUI();
			      var fileObject = target.files[0];
			      var fileType = [];
			      fileType = fileObject.name.split(".");
			      if(fileType[1].toLowerCase() == "csv"){
			    	 
			    	  $scope.gridApi.importer.importFile( fileObject );
			    	  $.unblockUI();
			    	  $scope.validUpload = true;
			    	  $scope.closeAlert();
			      }else{
			    	  $scope.alerts = [];
		                 $scope.alerts.push({
		                     type : "danger",
		                     msg : "Invalid file type!. Please choose '.CSV' file"
		                });
		                 $scope.validUpload = false;
		                 $scope.$apply();
		              $.unblockUI();
			      }
			    }			    
			  };
			 
			  var fileChooser = document.querySelectorAll('.file-chooser');
			  
			  if ( fileChooser.length !== 1 ){
			    console.log('Found > 1 or < 1 file choosers within the menu item, error, cannot continue');
			  } else {
			    fileChooser[0].addEventListener('change', handleFileSelect, false);
			  }
			  
		  $scope.closeAlert = function(index) {
			  if($scope.alerts.length !== 0){
				  $scope.alerts.splice(index, 1);
			  }
		  };
			
}]);
