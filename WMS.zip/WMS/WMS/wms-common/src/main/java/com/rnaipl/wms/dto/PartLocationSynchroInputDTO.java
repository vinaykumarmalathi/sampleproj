package com.rnaipl.wms.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name="SHOP_DETAIL")
@XmlAccessorType(XmlAccessType.FIELD)
public class PartLocationSynchroInputDTO implements Serializable{ 
	
	@XmlElement(name="PLANT")
	private String plant;
	
	@XmlElement(name="SHOP_NAME")
	private String shop;

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getShop() {
		return shop;
	}

	public void setShop(String shop) {
		this.shop = shop;
	}
	
	
}


