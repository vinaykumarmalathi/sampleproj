package com.rnaipl.wms.dto;

import java.io.Serializable;

/**
 * This class is to contain the details to be presented to user in presentation
 * layer for Shop related Data
 * 
 * @CreatedBy TechM
 * @CreatedOn 20-Apr-2016 
 */
public class ShopDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String shopId;
	private String shopName;
	

	/**
	 * 
	 * @return the shopId
	 */
	public String getShopId() {
		return shopId;
	}


	/**
	 * 
	 * @param shopId
	 * 			shopId to set
	 */
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}


	/**
	 * 
	 * @return the shopName
	 */
	public String getShopName() {
		return shopName;
	}


	/**
	 * 
	 * @param shopName
	 * 			shopName to set
	 */
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		StringBuilder builder = new StringBuilder();
        builder.append("ShopDTO [shopId=").append(shopId).append(", shopName=").append(shopName).append("]");
        return builder.toString();
	}
}
