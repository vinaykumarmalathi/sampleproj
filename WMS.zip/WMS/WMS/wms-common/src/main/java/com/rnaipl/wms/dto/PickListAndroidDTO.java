package com.rnaipl.wms.dto;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="PICKING_LIST")
@XmlAccessorType(XmlAccessType.FIELD)
public class PickListAndroidDTO implements Serializable{
	
	@XmlElementWrapper(name = "PICK_LIST")
    @XmlElement(name = "PICK_LIST")
	private List<PickingListHdrDTO> pickList;
	
	@XmlElementWrapper(name = "PART_LIST")
    @XmlElement(name = "PART_LIST")
	private List<PickingListDetailDTO> partList;
	
	@XmlElementWrapper(name = "RAN_LIST")
    @XmlElement(name = "RAN_LIST")
	private List<PickingListRanDTO> ranList;
	
	@XmlElementWrapper(name = "ERROR_LIST")
    @XmlElement(name = "ERROR_LIST")
	private String error;	

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public List<PickingListHdrDTO> getPickList() {
		return pickList;
	}

	public void setPickList(List<PickingListHdrDTO> pickList) {
		this.pickList = pickList;
	}

	public List<PickingListDetailDTO> getPartList() {
		return partList;
	}

	public void setPartList(List<PickingListDetailDTO> partList) {
		this.partList = partList;
	}

	public List<PickingListRanDTO> getRanList() {
		return ranList;
	}

	public void setRanList(List<PickingListRanDTO> ranList) {
		this.ranList = ranList;
	}	
	
	
}
