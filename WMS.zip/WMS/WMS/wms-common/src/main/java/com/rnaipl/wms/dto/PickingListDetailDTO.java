package com.rnaipl.wms.dto;

public class PickingListDetailDTO {
	
	private String pickListnumber;
	private String partNo;
	private int totalNoOpenBox;
	private int totalNoOpenQty;
	private String status;
	private int snip;
	
	public String getPickListnumber() {
		return pickListnumber;
	}
	public void setPickListnumber(String pickListnumber) {
		this.pickListnumber = pickListnumber;
	}
	public String getPartNo() {
		return partNo;
	}
	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}
	public int getTotalNoOpenBox() {
		return totalNoOpenBox;
	}
	public void setTotalNoOpenBox(int totalNoOpenBox) {
		this.totalNoOpenBox = totalNoOpenBox;
	}
	public int getTotalNoOpenQty() {
		return totalNoOpenQty;
	}
	public void setTotalNoOpenQty(int totalNoOpenQty) {
		this.totalNoOpenQty = totalNoOpenQty;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getSnip() {
		return snip;
	}
	public void setSnip(int snip) {
		this.snip = snip;
	}
	
	

}
