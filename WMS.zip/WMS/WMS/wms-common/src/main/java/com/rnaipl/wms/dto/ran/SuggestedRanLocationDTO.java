package com.rnaipl.wms.dto.ran;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="PART_DETAIL")
@XmlAccessorType(XmlAccessType.FIELD)
public class SuggestedRanLocationDTO implements Serializable {
	
	@XmlElement(name="PLANT", required = false)
	private String plant;

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}
	
	@XmlElement(name="PART_NO")
	private String partNumber;

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	
	@XmlElement(name="SHOP", required = false)
	private String shop;

	public String getShop() {
		return shop;
	}

	public void setShop(String shop) {
		this.shop = shop;
	}
	
	

}
