/**
 * 
 */
package com.rnaipl.wms.util;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.ss.util.RegionUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author TechM
 * @version 1.0
 * 
 */
public class ExcelWorkBookUtil {
	
	/**
	 * Member Variable LOGGER.
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ExcelWorkBookUtil.class);

	// to create a cell in excel workbook
	public static Cell createACell(final Sheet sheet, final Row row,
			final int index, final String data, final CellStyle styleDefault) {
		Cell cell = row.createCell(index);
		cell.setCellValue(data);
		cell.setCellStyle(styleDefault);
		//sheet.autoSizeColumn(index);
		return cell;
	}
	
	// to create a cell in excel workbook
		public static Cell createACell(final Sheet sheet, final Row row,
				final int index, final int data, final CellStyle styleDefault) {
			Cell cell = row.createCell(index);
			cell.setCellValue(data);
			cell.setCellStyle(styleDefault);
			//sheet.autoSizeColumn(index);
			return cell;
		}
		
		// To create a cell to display values in currency format
		public static HSSFCellStyle createCurrencyStyle(final Workbook workbook){
			String formatStr = "#,###";
	        HSSFCellStyle currencyStyle = (HSSFCellStyle) workbook.createCellStyle();
	        HSSFDataFormat format = (HSSFDataFormat) workbook.createDataFormat();
	        currencyStyle.setDataFormat(format.getFormat(formatStr));
	        return currencyStyle;
		}

	// To create a customised style for a cell
	public static CellStyle getCustomizedStyle(final Workbook workbook, final String color,
			final Boolean rightalign, final Boolean leftalign, final Boolean centeralign) {

		CellStyle style = workbook.createCellStyle();
		if (rightalign) {
			style.setAlignment(CellStyle.ALIGN_RIGHT);
		} else if (centeralign) {
			style.setAlignment(CellStyle.ALIGN_CENTER);
		} else if (leftalign) {
			style.setAlignment(CellStyle.ALIGN_LEFT);
		}
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setBorderTop(CellStyle.BORDER_THIN);
		style.setBorderBottom(CellStyle.BORDER_THIN);
		
		if("HEADER".equals(color)){
			Font headerFont = workbook.createFont();
			headerFont.setColor(IndexedColors.WHITE.getIndex());
			style.setFont(headerFont);
			style.setFillForegroundColor(IndexedColors.GREY_80_PERCENT.getIndex());
			style.setFillPattern(CellStyle.SOLID_FOREGROUND);
			style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
		}if ("GREEN".equalsIgnoreCase(color)) {

			style.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
			style.setFillPattern(CellStyle.SOLID_FOREGROUND);

		} else if ("RED".equalsIgnoreCase(color)) {

			style.setFillForegroundColor(IndexedColors.RED.getIndex());
			style.setFillPattern(CellStyle.SOLID_FOREGROUND);

		} else if ("CORAL".equalsIgnoreCase(color)) {

			style.setFillForegroundColor(IndexedColors.CORAL.getIndex());
			style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		} else if ("BLUE".equalsIgnoreCase(color)) {

			style.setFillForegroundColor(IndexedColors.SKY_BLUE.getIndex());
			style.setFillPattern(CellStyle.SOLID_FOREGROUND);

		} else if ("YELLOW".equalsIgnoreCase(color)) {

			style.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
			style.setFillPattern(CellStyle.SOLID_FOREGROUND);

		} else if ("LEMON_CHIFFON".equalsIgnoreCase(color)) {

			style.setFillForegroundColor(IndexedColors.LEMON_CHIFFON.getIndex()); 
			style.setFillPattern(CellStyle.SOLID_FOREGROUND);

		} else if ("GRAY".equalsIgnoreCase(color)) {

			style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT
					.getIndex());
			style.setAlignment(CellStyle.ALIGN_CENTER);
			style.setFillPattern(CellStyle.SOLID_FOREGROUND);
			style.setBorderLeft(CellStyle.BORDER_THICK);
			style.setBorderRight(CellStyle.BORDER_THICK);
			style.setBorderTop(CellStyle.BORDER_THICK);
			style.setBorderBottom(CellStyle.BORDER_THICK);
		} else if ("GRAYWITHNORMALBOARDER".equalsIgnoreCase(color)) {

			style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT
					.getIndex());
			style.setAlignment(CellStyle.ALIGN_CENTER);
			style.setFillPattern(CellStyle.SOLID_FOREGROUND);

		} else if ("TAN".equalsIgnoreCase(color)) {

			style.setFillForegroundColor(IndexedColors.TAN.getIndex());
			style.setAlignment(CellStyle.ALIGN_CENTER);
			style.setFillPattern(CellStyle.SOLID_FOREGROUND);

		} else if("GREY_50".equalsIgnoreCase(color)){
			style.setFillForegroundColor(IndexedColors.GREY_50_PERCENT
					.getIndex());
			style.setAlignment(CellStyle.ALIGN_CENTER);
			style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		}else if("FONT_YELLOW".equalsIgnoreCase(color)){
			HSSFFont font = (HSSFFont) workbook.createFont();
			font.setColor(HSSFColor.YELLOW.index);
			style.setFont(font);
		}else if("FONT_RED".equalsIgnoreCase(color)){
			HSSFFont font = (HSSFFont) workbook.createFont();
			font.setColor(HSSFColor.RED.index);
			style.setFont(font);
		}else if("FONT_BLUE".equalsIgnoreCase(color)){
			HSSFFont font = (HSSFFont) workbook.createFont();
			font.setColor(HSSFColor.BLUE.index);
			style.setFont(font);
		}else if("FONT_GREEN".equalsIgnoreCase(color)){
			HSSFFont font = (HSSFFont) workbook.createFont();
			font.setColor(HSSFColor.GREEN.index);
			style.setFont(font);
		}
		return style;
	}
	
	public static CellStyle getCustomizedStyle(final Workbook workbook, final String color,final Boolean reqFont, final Boolean headerName) {
		CellStyle style = workbook.createCellStyle();
		style.setAlignment(CellStyle.ALIGN_LEFT);
		if(reqFont){
			HSSFFont font = (HSSFFont) workbook.createFont();
			font.setFontName(HSSFFont.FONT_ARIAL);
			font.setFontHeightInPoints((short)10);
			font.setBoldweight(Font.BOLDWEIGHT_BOLD);
			style.setFont(font);
		}else if(headerName){
			style.setAlignment(CellStyle.ALIGN_CENTER);
			HSSFFont font = (HSSFFont) workbook.createFont();
			font.setFontName(HSSFFont.FONT_ARIAL);
			font.setFontHeightInPoints((short)16);
			font.setBoldweight(Font.BOLDWEIGHT_BOLD);
			style.setFont(font);
		}
		return style;
	}
	
	
	public static CellStyle getFontColor(final Workbook workbook, final String color) {
		CellStyle style = workbook.createCellStyle();
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setBorderTop(CellStyle.BORDER_THIN);
		style.setBorderBottom(CellStyle.BORDER_THIN);
		style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT
				.getIndex());
		if("FONT_YELLOW".equalsIgnoreCase(color)){
			HSSFFont font = (HSSFFont) workbook.createFont();
			style.setAlignment(CellStyle.ALIGN_CENTER);
			style.setFillPattern(CellStyle.SOLID_FOREGROUND);
			font.setColor(HSSFColor.YELLOW.index);
			style.setFont(font);
		}else if("FONT_RED".equalsIgnoreCase(color)){
			style.setAlignment(CellStyle.ALIGN_CENTER);
			style.setFillPattern(CellStyle.SOLID_FOREGROUND);
			HSSFFont font = (HSSFFont) workbook.createFont();
			font.setColor(HSSFColor.RED.index);
			style.setFont(font);
		}else if("FONT_BLUE".equalsIgnoreCase(color)){
			style.setAlignment(CellStyle.ALIGN_CENTER);
			style.setFillPattern(CellStyle.SOLID_FOREGROUND);
			HSSFFont font = (HSSFFont) workbook.createFont();
			font.setColor(HSSFColor.BLUE.index);
			style.setFont(font);
		}else if("FONT_GREEN".equalsIgnoreCase(color)){
			style.setAlignment(CellStyle.ALIGN_CENTER);
			style.setFillPattern(CellStyle.SOLID_FOREGROUND);
			HSSFFont font = (HSSFFont) workbook.createFont();
			font.setColor(HSSFColor.GREEN.index);
			style.setFont(font);
		}
		return style;
	}
	
	//To Apply border for the merged cells
	  public static void mergeCellRegion(Cell cell, CellRangeAddress region, Sheet sheet,Workbook workbook) {
		    RegionUtil.setBorderBottom(cell.getCellStyle().getBorderBottom(), region, sheet, workbook);
		    RegionUtil.setBorderTop(cell.getCellStyle().getBorderTop(), region, sheet, workbook);
		    RegionUtil.setBorderLeft(cell.getCellStyle().getBorderLeft(), region, sheet, workbook);
		    RegionUtil.setBorderRight(cell.getCellStyle().getBorderRight(), region, sheet, workbook);
		    
	    }
	  
	  public static String getCellName(Cell cell)
	  {
	      return CellReference.convertNumToColString(cell.getColumnIndex()) + (cell.getRowIndex() + 1);
	  }
}
