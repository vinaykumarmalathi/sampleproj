package com.rnaipl.wms.dto;

import java.io.Serializable;

public class LocationCountDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1364289984895495694L;
	
	private String location;	
	private String quantity;
	
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	
}
