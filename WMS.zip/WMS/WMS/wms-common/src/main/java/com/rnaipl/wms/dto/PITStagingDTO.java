package com.rnaipl.wms.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/*AJ00482484 -- PIT Automation -- START */

@XmlRootElement(name="PitScannedDetails")
@XmlAccessorType(XmlAccessType.FIELD)
public class PITStagingDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@XmlElement(name="TRANSACTION_ID")
	private String transactionId;
	
	@XmlElement(name="PART_NO")
	private String partNumber;
	
	@XmlElement(name="LOCATION")
	private String location;
	
	@XmlElement(name="RAN")
	private String ran;
	
	@XmlElement(name="SNP")
	private int snp;
	
	@XmlElement(name="NO_OF_BOXES")
	private int numberOfBoxes;
	
	@XmlElement(name="OPEN_QUANTITY")
	private int openQuantity;
	
	@XmlElement(name="TOTAL_QUANTITY")
	private int totalQuantity;
	
	@XmlElement(name="DATE_TIME")
	private String dateTime;
	
	@XmlElement(name="DEVICE_ID")
	private String deviceId;
	
	@XmlElement(name="TRANSACTION_TYPE")
	private String transactionType;
	
	@XmlElement(name="ISUPDATED")
	private String isUpdated;
	
	@XmlElement(name="COMMENTS_FLAG")
	private int commentsFlag;
	
	@XmlElement(name="COMMENTS")
	private String comments;

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getRan() {
		return ran;
	}

	public void setRan(String ran) {
		this.ran = ran;
	}

	public int getSnp() {
		return snp;
	}

	public void setSnp(int snp) {
		this.snp = snp;
	}

	public int getNumberOfBoxes() {
		return numberOfBoxes;
	}

	public void setNumberOfBoxes(int numberOfBoxes) {
		this.numberOfBoxes = numberOfBoxes;
	}

	public int getOpenQuantity() {
		return openQuantity;
	}

	public void setOpenQuantity(int openQuantity) {
		this.openQuantity = openQuantity;
	}

	public int getTotalQuantity() {
		return totalQuantity;
	}

	public void setTotalQuantity(int totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getIsUpdated() {
		return isUpdated;
	}

	public void setIsUpdated(String isUpdated) {
		this.isUpdated = isUpdated;
	}

	public int getCommentsFlag() {
		return commentsFlag;
	}

	public void setCommentsFlag(int commentsFlag) {
		this.commentsFlag = commentsFlag;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

}

/*AJ00482484 -- PIT Automation -- END */
