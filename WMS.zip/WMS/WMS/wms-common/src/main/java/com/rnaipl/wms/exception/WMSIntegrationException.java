package com.rnaipl.wms.exception;

/**
 * This is the exception class to be used in case of any errors caused during
 * the integration of third party API presentation or business whale integration
 * layer
 * 
 * <p>
 * It extends {@link WhaleRuntimeException} the base Exception class for Whale
 * application.
 * 
 * @CreatedBy TechM
 * @CreatedOn 07-Oct-2015 10:43:01 am
 */
@SuppressWarnings("serial")
public class WMSIntegrationException extends WMSRuntimeException {

    /**
     * Instantiates a new Whale Integration exception.
     * 
     * @param message
     *            the message
     * @param exception
     *            {@link Throwable} cause
     * @see RuntimeException#RuntimeException(String, Throwable)
     */
    public WMSIntegrationException(final String message, final Throwable exception) {
        super(message, exception);
    }

    /**
     * Instantiates a new Whale Integration exception.
     * 
     * @param message
     *            the message
     * @see RuntimeException#RuntimeException(String)
     */
    public WMSIntegrationException(final String message) {
        super(message);
    }

    /**
     * Instantiates a new Whale Integration exception.
     * 
     * @param exception
     *            {@link Throwable} cause
     * @see RuntimeException#RuntimeException(Throwable)
     */
    public WMSIntegrationException(final Throwable exception) {
        super(exception);
    }

}
