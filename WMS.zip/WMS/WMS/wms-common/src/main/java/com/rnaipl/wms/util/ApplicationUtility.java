package com.rnaipl.wms.util;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;


public final class ApplicationUtility {
	
	private static final Logger LOGGER = Logger.getLogger(ApplicationUtility.class);
	private static final Logger LOGGER_PART_INOUT = Logger.getLogger(WMSConstants.INOUT_LOGFILE);
	
	//Converting date string to sql time stamp
	public static Timestamp convertStringToSqlTimeStamp(final String scanTime, final String format) {
			java.sql.Timestamp scan = null;
			try {
				DateFormat formatter = new SimpleDateFormat(format);
				Date date = (Date) formatter.parse(scanTime);
				LOGGER_PART_INOUT.debug("* Formatted Date :" + date);
				scan = new Timestamp(date.getTime());
			} catch (Exception ex) {
				LOGGER.error("** Error in convertStringToSqlTimeStamp");
			}
			return scan;
		}
	
	/**
	 * @param dateString
	 *            input value
	 * @param format
	 *            input value
	 * @param returnFromat
	 *            input value
	 * @return String
	 */
	public static String displayDateStringToFromattedDateString(
			String dateString, String format, String returnFromat) {
		Date dateFormat = null;
		String date = "";

		if (null != dateString) {
			SimpleDateFormat formatter = new SimpleDateFormat(format);
			SimpleDateFormat returnFormatter = new SimpleDateFormat(
					returnFromat);
			try {
				dateFormat = formatter.parse(dateString);

			} catch (ParseException e) {
				/*
				 * LOGGER
				 * .debug("Error in displayDateStringToFromattedDateString---->"
				 * + e);
				 */
			}

			date = returnFormatter.format(dateFormat);

		}
		return date;
	}

}
