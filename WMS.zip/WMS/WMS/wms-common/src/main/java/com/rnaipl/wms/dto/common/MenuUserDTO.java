package com.rnaipl.wms.dto.common;

import java.util.List;

public class MenuUserDTO {
	private String userId;
	private String userMenu;
	private List<String> menuList;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserMenu() {
		return userMenu;
	}
	public void setUserMenu(String string) {
		this.userMenu = string;
	}
	public List<String> getMenuList() {
		return menuList;
	}
	public void setMenuList(List<String> menuList) {
		this.menuList = menuList;
	}
}
