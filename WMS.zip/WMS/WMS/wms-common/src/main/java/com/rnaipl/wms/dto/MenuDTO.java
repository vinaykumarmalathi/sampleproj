package com.rnaipl.wms.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;

public class MenuDTO implements Serializable{
	private String menuId;
	private String menuName;
	private int parentId;
	private int menuLevel;
	private int orderNumber;
	private LinkedList<MenuDTO> childMenu = new LinkedList();
	private List<UserDTO> users = new ArrayList<UserDTO>();

	public List<UserDTO> getUsers() {
		return users;
	}
	public void setUsers(List<UserDTO> users) {
		this.users = users;
	}
	public String getMenuId() {
		return menuId;
	}
	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public int getParentId() {
		return parentId;
	}
	public void setParentId(int parentId) {
		this.parentId = parentId;
	}
	public int getMenuLevel() {
		return menuLevel;
	}
	public void setMenuLevel(int menuLevel) {
		this.menuLevel = menuLevel;
	}
	public int getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	private String path;

	public LinkedList<MenuDTO> getChildMenu() {
		return childMenu;
	}
	public void setChildMenu(LinkedList<MenuDTO> childMenu) {
		this.childMenu = childMenu;
	}
	public void addChild(MenuDTO child) {
        childMenu.add(child);
    }
	private boolean checked;

	public boolean isChecked() {
		return checked;
	}
	public void setChecked(boolean checked) {
		this.checked = checked;
	}
	

}
