package com.rnaipl.wms.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;


@XmlAccessorType(XmlAccessType.FIELD)
public class PickingLineDetailsDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2491300071112893373L;

	@XmlElement(name="Pick_List_ID")
	private String pickListId;
	
	@XmlElement(name="Tot_No_of_Boxes")
	private int totalNumberOfBoxes;
	
	@XmlElement(name="Tot_No_of_Quantity")
	private int totalNumberOfQuantity;
	
	@XmlElement(name="ShopName")
	private String shopName;
	
	@XmlElement(name="Zone")
	private String zone;
	
	@XmlElement(name="DeviceID")
	private String deviceID;
	
	@XmlElement(name="PartNumber")
	private String partNumber;
	
	@XmlElement(name="No_of_Boxes")
	private int numberOfBoxes;
	
	@XmlElement(name="SNP")
	private int snp;
	
	
	@XmlElement(name="Total_Quantity")
	private int totalQuantity;
	
	@XmlElement(name="Scan_Time")
	private String scanTime;
	
	@XmlElement(name="Detail_Device_TranID")
	private String detailDeviceTranId;

	public String getPickListId() {
		return pickListId;
	}

	public void setPickListId(String pickListId) {
		this.pickListId = pickListId;
	}

	public int getTotalNumberOfBoxes() {
		return totalNumberOfBoxes;
	}

	public void setTotalNumberOfBoxes(int totalNumberOfBoxes) {
		this.totalNumberOfBoxes = totalNumberOfBoxes;
	}

	public int getTotalNumberOfQuantity() {
		return totalNumberOfQuantity;
	}

	public void setTotalNumberOfQuantity(int totalNumberOfQuantity) {
		this.totalNumberOfQuantity = totalNumberOfQuantity;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public String getDeviceID() {
		return deviceID;
	}

	public void setDeviceID(String deviceID) {
		this.deviceID = deviceID;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public int getNumberOfBoxes() {
		return numberOfBoxes;
	}

	public void setNumberOfBoxes(int numberOfBoxes) {
		this.numberOfBoxes = numberOfBoxes;
	}

	public int getSnp() {
		return snp;
	}

	public void setSnp(int snp) {
		this.snp = snp;
	}

	public int getTotalQuantity() {
		return totalQuantity;
	}

	public void setTotalQuantity(int totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	public String getScanTime() {
		return scanTime;
	}

	public void setScanTime(String scanTime) {
		this.scanTime = scanTime;
	}

	public String getDetailDeviceTranId() {
		return detailDeviceTranId;
	}

	public void setDetailDeviceTranId(String detailDeviceTranId) {
		this.detailDeviceTranId = detailDeviceTranId;
	}

	
	
}
