package com.rnaipl.wms.bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;





import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.RANDataDTO;
import com.rnaipl.wms.util.WMSBeanConstants;

@Stateless
@LocalBean

public class RANDataBean implements RANData {
	
	private static final Logger LOGGER = Logger.getLogger(RANDataBean.class);
	
	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;
	
	public List<RANDataDTO> getAllRan(RANDataDTO ranDTO){
		
		LOGGER.debug("RANBean -- > getAllRan() starts");
		
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
		//LOGGER.debug("** From Date -> "+ dateFormatter.format(ranDTO.getLppd()));
		
		StringBuffer queryStringBuf = new StringBuffer();
		List<RANDataDTO> ranDTOs = new ArrayList<RANDataDTO>();
		
		queryStringBuf.append("Select r.id.ran,r.id.partNo,r.lppd from Ran r where 1=1");
		LOGGER.debug(queryStringBuf.toString());
			if(null != ranDTO.getRan() && !ranDTO.getRan().equals("")){
				queryStringBuf.append(" and r.id.ran in (:ranIds)");
			}
			if(null != ranDTO.getPartNos() && !ranDTO.getPartNos().equals("")){
				queryStringBuf.append(" and r.id.partNo in (:partNos)");
			}
			if(null != ranDTO.getLppd() && !ranDTO.getLppd().equals("")){
				queryStringBuf.append(" and r.lppd = '" + dateFormatter.format(ranDTO.getLppd()) + "'");
			}
			
			Query query = entityManager.createQuery(queryStringBuf.toString());
			LOGGER.debug(queryStringBuf.toString());
			
			if(null != ranDTO.getRan() && !ranDTO.getRan().equalsIgnoreCase("")){
				query.setParameter("ranIds", ranDTO.getRanList());
			}
			if(null != ranDTO.getPartNos() && !ranDTO.getPartNos().equalsIgnoreCase("")){
				query.setParameter("partNos", ranDTO.getPartNoList());
			}
			
			query.setFirstResult(ranDTO.getStartIndex());
			query.setMaxResults(ranDTO.getEndIndex());
			
			List<Object[]> ranList = query.getResultList();
			for(Object[] values : ranList){
					int indexCount = 0;
					//Object[] values = (Object[]) i.next();
					RANDataDTO ranListDTO = new RANDataDTO();
					ranListDTO.setRan( values[indexCount].toString());
					indexCount++;
					ranListDTO.setPartNos(values[indexCount].toString());
					indexCount++;
					Date createdDate = (Date) values[indexCount];
					ranListDTO.setLppd(createdDate);
					ranDTOs.add(ranListDTO);
			}
			LOGGER.debug("RANBean -- > getAllRan() ends");
			
		return ranDTOs;
		
	}
	
public int getRanCount(RANDataDTO ranDTO){
		
		LOGGER.debug("RANBean -- > getRanCount() starts");
		
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
		
		StringBuffer queryStringBuf = new StringBuffer();
		queryStringBuf.append("Select count(*) from Ran r where 1=1");
		
			if(null != ranDTO.getRan() && !ranDTO.getRan().equals("")){
				queryStringBuf.append(" and r.ran in (:ranIds)");
			}
			if(null != ranDTO.getPartNos() && !ranDTO.getPartNos().equals("")){
				queryStringBuf.append(" and r.part.partNo in (:partNos)");
			}
			if(null != ranDTO.getLppd() && !ranDTO.getLppd().equals("")){
				queryStringBuf.append(" and r.lppd = '" + dateFormatter.format(ranDTO.getLppd()) + "'");
			}
			
			Query query1 = entityManager.createQuery(queryStringBuf.toString());
			LOGGER.debug(queryStringBuf.toString());
			
			if(null != ranDTO.getRan() && !ranDTO.getRan().equalsIgnoreCase("")){
				query1.setParameter("ranIds", ranDTO.getRanList());
			}
			if(null != ranDTO.getPartNos() && !ranDTO.getPartNos().equalsIgnoreCase("")){
				query1.setParameter("partNos", ranDTO.getPartNoList());
			}
			
			 Long noOfRecords = (Long) query1.getSingleResult();
			 LOGGER.debug("RANBean -- > getRanCount() ends" + noOfRecords);
			 return noOfRecords.intValue();
		
			 
	}

}
