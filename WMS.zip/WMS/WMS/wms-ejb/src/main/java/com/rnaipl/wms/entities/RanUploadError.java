package com.rnaipl.wms.entities;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="RAN_UPLOAD_ERROR")
@NamedQuery(name="RanUploadError.findAll", query="SELECT re FROM RanUploadError re")
public class RanUploadError {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="RUN_ID")
	private int runId;
	
	@Column(name="RAN")
	private String ran;
	
	@Column(name="PART_NO")
	private String partNo;

	@Column(name="MFG_DATE")
	private Timestamp mfgDate;

	public int getRunId() {
		return runId;
	}

	public void setRunId(int runId) {
		this.runId = runId;
	}

	public String getRan() {
		return ran;
	}

	public void setRan(String ran) {
		this.ran = ran;
	}

	public String getPartNo() {
		return partNo;
	}

	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}

	public Timestamp getMfgDate() {
		return mfgDate;
	}

	public void setMfgDate(Timestamp mfgDate) {
		this.mfgDate = mfgDate;
	}
	
	


}
