package com.rnaipl.wms.bean;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.ShopDTO;
import com.rnaipl.wms.entities.Shop;
import com.rnaipl.wms.util.WMSBeanConstants;

/**
 * 
 * @author TechM
 * 
 */
@Stateless
@LocalBean
public class ShopBean implements com.rnaipl.wms.bean.Shop {

    private static final Logger LOGGER = Logger.getLogger(ShopBean.class);

    @PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
    private EntityManager entityManager;

    /**
     * This method fetch the value from the database
     * 
     * @return - list of ShopDTO
     */
    public List<ShopDTO> getTempShopsList() {
        // TODO Auto-generated method stub
        List<ShopDTO> shops = new ArrayList<ShopDTO>();

        ShopDTO shop = new ShopDTO();
        shop.setShopId("shop001");
        shop.setShopName("Body Shop");
        shops.add(shop);

        shop = new ShopDTO();
        shop.setShopId("shop002");
        shop.setShopName("T&D Shop");
        shops.add(shop);

        shop = new ShopDTO();
        shop.setShopId("shop003");
        shop.setShopName("Metal Shop");
        shops.add(shop);

        shop = new ShopDTO();
        shop.setShopId("shop004");
        shop.setShopName("Container Shop");
        shops.add(shop);

        return shops;
    }

    /**
     * This method call getTempShopsList() to get the all the shops list
     * 
     * @return - list of ShopDTO
     */
    public List<ShopDTO> getAllShops() {
        // TODO Auto-generated method stub
        LOGGER.debug("getAllShops() method starts ");
        List<ShopDTO> shopDTOs = new ArrayList<ShopDTO>();

        Query query = entityManager.createQuery("select p from Shop p ORDER BY p.shopName");
        List<Shop> shops = query.getResultList();
        for (Shop shop : shops) {
            ShopDTO shopDTO = new ShopDTO();
            shopDTO.setShopId(shop.getShopId());
            shopDTO.setShopName(shop.getShopName());
            shopDTOs.add(shopDTO);
        }

        LOGGER.debug("getAllShops() method Ends ");
        return shopDTOs;
    }
    
    public List<ShopDTO> getShopByPlantId(String plantId) {
        // TODO Auto-generated method stub
        LOGGER.debug("getShopByPlantId() method starts ");
        List<ShopDTO> shopDTOs = new ArrayList<ShopDTO>();
        com.rnaipl.wms.entities.Plant plants = entityManager.find(com.rnaipl.wms.entities.Plant.class,plantId);
        if(plants!=null){
        List<Shop> shops = plants.getShops();
        for (Shop shop : shops) {
            ShopDTO shopDTO = new ShopDTO();
            shopDTO.setShopId(shop.getShopId());
            shopDTO.setShopName(shop.getShopName());
            shopDTOs.add(shopDTO);
        }
       }
        else{
        	return null;
        }
        LOGGER.debug("getShopByPlantId() method Ends ");
        return shopDTOs;
    }

}
