package com.rnaipl.wms.bean;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.LocationDTO;
import com.rnaipl.wms.dto.LocationHistoryDTO;
import com.rnaipl.wms.dto.PartLocationDTO;
import com.rnaipl.wms.dto.PartNumberDTO;
import com.rnaipl.wms.entities.LocationHistory;
import com.rnaipl.wms.entities.Part;
import com.rnaipl.wms.util.WMSBeanConstants;

@Stateless
@LocalBean
public class LocationBean implements com.rnaipl.wms.bean.Location {

	private static final Logger LOGGER = Logger.getLogger(LocationBean.class);

	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;

	public Set<PartNumberDTO> getLocation(String locationID) {

		LOGGER.debug("*****IN Get All Location Bean ");
		Set<PartNumberDTO> locations = new HashSet<PartNumberDTO>();
		Query query = entityManager
				.createQuery("select DISTINCT(l.locationId) from Location l where l.locationId LIKE :val");
		query.setParameter("val", locationID + "%");
		query.setMaxResults(10);
		List<String> locationList = query.getResultList();
		LOGGER.debug("*****Part List Size" + locationList.size());
		for (String location : locationList) {
			PartNumberDTO partNumberDTO = new PartNumberDTO();
			partNumberDTO.setText(location);
			locations.add(partNumberDTO);
		}
		return locations;

	}

	public List<PartNumberDTO> getLocationSearchData(PartLocationDTO location) {

		LOGGER.debug("*****IN Get All Location Bean ");

		List<PartNumberDTO> locations = new ArrayList<PartNumberDTO>();

		List<String> searchResults = new ArrayList<String>();

		if (location.getIsFullDownload() == 1) {
			searchResults = locationSearchData(location, false);
		} else {
			searchResults = locationSearchData(location, true);
		}

		if (null != searchResults && searchResults.size() > 0) {
			for (String locationId : searchResults) {
				PartNumberDTO locationDto = new PartNumberDTO();
				locationDto.setText((null == locationId ? "" : locationId.toString()));
				locations.add(locationDto);
			}
		}

		return locations;
	}

	public String insertLocation(LocationDTO locationDto) {

		LOGGER.debug("In Insert Location" + locationDto);
		com.rnaipl.wms.entities.Location existLocation = entityManager.find(com.rnaipl.wms.entities.Location.class,
				locationDto.getLocationId());
		LOGGER.debug("EXIST LOCATION-ID " + existLocation);
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		if (existLocation != null) {
			return "data found";
		}
		com.rnaipl.wms.entities.Location location = new com.rnaipl.wms.entities.Location();
		insertOrUpdateLocation(location, locationDto);

		String remarks = null == locationDto.getComments() ? "" : locationDto.getComments();
		String changeLog = locationDto.getUserId() + "##" + dateFormat.format(date) + "##" + remarks;

		location.setChangeLog(changeLog);

		LOGGER.debug(
				"Value Set into the Location Object" + location.getLocationId() + " --" + location.getLocationType());
		entityManager.persist(location);
		LOGGER.debug("IN insertLocation -- DATA inserted Successfully !!");
		return "success";
	}

	public String updateLocation(LocationDTO locationDto) {
		com.rnaipl.wms.entities.Location location = entityManager.find(com.rnaipl.wms.entities.Location.class,
				locationDto.getLocationId());
		if (location != null) {
			insertOrUpdateLocation(location, locationDto);

			entityManager.merge(location);
			return "success";
		} else {
			return "No Data Found";
		}
	}

	private void insertOrUpdateLocation(com.rnaipl.wms.entities.Location location, LocationDTO locationDto) {
		// TODO Auto-generated method stub
		List<Part> parts = new ArrayList<Part>();
		com.rnaipl.wms.entities.Plant plant = new com.rnaipl.wms.entities.Plant();
		com.rnaipl.wms.entities.Shop shop = new com.rnaipl.wms.entities.Shop();
		com.rnaipl.wms.entities.Section section = new com.rnaipl.wms.entities.Section();
		com.rnaipl.wms.entities.Line line = new com.rnaipl.wms.entities.Line();
		com.rnaipl.wms.entities.LocationType locationType = new com.rnaipl.wms.entities.LocationType();
		location.setLocationId(locationDto.getLocationId());

		if (null != locationDto.getPlant() && !"".equals(locationDto.getPlant())) {
			plant.setPlantId(locationDto.getPlant());
			location.setPlant(plant);
		}
		if (null != locationDto.getShop() && !"".equals(locationDto.getShop())) {
			shop.setShopId(locationDto.getShop());
			location.setShop(shop);
		}
		if (null != locationDto.getLine() && !"".equals(locationDto.getLine())) {
			line.setLineId(locationDto.getLine());
			location.setLine(line);
		}
		if (null != locationDto.getSection() && !"".equals(locationDto.getSection())) {
			section.setSectionId(locationDto.getSection());
			location.setSection(section);
		}
		if (null != locationDto.getLocationType() && !"".equals(locationDto.getLocationType())) {
			locationType.setLocationtypeId(locationDto.getLocationType());
			location.setLocationType(locationType);
		}

		location.setCellId(locationDto.getCellId());
		location.setLocationSeries1(locationDto.getLocationSeries1());
		location.setLocationSeries2(locationDto.getLocationSeries2());
		/*
		 * if(locationDto.getParts() != null) { for(String dtoPart :
		 * locationDto.getParts()) { Part part = new Part(); part.setPartNo(dtoPart);
		 * parts.add(part); } } location.setParts(parts);
		 */
		// location.setShop(shop);
		// location.setLine(line);
		// location.setPlant(plant);
		// location.setSection(section);
		// location.setLocationType(locationType);
		location.setSeries(locationDto.getSeries());
		location.setZone(locationDto.getZone());
		location.setLocationLevel(locationDto.getLocationLevel());
		location.setCellId(locationDto.getCellId());

	}

	public LocationDTO getLocationByLocationId(String locationId) {
		// TODO Auto-generated method stub
		LOGGER.debug("*****IN Get All Location Bean - getLocationByLocationId ");
		LocationDTO locationDTO = null;
		com.rnaipl.wms.entities.Location location = entityManager.find(com.rnaipl.wms.entities.Location.class,
				locationId);
		LOGGER.debug("***** lOCATION dETAILS" + location.getLocationId());

		if (location != null) {
			LOGGER.debug("Part exist in the database -- " + location.getLocationId());
			locationDTO = setLocationData(location);
		}
		return locationDTO;
	}

	private LocationDTO setLocationData(com.rnaipl.wms.entities.Location location) {
		LOGGER.debug("Entering - setLocationData method");
		LocationDTO locationDTO = new LocationDTO();
		Map<String, Integer> partCount = new HashMap<String, Integer>();
		List<String> parts = new ArrayList<String>();
		List<String> changeLogs = new ArrayList<String>();
		locationDTO.setCellId(location.getCellId());
		locationDTO.setLine(location.getLine() == null ? "" : location.getLine().getLineName());
		locationDTO.setLocationId(location.getLocationId());
		locationDTO.setLocationSeries1(location.getLocationSeries1());
		locationDTO.setLocationSeries2(location.getLocationSeries2());
		locationDTO.setLocationType(
				location.getLocationType() == null ? "" : location.getLocationType().getLocationType());
		/*
		 * for(com.rnaipl.wms.entities.Part part : location.getParts()) {
		 * parts.add(part.getPartNo()); }
		 */
		// locationDTO.setParts(parts);
		Query query = null;
		if (!location.getParts().isEmpty() && location.getParts().size() > 0) {
			// Added by Meena - Part number quantity non zero amount should be displayed for
			// overflow location : section as "F - Overflow" - Start
			/*if (location.getSection().getSectionName().trim().equalsIgnoreCase("OverFlow")) {*/
			if (location.getSection().getSectionName().trim().equalsIgnoreCase("OverFlow") || location.getSection().getSectionName().trim().equalsIgnoreCase("Trial Area")) {
				query = entityManager.createNativeQuery(
						"SELECT PART_NO,CURRENT_QTY FROM dbo.PART_LOCATION WHERE LOCATION_ID = :locationId and CURRENT_QTY <> 0 ");
			} else {
				query = entityManager.createNativeQuery(
						"SELECT PART_NO,CURRENT_QTY FROM dbo.PART_LOCATION WHERE LOCATION_ID = :locationId");
			}
			// Added by Meena - Part number quantity non zero amount should be displayed for
			// overflow location : section as "F - Overflow" - End
			LOGGER.debug("Location quantity query : " + query.toString());
			query.setParameter("locationId", location.getLocationId());
			List<Object[]> result = query.getResultList();
			if (!result.isEmpty() && result.size() > 0) {
				for (Iterator<Object[]> i = result.iterator(); i.hasNext();) {
					Object[] values = (Object[]) i.next();
					String part = (null == values[0] ? "" : values[0].toString());
					Integer currentQty = (null == values[1] ? new Integer(0) : (Integer) values[1]);
					partCount.put(part, currentQty);
				}
			}
		}

		locationDTO.setPartCount(partCount);
		locationDTO.setPlant(location.getPlant() == null ? "" : location.getPlant().getPlantName());
		locationDTO.setShop(location.getShop() == null ? "" : location.getShop().getShopName());
		locationDTO.setSection(location.getSection() == null ? "" : location.getSection().getSectionName());
		locationDTO.setSeries(location.getSeries());
		locationDTO.setZone(location.getZone());
		locationDTO.setComments(location.getChangeLog());
		return locationDTO;
	}

	/*
	 * public String deleteLocation(LocationDTO locationDto) { LocationHistoryDTO
	 * historyDto = new LocationHistoryDTO();
	 * 
	 * com.rnaipl.wms.entities.Location location = entityManager.find(
	 * com.rnaipl.wms.entities.Location.class, locationDto.getLocationId());
	 * 
	 * com.rnaipl.wms.entities.History history = new
	 * com.rnaipl.wms.entities.History(); insertDeletedLocation(history,
	 * historyDto);
	 * 
	 * //com.rnaipl.wms.entities.History history =
	 * entityManager.find(com.rnaipl.wms.entities.History.class, historyDto);
	 * 
	 * LOGGER.debug("PArts details : " +location.getParts());
	 * LOGGER.debug("PArts details size : " +location.getParts().size());
	 * 
	 * if (location != null) { if(!location.getParts().isEmpty() &&
	 * location.getParts().size() > 0 ) { // returns "1" if - location mapped with
	 * any other part return "2"; } else {
	 * 
	 * entityManager.persist(history);
	 * 
	 * //return "0" - delete the part if part is not mapped with any other location
	 * entityManager.remove(location); return "0"; } } else { //return "1" - if the
	 * part is not found in the database. return "1"; } }
	 */

	// Added by Meena - Part number quantity non zero amount should be displayed for
	// overflow location : section as "F - Overflow" - Start
	public String deleteLocation(LocationDTO locationDto) {
		LOGGER.debug("Entering delete location bean method");
		LocationHistoryDTO historyDto = new LocationHistoryDTO();
		com.rnaipl.wms.entities.Location location = entityManager.find(com.rnaipl.wms.entities.Location.class,
				locationDto.getLocationId());

		LOGGER.debug("location ID value in LocationDTO : " + locationDto.getLocationId());
		LOGGER.debug("Remarks in LocationDTO : " + locationDto.getRemarks());
		LOGGER.debug("User ID in LocationDTO : " + locationDto.getUserId());
		LOGGER.debug("Section value in Location :  " + location.getSection().getSectionId());

		LocationHistory history = new LocationHistory();
		historyDto.setLocationId(locationDto.getLocationId());
		historyDto.setLocationType(location.getSection().getSectionId());
		historyDto.setRemarks(locationDto.getRemarks());
		historyDto.setDeletedBy(locationDto.getUserId());
		// To set and insert the values to location_history table
		insertDeletedLocation(history, historyDto);
		if (location != null) {
			if (location.getSection().getSectionName().trim().equalsIgnoreCase("OverFlow") || location.getSection().getSectionName().trim().equalsIgnoreCase("Trial Area")) {
				Query query1 = null;
				query1 = entityManager.createNativeQuery(
						"SELECT count(CURRENT_QTY) FROM dbo.PART_LOCATION WHERE LOCATION_ID = :locationId and CURRENT_QTY <> 0");
				LOGGER.debug("Location quantity query : " + query1.toString());
				query1.setParameter("locationId", location.getLocationId());
				int resultCount = (Integer) query1.getSingleResult();
				LOGGER.debug("resultCount : " + resultCount);
				if (resultCount != 0) {
					// returns "1" if - location mapped with any other part
					return "2";
				} else {
					// return "0" - delete the part if part is not mapped with any other location
					entityManager.persist(history);
					Query query = entityManager
							.createNativeQuery("DELETE FROM dbo.PART_LOCATION WHERE LOCATION_ID = :locationId ");
					query.setParameter("locationId", location.getLocationId());
					LOGGER.debug("Part Location delete query : " + query.toString());
					int i = query.executeUpdate();
					entityManager.remove(location);
					return "0";
				}
			} else {
				if (!location.getParts().isEmpty() && location.getParts().size() > 0) {
					// returns "1" if - location mapped with any other part
					return "2";
				} else {
					// return "0" - delete the part if part is not mapped with any other location
					entityManager.persist(history);
					entityManager.remove(location);
					return "0";
				}
			}
		} else {
			// return "1" - if the part is not found in the database.
			return "1";
		}
	}

	// Added by Meena
	private void insertDeletedLocation(LocationHistory history, LocationHistoryDTO historyDto) {
		Date date = new Date();
		history.setLocationId(historyDto.getLocationId());
		history.setLocationType(historyDto.getLocationType());
		history.setRemarks(historyDto.getRemarks());
		history.setDeletedBy(historyDto.getDeletedBy());
		history.setDeletedOn(new Timestamp(date.getTime()));
	}
	// Added by Meena - Part number quantity non zero amount should be displayed for
	// overflow location : section as "F - Overflow" - End

	public int getLocationCount(PartLocationDTO location) {
		// TODO Auto-generated method stub
		List<String> searchResults = locationSearchData(location, false);

		// Long locationCount = (Long) query.getSingleResult();
		return searchResults.size();
	}

	private List<String> locationSearchData(PartLocationDTO location, boolean isIndexCheck) {
		StringBuffer countQuery = new StringBuffer();

		// searchQuery.append("select p from Location p JOIN p.locationType l");
		countQuery.append("select L.LOCATION_ID from [dbo].[LOCATION] L");
		countQuery.append(" WHERE 1=1");
		if (location.getLocationId() != null && !location.getLocationId().equals("")) {
			countQuery.append(" AND L.LOCATION_ID IN (:locationIds)");
		}
		if (null != location.getPlant() && !location.getPlant().equals("")) {
			countQuery.append(" AND  L.PLANT = '" + location.getPlant() + "'");
		}
		if (null != location.getShop() && !location.getShop().equals("")) {
			countQuery.append(" AND  L.SHOP = '" + location.getShop() + "'");
		}
		if (null != location.getLine() && !location.getLine().equals("")) {
			countQuery.append(" AND  L.LINE = '" + location.getLine() + "'");
		}
		if (null != location.getSection() && !location.getSection().equals("")) {
			countQuery.append(" AND  L.SECTION= '" + location.getSection() + "'");
		}
		if (location.getMapType() != null && location.getMapType().equalsIgnoreCase("Mapped")) {
			countQuery.append(" AND L.LOCATION_ID IN (SELECT PL.LOCATION_ID FROM PART_LOCATION PL) ");
		}
		if (location.getMapType() != null && location.getMapType().equalsIgnoreCase("Not Mapped")) {
			countQuery.append(" AND L.LOCATION_ID NOT IN (SELECT PL.LOCATION_ID FROM PART_LOCATION PL) ");
		}

		countQuery.append(" ORDER BY L.LOCATION_ID");

		Query query = entityManager.createNativeQuery(countQuery.toString());

		if (location.getLocationId() != null && !location.getLocationId().equals("")) {
			query.setParameter("locationIds", location.getLocationList());
		}

		if (isIndexCheck == true) {
			query.setFirstResult(location.getStartIndex());
			query.setMaxResults(location.getEndIndex());
		}

		List<String> results = query.getResultList();

		return results;
	}

}
