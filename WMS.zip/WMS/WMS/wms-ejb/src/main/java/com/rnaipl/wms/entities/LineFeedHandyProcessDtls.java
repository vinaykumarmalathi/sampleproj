package com.rnaipl.wms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "TBL_LNFD_HANDY_PROCESSING_DTLS")
@NamedQuery(name = "LineFeedHandyProcessDtls.findAll", query = "SELECT t FROM LineFeedHandyProcessDtls t")
public class LineFeedHandyProcessDtls {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private int id;

	@Column(name = "DEVICE_ID")
	private String deviceID;

	@Column(name = "ISPROCESSING")
	private int isProcessing;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDeviceID() {
		return deviceID;
	}

	public void setDeviceID(String deviceID) {
		this.deviceID = deviceID;
	}

	public int getIsProcessing() {
		return isProcessing;
	}

	public void setIsProcessing(int isProcessing) {
		this.isProcessing = isProcessing;
	}
	
	
}
