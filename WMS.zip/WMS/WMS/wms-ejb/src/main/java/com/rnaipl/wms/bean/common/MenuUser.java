package com.rnaipl.wms.bean.common;

import java.util.LinkedHashMap;
import java.util.LinkedList;

import com.rnaipl.wms.dto.MenuDTO;
import com.rnaipl.wms.dto.common.MenuUserDTO;

public interface MenuUser {

	public LinkedHashMap<Integer, MenuDTO>  getMenuForUser(String userID);
	public LinkedList<MenuDTO>  getMenuTreeAsList(LinkedHashMap<Integer, MenuDTO> menuMap);
	public void addUserMenu(MenuUserDTO userMenuDTO);
	//public void addUserMenu(String userId);
}
