package com.rnaipl.wms.bean;

import java.util.List;

import com.rnaipl.wms.dto.LiveReceiptsSearchDTO;
import com.rnaipl.wms.dto.MissingPartsDTO;

public interface MissingParts {
	public List<MissingPartsDTO> getMissingPartsList(MissingPartsDTO missingPartDTO)throws Exception;
	public int getMissingPartsListCount(MissingPartsDTO missingPartDTO)throws Exception;

}
