package com.rnaipl.wms.bean;

import com.rnaipl.wms.dto.PickingListDTO;

public interface PickingInOutStaging {

	public int insertPickingListToStagingTable(PickingListDTO pickingListDTO);
	
}
