package com.rnaipl.wms.entities;

import java.io.Serializable;

import javax.persistence.*;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the part_temp database table.
 * 
 */
@Entity
@Table(name="PART")
@NamedQuery(name="Part", query="SELECT p FROM Part p")
public class Part implements Serializable {
	private static final long serialVersionUID = 1L;
	
	public Part() {
	}
	

	

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="PART_NO")
	private String partNo;

	@ManyToMany
    @JoinTable(
        name="PART_LOCATION"
        , joinColumns={
            @JoinColumn(name="PART_NO")
            }
        , inverseJoinColumns={
            @JoinColumn(name="LOCATION_ID")
            }
        )
	private List<Location> locations;


	@Column(name="CATEGORY")
	private String category;

	@Column(name="CREATED_BY")
	private String createdBy;

	@Column(name="CREATED_ON")
	private Timestamp createdOn;


	@Column(name="DEPO_CODE")
	private String depoCode;

	@Column(name="DTL_FLAG")
	private String dtlFlag;

	@Column(name="LEAD_TIME")
	private int leadTime;
	

	@Column(name="PART_NAME")
	private String partName;

	
	@Column(name="PART_TYPE")
	private String partType;

	@Column(name="REPACKING_FLAG")
	private String repackingFlag;

	@Column(name="SAFETY_STOCK")
	private int safetyStock;

	@Column(name="SNP")
	private int snp;

	@Column(name="SUPPLIER_CODE")
	private String supplierCode;

	@Column(name="UPDATED_BY")
	private String updatedBy;

	@Column(name="UPDATED_ON")
	private Timestamp updatedOn;

	@Lob
	@Column(name="CHANGE_LOG")
	private String changeLog;

	@Column(name="SNIP")	
	private int snip;
	
	@Column(name="DEL_PLC")
	private String delPlc;
	
	@Column(name="EOP_MARK")
	private String eopMark;
	
	@Column(name="MIXED_MODULE")
	private String mixedModule;
	
	@Column(name="REPACK_SNP")
	private int repackSNP;
	
	@Column(name="DOL_FLAG")
	private String dolFlag;
	
	@Column(name="PC_CODE")
	private String pcCode;
	
	@Column(name="ADOPT_DATE")
	private Date adoptDate;
	
	@Column(name="ABOLISH_DATE")
	private Date abolishDate;
	
	@Column(name="SHELF_LIFE_PART")
	private String shelfLifePart;
	
	@Column(name="SHELF_LIFE_PERIOD")
	private int shelfLifePeriod;
	
	@Column(name="SHELF_LIFE_AGING")
	private String shelfLifeAging;
	
	@Column(name="PART_CATEGORY")
	private String partCategory;

	public String getPartCategory() {
		return partCategory;
	}

	public void setPartCategory(String partCategory) {
		this.partCategory = partCategory;
	}

	public String getShelfLifeAging() {
		return shelfLifeAging;
	}

	public void setShelfLifeAging(String shelfLifeAging) {
		this.shelfLifeAging = shelfLifeAging;
	}

	public String getChangeLog() {
		return changeLog;
	}

	public void setChangeLog(String changeLog) {
		this.changeLog = changeLog;
	}

	public String getPartNo() {
		return this.partNo;
	}

	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}

	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedOn() {
		return this.createdOn;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}


	public String getDepoCode() {
		return this.depoCode;
	}

	public void setDepoCode(String depoCode) {
		this.depoCode = depoCode;
	}

	public int getLeadTime() {
		return this.leadTime;
	}

	public void setLeadTime(int leadTime) {
		this.leadTime = leadTime;
	}


	public String getPartName() {
		return this.partName;
	}

	public void setPartName(String partName) {
		this.partName = partName;
	}


	public String getPartType() {
		return this.partType;
	}

	public void setPartType(String partType) {
		this.partType = partType;
	}

	public int getSafetyStock() {
		return this.safetyStock;
	}

	public void setSafetyStock(int safetyStock) {
		this.safetyStock = safetyStock;
	}

	public int getSnp() {
		return this.snp;
	}

	public void setSnp(int snp) {
		this.snp = snp;
	}

	public String getSupplierCode() {
		return this.supplierCode;
	}

	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Timestamp getUpdatedOn() {
		return this.updatedOn;
	}

	public void setUpdatedOn(Timestamp updatedOn) {
		this.updatedOn = updatedOn;
	}

	public int getSnip() {
		return snip;
	}

	public void setSnip(int snip) {
		this.snip = snip;
	}

	public String getDelPlc() {
		return delPlc;
	}

	public void setDelPlc(String delPlc) {
		this.delPlc = delPlc;
	}

	public void setEopMark(String eopMark) {
		this.eopMark = eopMark;
	}

	public int getRepackSNP() {
		return repackSNP;
	}

	public void setRepackSNP(int repackSNP) {
		this.repackSNP = repackSNP;
	}

	public String getPcCode() {
		return pcCode;
	}

	public void setPcCode(String pcCode) {
		this.pcCode = pcCode;
	}

	public String getEopMark() {
		return eopMark;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Date getAdoptDate() {
		return adoptDate;
	}

	public void setAdoptDate(Date adoptDate) {
		this.adoptDate = adoptDate;
	}

	public Date getAbolishDate() {
		return abolishDate;
	}

	public void setAbolishDate(Date abolishDate) {
		this.abolishDate = abolishDate;
	}

	public int getShelfLifePeriod() {
		return shelfLifePeriod;
	}

	public void setShelfLifePeriod(int shelfLifePeriod) {
		this.shelfLifePeriod = shelfLifePeriod;
	}

	public String getDtlFlag() {
		return dtlFlag;
	}

	public void setDtlFlag(String dtlFlag) {
		this.dtlFlag = dtlFlag;
	}

	public String getRepackingFlag() {
		return repackingFlag;
	}

	public void setRepackingFlag(String repackingFlag) {
		this.repackingFlag = repackingFlag;
	}

	public String getMixedModule() {
		return mixedModule;
	}

	public void setMixedModule(String mixedModule) {
		this.mixedModule = mixedModule;
	}

	public String getDolFlag() {
		return dolFlag;
	}

	public void setDolFlag(String dolFlag) {
		this.dolFlag = dolFlag;
	}

	public String getShelfLifePart() {
		return shelfLifePart;
	}

	public void setShelfLifePart(String shelfLifePart) {
		this.shelfLifePart = shelfLifePart;
	}
	public List<Location> getLocations() {
		return locations;
	}

	public void setLocations(List<Location> locations) {
		this.locations = locations;
	}

}