package com.rnaipl.wms.bean;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.MenuDTO;
import com.rnaipl.wms.dto.PartDTO;
import com.rnaipl.wms.dto.UserDTO;
import com.rnaipl.wms.entities.User;
import com.rnaipl.wms.util.WMSBeanConstants;

@Stateless
@LocalBean
public class UserMenuBean implements UserMenu{
	
	private static final Logger LOGGER = Logger.getLogger(UserMenuBean.class);

	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;

	/**
	 * get all the user menus by giving user input
	 * 
	 * @param user
	 * @return
	 */
	public List<MenuDTO> getUserMenus(UserDTO user) {
		LOGGER.debug("*****IN Get All User Menu Bean ");
		List<MenuDTO> userMenus = new ArrayList<MenuDTO>();
		Query query = entityManager
				.createQuery("select p from User p where p.userId = :val");
		query.setParameter("val", user.getUserId());
		
		List<com.rnaipl.wms.entities.User> userList = query.getResultList();
		LOGGER.debug("*****User List Size" + userList.size());
		if (!userList.isEmpty() && userList.size() > 0
				&& userList.get(0) != null) {
			for (com.rnaipl.wms.entities.Menu menu : userList.get(0).getMenus()) {
				MenuDTO menuDto = new MenuDTO();
				List<UserDTO> users = new ArrayList<UserDTO>();
				menuDto.setMenuLevel(null == String.valueOf(menu.getMenuLevel()) ? 0 : menu.getMenuLevel());
				menuDto.setMenuId(null == menu.getMenuId() ? "" : menu.getMenuId().toString());
				menuDto.setMenuName(null == menu.getMenuName() ? "" : menu.getMenuName().toString());
				//menuDto.setParentId(null == menu.getParentId() ? "" : menu.getParentId().toString());
				//List<User> users = menu.getUsers();
				if (menu.getUsers() != null) {
					for (User userMenu : menu.getUsers()) {
						UserDTO userDto = new UserDTO();
						userDto.setRole(userMenu.getRole());
						userDto.setUserId(userMenu.getUserId());
						userDto.setUserName(userMenu.getUserName());
						users.add(userDto);
					}
				}
				menuDto.setUsers(users);
				menuDto.setPath(null == menu.getPath() ? "" : menu.getPath().toString());
				menuDto.setOrderNumber(null == String.valueOf(menu.getOrderNumber()) ? 0 : menu.getOrderNumber());
				userMenus.add(menuDto);
			}
		}
		LOGGER.debug("getAllParts() method Ends ");
		return userMenus;
	}
	
	public List<String> rolesPrivilege() {
		LOGGER.debug("*** In LoginAuthentication Bean Class rolesPrivilege");
		Query query = entityManager.createNativeQuery("SELECT * FROM USER_ADMIN");
		List<String> rolesList = query.getResultList();
		LOGGER.debug("*** In LoginAuthentication Bean Class rolesPrivilege"+rolesList);
		return rolesList;

		}

}
