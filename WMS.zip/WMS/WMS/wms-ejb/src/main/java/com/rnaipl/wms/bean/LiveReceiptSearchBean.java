package com.rnaipl.wms.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.LiveReceiptInputDTO;
import com.rnaipl.wms.dto.LiveReceiptQtyMismatchDTO;
import com.rnaipl.wms.dto.LiveReceiptsSearchDTO;
import com.rnaipl.wms.dto.PartDTO;
import com.rnaipl.wms.dto.PartNumberDTO;
import com.rnaipl.wms.dto.ZoneDTO;
import com.rnaipl.wms.entities.LiveReceipt;
import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSBeanUtil;
import com.rnaipl.wms.util.WMSConstants;

/*AJ00482484 : LIVE Receipt Change : START*/

public class LiveReceiptSearchBean implements LiveReceiptSearch{
	
	private static final Logger LOGGER = Logger.getLogger(LiveReceiptSearchBean.class);
	
	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
    private EntityManager entityManager;

	
	public List<LiveReceiptsSearchDTO> getAllLiveReceipts()throws Exception {
		
		LOGGER.debug("*****In getAllLiveReceipts bean****" );
		List<LiveReceiptsSearchDTO> liveReceiptSearchList = new ArrayList<LiveReceiptsSearchDTO>();
		
		StringBuffer queryStringBuf = new StringBuffer();
		queryStringBuf.append("select l from LiveReceipt l");
		
		Query query = entityManager.createQuery(queryStringBuf.toString());
		LOGGER.debug("*****Query Generated getAllLiveReceipts() == " + queryStringBuf.toString() );
		
		List<LiveReceipt> queryDatas = query.getResultList();
		LOGGER.debug("Live Receipt Data size " + queryDatas.size());
		
		if (null != queryDatas && queryDatas.size() > 0) {
			for(LiveReceipt values : queryDatas){
				LiveReceiptsSearchDTO liveReceiptSearchDTO = setLiveReceiptValues(values);
				liveReceiptSearchList.add(liveReceiptSearchDTO);
			}
		}
		
		
		return liveReceiptSearchList;
	}

	private LiveReceiptsSearchDTO setLiveReceiptValues(LiveReceipt liveReceiptData)throws Exception {
		LiveReceiptsSearchDTO liveReceiptSearchDTO = new LiveReceiptsSearchDTO();
		
		try{
			liveReceiptSearchDTO.setPartNumber((null == liveReceiptData.getPartNumber()? "" : liveReceiptData.getPartNumber().toString()));
			liveReceiptSearchDTO.setQuantity(liveReceiptData.getQuantity());
		}catch(Exception e){
			LOGGER.error(e);
			throw e;
		}
		
		return liveReceiptSearchDTO;
	}
	
	public List<LiveReceiptsSearchDTO> getLiveReceiptsByRAN(LiveReceiptInputDTO inputDto) throws Exception {
		
		LOGGER.debug("*****In getLiveReceiptsByRAN bean****" );
		List<LiveReceiptsSearchDTO> liveReceiptSearchList = new ArrayList<LiveReceiptsSearchDTO>();
		
		String duplicateRanQueryString = getDuplicateRanCheckQuery(inputDto);
		Query duplicateRanCheckQuery = entityManager.createNativeQuery(duplicateRanQueryString);
		List<Object[]> duplicateRanDatas = duplicateRanCheckQuery.getResultList();
		
		LiveReceiptsSearchDTO liveReceiptSearch = new LiveReceiptsSearchDTO();
		String ranExist = "";
		if(duplicateRanDatas.size() > 0){ // RAN already Exist in PARTINOUT_STAGING_AUDIT Table
			ranExist = "YES";
			liveReceiptSearch.setPartNumber("");
			liveReceiptSearch.setQuantity(0);
			liveReceiptSearch.setRanExist(ranExist);
			
			liveReceiptSearchList.add(liveReceiptSearch);
			
		}else{// RAN already Not Exist in PARTINOUT_STAGING_AUDIT Table
			ranExist = "NO";
			
			StringBuffer queryStringBuf = new StringBuffer();
			queryStringBuf.append("SELECT TOP 1 PART_NO, QUANTITY FROM DBO.LIVE_RECEIPT ");
			queryStringBuf.append(" WHERE RAN = substring('"+inputDto.getRan()+"',1,7) ");
			
			//Added plant condition to avoid of getting duplicate RAN - Start
			if(inputDto.getPlant() != null ) {
				queryStringBuf.append(" AND SUBSTRING(filename, 1, 1) = '"+inputDto.getPlant()+"'  "); 
            }else{
				queryStringBuf.append(" AND SUBSTRING(filename, 1, 1) = 'G'  "); 
			}
			//Added plant condition to avoid of getting duplicate RAN - End
			
			queryStringBuf.append(" ORDER BY UPDATED_DATETIME DESC");
			
			Query query = entityManager.createNativeQuery(queryStringBuf.toString());
			LOGGER.debug("*****Query Generated getLiveReceiptsByRAN() == " + queryStringBuf.toString() );
			
			List<Object[]> queryDatas = query.getResultList();
			LOGGER.debug("getLiveReceiptsByRAN() == Live Receipt Data size ==  " + queryDatas.size());
			
			if (null != queryDatas && queryDatas.size() > 0) {
				
				Object[] liveReceiptDetails = queryDatas.get(0);
				
				int indexCount=0;
				liveReceiptSearch.setPartNumber((null == liveReceiptDetails[indexCount]?"":liveReceiptDetails[indexCount].toString()));
							
				indexCount++;
				if(null != liveReceiptDetails[indexCount]){
					liveReceiptSearch.setQuantity((Integer) liveReceiptDetails[indexCount]);
				}
				liveReceiptSearch.setRanExist(ranExist);
				liveReceiptSearchList.add(liveReceiptSearch);
				
			}else{
				liveReceiptSearch.setPartNumber("");
				liveReceiptSearch.setQuantity(0);
				liveReceiptSearch.setRanExist(ranExist);
				liveReceiptSearchList.add(liveReceiptSearch);
			}
		}
		
		
		return liveReceiptSearchList;
	}

	private String getDuplicateRanCheckQuery(LiveReceiptInputDTO inputDto) {
		StringBuffer duplicateRanCheckQuery = new StringBuffer();
		duplicateRanCheckQuery.append("SELECT * FROM DBO.PARTINOUT_STAGING_AUDIT WHERE 1=1 ");
		duplicateRanCheckQuery.append(" AND RAN = '"); duplicateRanCheckQuery.append(inputDto.getRan()); duplicateRanCheckQuery.append("' ");
		
		//Added plant condition to avoid of getting duplicate RAN - Start
		if(inputDto.getPlant() != null && inputDto.getPlant().charAt(0) == 'D') {
			duplicateRanCheckQuery.append(" AND SUBSTRING(LOCATION, 1, 1) = '"+inputDto.getPlant()+"'  "); 
			duplicateRanCheckQuery.append(" AND SUBSTRING(LOCATION, 2, 1) IN ('A','B') ");
		} else {
			//Added plant condition to avoid of getting duplicate RAN - End		
			//Added to get both T and K shops when shop is selected in handy as 'T' - Start
			if(inputDto.getShop().charAt(0) != 'T') {
				duplicateRanCheckQuery.append(" AND SUBSTRING(LOCATION, 2, 1) IN ('"); 
				duplicateRanCheckQuery.append(inputDto.getShop()); duplicateRanCheckQuery.append("') ");
			}else {
				duplicateRanCheckQuery.append(" AND SUBSTRING(LOCATION, 2, 1) IN ('T','K') ");
			}
		}
		
		//Added to get both T and K shops when shop is selected in handy as 'T' - End
		duplicateRanCheckQuery.append(" AND datediff(month, part_in_out_time, getdate()) <= 6");
		duplicateRanCheckQuery.append(" ORDER BY SCAN_TIME DESC");
		LOGGER.debug("Query Generated for Duplicate RAN Check == "+duplicateRanCheckQuery.toString());
		return duplicateRanCheckQuery.toString();
	}

	public List<LiveReceiptQtyMismatchDTO> getLiveReceiptQtyMismatchSearch(LiveReceiptQtyMismatchDTO lrQtyMismatchDto)throws Exception {
		LOGGER.debug("*****In getLiveReceiptsByRAN bean****" );
		List<LiveReceiptQtyMismatchDTO> liveReceiptMismatchSearch = new ArrayList<LiveReceiptQtyMismatchDTO>();
		int startIndex = lrQtyMismatchDto.getStartIndex();
		int endIndex = lrQtyMismatchDto.getEndIndex();			
		StringBuffer queryStringBuf = new StringBuffer();
		
		queryStringBuf.append(getQuery1(lrQtyMismatchDto));
		
		Query query = entityManager.createNativeQuery(queryStringBuf.toString());
		
		
		List<Object[]> queryDatas = query.getResultList();
		LOGGER.debug("getLiveReceiptQtyMismatchSearch() == Quantity Mismatch Data size ==  " + queryDatas.size());

		if(lrQtyMismatchDto.getIsFullDownload()!=1){
			query.setFirstResult(lrQtyMismatchDto.getStartIndex());
			query.setMaxResults(lrQtyMismatchDto.getEndIndex());
		}
		
		if(null != queryDatas && queryDatas.size() > 0){
			for(int i = 0; i<queryDatas.size(); i++){
				LiveReceiptQtyMismatchDTO resultDto = new LiveReceiptQtyMismatchDTO();
				Object[] data = queryDatas.get(i);
				
				int index = 0;
				resultDto.setPartType(lrQtyMismatchDto.getPartType());
				
				index++;
				resultDto.setPartNumber((null == data[index] ? "" : data[index].toString()));
				
				index++;
				resultDto.setProcessCode((null == data[index] ? "" : data[index].toString()));
				
				index++;
				resultDto.setLocation((null == data[index] ? "" : data[index].toString()));
				
				index++;
				resultDto.setRan((null == data[index] ? "" : data[index].toString()));
				index++;
				resultDto.setSupplier((null == data[index] ? "" : data[index].toString()));
				
				index++;
				resultDto.setSnp((Integer) (null == data[index] ? 0 : data[index]));
				
				index++;
				resultDto.setBoxRecCats((Integer) (null == data[index] ? 0 : data[index]));
				
				if(lrQtyMismatchDto.getPartType()=="A"){
					index++;
					resultDto.setContainerNo((null == data[index] ? "" : data[index].toString()));
				}else{
					index++;
					resultDto.setdNote((null == data[index] ? "" : data[index].toString()));
				}
				
				index++;
				resultDto.setdNoteQty((Integer) (null == data[index] ? 0 : data[index]));
				
				/*index++;
				resultDto.setLiveReceiptUpdatedTime((Date) data[index]);*/
				
				index++;
				resultDto.setLiveReceiptUpdatedTime((null == data[index] ? "" : data[index].toString()));
				
				index++;
				resultDto.setBoxRecWms((Integer) (null == data[index] ? 0 : data[index]));
				
				index++;
				resultDto.setAuditQuantity((Integer) (null == data[index] ? 0 : data[index]));
				
				/*index++;
				resultDto.setAuditScanTime((Date) data[index]);*/
				
				index++;
				resultDto.setAuditScanTime((null == data[index] ? "" : data[index].toString()));
				
				index++;
				resultDto.setBoxMismatch((Integer) (null == data[index] ? 0 : data[index]));
				
				index++;
				resultDto.setQtyMismatch((Integer) (null == data[index] ? 0 : data[index]));
				
				index++;
				resultDto.setRemarks((null == data[index] ? "" : data[index].toString()));
				
				liveReceiptMismatchSearch.add(resultDto);
			}
		}
		
		return liveReceiptMismatchSearch;
	}

	public int getLiveReceiptQtyMismatchListCount(LiveReceiptQtyMismatchDTO lrQtyMismatchDto)throws Exception {
		StringBuffer queryStringBuf = new StringBuffer();
		int noOfRecords = 0 ;
		queryStringBuf.append(getListCount(lrQtyMismatchDto));
		/*queryStringBuf.append(getQuery1(lrQtyMismatchDto));*/
		
		Query query = entityManager.createNativeQuery(queryStringBuf.toString());
		//List<Object[]> queryDatas = query.getResultList();		
		//noOfRecords = queryDatas.size();
		noOfRecords = (Integer) query.getSingleResult();
		//LOGGER.debug("getLiveReceiptQtyMismatchListCount() == Quantity Mismatch Data size ==  " + noOfRecords);
		
		//int noOfRecords = queryDatas.size();
        LOGGER.debug("Live Receipt Quantity Mismatch RecordCount :  " + noOfRecords);
		return noOfRecords;
	}
	
	
	private String getListCount(LiveReceiptQtyMismatchDTO lrQtyMismatchDto) {
		StringBuffer query = new StringBuffer();
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				
		query.append("select count(*) from ( ");
		
		if(lrQtyMismatchDto.getReceipt()!=null && lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_MISMATCH)){
			/*query.append("SELECT DISTINCT P.PART_TYPE,A.PART_NO ,'' as PROCESS_CODE,A.[LOCATION],A.RAN,P.SUPPLIER_CODE as SUPPLIER,A.SNP, ");
			query.append(" (LR.QUANTITY/P.SNP) as CATS_NO_OF_BOXES ,'' as DNOTE,LR.QUANTITY,LR.UPDATED_DATETIME, ");
			query.append(" A.NO_OF_BOXES as WMS_NO_OF_BOXES,[COUNT],SCAN_TIME,ABS(A.NO_OF_BOXES - (LR.QUANTITY/P.SNP) ) as NO_OF_BOX_MISMATCH, ");
			query.append(" ABS(A.COUNT-LR.QUANTITY) as QUANTITY_MISMATCH,'MISMATCH' as REMARKS "
					+ "from PARTINOUT_STAGING_AUDIT A ");
			query.append(" inner join LIVE_RECEIPT LR on A.RAN=LR.RAN left outer join PART P on P.PART_NO=A.PART_NO");
			query.append(" where A.COUNT!=LR.QUANTITY and A.TRANSACTION_TYPE='IN' ");*/
			
			query.append(" SELECT distinct P.PART_TYPE,A.PART_NO ,'' as PROCESS_CODE,A.[LOCATION],substring(A.RAN,1,7) as RAN, ");
			query.append(" concat(P.SUPPLIER_CODE,' - ',P.SUPPLIER_NAME) as SUPPLIER,A.SNP,(LR.QUANTITY/P.SNP) as CATS_NO_OF_BOXES , ");			
			if (lrQtyMismatchDto.getPartType() != null && !lrQtyMismatchDto.getPartType().toString().trim().equalsIgnoreCase("")){
				if (lrQtyMismatchDto.getPartType().toString().trim().equalsIgnoreCase("A")){
					query.append(" LR.Container_No, ");
				}else{
					query.append(" LR.DNote_No, ");
				}
			}			
			query.append(" LR.QUANTITY,convert(varchar,LR.UPDATED_DATETIME,120) as UPDATED_DATETIME, count(A.NO_OF_BOXES) as WMS_NO_OF_BOXES, ");
			query.append(" sum(A.COUNT) as totCount,convert(varchar,PART_IN_OUT_TIME,120) as PART_IN_OUT_TIME, ");
			query.append(" ABS(count(A.NO_OF_BOXES) - (LR.QUANTITY/P.SNP) ) as NO_OF_BOX_MISMATCH,ABS(sum(A.COUNT)-LR.QUANTITY) as QUANTITY_MISMATCH,'MISMATCH' as REMARKS ");
			query.append(" from PARTINOUT_STAGING_AUDIT A inner join LIVE_RECEIPT LR on substring(A.RAN,1,7)=LR.RAN ");
			query.append(" and SUBSTRING(A.LOCATION,1,1) = SUBSTRING(LR.filename,1,1) ");
			query.append(" inner join PART P on P.PART_NO=A.PART_NO ");
			query.append(" inner join TBL_ZONE_MASTER Z on Z.PART_NO = A.PART_NO where A.TRANSACTION_TYPE='IN' ");
			
		} else if(lrQtyMismatchDto.getReceipt()!=null && lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_WMS)){
			query.append("SELECT DISTINCT P.PART_TYPE,A.PART_NO ,'' as PROCESS_CODE,A.[LOCATION],substring(A.RAN,1,7) as RAN, "
					+ "concat(P.SUPPLIER_CODE,' - ',P.SUPPLIER_NAME)  as SUPPLIER,A.SNP, ");
			query.append(" 0 as CATS_NO_OF_BOXES ,'' as DNOTE,LR.QUANTITY,convert(varchar,LR.UPDATED_DATETIME,120) as UPDATED_DATETIME, ");
			query.append(" count(A.NO_OF_BOXES) as WMS_NO_OF_BOXES,sum(COUNT) as count,convert(varchar,PART_IN_OUT_TIME,120) as PART_IN_OUT_TIME, "
					+ "0 as NO_OF_BOX_MISMATCH,0 as QUANTITY_MISMATCH,  ");
			query.append(" 'CATS NOT DONE' as REMARKS from PARTINOUT_STAGING_AUDIT A ");
			query.append(" left outer join LIVE_RECEIPT LR on substring(A.RAN,1,7)=LR.RAN inner join PART P on P.PART_NO=A.PART_NO ");
			query.append(" inner join TBL_ZONE_MASTER Z on Z.PART_NO = A.PART_NO  ");
			query.append(" where A.TRANSACTION_TYPE='IN' and A.RAN<>'*' and A.RAN<>'' and LR.RAN is null ");	
			
		}else if(lrQtyMismatchDto.getReceipt()!=null && lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_CATS)){
			query.append("Select DISTINCT P.PART_TYPE,LR.PART_NO,LR.PROCESS_CODE, PL.[LOCATION_ID],LR.RAN,concat(P.SUPPLIER_CODE,' - ',P.SUPPLIER_NAME) as SUPPLIER,P.SNP, ");
			query.append(" (LR.QUANTITY/P.SNP) as CATS_NO_OF_BOXES , ");
			if (lrQtyMismatchDto.getPartType() != null && !lrQtyMismatchDto.getPartType().toString().trim().equalsIgnoreCase("")){
				if (lrQtyMismatchDto.getPartType().toString().trim().equalsIgnoreCase("A")){
					query.append(" LR.Container_No, ");
				}else{
					query.append(" LR.DNote_No, ");
				}
			}
			query.append(" LR.QUANTITY, convert(varchar,LR.UPDATED_DATETIME,120) as UPDATED_DATETIME, ");
			query.append(" A.NO_OF_BOXES as WMS_NO_OF_BOXES,[COUNT],A.PART_IN_OUT_TIME,0 as NO_OF_BOX_MISMATCH, ");
			query.append(" 0 as QUANTITY_MISMATCH,'WH-IN NOT DONE' as REMARKS from LIVE_RECEIPT LR ");
			query.append(" left outer join PARTINOUT_STAGING_AUDIT A on LR.RAN=substring(A.RAN,1,7) left outer join PART_LOCATION PL on PL.PART_NO=LR.part_no ");
			query.append(" left outer join part p on p.PART_NO = LR.PART_NO and (P.SNP is not null and P.SNP <>'') ");
			query.append(" left outer join TBL_ZONE_MASTER Z on Z.PART_NO = LR.PART_NO where A.RAN is null ");
		}
		
		if (lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_MISMATCH)
				|| lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_WMS)) {
			if (lrQtyMismatchDto.getPlant() != null
					&& !lrQtyMismatchDto.getPlant().toString().trim().equalsIgnoreCase("")) {
				LOGGER.debug("Audit Table Search Input Rans == " + lrQtyMismatchDto.getPlant());
				query.append(" and SUBSTRING(A.LOCATION,1,1)='" + lrQtyMismatchDto.getPlant() + "'");
			}

			if (lrQtyMismatchDto.getShop() != null
					&& !lrQtyMismatchDto.getShop().toString().trim().equalsIgnoreCase("")) {
				LOGGER.debug("Audit Table Search getShop == " + lrQtyMismatchDto.getShop().charAt(0));
				if(lrQtyMismatchDto.getShop().charAt(0)!='K'){
					query.append(" and SUBSTRING(A.LOCATION,2,1)='" + lrQtyMismatchDto.getShop().trim().charAt(0) + "'");
				}else{
					query.append(" and SUBSTRING(A.LOCATION,2,1) in ('T','K') ");
				}
			}

			if (lrQtyMismatchDto.getLine() != null
					&& !lrQtyMismatchDto.getLine().toString().trim().equalsIgnoreCase("")) {
				LOGGER.debug("Audit Table Search getLine == " + lrQtyMismatchDto.getLine());
				query.append(" and SUBSTRING(A.LOCATION,3,1)='" + lrQtyMismatchDto.getLine() + "'");
			}
		}else if (lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_CATS)){
			if (lrQtyMismatchDto.getPlant() != null
					&& !lrQtyMismatchDto.getPlant().toString().trim().equalsIgnoreCase("")) {
				LOGGER.debug("Audit Table Search Input Rans == " + lrQtyMismatchDto.getPlant());
				query.append(" and SUBSTRING(LR.filename,1,1)='" + lrQtyMismatchDto.getPlant() + "'");
			}

			if (lrQtyMismatchDto.getShop() != null
					&& !lrQtyMismatchDto.getShop().toString().trim().equalsIgnoreCase("")) {
				LOGGER.debug("Audit Table Search getShop == " + lrQtyMismatchDto.getShop().charAt(0));
				if(lrQtyMismatchDto.getShop().charAt(0)!='K'){
					query.append(" and SUBSTRING(PL.LOCATION_ID,2,1)='" + lrQtyMismatchDto.getShop().trim().charAt(0) + "'");
				}else{
					query.append(" and SUBSTRING(PL.LOCATION_ID,2,1) in ('T','K') ");
				}
			}

			if (lrQtyMismatchDto.getLine() != null
					&& !lrQtyMismatchDto.getLine().toString().trim().equalsIgnoreCase("")) {
				LOGGER.debug("Audit Table Search getLine == " + lrQtyMismatchDto.getLine());
				query.append(" and SUBSTRING(PL.LOCATION_ID,3,1)='" + lrQtyMismatchDto.getLine() + "'");
			}
		}
		
		if (lrQtyMismatchDto.getPartType() != null && !lrQtyMismatchDto.getPartType().toString().trim().equalsIgnoreCase("")){
			 query.append(" and P.PART_TYPE= '"+lrQtyMismatchDto.getPartType()+"'  ");
		}
		
		if (lrQtyMismatchDto.getZone() != null
				&& !lrQtyMismatchDto.getZone().toString().trim().equalsIgnoreCase("")) {
			LOGGER.debug("Audit Table Search getZone == " + lrQtyMismatchDto.getZone());
			query.append(" and Z.Zonecode ='" + lrQtyMismatchDto.getZone() + "'");
		}
		
		if (lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_MISMATCH)) {
			if (lrQtyMismatchDto.getFromDate() != null || lrQtyMismatchDto.getToDate() != null) {
				query.append(" AND ( (convert(varchar,A.PART_IN_OUT_TIME,120) >= '" + dateFormatter.format(lrQtyMismatchDto.getFromDate()) + "'");
				query.append(" AND convert(varchar,A.PART_IN_OUT_TIME,120) <= '" + dateFormatter.format(lrQtyMismatchDto.getToDate()) + "' ) ");
				
				query.append(" OR ( convert(varchar,LR.UPDATED_DATETIME,120) >= '" + dateFormatter.format(lrQtyMismatchDto.getFromDate()) + "'");
				query.append(" AND convert(varchar,LR.UPDATED_DATETIME,120) <= '" + dateFormatter.format(lrQtyMismatchDto.getToDate()) + "' ) ) ");
			}
		}		
		
		if(lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_WMS)){
			if (lrQtyMismatchDto.getFromDate() != null || lrQtyMismatchDto.getToDate() != null) {
				/*query.append(" AND ( A.SCAN_TIME >= '" + dateFormatter.format(lrQtyMismatchDto.getFromDate()) + "'");
				query.append(" AND A.SCAN_TIME <= '" + dateFormatter.format(lrQtyMismatchDto.getToDate()) + "' ) ");*/
				query.append(" AND ( convert(varchar,A.PART_IN_OUT_TIME,120) >= '" + dateFormatter.format(lrQtyMismatchDto.getFromDate()) + "'");
				query.append(" AND convert(varchar,A.PART_IN_OUT_TIME,120) <= '" + dateFormatter.format(lrQtyMismatchDto.getToDate()) + "' ) ");
			}
		}
		
		if (lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_CATS)
				/*|| lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_ALL)*/) {
			if (lrQtyMismatchDto.getFromDate() != null || lrQtyMismatchDto.getToDate() != null) {
				query.append(" AND (convert(varchar,LR.UPDATED_DATETIME,120) >= '" + dateFormatter.format(lrQtyMismatchDto.getFromDate()) + "'");
				query.append(" AND convert(varchar,LR.UPDATED_DATETIME,120) <= '" + dateFormatter.format(lrQtyMismatchDto.getToDate()) + "' ) ");
			}
		}	
		
		if (lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_MISMATCH)){
			if(lrQtyMismatchDto.getPartType().toString().trim().equalsIgnoreCase("A")){
				if(null != lrQtyMismatchDto.getContNoList() && lrQtyMismatchDto.getContNoList().size() > 0){
					String contNoString = queryStr(lrQtyMismatchDto.getContNoList());
					LOGGER.debug("Live Receipt Search Input cont No's == "+contNoString);
					query.append(" AND LR.CONTAINER_NO IN ("); query.append(contNoString);  query.append(")");
				}	
			}else{
				if(null != lrQtyMismatchDto.getdNoteNoList() && lrQtyMismatchDto.getdNoteNoList().size() > 0){
					String dnoteNoString = queryStr(lrQtyMismatchDto.getdNoteNoList());
					LOGGER.debug("Live Receipt Search Input dNote No's == "+dnoteNoString);
					query.append(" AND LR.DNOTE_NO IN ("); query.append(dnoteNoString);  query.append(")");
				}	
			}
			if(null != lrQtyMismatchDto.getRecPlaceList() && lrQtyMismatchDto.getRecPlaceList().size() > 0){
				String recPlaceString = queryStr(lrQtyMismatchDto.getRecPlaceList());
				LOGGER.debug("Live Receipt Search Input receiving Place == "+recPlaceString);
				query.append(" AND LR.REC_PLACE IN ("); query.append(recPlaceString);  query.append(")");
			}				
		}
				
		
		if (lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_MISMATCH)
				|| lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_WMS)) {
			if (null != lrQtyMismatchDto.getPartList() && lrQtyMismatchDto.getPartList().size() > 0) {
				String partString = queryStr(lrQtyMismatchDto.getPartList());
				LOGGER.debug("Audit Table Search Input Part Numbers == " + partString);
				query.append(" AND A.PART_NO IN (");query.append(partString);query.append(")");
			}
			if(null != lrQtyMismatchDto.getRanList() && lrQtyMismatchDto.getRanList().size() > 0){
				String ranString = queryStr(lrQtyMismatchDto.getRanList());
				LOGGER.debug("Live Receipt Search Input Rans == "+ranString);
				query.append(" AND substring(A.RAN,1,7) IN ("); query.append(ranString);  query.append(")");
			}
			if(null != lrQtyMismatchDto.getSupList() && lrQtyMismatchDto.getSupList().size() > 0){
				String supString = queryStr(lrQtyMismatchDto.getSupList());
				LOGGER.debug("Live Receipt Search Input Suppliers == "+supString);
				query.append(" AND P.SUPPLIER_CODE IN ("); query.append(supString);  query.append(")");
			}		
			
			if (lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_MISMATCH)){
				if(lrQtyMismatchDto.getPartType().toString().trim().equalsIgnoreCase("A")){
					if(null != lrQtyMismatchDto.getContNoList() && lrQtyMismatchDto.getContNoList().size() > 0){
						String contNoString = queryStr(lrQtyMismatchDto.getContNoList());
						LOGGER.debug("Live Receipt Search Input cont No's == "+contNoString);
						/*query.append(" AND LR.CONTAINER_NO IN ("); query.append(contNoString);  query.append(")");*/
					}	
				}else{
					if(null != lrQtyMismatchDto.getdNoteNoList() && lrQtyMismatchDto.getdNoteNoList().size() > 0){
						String dnoteNoString = queryStr(lrQtyMismatchDto.getdNoteNoList());
						LOGGER.debug("Live Receipt Search Input dNote No's == "+dnoteNoString);
						query.append(" AND LR.DNOTE_NO IN ("); query.append(dnoteNoString);  query.append(")");
					}	
					if(null != lrQtyMismatchDto.getRecPlaceList() && lrQtyMismatchDto.getRecPlaceList().size() > 0){
						String recPlaceString = queryStr(lrQtyMismatchDto.getRecPlaceList());
						LOGGER.debug("Live Receipt Search Input receiving Place == "+recPlaceString);
						query.append(" AND substring(LR.DNOTE_NO,2,3) IN ("); query.append(recPlaceString);  query.append(")");
					}		
				}
			}
			
			query.append(" group by P.PART_TYPE,A.PART_NO,[LOCATION],substring(A.RAN,1,7),P.SUPPLIER_CODE,A.SNP,P.SNP,QUANTITY,"
					+ "convert(varchar,LR.UPDATED_DATETIME,120),convert(varchar,A.PART_IN_OUT_TIME,120),P.SUPPLIER_NAME  ");
			
			if (lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_MISMATCH)){
				query.append(" ,LR.Container_No,LR.Dnote_no ");
				query.append(" having sum(A.count)<>LR.QUANTITY ");
			}
			
			
		} else if (lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_CATS)
				/*|| lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_ALL)*/) {
			if (null != lrQtyMismatchDto.getPartList() && lrQtyMismatchDto.getPartList().size() > 0) {
			String partString = queryStr(lrQtyMismatchDto.getPartList());
			LOGGER.debug("Audit Table Search Input Part Numbers == " + partString);
			query.append(" AND LR.PART_NO IN (");query.append(partString);query.append(")");
			}
			
			if(null != lrQtyMismatchDto.getRanList() && lrQtyMismatchDto.getRanList().size() > 0){
				String ranString = queryStr(lrQtyMismatchDto.getRanList());
				LOGGER.debug("Live Receipt Search Input Rans == "+ranString);
				query.append(" AND LR.RAN IN ("); query.append(ranString);  query.append(")");
			}
			
			if(null != lrQtyMismatchDto.getSupList() && lrQtyMismatchDto.getSupList().size() > 0){
				String supString = queryStr(lrQtyMismatchDto.getSupList());
				LOGGER.debug("Live Receipt Search Input Suppliers == "+supString);
				query.append(" AND P.SUPPLIER_CODE IN ("); query.append(supString);  query.append(")");
			}
			
			if(lrQtyMismatchDto.getPartType().toString().trim().equalsIgnoreCase("A")){
				if(null != lrQtyMismatchDto.getContNoList() && lrQtyMismatchDto.getContNoList().size() > 0){
					String contNoString = queryStr(lrQtyMismatchDto.getContNoList());
					LOGGER.debug("Live Receipt Search Input cont No's == "+contNoString);
					/*query.append(" AND LR.CONTAINER_NO IN ("); query.append(contNoString);  query.append(")");*/
				}	
			}else{
				if(null != lrQtyMismatchDto.getdNoteNoList() && lrQtyMismatchDto.getdNoteNoList().size() > 0){
					String dnoteNoString = queryStr(lrQtyMismatchDto.getdNoteNoList());
					LOGGER.debug("Live Receipt Search Input dNote No's == "+dnoteNoString);
					query.append(" AND LR.DNOTE_NO IN ("); query.append(dnoteNoString);  query.append(")");
				}	
				if(null != lrQtyMismatchDto.getRecPlaceList() && lrQtyMismatchDto.getRecPlaceList().size() > 0){
					String recPlaceString = queryStr(lrQtyMismatchDto.getRecPlaceList());
					LOGGER.debug("Live Receipt Search Input receiving Place == "+recPlaceString);
					query.append(" AND substring(LR.DNOTE_NO,2,3) IN ("); query.append(recPlaceString);  query.append(")");
				}		
			}
			
		}
		
		query.append(" ) c ");
		
		LOGGER.debug("Query Generated for Quantity Mismatch Count : "+query.toString());
		return query.toString();
	}
	
	private String getQuery1(LiveReceiptQtyMismatchDTO lrQtyMismatchDto) throws Exception {
		StringBuffer query = new StringBuffer();
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		int startIndex = lrQtyMismatchDto.getStartIndex();
		int endIndex = lrQtyMismatchDto.getEndIndex();	
		
		if(lrQtyMismatchDto.getReceipt()!=null && lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_MISMATCH)){
			/*query.append("SELECT DISTINCT P.PART_TYPE,A.PART_NO ,'' as PROCESS_CODE,A.[LOCATION],A.RAN,P.SUPPLIER_CODE as SUPPLIER,A.SNP, ");
			query.append(" (LR.QUANTITY/P.SNP) as CATS_NO_OF_BOXES ,'' as DNOTE,LR.QUANTITY,LR.UPDATED_DATETIME, ");
			query.append(" A.NO_OF_BOXES as WMS_NO_OF_BOXES,[COUNT],SCAN_TIME,ABS(A.NO_OF_BOXES - (LR.QUANTITY/P.SNP) ) as NO_OF_BOX_MISMATCH, ");
			query.append(" ABS(A.COUNT-LR.QUANTITY) as QUANTITY_MISMATCH,'MISMATCH' as REMARKS "
					+ "from PARTINOUT_STAGING_AUDIT A ");
			query.append(" inner join LIVE_RECEIPT LR on A.RAN=LR.RAN left outer join PART P on P.PART_NO=A.PART_NO");
			query.append(" where A.COUNT!=LR.QUANTITY and A.TRANSACTION_TYPE='IN' ");*/
			
			query.append(" SELECT distinct P.PART_TYPE,A.PART_NO ,'' as PROCESS_CODE,A.[LOCATION],substring(A.RAN,1,7) as RAN, ");
			query.append(" concat(P.SUPPLIER_CODE,' - ',P.SUPPLIER_NAME) as SUPPLIER,A.SNP,(LR.QUANTITY/P.SNP) as CATS_NO_OF_BOXES , ");			
			if (lrQtyMismatchDto.getPartType() != null && !lrQtyMismatchDto.getPartType().toString().trim().equalsIgnoreCase("")){
				if (lrQtyMismatchDto.getPartType().toString().trim().equalsIgnoreCase("A")){
					query.append(" LR.Container_No, ");
				}else{
					query.append(" LR.DNote_No, ");
				}
			}			
			query.append(" LR.QUANTITY,convert(varchar,LR.UPDATED_DATETIME,120) as UPDATED_DATETIME, count(A.NO_OF_BOXES) as WMS_NO_OF_BOXES, ");
			query.append(" sum(A.COUNT) as totCount,convert(varchar,PART_IN_OUT_TIME,120) as PART_IN_OUT_TIME, ");
			query.append(" ABS(count(A.NO_OF_BOXES) - (LR.QUANTITY/P.SNP) ) as NO_OF_BOX_MISMATCH,ABS(sum(A.COUNT)-LR.QUANTITY) as QUANTITY_MISMATCH,'MISMATCH' as REMARKS ");
			query.append(" from PARTINOUT_STAGING_AUDIT A inner join LIVE_RECEIPT LR on substring(A.RAN,1,7)=LR.RAN ");
			query.append(" and SUBSTRING(A.LOCATION,1,1) = SUBSTRING(LR.filename,1,1) ");
			query.append(" inner join PART P on P.PART_NO=A.PART_NO ");
			query.append(" inner join TBL_ZONE_MASTER Z on Z.PART_NO = A.PART_NO where A.TRANSACTION_TYPE='IN' ");
			
		} else if(lrQtyMismatchDto.getReceipt()!=null && lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_WMS)){
			query.append("SELECT DISTINCT P.PART_TYPE,A.PART_NO ,'' as PROCESS_CODE,A.[LOCATION],substring(A.RAN,1,7) as RAN, "
					+ "concat(P.SUPPLIER_CODE,' - ',P.SUPPLIER_NAME)  as SUPPLIER,A.SNP, ");
			query.append(" 0 as CATS_NO_OF_BOXES ,'' as DNOTE,LR.QUANTITY,convert(varchar,LR.UPDATED_DATETIME,120) as UPDATED_DATETIME, ");
			query.append(" count(A.NO_OF_BOXES) as WMS_NO_OF_BOXES,sum(COUNT) as count,convert(varchar,PART_IN_OUT_TIME,120) as PART_IN_OUT_TIME, "
					+ "0 as NO_OF_BOX_MISMATCH,0 as QUANTITY_MISMATCH,  ");
			query.append(" 'CATS NOT DONE' as REMARKS from PARTINOUT_STAGING_AUDIT A ");
			query.append(" left outer join LIVE_RECEIPT LR on substring(A.RAN,1,7)=LR.RAN inner join PART P on P.PART_NO=A.PART_NO ");
			query.append(" inner join TBL_ZONE_MASTER Z on Z.PART_NO = A.PART_NO  ");
			query.append(" where A.TRANSACTION_TYPE='IN' and A.RAN<>'*' and A.RAN<>'' and LR.RAN is null ");	
			
		}else if(lrQtyMismatchDto.getReceipt()!=null && lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_CATS)){
			query.append("Select DISTINCT P.PART_TYPE,LR.PART_NO,LR.PROCESS_CODE, PL.[LOCATION_ID],LR.RAN,concat(P.SUPPLIER_CODE,' - ',P.SUPPLIER_NAME) as SUPPLIER,P.SNP, ");
			query.append(" (LR.QUANTITY/P.SNP) as CATS_NO_OF_BOXES , ");
			if (lrQtyMismatchDto.getPartType() != null && !lrQtyMismatchDto.getPartType().toString().trim().equalsIgnoreCase("")){
				if (lrQtyMismatchDto.getPartType().toString().trim().equalsIgnoreCase("A")){
					query.append(" LR.Container_No, ");
				}else{
					query.append(" LR.DNote_No, ");
				}
			}
			query.append(" LR.QUANTITY, convert(varchar,LR.UPDATED_DATETIME,120) as UPDATED_DATETIME, ");
			query.append(" A.NO_OF_BOXES as WMS_NO_OF_BOXES,[COUNT],A.PART_IN_OUT_TIME,0 as NO_OF_BOX_MISMATCH, ");
			query.append(" 0 as QUANTITY_MISMATCH,'WH-IN NOT DONE' as REMARKS from LIVE_RECEIPT LR ");
			query.append(" left outer join PARTINOUT_STAGING_AUDIT A on LR.RAN=substring(A.RAN,1,7) left outer join PART_LOCATION PL on PL.PART_NO=LR.part_no ");
			query.append(" left outer join part p on p.PART_NO = LR.PART_NO and (P.SNP is not null and P.SNP <>'') ");
			query.append(" left outer join TBL_ZONE_MASTER Z on Z.PART_NO = LR.PART_NO where A.RAN is null ");
		}
		
		if (lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_MISMATCH)
				|| lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_WMS)) {
			if (lrQtyMismatchDto.getPlant() != null
					&& !lrQtyMismatchDto.getPlant().toString().trim().equalsIgnoreCase("")) {
				LOGGER.debug("Audit Table Search Input Rans == " + lrQtyMismatchDto.getPlant());
				query.append(" and SUBSTRING(A.LOCATION,1,1)='" + lrQtyMismatchDto.getPlant() + "'");
			}

			if (lrQtyMismatchDto.getShop() != null
					&& !lrQtyMismatchDto.getShop().toString().trim().equalsIgnoreCase("")) {
				LOGGER.debug("Audit Table Search getShop == " + lrQtyMismatchDto.getShop().charAt(0));
				if(lrQtyMismatchDto.getShop().charAt(0)!='K'){
					query.append(" and SUBSTRING(A.LOCATION,2,1)='" + lrQtyMismatchDto.getShop().trim().charAt(0) + "'");
				}else{
					query.append(" and SUBSTRING(A.LOCATION,2,1) in ('T','K') ");
				}
			}

			if (lrQtyMismatchDto.getLine() != null
					&& !lrQtyMismatchDto.getLine().toString().trim().equalsIgnoreCase("")) {
				LOGGER.debug("Audit Table Search getLine == " + lrQtyMismatchDto.getLine());
				query.append(" and SUBSTRING(A.LOCATION,3,1)='" + lrQtyMismatchDto.getLine() + "'");
			}
		}else if (lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_CATS)){
			if (lrQtyMismatchDto.getPlant() != null
					&& !lrQtyMismatchDto.getPlant().toString().trim().equalsIgnoreCase("")) {
				LOGGER.debug("Audit Table Search Input Rans == " + lrQtyMismatchDto.getPlant());
				query.append(" and SUBSTRING(LR.filename,1,1)='" + lrQtyMismatchDto.getPlant() + "'");
			}

			if (lrQtyMismatchDto.getShop() != null
					&& !lrQtyMismatchDto.getShop().toString().trim().equalsIgnoreCase("")) {
				LOGGER.debug("Audit Table Search getShop == " + lrQtyMismatchDto.getShop().charAt(0));
				if(lrQtyMismatchDto.getShop().charAt(0)!='K'){
					query.append(" and SUBSTRING(PL.LOCATION_ID,2,1)='" + lrQtyMismatchDto.getShop().trim().charAt(0) + "'");
				}else{
					query.append(" and SUBSTRING(PL.LOCATION_ID,2,1) in ('T','K') ");
				}
			}

			if (lrQtyMismatchDto.getLine() != null
					&& !lrQtyMismatchDto.getLine().toString().trim().equalsIgnoreCase("")) {
				LOGGER.debug("Audit Table Search getLine == " + lrQtyMismatchDto.getLine());
				query.append(" and SUBSTRING(PL.LOCATION_ID,3,1)='" + lrQtyMismatchDto.getLine() + "'");
			}
		}
		
		if (lrQtyMismatchDto.getPartType() != null && !lrQtyMismatchDto.getPartType().toString().trim().equalsIgnoreCase("")){
			 query.append(" and P.PART_TYPE= '"+lrQtyMismatchDto.getPartType()+"'  ");
		}
		
		if (lrQtyMismatchDto.getZone() != null
				&& !lrQtyMismatchDto.getZone().toString().trim().equalsIgnoreCase("")) {
			LOGGER.debug("Audit Table Search getZone == " + lrQtyMismatchDto.getZone());
			query.append(" and Z.Zonecode ='" + lrQtyMismatchDto.getZone() + "'");
		}
		
		if (lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_MISMATCH)) {
			if (lrQtyMismatchDto.getFromDate() != null || lrQtyMismatchDto.getToDate() != null) {
				query.append(" AND ( (convert(varchar,A.PART_IN_OUT_TIME,120) >= '" + dateFormatter.format(lrQtyMismatchDto.getFromDate()) + "'");
				query.append(" AND convert(varchar,A.PART_IN_OUT_TIME,120) <= '" + dateFormatter.format(lrQtyMismatchDto.getToDate()) + "' ) ");
				
				query.append(" OR ( convert(varchar,LR.UPDATED_DATETIME,120) >= '" + dateFormatter.format(lrQtyMismatchDto.getFromDate()) + "'");
				query.append(" AND convert(varchar,LR.UPDATED_DATETIME,120) <= '" + dateFormatter.format(lrQtyMismatchDto.getToDate()) + "' ) ) ");
			}
		}		
		
		if(lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_WMS)){
			if (lrQtyMismatchDto.getFromDate() != null || lrQtyMismatchDto.getToDate() != null) {
				/*query.append(" AND ( A.SCAN_TIME >= '" + dateFormatter.format(lrQtyMismatchDto.getFromDate()) + "'");
				query.append(" AND A.SCAN_TIME <= '" + dateFormatter.format(lrQtyMismatchDto.getToDate()) + "' ) ");*/
				query.append(" AND ( convert(varchar,A.PART_IN_OUT_TIME,120) >= '" + dateFormatter.format(lrQtyMismatchDto.getFromDate()) + "'");
				query.append(" AND convert(varchar,A.PART_IN_OUT_TIME,120) <= '" + dateFormatter.format(lrQtyMismatchDto.getToDate()) + "' ) ");
			}
		}
		
		if (lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_CATS)
				/*|| lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_ALL)*/) {
			if (lrQtyMismatchDto.getFromDate() != null || lrQtyMismatchDto.getToDate() != null) {
				query.append(" AND (convert(varchar,LR.UPDATED_DATETIME,120) >= '" + dateFormatter.format(lrQtyMismatchDto.getFromDate()) + "'");
				query.append(" AND convert(varchar,LR.UPDATED_DATETIME,120) <= '" + dateFormatter.format(lrQtyMismatchDto.getToDate()) + "' ) ");
			}
		}	
		
		if (lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_MISMATCH)){
			if(lrQtyMismatchDto.getPartType().toString().trim().equalsIgnoreCase("A")){
				if(null != lrQtyMismatchDto.getContNoList() && lrQtyMismatchDto.getContNoList().size() > 0){
					String contNoString = queryStr(lrQtyMismatchDto.getContNoList());
					LOGGER.debug("Live Receipt Search Input cont No's == "+contNoString);
					query.append(" AND LR.CONTAINER_NO IN ("); query.append(contNoString);  query.append(")");
				}	
			}else{
				if(null != lrQtyMismatchDto.getdNoteNoList() && lrQtyMismatchDto.getdNoteNoList().size() > 0){
					String dnoteNoString = queryStr(lrQtyMismatchDto.getdNoteNoList());
					LOGGER.debug("Live Receipt Search Input dNote No's == "+dnoteNoString);
					query.append(" AND LR.DNOTE_NO IN ("); query.append(dnoteNoString);  query.append(")");
				}	
			}
			if(null != lrQtyMismatchDto.getRecPlaceList() && lrQtyMismatchDto.getRecPlaceList().size() > 0){
				String recPlaceString = queryStr(lrQtyMismatchDto.getRecPlaceList());
				LOGGER.debug("Live Receipt Search Input receiving Place == "+recPlaceString);
				query.append(" AND LR.REC_PLACE IN ("); query.append(recPlaceString);  query.append(")");
			}				
		}
				
		
		if (lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_MISMATCH)
				|| lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_WMS)) {
			if (null != lrQtyMismatchDto.getPartList() && lrQtyMismatchDto.getPartList().size() > 0) {
				String partString = queryStr(lrQtyMismatchDto.getPartList());
				LOGGER.debug("Audit Table Search Input Part Numbers == " + partString);
				query.append(" AND A.PART_NO IN (");query.append(partString);query.append(")");
			}
			if(null != lrQtyMismatchDto.getRanList() && lrQtyMismatchDto.getRanList().size() > 0){
				String ranString = queryStr(lrQtyMismatchDto.getRanList());
				LOGGER.debug("Live Receipt Search Input Rans == "+ranString);
				query.append(" AND substring(A.RAN,1,7) IN ("); query.append(ranString);  query.append(")");
			}
			if(null != lrQtyMismatchDto.getSupList() && lrQtyMismatchDto.getSupList().size() > 0){
				String supString = queryStr(lrQtyMismatchDto.getSupList());
				LOGGER.debug("Live Receipt Search Input Suppliers == "+supString);
				query.append(" AND P.SUPPLIER_CODE IN ("); query.append(supString);  query.append(")");
			}		
			
			if (lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_MISMATCH)){
				if(lrQtyMismatchDto.getPartType().toString().trim().equalsIgnoreCase("A")){
					if(null != lrQtyMismatchDto.getContNoList() && lrQtyMismatchDto.getContNoList().size() > 0){
						String contNoString = queryStr(lrQtyMismatchDto.getContNoList());
						LOGGER.debug("Live Receipt Search Input cont No's == "+contNoString);
						/*query.append(" AND LR.CONTAINER_NO IN ("); query.append(contNoString);  query.append(")");*/
					}	
				}else{
					if(null != lrQtyMismatchDto.getdNoteNoList() && lrQtyMismatchDto.getdNoteNoList().size() > 0){
						String dnoteNoString = queryStr(lrQtyMismatchDto.getdNoteNoList());
						LOGGER.debug("Live Receipt Search Input dNote No's == "+dnoteNoString);
						query.append(" AND LR.DNOTE_NO IN ("); query.append(dnoteNoString);  query.append(")");
					}	
					if(null != lrQtyMismatchDto.getRecPlaceList() && lrQtyMismatchDto.getRecPlaceList().size() > 0){
						String recPlaceString = queryStr(lrQtyMismatchDto.getRecPlaceList());
						LOGGER.debug("Live Receipt Search Input receiving Place == "+recPlaceString);
						query.append(" AND substring(LR.DNOTE_NO,2,3) IN ("); query.append(recPlaceString);  query.append(")");
					}		
				}
			}
			
			query.append(" group by P.PART_TYPE,A.PART_NO,[LOCATION],substring(A.RAN,1,7),P.SUPPLIER_CODE,A.SNP,P.SNP,QUANTITY,"
					+ "convert(varchar,LR.UPDATED_DATETIME,120),convert(varchar,A.PART_IN_OUT_TIME,120),P.SUPPLIER_NAME  ");
			
			if (lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_MISMATCH)){
				query.append(" ,LR.Container_No,LR.Dnote_no ");
				query.append(" having sum(A.count)<>LR.QUANTITY ");
			}
			
			query.append(" order by A.PART_NO OFFSET ");
			
		} else if (lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_CATS)
				/*|| lrQtyMismatchDto.getReceipt().toString().trim().equalsIgnoreCase(WMSConstants.LI_RECEIPT_ALL)*/) {
			if (null != lrQtyMismatchDto.getPartList() && lrQtyMismatchDto.getPartList().size() > 0) {
			String partString = queryStr(lrQtyMismatchDto.getPartList());
			LOGGER.debug("Audit Table Search Input Part Numbers == " + partString);
			query.append(" AND LR.PART_NO IN (");query.append(partString);query.append(")");
			}
			
			if(null != lrQtyMismatchDto.getRanList() && lrQtyMismatchDto.getRanList().size() > 0){
				String ranString = queryStr(lrQtyMismatchDto.getRanList());
				LOGGER.debug("Live Receipt Search Input Rans == "+ranString);
				query.append(" AND LR.RAN IN ("); query.append(ranString);  query.append(")");
			}
			
			if(null != lrQtyMismatchDto.getSupList() && lrQtyMismatchDto.getSupList().size() > 0){
				String supString = queryStr(lrQtyMismatchDto.getSupList());
				LOGGER.debug("Live Receipt Search Input Suppliers == "+supString);
				query.append(" AND P.SUPPLIER_CODE IN ("); query.append(supString);  query.append(")");
			}
			
			if(lrQtyMismatchDto.getPartType().toString().trim().equalsIgnoreCase("A")){
				if(null != lrQtyMismatchDto.getContNoList() && lrQtyMismatchDto.getContNoList().size() > 0){
					String contNoString = queryStr(lrQtyMismatchDto.getContNoList());
					LOGGER.debug("Live Receipt Search Input cont No's == "+contNoString);
					/*query.append(" AND LR.CONTAINER_NO IN ("); query.append(contNoString);  query.append(")");*/
				}	
			}else{
				if(null != lrQtyMismatchDto.getdNoteNoList() && lrQtyMismatchDto.getdNoteNoList().size() > 0){
					String dnoteNoString = queryStr(lrQtyMismatchDto.getdNoteNoList());
					LOGGER.debug("Live Receipt Search Input dNote No's == "+dnoteNoString);
					query.append(" AND LR.DNOTE_NO IN ("); query.append(dnoteNoString);  query.append(")");
				}	
				if(null != lrQtyMismatchDto.getRecPlaceList() && lrQtyMismatchDto.getRecPlaceList().size() > 0){
					String recPlaceString = queryStr(lrQtyMismatchDto.getRecPlaceList());
					LOGGER.debug("Live Receipt Search Input receiving Place == "+recPlaceString);
					query.append(" AND substring(LR.DNOTE_NO,2,3) IN ("); query.append(recPlaceString);  query.append(")");
				}		
			}
			
			query.append(" order by LR.PART_NO OFFSET ");
		}
		
		if(lrQtyMismatchDto!=null && lrQtyMismatchDto.getIsFullDownload()==1){
			startIndex=0;
			/*StringBuffer queryStringBufDwld = new StringBuffer();			
			queryStringBufDwld.append(getListCount(lrQtyMismatchDto));
			Query query1 = entityManager.createNativeQuery(queryStringBufDwld.toString());*/
			
			endIndex = getLiveReceiptQtyMismatchListCount(lrQtyMismatchDto);
		}
		
		query.append(  startIndex );
		query.append(" ROWS FETCH NEXT "); 
		query.append( endIndex );
		query.append(" ROWS only ");
		
		LOGGER.debug("Query Generated for Quantity Mismatch Count : "+query.toString());
		return query.toString();
	}
	
	
/*	private String getQuery1(LiveReceiptQtyMismatchDTO lrQtyMismatchDto) {
		StringBuffer query = new StringBuffer();
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		query.append("SELECT LIVERECEIPT_TABLE.RAN AS LR_RAN,AUDIT_TABLE.PLANT, LIVERECEIPT_TABLE.PART_NO AS LR_PART_NO, LIVERECEIPT_TABLE.QUANTITY AS LR_QUANTITY, LIVERECEIPT_TABLE.UPDATED_DATETIME AS LR_UPDATED_DATETIME, ");
		query.append(" AUDIT_TABLE.PART_PK AS AUDIT_PART_PK, AUDIT_TABLE.RAN AS AUDIT_RAN, AUDIT_TABLE.PART_NO AS AUDIT_PART_NO, AUDIT_TABLE.COUNT AS AUDIT_QUANTITY, AUDIT_TABLE.SCAN_TIME AS AUDIT_SCAN_TIME FROM");
		query.append(" (SELECT PART_PK,PART_NO,LOCATION,[COUNT],RAN,SCAN_TIME ,Concat(PL.PLANT_ID ").append(",");
		query.append("'").append("-").append("'").append(",").append("PLANT_NAME) as PLANT ");
		query.append("FROM DBO.PARTINOUT_STAGING_AUDIT P INNER JOIN [dbo].[LOCATION] L on P.LOCATION=L.LOCATION_ID INNER JOIN [DBO].[PLANT] PL ON L.PLANT=PL.PLANT_ID WHERE PART_PK IN");
		query.append(" (SELECT MIN(PART_PK)  MINPART_PK FROM DBO.PARTINOUT_STAGING_AUDIT PT WHERE TRANSACTION_TYPE='IN' ");
		
		if(lrQtyMismatchDto.getPlant()!=null) {
			
			LOGGER.debug("Audit Table Search Input Rans == "+lrQtyMismatchDto.getPlant());
			query.append("and PL.PLANT_ID='"+lrQtyMismatchDto.getPlant()+"'");
			
		}
		
		if(null != lrQtyMismatchDto.getRanList() && lrQtyMismatchDto.getRanList().size() > 0){
			String ranString = queryStr(lrQtyMismatchDto.getRanList());
			LOGGER.debug("Audit Table Search Input Rans == "+ranString);
			query.append(" AND RAN IN ("); query.append(ranString);  query.append(")");
		}
		
		if(null != lrQtyMismatchDto.getPartList() && lrQtyMismatchDto.getPartList().size() > 0){
			String partString = queryStr(lrQtyMismatchDto.getPartList());
			LOGGER.debug("Audit Table Search Input Part Numbers == "+partString);
			query.append(" AND PART_NO IN ("); query.append(partString);  query.append(")");
		}
		
		if (lrQtyMismatchDto.getAuditFromDate() != null	|| lrQtyMismatchDto.getAuditToDate() != null) {
			
			Map<String,Date> shiftTimes  = WMSBeanUtil.getShiftTime("",lrQtyMismatchDto.getAuditFromDate(),lrQtyMismatchDto.getAuditToDate());
			
			lrQtyMismatchDto.setAuditFromDate(shiftTimes.get("fromDate"));
			lrQtyMismatchDto.setAuditToDate(shiftTimes.get("toDate"));
			
			LOGGER.debug("Audit From Date -> "+ dateFormatter.format(lrQtyMismatchDto.getAuditFromDate()));
			LOGGER.debug("Audit To Date -> "+ dateFormatter.format(lrQtyMismatchDto.getAuditToDate()));
			
			query.append(" AND SCAN_TIME >= '"+ dateFormatter.format(lrQtyMismatchDto.getAuditFromDate()) + "'");
			query.append(" AND SCAN_TIME < '"+ dateFormatter.format(lrQtyMismatchDto.getAuditToDate()) + "'");
		}
		query.append(" GROUP BY RAN)");
		query.append(") AUDIT_TABLE,");
		query.append("(SELECT L.SEQ_NO,L.RAN,L.PART_NO,L.QUANTITY,L.UPDATED_DATETIME ,Substring(L.filename,1,1) as Plant FROM DBO.LIVE_RECEIPT L WHERE L.SEQ_NO IN ");
		query.append(" (SELECT MAX(SEQ_NO) MAXSEQ FROM DBO.LIVE_RECEIPT WHERE 1=1 ");
		
		
		if(lrQtyMismatchDto.getPlant()!=null) {
			
			
			LOGGER.debug("Live Receipt Search Input =="+lrQtyMismatchDto.getPlant());
			
			query.append(" and substring(filename,1,1)='"+lrQtyMismatchDto.getPlant()+"' ");
		}
		
		if(null != lrQtyMismatchDto.getRanList() && lrQtyMismatchDto.getRanList().size() > 0){
			String ranString = queryStr(lrQtyMismatchDto.getRanList());
			LOGGER.debug("Live Receipt Search Input Rans == "+ranString);
			query.append(" AND RAN IN ("); query.append(ranString);  query.append(")");
		}
		
		if(null != lrQtyMismatchDto.getPartList() && lrQtyMismatchDto.getPartList().size() > 0){
			String partString = queryStr(lrQtyMismatchDto.getPartList());
			LOGGER.debug("Live Receipt Search Input Part Numbers == "+partString);
			query.append(" AND PART_NO IN ("); query.append(partString);  query.append(")");
		}
		
		if (lrQtyMismatchDto.getFromDate() != null	|| lrQtyMismatchDto.getToDate() != null) {
			
			Map<String,Date> shiftTimes  = WMSBeanUtil.getShiftTime("",lrQtyMismatchDto.getFromDate(),lrQtyMismatchDto.getToDate());
			
			lrQtyMismatchDto.setFromDate(shiftTimes.get("fromDate"));
			lrQtyMismatchDto.setToDate(shiftTimes.get("toDate"));
			
			LOGGER.debug("Live Receipt From Date -> "+ dateFormatter.format(lrQtyMismatchDto.getFromDate()));
			LOGGER.debug("Live Receipt To Date -> "+ dateFormatter.format(lrQtyMismatchDto.getToDate()));
			
			query.append(" AND UPDATED_DATETIME >= '"+ dateFormatter.format(lrQtyMismatchDto.getFromDate()) + "'");
			query.append(" AND UPDATED_DATETIME < '"+ dateFormatter.format(lrQtyMismatchDto.getToDate()) + "'");
		}
		query.append(" GROUP BY RAN)");
		query.append(")LIVERECEIPT_TABLE");
		query.append(" WHERE AUDIT_TABLE.RAN=LIVERECEIPT_TABLE.RAN ");
		query.append(" AND LIVERECEIPT_TABLE.QUANTITY!=AUDIT_TABLE.COUNT");
		query.append(" and Substring(AUDIT_TABLE.PLANT,1,1)=LIVERECEIPT_TABLE.Plant");
		
		LOGGER.debug("Query Generated for Quantity Mismatch Count : "+query.toString());
		return query.toString();
	}*/
	
/*	private String getQuery1(LiveReceiptQtyMismatchDTO lrQtyMismatchDto) {
		StringBuffer query = new StringBuffer();
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		query.append("select A.PART_TYPE,A.PART_NO AS AUDIT_PART_NO,'' as PROCESSCODE,A.LOCATION,A.RAN AS AUDIT_RAN, '' as SUPPLIER,A.SNP,0 as NO_OF_BOXES_CATS, ");
		query.append(" (CASE When A.PART_TYPE='"+lrQtyMismatchDto.getPartType()+"' then '' else LI.DNOTE_NO end) as CONDOTE,LI.QUANTITY as DNOTEQTY, LI.UPDATED_DATETIME, ");
		query.append(" A.NO_OF_BOXES,A.COUNT AS AUDIT_QUANTITY, A.SCAN_TIME AS AUDIT_SCAN_TIME,  0 as BOXMISMATCH, (A.COUNT - LI.QUANTITY) as QTYMISMATCH, ");
		query.append(" (CASE when A.COUNT!=LI.QUANTITY then 'Mismatch' else '' end) as REMARKS FROM ");
		query.append(" (SELECT PART_PK,P.PART_NO,LOCATION,[COUNT],RAN,SCAN_TIME ,Concat(PL.PLANT_ID ,'-',PLANT_NAME) as PLANT ,P.SNP,NO_OF_BOXES,PA.PART_TYPE ");
		query.append(" FROM DBO.PARTINOUT_STAGING_AUDIT P INNER JOIN [dbo].[LOCATION] L on P.LOCATION=L.LOCATION_ID ");
		query.append(" INNER JOIN [dbo].[PART] PA on P.PART_NO=PA.PART_NO ");
		query.append(" INNER JOIN [DBO].[PLANT] PL ON L.PLANT=PL.PLANT_ID WHERE PART_PK IN ");
		query.append(" (SELECT MIN(PART_PK)  MINPART_PK FROM DBO.PARTINOUT_STAGING_AUDIT PT WHERE TRANSACTION_TYPE='IN' ");
		
        if(lrQtyMismatchDto.getPlant()!=null && !lrQtyMismatchDto.getPlant().toString().trim().equalsIgnoreCase("")) {
			LOGGER.debug("Audit Table Search Input Rans == "+lrQtyMismatchDto.getPlant());
			query.append(" and PL.PLANT_ID='"+lrQtyMismatchDto.getPlant()+"'");
		}
        
        if(lrQtyMismatchDto.getShop()!=null && !lrQtyMismatchDto.getShop().toString().trim().equalsIgnoreCase("")) {
			LOGGER.debug("Audit Table Search getShop == "+lrQtyMismatchDto.getShop().charAt(0));
			query.append(" and SUBSTRING(LOCATION,2,1)='"+lrQtyMismatchDto.getShop().trim().charAt(0)+"'");
		}
        
        if(lrQtyMismatchDto.getLine()!=null && !lrQtyMismatchDto.getLine().toString().trim().equalsIgnoreCase("")) {
			LOGGER.debug("Audit Table Search getLine == "+lrQtyMismatchDto.getLine());
			query.append(" and SUBSTRING(LOCATION,3,1)='"+lrQtyMismatchDto.getLine()+"'");
		}
        
        if(null != lrQtyMismatchDto.getRanList() && lrQtyMismatchDto.getRanList().size() > 0){
			String ranString = queryStr(lrQtyMismatchDto.getRanList());
			LOGGER.debug("Audit Table Search Input Rans == "+ranString);
			query.append(" AND RAN IN ("); query.append(ranString);  query.append(")");
		}
		
       if (lrQtyMismatchDto.getFromDate() != null	|| lrQtyMismatchDto.getToDate() != null) {
			Map<String,Date> shiftTimes  = WMSBeanUtil.getShiftTime("",lrQtyMismatchDto.getFromDate(),lrQtyMismatchDto.getToDate());
			lrQtyMismatchDto.setFromDate(shiftTimes.get("fromDate"));
			lrQtyMismatchDto.setToDate(shiftTimes.get("toDate"));			
			LOGGER.debug("Audit From Date -> "+ dateFormatter.format(lrQtyMismatchDto.getFromDate()));
			LOGGER.debug("Audit To Date -> "+ dateFormatter.format(lrQtyMismatchDto.getToDate()));			
			query.append(" AND PT.SCAN_TIME >= '"+ dateFormatter.format(lrQtyMismatchDto.getFromDate()) + "'");
			query.append(" AND PT.SCAN_TIME < '"+ dateFormatter.format(lrQtyMismatchDto.getToDate()) + "'");
		}
		query.append(" GROUP BY RAN)) A, ");
		query.append(" (SELECT L.SEQ_NO,L.RAN,L.PART_NO,L.DNOTE_NO,L.QUANTITY,L.UPDATED_DATETIME ,Substring(L.filename,1,1) as Plant FROM DBO.LIVE_RECEIPT L ");
		query.append(" WHERE L.SEQ_NO IN (SELECT MAX(SEQ_NO) MAXSEQ FROM DBO.LIVE_RECEIPT WHERE 1=1");
		
        if(lrQtyMismatchDto.getPlant()!=null) {
			LOGGER.debug("Live Receipt Search Input =="+lrQtyMismatchDto.getPlant());
			query.append(" and substring(filename,1,1)='"+lrQtyMismatchDto.getPlant()+"' ");
		}
		
		if(null != lrQtyMismatchDto.getRanList() && lrQtyMismatchDto.getRanList().size() > 0){
			String ranString = queryStr(lrQtyMismatchDto.getRanList());
			LOGGER.debug("Live Receipt Search Input Rans == "+ranString);
			query.append(" AND RAN IN ("); query.append(ranString);  query.append(")");
		}
		
		if(null != lrQtyMismatchDto.getPartList() && lrQtyMismatchDto.getPartList().size() > 0){
			String partString = queryStr(lrQtyMismatchDto.getPartList());
			LOGGER.debug("Live Receipt Search Input Part Numbers == "+partString);
			query.append(" AND PART_NO IN ("); query.append(partString);  query.append(")");
		}
		
		if (lrQtyMismatchDto.getFromDate() != null	|| lrQtyMismatchDto.getToDate() != null) {
			Map<String,Date> shiftTimes  = WMSBeanUtil.getShiftTime("",lrQtyMismatchDto.getFromDate(),lrQtyMismatchDto.getToDate());
			lrQtyMismatchDto.setFromDate(shiftTimes.get("fromDate"));
			lrQtyMismatchDto.setToDate(shiftTimes.get("toDate"));
			LOGGER.debug("Live Receipt From Date -> "+ dateFormatter.format(lrQtyMismatchDto.getFromDate()));
			LOGGER.debug("Live Receipt To Date -> "+ dateFormatter.format(lrQtyMismatchDto.getToDate()));
			query.append(" AND UPDATED_DATETIME >= '"+ dateFormatter.format(lrQtyMismatchDto.getFromDate()) + "'");
			query.append(" AND UPDATED_DATETIME < '"+ dateFormatter.format(lrQtyMismatchDto.getToDate()) + "'");
		}
		query.append(" GROUP BY RAN)) LI ");
		query.append(" WHERE A.RAN=LI.RAN  AND LI.QUANTITY!=A.COUNT and Substring(A.PLANT,1,1)=LI.Plant ");
		
		if (lrQtyMismatchDto.getPartType() != null){
			 query.append(" and A.PART_TYPE= '"+lrQtyMismatchDto.getPartType()+"'  ");
		}
		
		if(null != lrQtyMismatchDto.getPartList() && lrQtyMismatchDto.getPartList().size() > 0){
			String partString = queryStr(lrQtyMismatchDto.getPartList());
			LOGGER.debug("Audit Table Search Input Part Numbers == "+partString);
			query.append(" AND PART_NO IN ("); query.append(partString);  query.append(")");
		}
		
		LOGGER.debug("Query Generated for Quantity Mismatch Count : "+query.toString());
		return query.toString();
	}*/
	
	
	private String queryStr(List<String> queryStr){
		String result = "";
		for(String str : queryStr){
			result = result + "'"+str+"',";
		}
		result = result.substring(0, result.length()-1);
		return result;
	}
	
	
	public Set<PartDTO> getRanList(String inputRan) {
		LOGGER.debug("*****IN Get RAN List : " + inputRan);
		Set<PartDTO> ranSet = new HashSet<PartDTO>();
		StringBuffer queryBuf = new StringBuffer();
		queryBuf.append("select distinct RAN from ");
		queryBuf.append(
				" (select distinct substring(A.RAN,1,7) as RAN from PARTINOUT_STAGING_AUDIT A where A.TRANSACTION_TYPE='IN' and A.RAN is not null and A.RAN<>'*' ");
		queryBuf.append(" UNION ");
		queryBuf.append(" select distinct LR.RAN from LIVE_RECEIPT LR where LR.RAN is not null and LR.RAN<>'*') P ");
		queryBuf.append(" where P.RAN LIKE '" + inputRan + "%' order by P.RAN asc ");

		LOGGER.debug("Query for getRanList : " + queryBuf);
		Query query = entityManager.createNativeQuery(queryBuf.toString());
		query.setMaxResults(10);
		List<String> ranList = query.getResultList();
		LOGGER.debug("*****IN Get RAN List result :" + ranList.size());
		for (String ran : ranList) {
			PartDTO ranDTO = new PartDTO();
			ranDTO.setText(ran);
			ranSet.add(ranDTO);
		}
		return ranSet;
	}
	
	private String getString(Object object) {
		return checkNull(object) ? (String) object : "";
	}
	
	private boolean checkNull(Object object) {
		return object != null;
	}
	
	/**
	 * method to fetch all the Zone-codes
	 */
	@SuppressWarnings("unchecked")
	public List<ZoneDTO> getZoneCodeList() {
		LOGGER.debug("*****IN Get All zones from bean ");
		List<ZoneDTO> zoneDTOList = new ArrayList<ZoneDTO>();
		Query query = entityManager.createNativeQuery("select distinct(ZoneCode) from [TBL_Zone_Master] order by zonecode asc ");
		List<Object> objectsArrayList = query.getResultList();
		if (objectsArrayList != null && objectsArrayList.size() > 0) {
			for (Object objectsArray : objectsArrayList) {
				ZoneDTO zoneDTO = new ZoneDTO();
				zoneDTO.setZoneId(getString(objectsArray));
				zoneDTOList.add(zoneDTO);
			}
		}
		return zoneDTOList;
	}
	
	/**
	 * method to fetch all the supplier-codes
	 */
	public Set<PartNumberDTO> getSupCodeList(String supCode) {
		// TODO Auto-generated method stub
		LOGGER.debug("*****IN Get All suppliers from bean ");
		Set<PartNumberDTO> supCodeList = new HashSet<PartNumberDTO>();
		Query query = null;		
		query = entityManager.createNativeQuery(
				"select distinct supplier_code from Part where supplier_code is not null and supplier_code<>'' "
						+ "and supplier_code LIKE :val order by supplier_code asc");
		query.setParameter("val", "%" + supCode + "%");
		query.setMaxResults(10);
		List<String> supList = query.getResultList();
		for (String suppCode : supList) {
			PartNumberDTO supCodeDTO = new PartNumberDTO();
			supCodeDTO.setText(suppCode);
			supCodeList.add(supCodeDTO);
		}
		return supCodeList;
	}
	
	/**
	 * method to fetch all the supplier-codes
	 */
	public Set<PartNumberDTO> getLiveReceiptForAutoComplete(String input,LiveReceiptQtyMismatchDTO lrQtyMismatchDto) {
		// TODO Auto-generated method stub
		LOGGER.debug("*****IN Get getLiveReceiptForAutoComplete from bean ");
		Set<PartNumberDTO> liveReceiptList = new HashSet<PartNumberDTO>();
		Query query = null;	
		LOGGER.debug("lrQtyMismatchDto.getPartType() in bean : " +lrQtyMismatchDto.getPartType() );
		LOGGER.debug("input value in bean : " +input );
		if(lrQtyMismatchDto.getColName().trim().equalsIgnoreCase(WMSConstants.REC_PLACE)){
			query = entityManager.createNativeQuery(
					"select distinct substring(DNOTE_NO,2,3) as Rec_Place from Live_Receipt where DNOTE_NO is not null and DNOTE_NO <>'' "
							+ "and substring(DNOTE_NO,2,3) LIKE :val order by Rec_Place asc");
		}else{
			query = entityManager.createNativeQuery(
					"select distinct "+lrQtyMismatchDto.getColName()+" from Live_Receipt where "+lrQtyMismatchDto.getColName()+" is not null and "+lrQtyMismatchDto.getColName()+" <>'' "
							+ "and "+lrQtyMismatchDto.getColName()+" LIKE :val order by "+lrQtyMismatchDto.getColName()+" asc");
		}		
		query.setParameter("val", "%" + input + "%");
		query.setMaxResults(10);
		List<String> liveList = query.getResultList();
		for (String suppCode : liveList) {
			PartNumberDTO liveReceiptDTO = new PartNumberDTO();
			liveReceiptDTO.setText(suppCode);
			liveReceiptList.add(liveReceiptDTO);
		}
		return liveReceiptList;
	}
	
}
/*AJ00482484 : LIVE Receipt Change : END*/
