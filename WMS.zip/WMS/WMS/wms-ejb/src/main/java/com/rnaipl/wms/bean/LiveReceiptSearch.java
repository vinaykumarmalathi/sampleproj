package com.rnaipl.wms.bean;

import java.util.List;
import java.util.Set;

import com.rnaipl.wms.dto.LiveReceiptInputDTO;
import com.rnaipl.wms.dto.LiveReceiptQtyMismatchDTO;
import com.rnaipl.wms.dto.LiveReceiptsSearchDTO;
import com.rnaipl.wms.dto.PartDTO;
import com.rnaipl.wms.dto.PartNumberDTO;
import com.rnaipl.wms.dto.ZoneDTO;
/*AJ00482484 : LIVE Receipt Change : START*/
public interface LiveReceiptSearch {
	public List<LiveReceiptsSearchDTO> getAllLiveReceipts() throws Exception;
	public List<LiveReceiptsSearchDTO> getLiveReceiptsByRAN(LiveReceiptInputDTO inputDto) throws Exception;
	public List<LiveReceiptQtyMismatchDTO> getLiveReceiptQtyMismatchSearch(LiveReceiptQtyMismatchDTO lrQtyMismatchDto)throws Exception;
	public int getLiveReceiptQtyMismatchListCount(LiveReceiptQtyMismatchDTO lrQtyMismatchDto)throws Exception ;
	public Set<PartDTO> getRanList(String inputRan) throws Exception;
	public Set<PartNumberDTO> getSupCodeList(String supCode) throws Exception;
	public Set<PartNumberDTO> getLiveReceiptForAutoComplete(String input,LiveReceiptQtyMismatchDTO lrQtyMismatchDto) throws Exception;
	public List<ZoneDTO> getZoneCodeList() throws Exception;

}
/*AJ00482484 : LIVE Receipt Change : END*/