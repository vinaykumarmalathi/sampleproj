package com.rnaipl.wms.bean;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.PickingListDTO;
import com.rnaipl.wms.util.ApplicationUtility;
import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSConstants;

@Stateless
@LocalBean
public class PickingListBean implements PickingInOutStaging {

	
	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	 private EntityManager entityManager;
	
	private static final Logger LOGGER = Logger.getLogger(PickingListBean.class);
	
	public int insertPickingListToStagingTable(PickingListDTO pickingListDTO) {
			LOGGER.debug("picking list size"+pickingListDTO);
		
			
					for(int i=0; i<pickingListDTO.getPickingLineDetailsDTO().size();i++) {
						com.rnaipl.wms.entities.PickingList pickingList = new com.rnaipl.wms.entities.PickingList();
						pickingList.setPickListID(pickingListDTO.getPickingLineDetailsDTO().get(i).getPickListId());
						pickingList.setTotalNumberOfBoxes(pickingListDTO.getPickingLineDetailsDTO().get(i).getTotalNumberOfBoxes());
						pickingList.setTotalNumberOfQuantity(pickingListDTO.getPickingLineDetailsDTO().get(i).getTotalNumberOfQuantity());
						pickingList.setShopName(pickingListDTO.getPickingLineDetailsDTO().get(i).getShopName());
						pickingList.setZone(pickingListDTO.getPickingLineDetailsDTO().get(i).getZone());
						pickingList.setDeviceID(pickingListDTO.getPickingLineDetailsDTO().get(i).getDeviceID());
						pickingList.setPartNumber(pickingListDTO.getPickingLineDetailsDTO().get(i).getPartNumber());
						pickingList.setNumberOfBoxes(pickingListDTO.getPickingLineDetailsDTO().get(i).getNumberOfBoxes());
						pickingList.setSnp(pickingListDTO.getPickingLineDetailsDTO().get(i).getSnp());
						pickingList.setTotalQuantity(pickingListDTO.getPickingLineDetailsDTO().get(i).getTotalQuantity());
						pickingList.setScanTime(ApplicationUtility.convertStringToSqlTimeStamp(pickingListDTO.getPickingLineDetailsDTO().get(i).getScanTime(), WMSConstants.TIMESTAMP_FORMAT));
						pickingList.setDetailDeviceTranID(pickingListDTO.getPickingLineDetailsDTO().get(i).getDetailDeviceTranId());
						
						LOGGER.debug("* Pick List ID :" + pickingListDTO.getPickingLineDetailsDTO().get(i).getPickListId());
						LOGGER.debug("* Total Number of Boxes :" + pickingListDTO.getPickingLineDetailsDTO().get(i).getTotalNumberOfBoxes());
						LOGGER.debug("* Total Number Of Quantity " + pickingListDTO.getPickingLineDetailsDTO().get(i).getTotalNumberOfQuantity());
						LOGGER.debug("* Shop Name" + pickingListDTO.getPickingLineDetailsDTO().get(i).getShopName());				
						LOGGER.debug("* Zone " + pickingListDTO.getPickingLineDetailsDTO().get(i).getZone());
						LOGGER.debug("* Device ID" + pickingListDTO.getPickingLineDetailsDTO().get(i).getDeviceID());
						LOGGER.debug("* Part Number" + pickingListDTO.getPickingLineDetailsDTO().get(i).getPartNumber());
						LOGGER.debug("* Total Number Of Boxes " + pickingListDTO.getPickingLineDetailsDTO().get(i).getTotalNumberOfBoxes());
						LOGGER.debug("* SNP" + pickingListDTO.getPickingLineDetailsDTO().get(i).getSnp());	
						LOGGER.debug("* Total Quantity " + pickingListDTO.getPickingLineDetailsDTO().get(i).getTotalQuantity());
						LOGGER.debug("* Scan Time" + pickingListDTO.getPickingLineDetailsDTO().get(i).getScanTime());
						LOGGER.debug("* Detail Device Tran ID" + pickingListDTO.getPickingLineDetailsDTO().get(i).getDetailDeviceTranId());
						
						entityManager.persist(pickingList);
						
				}
			
		 return 1;
	}

}
