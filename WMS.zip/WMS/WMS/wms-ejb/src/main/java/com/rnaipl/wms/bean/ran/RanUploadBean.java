package com.rnaipl.wms.bean.ran;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.ran.RANSuggestionDTO;
import com.rnaipl.wms.dto.ran.RanUploadDTO;
import com.rnaipl.wms.dto.ran.RanUploadErrorDTO;
import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSBeanUtil;
import com.rnaipl.wms.util.WMSConstants;

@Stateless
@LocalBean
public class RanUploadBean implements RanUpload{
	private static final Logger LOGGER = Logger
			.getLogger(RanUploadBean.class);

	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;
	public List<RanUploadDTO> getRanUploadData(){
		List<RanUploadDTO> ranUploadDTOList = new ArrayList<RanUploadDTO>();
		StringBuffer queryStringBuf = new StringBuffer();
		queryStringBuf.append("  SELECT R.RUN_ID,case when R.PLANT = 'G' THEN 'PV' else 'PT' end,R.START_TIME,R.END_TIME,R.STATUS,R.PROCEDURE_ERROR,R.PROCEDURE_ERROR_MSG,R.TOTAL_RECORDS_UPLOADED,RAN_ERROR_COUNT.ERROR_COUNT FROM DBO.RAN_UPLOAD_BATCH_DETAILS R ");  
		queryStringBuf.append("LEFT JOIN (SELECT RUN_ID,COUNT(RUN_ID) AS ERROR_COUNT FROM DBO.RAN_UPLOAD_ERROR GROUP BY RUN_ID) RAN_ERROR_COUNT ON R.RUN_ID=RAN_ERROR_COUNT.RUN_ID ");
		queryStringBuf.append("ORDER BY R.RUN_ID DESC ");
		LOGGER.debug("RAN Upload Query" +queryStringBuf.toString());
		Query query = entityManager.createNativeQuery(queryStringBuf.toString());
		
		 List<Object[]> queryDatas = query.getResultList();
			LOGGER.debug("RAN Upload Data size " + queryDatas.size());

			if (null != queryDatas && queryDatas.size() > 0) {
				 for (Iterator<Object[]> i = queryDatas.iterator(); i.hasNext();) {
		            	int indexCount=0;
		                Object[] values = (Object[]) i.next();
		                RanUploadDTO ranUploadDTO = new RanUploadDTO();
		                ranUploadDTO.setRunId((Integer) (null == values[indexCount] ? 0 : values[indexCount]));	      
		                indexCount++;	
		                ranUploadDTO.setPlant(null == values[indexCount] ? "" : values[indexCount].toString());
		                indexCount++;
		                if(null != values[indexCount]){
		                	ranUploadDTO.setStartTime((Date)values[indexCount]);
		                }		               
		                indexCount++;		                
		                if(null != values[indexCount]){
		                	 ranUploadDTO.setEndTime((Date)values[indexCount]);
		                }
		                indexCount++;
		                if(null != values[indexCount]){
		                	 ranUploadDTO.setStatus((Integer)values[indexCount]);
		                }
		                indexCount++;
		                ranUploadDTO.setProcedureError(null == values[indexCount] ? "No" : "Yes");
		                indexCount++;
		                ranUploadDTO.setProcedureErrorMsg(null == values[indexCount] ? "" : values[indexCount].toString());
		                indexCount++;
		                ranUploadDTO.setTotalNoOfRecordUploaded((Integer) (null == values[indexCount] ? 0 : values[indexCount]));
		                indexCount++;
		                ranUploadDTO.setError((Integer) (null == values[indexCount] ? 0 : values[indexCount]));
		                indexCount++;
		                ranUploadDTOList.add(ranUploadDTO);
				 }
			}
			
		return ranUploadDTOList;
		
	}
	
	public List<Integer> isRanUploadInProgress() {
		Query query = entityManager.createQuery("select rd.status from RanUploadBatchDetails rd where rd.status = 0");
		List<Integer> queryDatas = query.getResultList();
		LOGGER.debug("RAN Upload getRanUploadStatus--->" +queryDatas);
		return queryDatas;  
		
	}
	
	public void triggerJob(String fileName){
		StringBuffer queryStrBfr = new StringBuffer();
		LOGGER.debug("**Before triggering RAN_UPLOAD batch job");
		queryStrBfr.append("EXEC msdb.dbo.sp_start_job RAN_UPLOAD");
        Query query = entityManager.createNativeQuery(queryStrBfr.toString());
      //  query.setParameter(1, fileName);
        query.executeUpdate();
        entityManager.flush();
        LOGGER.debug("**After triggering RAN_UPLOAD batch job");
	}
	
	public List<RanUploadErrorDTO> getRanDownloadDetails(int runId){
		List<RanUploadErrorDTO> ranUploadErrorDTOList = new ArrayList<RanUploadErrorDTO>();
		StringBuffer queryStringBuf = new StringBuffer();
		queryStringBuf.append(" SELECT R.RAN,R.PART_NO,R.MFG_DATE,R.ERROR_REASON FROM RAN_UPLOAD_ERROR R ");
		queryStringBuf.append("WHERE R.RUN_ID = "+runId );
		LOGGER.debug("RAN Upload Error" +queryStringBuf.toString());
		Query query = entityManager.createNativeQuery(queryStringBuf.toString() );
		List<Object[]> queryDatas = query.getResultList();
		if (null != queryDatas && queryDatas.size() > 0) {
			 for (Iterator<Object[]> i = queryDatas.iterator(); i.hasNext();) {
	            	int indexCount=0;
	                Object[] values = (Object[]) i.next();
	                RanUploadErrorDTO ranUploadErrorDTO = new RanUploadErrorDTO();	                
	                ranUploadErrorDTO.setRan((null == values[indexCount] ? "" : values[indexCount]).toString());
	                indexCount++;
	                ranUploadErrorDTO.setPartNumber((null == values[indexCount] ? "" : values[indexCount]).toString());
	                indexCount++;
	                ranUploadErrorDTO.setMfgDate((null == values[indexCount] ? "" : values[indexCount].toString()));
	                indexCount++;
	                ranUploadErrorDTO.setErrorReason((null == values[indexCount] ? "" : WMSBeanUtil.getErrorReason(values[indexCount].toString())));
	                indexCount++;
	                ranUploadErrorDTOList.add(ranUploadErrorDTO);
			 }
		}
		
		return  ranUploadErrorDTOList;
			
	}
	
	public String getUploadDestinationPath(){
		String uploadDestinationPath="";
		try {
			Query query = entityManager
					.createNativeQuery("SELECT VALUE FROM COMMON_PARAMETER WHERE ID = '1'");
			uploadDestinationPath = (String) query.getSingleResult();
			if (uploadDestinationPath.equals("null") || uploadDestinationPath==null || uploadDestinationPath.equals("")) {
				uploadDestinationPath = WMSConstants.UPLOAD_RAN_DESTINATION_PATH;
			}
			LOGGER.debug("Upload Destination Path" + uploadDestinationPath);
		} catch (Exception e) {
			// TODO: handle exception
			uploadDestinationPath=WMSConstants.UPLOAD_RAN_DESTINATION_PATH;
			LOGGER.error("RanUploadBean---> getUploadDestinationPath",e);
		}
		return uploadDestinationPath;
		
	}
	
	public String getParamUploadDestinationPath(String parameter){
		String uploadDestinationPath="";
		try {
			Query query = entityManager
					.createNativeQuery("SELECT VALUE FROM COMMON_PARAMETER WHERE NAME = '"+parameter+"'");
			uploadDestinationPath = (String) query.getSingleResult();
			LOGGER.debug("Upload Destination Path by Query : " + uploadDestinationPath);
			if (uploadDestinationPath.equals("null") || uploadDestinationPath==null || uploadDestinationPath.equals("")) {
				if(parameter.toUpperCase().trim() =="PV") {
					uploadDestinationPath = WMSConstants.UPLOAD_RAN_DESTINATION_PATH_PV;
				} else {
					uploadDestinationPath = WMSConstants.UPLOAD_RAN_DESTINATION_PATH_PT;
				}
				
			}
			LOGGER.debug("Upload Destination Path : " + uploadDestinationPath);
		} catch (Exception e) {
			// TODO: handle exception
			uploadDestinationPath=WMSConstants.UPLOAD_RAN_DESTINATION_PATH;
			LOGGER.error("RanUploadBean---> getUploadDestinationPath",e);
		}
		return uploadDestinationPath;
		
	}
	

}
