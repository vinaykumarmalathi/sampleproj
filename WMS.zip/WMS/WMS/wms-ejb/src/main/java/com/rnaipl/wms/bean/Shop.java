package com.rnaipl.wms.bean;

import java.util.List;

import com.rnaipl.wms.dto.ShopDTO;

/**
 * 
 * @author TechM
 *
 */
public interface Shop {
	
	/**
	 *  Retrives all the Shop details from the database
	 *  @return - list of ShopDTO object
	 */
	public List<ShopDTO> getShopByPlantId(String plant);
	public List<ShopDTO> getAllShops();
}
