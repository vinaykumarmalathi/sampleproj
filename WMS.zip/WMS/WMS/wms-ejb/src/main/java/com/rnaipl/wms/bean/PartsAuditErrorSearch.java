package com.rnaipl.wms.bean;

import java.util.List;

import com.rnaipl.wms.dto.PartsInOutAuditErrorDTO;
import com.rnaipl.wms.dto.PartsInOutAuditSearchDTO;

public interface PartsAuditErrorSearch {
	
		
	public List<PartsInOutAuditErrorDTO> getPartsAuditErrorSearch(PartsInOutAuditErrorDTO PartsInOutAuditErrorDTO);
	
	public int getPartInOutAuditErrorSearchCount(PartsInOutAuditErrorDTO PartsInOutAuditErrorDTO);

}
