package com.rnaipl.wms.bean.ran;

import java.util.List;
import java.util.Set;

import com.rnaipl.wms.dto.LineDTO;
import com.rnaipl.wms.dto.PlantDTO;
import com.rnaipl.wms.dto.ran.AgedAgingRanDTO;
import com.rnaipl.wms.dto.ran.AgedAgingRanInputDTO;
import com.rnaipl.wms.dto.ran.RANSuggestionDTO;
import com.rnaipl.wms.dto.ran.RANPickDateDTO;

/**
 * 
 * @author TechM
 *
 */
public interface AgedRAN {
	
	
	public List<AgedAgingRanDTO> getAgedAgingRAN(AgedAgingRanInputDTO agedAgingRanInputDTO);
	
}
