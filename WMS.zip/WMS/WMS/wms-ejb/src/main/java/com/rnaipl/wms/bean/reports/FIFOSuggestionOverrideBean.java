package com.rnaipl.wms.bean.reports;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.reports.FIFOSuggestionDTO;
import com.rnaipl.wms.dto.reports.FIFOSuggestionOverrideDTO;
import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSBeanUtil;

public class FIFOSuggestionOverrideBean implements FIFOSuggestionOverride{

	private static final Logger LOGGER = Logger
			.getLogger(FIFOSuggestionOverrideBean.class);

	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;
	
	public List<FIFOSuggestionDTO> getFIFOSuggestion(FIFOSuggestionOverrideDTO fifoSuggestionOverrideDTO) throws Exception { 
		
		List<FIFOSuggestionDTO> fifoSuggestionDTOs = new ArrayList<FIFOSuggestionDTO>();

		StringBuffer queryStringBuf = new StringBuffer();
		queryStringBuf.append("SELECT PA.PART_NO, PA.SUGGESTED_RAN,PA.SUGGESTED_LOCATION,");
		queryStringBuf.append(" (SELECT distinct LPPD FROM DBO.RAN R WHERE R.RAN=substring(PA.SUGGESTED_RAN,1,7) ) AS SUGGESTEDRAN_LPPD,");
		queryStringBuf.append(" PA.RAN AS ACTUAL_RAN,PA.LOCATION AS ACTUAL_LOCATION,(SELECT distinct LPPD FROM DBO.RAN R WHERE R.RAN=substring(PA.RAN,1,7) ) AS ACTUALRAN_LPPD,");
		queryStringBuf.append(" (SELECT DATEDIFF(DAY,(SELECT distinct LPPD FROM DBO.RAN R WHERE R.RAN=substring(PA.SUGGESTED_RAN,1,7)) , (SELECT distinct LPPD FROM DBO.RAN R WHERE R.RAN=substring(PA.RAN,1,7) ))) AS DURATION,");
		queryStringBuf.append(" (SELECT TOP 1 REASONCODEDESC FROM DBO.TBL_DEVIATION_REASONCODE TR WHERE TR.DEVIATION_REASONCODEID = PA.DEVIATION_REASONCODEID ) AS REASONCODEDESC,");
		queryStringBuf.append(" PA.SNP,PA.COUNT AS QTY,PA.SCAN_TIME, PA.PART_IN_OUT_TIME,PA.DEVICE_ID");
		queryStringBuf.append(" FROM PARTINOUT_STAGING_AUDIT PA,PART P WHERE P.PART_NO=PA.PART_NO ");
		queryStringBuf.append(" AND P.SHELF_LIFE_PART='YES' AND  PA.TRANSACTION_TYPE='OUT' AND (PA.SUGGESTED_RAN!=PA.RAN OR PA.SUGGESTED_LOCATION!=PA.LOCATION)");
		queryStringBuf.append(WMSBeanUtil.createQueryParamForFIFOSuggestion(fifoSuggestionOverrideDTO));

		Query query = entityManager.createNativeQuery(queryStringBuf.toString());
		
		if (null != fifoSuggestionOverrideDTO.getPartNumber() && !fifoSuggestionOverrideDTO.getPartNumber().equalsIgnoreCase("")) {
			query.setParameter("partNos", fifoSuggestionOverrideDTO.getPartList());
        }
		if (null != fifoSuggestionOverrideDTO.getLocation() && !fifoSuggestionOverrideDTO.getLocation().equalsIgnoreCase("")) {
			query.setParameter("locationNos", fifoSuggestionOverrideDTO.getLocationList());
        }
		if (null != fifoSuggestionOverrideDTO.getRan() && !fifoSuggestionOverrideDTO.getRan().equalsIgnoreCase("")) {
			query.setParameter("rans", fifoSuggestionOverrideDTO.getRanList());
        }
		LOGGER.debug("FIFO Data Query " + queryStringBuf.toString());
		
		if(!fifoSuggestionOverrideDTO.isDownload()){
			query.setFirstResult(fifoSuggestionOverrideDTO.getStartIndex());
			query.setMaxResults(fifoSuggestionOverrideDTO.getEndIndex());
		}

		List<Object[]> fifoSuggestionList = query.getResultList();
		LOGGER.debug("FIFO Suggestion Data size " + fifoSuggestionList.size());

		if (null != fifoSuggestionList && fifoSuggestionList.size() > 0) {
			for (Iterator<Object[]> i = fifoSuggestionList.iterator(); i.hasNext();) {
				Object[] fifoSuggestion = (Object[]) i.next();
				FIFOSuggestionDTO fifoSuggestionDTO = setFifoSuggestion(fifoSuggestion);
				LOGGER.debug("***  getFIFOSuggestionReasonValue : " +fifoSuggestionDTO.getReason());
				fifoSuggestionDTOs.add(fifoSuggestionDTO);
			}
		}
		LOGGER.debug("***  getFIFOSuggestion * EXIT");
		return fifoSuggestionDTOs;

	}
	
	private FIFOSuggestionDTO setFifoSuggestion(Object[]  fifoSuggestion) throws Exception{

		FIFOSuggestionDTO fifoSuggestionDTO = new FIFOSuggestionDTO();
		try {
			int indexCount=0;
			fifoSuggestionDTO.setPartNumber((null ==  fifoSuggestion[indexCount] ? "": fifoSuggestion[indexCount].toString()));
			indexCount++;
			fifoSuggestionDTO.setSuggestedRan((null ==  fifoSuggestion[indexCount] ? "": fifoSuggestion[indexCount].toString()));
			indexCount++;
			fifoSuggestionDTO.setSuggestedLocation((null ==  fifoSuggestion[indexCount] ? "": fifoSuggestion[indexCount].toString()));
			indexCount++;
			if(null != fifoSuggestion[indexCount]){
			fifoSuggestionDTO.setSuggestedRanLppd((Date) fifoSuggestion[indexCount]);
			}
			indexCount++;
			fifoSuggestionDTO.setActualRan((null ==  fifoSuggestion[indexCount] ? "": fifoSuggestion[indexCount].toString()));
			indexCount++;
			fifoSuggestionDTO.setActualLocation((null ==  fifoSuggestion[indexCount] ? "": fifoSuggestion[indexCount].toString()));
			indexCount++;
			if(null != fifoSuggestion[indexCount]){
				fifoSuggestionDTO.setActualRanLppd( (Date) fifoSuggestion[indexCount]);
			}
			indexCount++;
			if(null != fifoSuggestion[indexCount]){
				fifoSuggestionDTO.setDuration((Integer) fifoSuggestion[indexCount]);
			}
			indexCount++;
			if(null != fifoSuggestion[indexCount]){
				fifoSuggestionDTO.setReason((null ==  fifoSuggestion[indexCount] ? "": fifoSuggestion[indexCount].toString()));
			}
			indexCount++;
			if(null != fifoSuggestion[indexCount]){
				fifoSuggestionDTO.setSnp((Integer) fifoSuggestion[indexCount]);
			}
			indexCount++;
			if(null != fifoSuggestion[indexCount]){
				fifoSuggestionDTO.setQuantity((Integer) fifoSuggestion[indexCount]);
			}
			indexCount++;
			if(null != fifoSuggestion[indexCount]){
				fifoSuggestionDTO.setScanTime((Date) fifoSuggestion[indexCount]);
			}
			indexCount++;
			if(null != fifoSuggestion[indexCount]){
				fifoSuggestionDTO.setPartInOutTime((Date) fifoSuggestion[indexCount]);
			}
			indexCount++;
			fifoSuggestionDTO.setDeviceId((null ==  fifoSuggestion[indexCount] ? "": fifoSuggestion[indexCount].toString()));
			indexCount++;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error(e);
			throw e;
		}
		return fifoSuggestionDTO;

	}
	
}
