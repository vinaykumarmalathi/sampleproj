package com.rnaipl.wms.bean;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.PartsInOutStagingByDeviceDTO;
import com.rnaipl.wms.dto.PartsInOutStagingDTO;
import com.rnaipl.wms.entities.LineFeedHandyProcessDtls;
import com.rnaipl.wms.entities.PartinOutStagingAudit;
import com.rnaipl.wms.entities.PartinoutStaging;
import com.rnaipl.wms.entities.PartsOutReason;
import com.rnaipl.wms.util.ApplicationUtility;
import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSConstants;

@Stateless
@LocalBean
public class PartsInOutStagingBean implements PartsInOutStaging{

	 private static final Logger LOGGER = Logger.getLogger(PartsInOutStagingBean.class);
	 private static final Logger LOGGER_PART_INOUT = Logger.getLogger(WMSConstants.INOUT_LOGFILE);
	 
	
	 @PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)	 
	 private EntityManager entityManager;

	 
	
	public int insertPartsInOutStaging(List<PartsInOutStagingByDeviceDTO> partsInOutInfoList){
		
		int retParam = 0;
		String pickListNo = "";
		String deviceId = "";
		
		LOGGER_PART_INOUT.debug("**In insertPartsInOutStaging ->partsInOutInfoList size ** " + partsInOutInfoList.size());
		 for (PartsInOutStagingByDeviceDTO partsInOutInfo : partsInOutInfoList) {
			 
			 PartinoutStaging partInOutBean = new PartinoutStaging();
				PartsOutReason partsOutReason = new PartsOutReason();
				String formattedPartNumber="";
			    formattedPartNumber=partsInOutInfo.getPartNumber().replaceAll("=","");
				formattedPartNumber=formattedPartNumber.replaceAll("\"","");
				formattedPartNumber=formattedPartNumber.toUpperCase();
				partInOutBean.setPartNo(formattedPartNumber);
				partInOutBean.setCount(partsInOutInfo.getCount());
				partInOutBean.setDeviceId(partsInOutInfo.getDeviceId());
				deviceId=partsInOutInfo.getDeviceId();
				partInOutBean.setLocation(partsInOutInfo.getLocation().toUpperCase());
				partInOutBean
						.setPartInOutTime(new Timestamp(System.currentTimeMillis()));
				if((partsInOutInfo.getRan()==null || partsInOutInfo.getRan().trim().equals("")))
				{
					partInOutBean.setRan(WMSConstants.DEFAULT_RAN);
				}
				else{
					partInOutBean.setRan(partsInOutInfo.getRan());	
				}
				
				partInOutBean.setTransactionType(partsInOutInfo.getTransactionType().toUpperCase());
				partInOutBean.setUserId(partsInOutInfo.getUserId());
				partInOutBean.setNoOfBoxes(partsInOutInfo.getNoOfBoxes());						
				partInOutBean.setComments(partsInOutInfo.getComments());
				partInOutBean.setSnp(partsInOutInfo.getSnp());
			    partInOutBean.setScanTime(ApplicationUtility.convertStringToSqlTimeStamp(partsInOutInfo.getScanTime(), WMSConstants.TIMESTAMP_FORMAT));
			    if( partInOutBean.getScanTime()==null){
			    	partInOutBean.setScanTime(partInOutBean.getPartInOutTime());
			    	partInOutBean.setComments("Scan time updated with In-Out");
			    }
				if (partsInOutInfo.getTransactionType().trim().equalsIgnoreCase("Out") || partsInOutInfo.getTransactionType().trim().equalsIgnoreCase("Move")) {
					
					if(partsInOutInfo.getReasonCode()!=null && partsInOutInfo.getReasonCode().length()>0){						
						partsOutReason.setReasonCode(getPartReasonCode(partsInOutInfo.getReasonCode()));
						partInOutBean.setReasonCode(partsOutReason);
					}
				}
				
				LOGGER.debug("PartsInOutStaging Suggested Location: "+partsInOutInfo.getSuggestedLocation());
				LOGGER.debug("PartsInOutStaging Suggested Ran: "+partsInOutInfo.getSuggestedRan());
				LOGGER.debug("PartsInOutStaging Location Destination: "+partsInOutInfo.getLocationDestination());
				
				if(null == partsInOutInfo.getSuggestedLocation() || partsInOutInfo.getSuggestedLocation().isEmpty()){
					partInOutBean.setSuggestedLocation(null);
				} else{
					partInOutBean.setSuggestedLocation(partsInOutInfo.getSuggestedLocation());
				}
				
				if(null == partsInOutInfo.getSuggestedRan() || partsInOutInfo.getSuggestedRan().isEmpty()){
					partInOutBean.setSuggestedRan(null);
				} else{
					partInOutBean.setSuggestedRan(partsInOutInfo.getSuggestedRan());
				}
				
				partInOutBean.setLocationDestination(partsInOutInfo.getLocationDestination());
				
				//added for deviation resoncode
				partInOutBean.setDeviationResonCode(partsInOutInfo.getDeviationResonCode());
				
				//added for picking list entry
				partInOutBean.setPickListNo(partsInOutInfo.getPickListNo());
				
				if(partsInOutInfo.getPickListNo()!=null && partsInOutInfo.getPickListNo().toString().trim().length()>0){
					pickListNo = partsInOutInfo.getPickListNo();
				}				
				
				LOGGER_PART_INOUT.debug("* Part Number :" + partsInOutInfo.getPartNumber());
				LOGGER_PART_INOUT.debug("* Location :" + partsInOutInfo.getLocation());
				LOGGER_PART_INOUT.debug("* RAN :" + partsInOutInfo.getRan());
				LOGGER_PART_INOUT.debug("* Transaction Type :" + partsInOutInfo.getTransactionType());				
				LOGGER_PART_INOUT.debug("* Device ID :" + partsInOutInfo.getDeviceId());
				LOGGER_PART_INOUT.debug("* User ID :" + partsInOutInfo.getUserId());
				LOGGER_PART_INOUT.debug("* Reason Code :" + partsInOutInfo.getReasonCode());
				LOGGER_PART_INOUT.debug("* SNP :" + partsInOutInfo.getSnp());
				LOGGER_PART_INOUT.debug("* Count :" + partsInOutInfo.getCount());	
				LOGGER_PART_INOUT.debug("* Input Scan Time : " + partsInOutInfo.getScanTime());
				LOGGER_PART_INOUT.debug("* Scan Time Storing :" + partInOutBean.getScanTime());
				LOGGER_PART_INOUT.debug("* In Out Time :" + partInOutBean.getPartInOutTime());
				LOGGER_PART_INOUT.debug("* Suggested Location :" + partInOutBean.getSuggestedLocation());
				LOGGER_PART_INOUT.debug("* Suggested Ran :" + partInOutBean.getSuggestedRan());
				LOGGER_PART_INOUT.debug("* Location destination :" + partInOutBean.getLocationDestination());
				LOGGER_PART_INOUT.debug("* Deviation Reason Code :" + partInOutBean.getDeviationResonCode());
				LOGGER_PART_INOUT.debug("* Picking List Number :" + partInOutBean.getPickListNo());
				
				entityManager.persist(partInOutBean);
				retParam = 1;
         }
		 
		if (pickListNo != null && pickListNo.length() > 0 && retParam == 1) {
			LineFeedHandyProcessDtls lnfdProcessDtls = new LineFeedHandyProcessDtls();
			String deviceEqual = null;
			try {
				Query query1 = null;
				query1 = entityManager.createNativeQuery(
						"SELECT DEVICE_ID FROM TBL_LNFD_HANDY_PROCESSING_DTLS WHERE DEVICE_ID='" + deviceId + "' ");
				LOGGER.debug("TBL_LNFD_HANDY_PROCESSING_DTLS query : " + query1.toString());
				deviceEqual = (String) query1.getSingleResult();
				LOGGER.debug("deviceEqual : " + deviceEqual);
			} catch (NoResultException Ex) {
				LOGGER.error("No result found in TBL_LNFD_HANDY_PROCESSING_DTLS for device check");
			}
			if (deviceEqual != null && deviceEqual.length() > 0) {
				Query query = entityManager.createNativeQuery(
						"DELETE FROM TBL_LNFD_HANDY_PROCESSING_DTLS WHERE DEVICE_ID = '" + deviceId + "' ");
				LOGGER.debug("TBL_LNFD_HANDY_PROCESSING_DTLS delete query : " + query.toString());
				int i = query.executeUpdate();
				lnfdProcessDtls.setDeviceID(deviceId);
				lnfdProcessDtls.setIsProcessing(1);
				entityManager.persist(lnfdProcessDtls);
			} else {
				LOGGER.debug("deviceId in else : " + deviceId);
				lnfdProcessDtls.setDeviceID(deviceId);
				lnfdProcessDtls.setIsProcessing(1);
				entityManager.persist(lnfdProcessDtls);
			}
		}
		 return retParam;
	}
	
	/*public void executeStoreProcedure()
	{
		try {
			
			String queryStringBuf = "EXEC USP_WMS_PARTS_IN_OUT_UPDATE ";
			Query query = entityManager.createNativeQuery(queryStringBuf.toString());
			query.executeUpdate();
		} catch (Exception e) {
		
			LOGGER_PART_INOUT.error("** Error in Executing procedure USP_WMS_PARTS_IN_OUT_UPDATE ",e);
		}
	}*/

	private String getPartReasonCode(String partReason)
	{
		String reasonCode ="0";
		if(partReason!=null){
			partReason=partReason.trim();
			if(partReason.equalsIgnoreCase("LS Pick")){
				reasonCode= "1";
			}
			else  if(partReason.equalsIgnoreCase("Aftersales")){
				reasonCode= "2";
			}
			else  if(partReason.equalsIgnoreCase("Retrofit")){
				reasonCode= "3";
			}
			else  if(partReason.equalsIgnoreCase("Quality")){
				reasonCode= "4";
			}
			else  if(partReason.equalsIgnoreCase("Replenishment")){
				reasonCode= "5";
			}
			else  if(partReason.equalsIgnoreCase("Quality Out")){
				reasonCode= "6";
			}
			else  if(partReason.equalsIgnoreCase("Rejected")){
				reasonCode= "7";
			}
			else  if(partReason.equalsIgnoreCase("Supplier Shipment")){
				reasonCode= "8";
			}
			else  if(partReason.equalsIgnoreCase("Aged RAN")){
				reasonCode= "9";
			}
			else {
				reasonCode= "0";
			}
		}
		//LOGGER_PART_INOUT.debug("** Reason Code for the reason" + partReason + " is " +  reasonCode);
		return reasonCode;
	}
	public List<PartsInOutStagingDTO> getPartsInOutAuditByLocaiton(
			PartsInOutStagingDTO partsInOutAudit) {
		LOGGER.debug("*** getPartsInOutAuditByLocaiton -- Location*"
				+ partsInOutAudit.getLocation());
		List<PartsInOutStagingDTO> partInOutAuditDtos = new ArrayList<PartsInOutStagingDTO>();
		if (partsInOutAudit.getLocation() != null
				|| partsInOutAudit.getLocation().isEmpty()) {
			Query query = entityManager
					.createQuery(
							"select p from PartinOutStagingAudit p where p.location = :location or p.locationDestination = :location ORDER BY p.partInOutTime DESC");
			query.setParameter("location", partsInOutAudit.getLocation());
			List<PartinOutStagingAudit> queryDatas = query.getResultList();
			if (queryDatas != null) {
				for (PartinOutStagingAudit partsInOutAuditData : queryDatas) {
					
					PartsInOutStagingDTO partInOutAuditDto = new PartsInOutStagingDTO();
					String transactionType=partsInOutAuditData.getTransactionType();
					int count = partsInOutAuditData.getCount();
					partInOutAuditDto
							.setPartPk(partsInOutAuditData.getPartPk());
					if(transactionType!=null && transactionType.equalsIgnoreCase("Out")){
						count=-count;
					}
					//changed for move transaction
					if(transactionType!=null && transactionType.equalsIgnoreCase("Move")){
						if(partsInOutAuditData.getLocation().equals(partsInOutAudit.getLocation())){
							count = -count;
							partInOutAuditDto.setLocation(partsInOutAuditData
									.getLocation());
						}else{
							partInOutAuditDto.setLocation(partsInOutAuditData
									.getLocationDestination());
						}
					}else{
						partInOutAuditDto.setLocation(partsInOutAuditData
								.getLocation());
					}
					//ends
					partInOutAuditDto.setCount(count);
					partInOutAuditDto.setDeviceId(partsInOutAuditData
							.getDeviceId());
					partInOutAuditDto.setPartInOutTime(partsInOutAuditData
							.getPartInOutTime());
					partInOutAuditDto.setPartNumber(partsInOutAuditData
							.getPartNo());
					partInOutAuditDto.setReasonCode(partsInOutAuditData
							.getReasonCode() == null ? null
							: partsInOutAuditData.getReasonCode()
									.getReason());
					partInOutAuditDto.setRan(partsInOutAuditData.getRan());
					partInOutAuditDto
							.setUserId(partsInOutAuditData.getUserId());
					partInOutAuditDto.setTransactionType(partsInOutAuditData
							.getTransactionType());
					partInOutAuditDto.setComments(partsInOutAuditData.getComments());
					partInOutAuditDtos.add(partInOutAuditDto);
				}
			}
		}

		return partInOutAuditDtos;
	}



}
