package com.rnaipl.wms.bean;

public interface PickingList {

	public String getPickingListPath();
}
