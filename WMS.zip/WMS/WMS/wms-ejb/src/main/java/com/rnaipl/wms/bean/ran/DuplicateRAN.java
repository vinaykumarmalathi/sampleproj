package com.rnaipl.wms.bean.ran;

import java.util.List;





import com.rnaipl.wms.dto.PartsInOutAuditSearchDTO;
import com.rnaipl.wms.dto.ran.DuplicateRANDTO;
import com.rnaipl.wms.dto.ran.DuplicateRANInputDTO;

public interface DuplicateRAN {

	public List<DuplicateRANDTO> getDuplicateRANs(DuplicateRANInputDTO duplicateRANInputDTO) throws Exception;
	
}
