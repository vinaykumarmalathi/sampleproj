package com.rnaipl.wms.bean;

import java.util.List;

import com.rnaipl.wms.dto.RANDataDTO;


public interface RANData {

	public List<RANDataDTO> getAllRan(RANDataDTO ranDTO);
	
	public int getRanCount(RANDataDTO ranDTO);
}
