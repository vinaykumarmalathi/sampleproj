package com.rnaipl.wms.bean.reports;

import java.util.List;

import com.rnaipl.wms.dto.PickListAndroidDTO;
import com.rnaipl.wms.dto.reports.LineAllocationDTO;
import com.rnaipl.wms.dto.reports.PickinglistDTO;
import com.rnaipl.wms.dto.reports.PickinglistResultsDTO;

public interface IPickingList {
	List<PickinglistResultsDTO> getPickingList(PickinglistDTO pickinglistDTO);

	PickinglistResultsDTO getPickingListDetail(String deviceTranId);
	
	int getClosurePickingListDetail(String deviceTranId, String partNumber,String userId);

	//List<ZoneDTO> getZoneList();

	// ADDED FOR UAT REQ TO MERGE T&K SHOP DROP DOWN -START
	public List<PickinglistDTO> getShopByPlantId(String plant);
	// ADDED FOR UAT REQ TO MERGE T&K SHOP DROP DOWN -END

    public String getImageLogoPath();
        
    public List<PickinglistDTO> getAllocationByZone(String zone);
    
    public List<PickinglistDTO> getZoneList();
    
    public int getPickingListCount(PickinglistDTO pickinglistDTO);

	public List<LineAllocationDTO> getLineAllocation(String plant, String shop);
	
	public PickListAndroidDTO getPickListDtlsAndroid(String plant, String line,String shop,String allocation,String pickingList,String deviceID);

}
