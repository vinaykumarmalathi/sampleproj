package com.rnaipl.wms.bean;

import java.util.List;

import com.rnaipl.wms.dto.PITCumulativeReportDTO;
import com.rnaipl.wms.dto.PITStagingDTO;
import com.rnaipl.wms.dto.PITTransactionReportDTO;

/*AJ00482484 -- PIT Automation -- START */

public interface PITStaging {
	public int insertPitStaging(List<PITStagingDTO> pitStagingDto);

	public int getTransactionReportCount(PITTransactionReportDTO pitTransactionReportDto);

	public List<PITTransactionReportDTO> getPitTransactionReportList(
			PITTransactionReportDTO pitTransactionReportDto);

	public int getCumulativeReportCount(PITCumulativeReportDTO pitCumulativeReportDto);

	public List<PITCumulativeReportDTO> getPitCumulativeReportList(PITCumulativeReportDTO pitCumulativeReportDto);
}

/*AJ00482484 -- PIT Automation -- END */
