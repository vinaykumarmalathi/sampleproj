package com.rnaipl.wms.bean;

public interface TagSheet {

	public String getTagSheetPath();
}
