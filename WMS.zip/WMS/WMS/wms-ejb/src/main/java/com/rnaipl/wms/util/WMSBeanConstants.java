package com.rnaipl.wms.util;

public class WMSBeanConstants {

    public static final String DATA_SOURCE_NAME = "WMS";
    public static final String TRANSACTION_TYPE_OUT = "OUT";
    public static final String TRANSACTION_TYPE_IN = "IN";
    public static final String TRANSACTION_TYPE_MOVE = "MOVE";
}
