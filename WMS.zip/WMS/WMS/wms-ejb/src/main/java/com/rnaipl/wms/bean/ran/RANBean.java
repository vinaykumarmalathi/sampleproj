package com.rnaipl.wms.bean.ran;


import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.PartLocationSynchroInputDTO;
import com.rnaipl.wms.dto.ran.RANDTO;
import com.rnaipl.wms.dto.ran.RANPickDateDTO;
import com.rnaipl.wms.dto.ran.RANSuggestionDTO;
import com.rnaipl.wms.dto.ran.SuggestedRANLocationForPartNoDTO;
import com.rnaipl.wms.dto.ran.SuggestedRanLocationDTO;
import com.rnaipl.wms.dto.reports.FIFOSuggestionOverrideInputDTO;
import com.rnaipl.wms.dto.reports.FIFOSuggestionOverrideValidationDTO;
import com.rnaipl.wms.entities.Ran;
import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.dto.ran.WhMovementRanValidationInDTO;
import com.rnaipl.wms.dto.ran.WhMovementRanValidationOutDTO;

/**
 * 
 * @author TechM
 * 
 */
@Stateless
@LocalBean
public class RANBean implements com.rnaipl.wms.bean.ran.RAN {

	private static final Logger LOGGER = Logger.getLogger(RANBean.class);

    @PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
    private EntityManager entityManager;

	public List<String> getAllRans() {
		// TODO Auto-generated method stub
		return null;
	}

	public Set<RANSuggestionDTO> getRan(String inputRan)
	{
		LOGGER.debug("*****IN Get RAN bean" + inputRan);
		 Set<RANSuggestionDTO> ranSet = new HashSet<RANSuggestionDTO>();
		/*Query query = entityManager.createQuery("select r.id.ran from Ran r where r.id.ran LIKE :val");*/
		 /*Query query = entityManager.createNativeQuery("select ran from Ran where ran LIKE :val ");*/
		 StringBuffer queryStringBuf = new StringBuffer();
		 queryStringBuf.append("SELECT a.* FROM ");
		 queryStringBuf.append(" (select distinct R.RAN from RAN R left outer join  PART_LOCATION PL on R.RAN=SUBSTRING(PL.RAN,1,7) ");
		 queryStringBuf.append(" where R.RAN<>'*' and R.RAN is not null and PL.RAN is null ");
		 queryStringBuf.append(" UNION ");
		 queryStringBuf.append(" SELECT distinct RAN FROM PART_LOCATION where ran<>'*' and RAN is not null )a ");
		 queryStringBuf.append(" where a.RAN like :val ");
		 Query query = entityManager.createNativeQuery(queryStringBuf.toString());
		query.setParameter("val", inputRan + "%");
		query.setMaxResults(10);
		List<String> ranList = query.getResultList();
		LOGGER.debug("*****IN Get RAN bean result" + ranList.size());
		   for(String ran : ranList){
	        	RANSuggestionDTO ranDTO = new RANSuggestionDTO();
	        	ranDTO.setText(ran);
	        	ranSet.add(ranDTO);
	        }
		 return ranSet;
	}
	
	public Set<RANSuggestionDTO> getRanFmRANTbl(String inputRan) {
		LOGGER.debug("*****IN getRanFmRANTbl bean" + inputRan);
		Set<RANSuggestionDTO> ranSet = new HashSet<RANSuggestionDTO>();
		Query query = entityManager.createNativeQuery("select ran from Ran where ran LIKE :val ");
		query.setParameter("val", inputRan + "%");
		query.setMaxResults(10);
		List<String> ranList = query.getResultList();
		LOGGER.debug("*****IN getRanFmRANTbl bean result" + ranList.size());
		for (String ran : ranList) {
			RANSuggestionDTO ranDTO = new RANSuggestionDTO();
			ranDTO.setText(ran);
			ranSet.add(ranDTO);
		}
		return ranSet;
	}	
	
	public List<RANDTO> getRanList(RANDTO ranDTO)
	{
		
		// Set<RANSuggestionDTO> ranSet = new HashSet<RANSuggestionDTO>();
		 List<RANDTO> ranDTOs = new ArrayList<RANDTO>();
		 
		 StringBuffer queryStringBuf = new StringBuffer();
		 queryStringBuf.append("SELECT R.RAN,R.PART_NO,R.MFG_DATE,R.LPPD,R.UPDATED_DATETIME FROM DBO.RAN R WHERE 1=1  "); 
		 
		 if (ranDTO!=null && ranDTO.getPlant()!=null && !ranDTO.getPlant().toString().trim().equalsIgnoreCase("")) {
			 queryStringBuf.append(" AND  R.PLANT = '"+ranDTO.getPlant()+"' ");	
		 }
		
		// LOGGER.debug("** RAN List size " + ranDTO.getRanList().size());
		 if (ranDTO.getPartList()!=null && ranDTO.getPartList().size()>0) {
			 
			 queryStringBuf.append(" AND  R.PART_NO IN (:partNos)");
		 }

		 if (ranDTO.getRanList()!=null && ranDTO.getRanList().size()>0) {
			 queryStringBuf.append(" AND  R.RAN IN (:rans)");
		 }
		 
		 SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");

		 if(ranDTO.getLppdType()!=null){
			 if(ranDTO.getLppdType().equalsIgnoreCase("Available")){
				 queryStringBuf.append(" AND R.LPPD IS NOT NULL");
			 }
			 if(ranDTO.getLppdType().equalsIgnoreCase("Not Available")){
				 queryStringBuf.append(" AND R.LPPD IS NULL");
			 }
		 }
		 
		
		 if(ranDTO.getUpdatedDate() != null) {

			 queryStringBuf.append(" AND CONVERT(VARCHAR(10),R.UPDATED_DATETIME,126) = '"+ dateFormatter.format(ranDTO.getUpdatedDate()) + "'");
		 }
		
		 Query query = entityManager.createNativeQuery(queryStringBuf.toString());
		 if(ranDTO.getIsForCount()==1){
			 ranDTO.setIsFullDownload(1);
		 }
		 if(!(ranDTO.getIsFullDownload()==1)){	        	
	        	
	        	query.setFirstResult(ranDTO.getStartIndex());
	        	query.setMaxResults(ranDTO.getEndIndex());
	     }
	     LOGGER.debug("Query Formed " + queryStringBuf.toString());
	     if (ranDTO.getPartList()!=null && ranDTO.getPartList().size()>0) {
	    	 query.setParameter("partNos", ranDTO.getPartList());
	     }
		 if (ranDTO.getRanList()!=null && ranDTO.getRanList().size()>0) {
			 query.setParameter("rans", ranDTO.getRanList());
		 }
		List<Object[]> ranList = query.getResultList();
		LOGGER.debug("*RAN List Size " + ranList.size());
		  if (null != ranList && ranList.size() > 0) {
	            for (Iterator<Object[]> i = ranList.iterator(); i.hasNext();) {
	            	int indexCount=0;
	                Object[] values = (Object[]) i.next();
	                RANDTO ranResultDTO = new RANDTO();
	                
	                ranResultDTO.setRanId((null == values[indexCount] ? "" : values[indexCount].toString()));	               
	                indexCount++;	                
	                ranResultDTO.setPartNo((null == values[indexCount] ? "" : values[indexCount].toString()));
	                indexCount++;
	                ranResultDTO.setMfgDate((null == values[indexCount] ? "" : values[indexCount].toString().substring(0,10)));
	                indexCount++;
	                ranResultDTO.setLppd((null == values[indexCount] ? "" : values[indexCount].toString().substring(0,10)));
	                indexCount++;
	                ranResultDTO.setUpdatedDateTime((Timestamp) values[indexCount]);
	                ranDTOs.add(ranResultDTO);
	            }

	        }
		
		
		return ranDTOs;
		
	}
	
	public List<RANPickDateDTO> getAllRANLastPickDate(PartLocationSynchroInputDTO inputDto)
	{
		LOGGER.debug("*****In getAllRANLastPickDate bean" );		
		StringBuffer queryStringBuf = new StringBuffer();
		/*queryStringBuf.append(" select r from Ran r where r.lppd !=null and  r.lppd < DATEADD(DAY,30,getdate())  ");*/
		queryStringBuf.append(" select r from Ran r where r.lppd is not null and  r.lppd < DATEADD(DAY,30,getdate())  ");
		//Select the part which expires in next one month
		if(inputDto!=null && inputDto.getShop()!=null && inputDto.getShop().toString().trim().equalsIgnoreCase("D")){
			 queryStringBuf.append(" and r.plant = '"+inputDto.getShop()+"' ");
		}else{
			queryStringBuf.append(" and r.plant = 'G' ");
		}
		Query query = entityManager.createQuery(queryStringBuf.toString());
		LOGGER.debug("*****Query Generated" + query.toString() );
		List<Ran> ranList = query.getResultList();		
		List<RANPickDateDTO> ranDtoList = new ArrayList<RANPickDateDTO>();
		
		//LOGGER.debug("*****RAN List Size" + ranList.size());
		if(ranList!=null){
		   for(Ran ran : ranList){
			   RANPickDateDTO ranPickDateDTO = new RANPickDateDTO();
	        	ranPickDateDTO.setRAN(ran.getId().getRan());
	        //	LOGGER.debug(" Dummy Field value " + ran.getDummyField());
	        	//ranPickDateDTO.setPartNo(ran.getPart().getPartNo());
	        	if(ran.getLppd()!=null)
	        	{
	        		String lppd;
	        		Calendar lppdDate = Calendar.getInstance();	        		
	        		lppdDate.setTimeInMillis(ran.getLppd().getTime());
	        		//Add shelf life period to the manufacturing date to get the last possible pick date
	        		//lppdDate.add(Calendar.DATE, ran.getPart().getShelfLifePeriod());
	        		//Add +1 to month, since Java month starts from 0.
	        		lppd=lppdDate.get(Calendar.YEAR)+"-"+(lppdDate.get(Calendar.MONTH)+1)+"-"+lppdDate.get(Calendar.DATE);	        		
	        		ranPickDateDTO.setLPPD(lppd);
	        		
	        	}	        	
	        	ranDtoList.add(ranPickDateDTO);
	        }
		}
		return ranDtoList;
	}
	
	public String checkAgedRAN(List<String> ranSearchList)
	{
		StringBuffer queryStringBuf = new StringBuffer();
		String s= ranSearchList.get(0).toString();
		LOGGER.debug("Check Aged RAN List " + s);
		
		String agedRan="";
		queryStringBuf.append("select r from Ran r where  r.lppd < getdate()-1 ");
		queryStringBuf.append(" and r.id.ran in (:rans) ");		
		
		Query query = entityManager.createQuery(queryStringBuf.toString());
		query.setParameter("rans", ranSearchList);
		List<Ran> ranList = query.getResultList();
		LOGGER.debug("***Aged RAN from DB size " + ranList.size());
		if(ranList!=null && ranList.size()>0)
		{
			for(Ran ran : ranList){
				agedRan=agedRan+ran.getId().getRan()+",";
			}
			if(agedRan.length()>1)
			{
				agedRan=agedRan.substring(0,agedRan.length()-1);
			}
		}		
		
		return agedRan;
	}
	
	public SuggestedRANLocationForPartNoDTO getSuggestedRANandLocationForPartNumberWHOut(SuggestedRanLocationDTO suggestedRanLocationPartNo){
		SuggestedRANLocationForPartNoDTO suggestedRanLocationForPartNo = new SuggestedRANLocationForPartNoDTO();
		StringBuffer queryStringBuf = new StringBuffer();
		queryStringBuf.append(" SELECT TOP 1 R.PART_NO,R.RAN,PL.LOCATION_ID,PL.CURRENT_QTY, DATEDIFF(DAY,GETDATE(),R.LPPD) AS DURATION ");		
		queryStringBuf.append(" FROM  DBO.RAN R JOIN PART_LOCATION PL ON R.PART_NO=PL.PART_NO AND R.RAN=SUBSTRING(PL.RAN,1,7)  AND R.PLANT = SUBSTRING(PL.LOCATION_ID,1,1) AND R.PART_NO = '"+suggestedRanLocationPartNo.getPartNumber()+"'");
		queryStringBuf.append(" AND PL.CURRENT_QTY>0 AND R.LPPD IS NOT NULL AND CAST(R.LPPD AS DATE) >= CAST(GETDATE() AS DATE)  ");
		//Added plant condition to avoid of getting duplicate RAN - Start		
		if(suggestedRanLocationPartNo.getPlant()!= null){
			queryStringBuf.append(" AND SUBSTRING(PL.LOCATION_ID,1,1) = '"+suggestedRanLocationPartNo.getPlant()+"'");
		}else{
			queryStringBuf.append(" AND SUBSTRING(PL.LOCATION_ID,1,1) = 'G'");
		}
		//Added plant condition to avoid of getting duplicate RAN - End		
		//Added By Meena - To get both T and K shops when shop is selected in handy as 'T' - Start
		if(suggestedRanLocationPartNo.getShop()!= null){
			if(suggestedRanLocationPartNo.getShop().charAt(0) != 'T') {
				queryStringBuf.append(" AND SUBSTRING(PL.LOCATION_ID,2,1) = '"+suggestedRanLocationPartNo.getShop()+"'");
			}else {
				queryStringBuf.append(" AND SUBSTRING(PL.LOCATION_ID,2,1) IN ('T','K') ");
			}
		}
		//Added By Meena - To get both T and K shops when shop is selected in handy as 'T' - End
		
		queryStringBuf.append(" LEFT JOIN DBO.PARTINOUT_STAGING_AUDIT PA ON SUBSTRING(PA.RAN,1,7)=R.RAN AND PA.PART_NO=R.PART_NO AND PA.TRANSACTION_TYPE in ('IN','MOVE') ");
		queryStringBuf.append(" ORDER BY R.LPPD ASC,PA.SCAN_TIME ");
		
		Query query = entityManager.createNativeQuery(queryStringBuf.toString());
		LOGGER.debug("Query for RAN Suggestion "+queryStringBuf.toString());
		List<Object[]> suggetedRanLocationList = query.getResultList();
		LOGGER.debug("*** getSuggestedRANandLocationForPartNumberWHOut suggetedRanLocationList size: " + suggetedRanLocationList.size());
		
		if(suggetedRanLocationList!=null && suggetedRanLocationList.size()>0){
				Object[] suggetedRanLocation = suggetedRanLocationList.get(0);
				int indexCount=0;
				suggestedRanLocationForPartNo.setPartNumber((null ==  suggetedRanLocation[indexCount] ? "": suggetedRanLocation[indexCount].toString()));
				indexCount++;
				suggestedRanLocationForPartNo.setRan((null ==  suggetedRanLocation[indexCount] ? "": suggetedRanLocation[indexCount].toString()));				
				indexCount++;
				suggestedRanLocationForPartNo.setLocation((null ==  suggetedRanLocation[indexCount] ? "": suggetedRanLocation[indexCount].toString()));
				indexCount++;
				if(null != suggetedRanLocation[indexCount]){
					suggestedRanLocationForPartNo.setQuantity((Integer) suggetedRanLocation[indexCount]);
				}
				indexCount++;
				if(null != suggetedRanLocation[indexCount]){
					suggestedRanLocationForPartNo.setAgeddays((Integer) suggetedRanLocation[indexCount]);
				}
		}
		else{
			StringBuffer queryStringBuffer = new StringBuffer();
			String plant= null;
			queryStringBuffer.append("SELECT TOP 1 PART_NO, RAN, LOCATION, CURRENT_QTY,SCAN_TIME FROM( ");
			queryStringBuffer.append("SELECT   PL.PART_NO,PL.RAN,LOCATION,CURRENT_QTY,SCAN_TIME  ");
			queryStringBuffer.append("FROM  DBO.PARTINOUT_STAGING_AUDIT P INNER JOIN PART_LOCATION PL "); 
			queryStringBuffer.append("ON P.PART_NO=PL.PART_NO AND P.RAN=PL.RAN  AND P.LOCATION=PL.LOCATION_ID ");
			queryStringBuffer.append("WHERE  p.TRANSACTION_TYPE='IN' and P.PART_NO='"+suggestedRanLocationPartNo.getPartNumber()+"' ");
			if(suggestedRanLocationPartNo.getPlant()!= null){
				plant = suggestedRanLocationPartNo.getPlant();
				queryStringBuffer.append(" AND SUBSTRING(PL.LOCATION_ID,1,1) = '"+suggestedRanLocationPartNo.getPlant()+"' ");
			}else{
				plant = "G";
				queryStringBuffer.append(" AND SUBSTRING(PL.LOCATION_ID,1,1) = 'G' ");
			}
			//Added plant condition to avoid of getting duplicate RAN - End		
			//Added By Meena - To get both T and K shops when shop is selected in handy as 'T' - Start
			if(suggestedRanLocationPartNo.getShop().charAt(0) != 'T') {
				queryStringBuffer.append(" AND SUBSTRING(PL.LOCATION_ID,2,1) = '"+suggestedRanLocationPartNo.getShop()+"' ");
			}else {
				queryStringBuffer.append(" AND SUBSTRING(PL.LOCATION_ID,2,1) IN ('T','K') ");
			}
			/*queryStringBuffer.append("AND P.RAN NOT IN (SELECT RAN FROM DBO.RAN WHERE PLANT = '"+plant+"' ) AND CURRENT_QTY>0 AND P.STATUS IS NULL ");*/
			queryStringBuffer.append("AND SUBSTRING(P.RAN,1,7) NOT IN (SELECT RAN FROM DBO.RAN WHERE PLANT = '"+plant+"' ) AND CURRENT_QTY>0 AND P.STATUS IS NULL ");
			queryStringBuffer.append("UNION ");
			queryStringBuffer.append("SELECT PL.PART_NO,PL.RAN,PL.LOCATION_ID as LOCATION,CURRENT_QTY, ");
			queryStringBuffer.append("(CASE WHEN (SELECT  scan_time FROM  DBO.PARTINOUT_STAGING_AUDIT WHERE part_pk=p.source_part_pk) ");  
			queryStringBuffer.append("IS NULL  THEN GETDATE() ELSE (SELECT  scan_time FROM  DBO.PARTINOUT_STAGING_AUDIT WHERE part_pk=p.source_part_pk) ");
			queryStringBuffer.append("END) ");
			queryStringBuffer.append("AS SCAN_TIME ");
			queryStringBuffer.append("FROM  DBO.PARTINOUT_STAGING_AUDIT P INNER JOIN PART_LOCATION PL "); 
			queryStringBuffer.append("ON P.PART_NO=PL.PART_NO AND P.RAN=PL.RAN AND P.LOCATION_DESTINATION=PL.LOCATION_ID ");
			queryStringBuffer.append("WHERE  p.TRANSACTION_TYPE='MOVE' and P.PART_NO='"+suggestedRanLocationPartNo.getPartNumber()+"' ");
			if(suggestedRanLocationPartNo.getPlant()!= null){
				plant = suggestedRanLocationPartNo.getPlant();
				queryStringBuffer.append(" AND SUBSTRING(PL.LOCATION_ID,1,1) = '"+suggestedRanLocationPartNo.getPlant()+"' ");
			}else{
				plant = "G";
				queryStringBuffer.append(" AND SUBSTRING(PL.LOCATION_ID,1,1) = 'G' ");
			}
			//Added plant condition to avoid of getting duplicate RAN - End		
			//Added By Meena - To get both T and K shops when shop is selected in handy as 'T' - Start
			if(suggestedRanLocationPartNo.getShop().charAt(0) != 'T') {
				queryStringBuffer.append(" AND SUBSTRING(PL.LOCATION_ID,2,1) = '"+suggestedRanLocationPartNo.getShop()+"' ");
			}else {
				queryStringBuffer.append(" AND SUBSTRING(PL.LOCATION_ID,2,1) IN ('T','K') ");
			}
			/*queryStringBuffer.append("AND P.RAN NOT IN (SELECT RAN FROM DBO.RAN WHERE PLANT = '"+plant+"' ) AND CURRENT_QTY>0 AND P.STATUS IS NULL ");*/
			queryStringBuffer.append("AND SUBSTRING(P.RAN,1,7) NOT IN (SELECT RAN FROM DBO.RAN WHERE PLANT = '"+plant+"' ) AND CURRENT_QTY>0 AND P.STATUS IS NULL ");
			/*queryStringBuffer.append(") a WHERE a.RAN <>'*' ORDER BY a.SCAN_TIME ASC ");	*/		
			queryStringBuffer.append(" ) a ORDER BY a.SCAN_TIME ASC ");			
			
			Query suggestedRanLocationByAuditquery = entityManager.createNativeQuery(queryStringBuffer.toString());
			List<Object[]> suggetedRanLocationByAuditList = suggestedRanLocationByAuditquery.getResultList();
			LOGGER.debug("suggetedRanLocationByAuditList Query "+queryStringBuffer.toString());
			LOGGER.debug("*** getSuggestedRANandLocationForPartNumberWHOut suggetedRanLocationByAuditList size: " + suggetedRanLocationByAuditList.size());
			
			if(suggetedRanLocationByAuditList!=null && suggetedRanLocationByAuditList.size()>0){
				Object[] suggetedRanLocation = suggetedRanLocationByAuditList.get(0);
				int indexCount=0;
				suggestedRanLocationForPartNo.setPartNumber((null ==  suggetedRanLocation[indexCount] ? "": suggetedRanLocation[indexCount].toString()));
				indexCount++;
				suggestedRanLocationForPartNo.setRan((null ==  suggetedRanLocation[indexCount] ? "": suggetedRanLocation[indexCount].toString()));
				indexCount++;
				suggestedRanLocationForPartNo.setLocation((null ==  suggetedRanLocation[indexCount] ? "": suggetedRanLocation[indexCount].toString()));
				indexCount++;
				if(null != suggetedRanLocation[indexCount]){
				suggestedRanLocationForPartNo.setQuantity((Integer) suggetedRanLocation[indexCount]);
				}
			}
			/*else{
				return null;
			}*/
		}
		return suggestedRanLocationForPartNo;
	}
	
	
	public List<SuggestedRANLocationForPartNoDTO> getSuggestedRANandLocationForPartNumberWHOutTC(SuggestedRanLocationDTO suggestedRanLocationPartNo){
		SuggestedRANLocationForPartNoDTO suggestedRanLocationForPartNo ;
		List<SuggestedRANLocationForPartNoDTO> suggetedRanLocationListAdd = new ArrayList<SuggestedRANLocationForPartNoDTO>();
		StringBuffer queryStringBuf = new StringBuffer();
		queryStringBuf.append(" SELECT DISTINCT TOP 5 R.PART_NO,PL.RAN,PL.LOCATION_ID,PL.CURRENT_QTY, DATEDIFF(DAY,GETDATE(),R.LPPD) AS DURATION ");		
		queryStringBuf.append(" FROM  DBO.RAN R JOIN PART_LOCATION PL ON R.PART_NO=PL.PART_NO AND R.RAN=SUBSTRING(PL.RAN,1,7)  AND R.PLANT = SUBSTRING(PL.LOCATION_ID,1,1) AND R.PART_NO = '"+suggestedRanLocationPartNo.getPartNumber()+"'");
		queryStringBuf.append(" AND PL.CURRENT_QTY>0 AND R.LPPD IS NOT NULL AND CAST(R.LPPD AS DATE) >= CAST(GETDATE() AS DATE)  ");
		//Added plant condition to avoid of getting duplicate RAN - Start		
		if(suggestedRanLocationPartNo.getPlant()!= null){
			queryStringBuf.append(" AND SUBSTRING(PL.LOCATION_ID,1,1) = '"+suggestedRanLocationPartNo.getPlant()+"'");
		}else{
			queryStringBuf.append(" AND SUBSTRING(PL.LOCATION_ID,1,1) = 'G'");
		}
		//Added plant condition to avoid of getting duplicate RAN - End		
		//Added By Meena - To get both T and K shops when shop is selected in handy as 'T' - Start
		if(suggestedRanLocationPartNo.getShop()!= null){
			if(suggestedRanLocationPartNo.getShop().charAt(0) != 'T') {
				queryStringBuf.append(" AND SUBSTRING(PL.LOCATION_ID,2,1) = '"+suggestedRanLocationPartNo.getShop()+"'");
			}else {
				queryStringBuf.append(" AND SUBSTRING(PL.LOCATION_ID,2,1) IN ('T','K') ");
			}
		}
		//Added By Meena - To get both T and K shops when shop is selected in handy as 'T' - End
		
		queryStringBuf.append(" LEFT JOIN DBO.PARTINOUT_STAGING_AUDIT PA ON SUBSTRING(PA.RAN,1,7)=R.RAN AND PA.RAN=PL.RAN AND PA.PART_NO=R.PART_NO AND PA.TRANSACTION_TYPE in ('IN','MOVE') ");
		queryStringBuf.append(" ORDER BY DATEDIFF(DAY,GETDATE(),R.LPPD) ASC ");
		
		Query query = entityManager.createNativeQuery(queryStringBuf.toString());
		LOGGER.debug("Query for RAN Suggestion "+queryStringBuf.toString());
		List<Object[]> suggetedRanLocationList = query.getResultList();
		LOGGER.debug("*** getSuggestedRANandLocationForPartNumberWHOut suggetedRanLocationList size: " + suggetedRanLocationList.size());
		
		if(suggetedRanLocationList!=null && suggetedRanLocationList.size()>0){
			for (Iterator<Object[]> i = suggetedRanLocationList.iterator(); i.hasNext();) {
				suggestedRanLocationForPartNo = new SuggestedRANLocationForPartNoDTO();
				int indexCount = 0;
					Object[] suggetedRanLocation = (Object[]) i.next();
					suggestedRanLocationForPartNo.setPartNumber(
							(null == suggetedRanLocation[indexCount] ? "" : suggetedRanLocation[indexCount].toString()));
					indexCount++;
					suggestedRanLocationForPartNo.setRan(
							(null == suggetedRanLocation[indexCount] ? "" : suggetedRanLocation[indexCount].toString()));
					indexCount++;
					suggestedRanLocationForPartNo.setLocation(
							(null == suggetedRanLocation[indexCount] ? "" : suggetedRanLocation[indexCount].toString()));
					indexCount++;
					if (null != suggetedRanLocation[indexCount]) {
						suggestedRanLocationForPartNo.setQuantity((Integer) suggetedRanLocation[indexCount]);
						indexCount++;
					}
					if (null != suggetedRanLocation[indexCount]) {
						suggestedRanLocationForPartNo.setAgeddays((Integer) suggetedRanLocation[indexCount]);
						indexCount++;
					}
					suggetedRanLocationListAdd.add(suggestedRanLocationForPartNo);
			}
		}
		
		
		if(suggetedRanLocationList==null ||  suggetedRanLocationList.size()<5){
			LOGGER.debug("*** inside IF ELSE suggetedRanLocationList size: " + suggetedRanLocationList.size());
			StringBuffer queryStringBuffer = new StringBuffer();
			String plant= null;
			queryStringBuffer.append("SELECT TOP 5 PART_NO, RAN, LOCATION, CURRENT_QTY,PART_IN_OUT_TIME FROM( ");
			queryStringBuffer.append(" Select * from ( SELECT  top 5 PL.PART_NO,PL.RAN,LOCATION,CURRENT_QTY,PART_IN_OUT_TIME  ");
			queryStringBuffer.append("FROM  DBO.PARTINOUT_STAGING_AUDIT P INNER JOIN PART_LOCATION PL "); 
			queryStringBuffer.append("ON P.PART_NO=PL.PART_NO AND P.RAN=PL.RAN  AND P.LOCATION=PL.LOCATION_ID ");
			queryStringBuffer.append("WHERE  p.TRANSACTION_TYPE='IN' and P.PART_NO='"+suggestedRanLocationPartNo.getPartNumber()+"' ");
			if(suggestedRanLocationPartNo.getPlant()!= null){
				plant = suggestedRanLocationPartNo.getPlant();
				queryStringBuffer.append(" AND SUBSTRING(PL.LOCATION_ID,1,1) = '"+suggestedRanLocationPartNo.getPlant()+"' ");
			}else{
				plant = "G";
				queryStringBuffer.append(" AND SUBSTRING(PL.LOCATION_ID,1,1) = 'G' ");
			}
			//Added plant condition to avoid of getting duplicate RAN - End		
			//Added By Meena - To get both T and K shops when shop is selected in handy as 'T' - Start
			if(suggestedRanLocationPartNo.getShop().charAt(0) != 'T') {
				queryStringBuffer.append(" AND SUBSTRING(PL.LOCATION_ID,2,1) = '"+suggestedRanLocationPartNo.getShop()+"' ");
			}else {
				queryStringBuffer.append(" AND SUBSTRING(PL.LOCATION_ID,2,1) IN ('T','K') ");
			}
			queryStringBuffer.append("AND SUBSTRING(P.RAN,1,7) NOT IN (SELECT RAN FROM DBO.RAN WHERE PLANT = '"+plant+"' ) AND CURRENT_QTY>0 AND P.STATUS IS NULL ORDER BY PART_IN_OUT_TIME) a  ");
			queryStringBuffer.append("UNION ");
			queryStringBuffer.append(" Select * from ( SELECT top 5 PL.PART_NO,PL.RAN,PL.LOCATION_ID as LOCATION,CURRENT_QTY, ");
			queryStringBuffer.append("(CASE WHEN (SELECT  PART_IN_OUT_TIME FROM  DBO.PARTINOUT_STAGING_AUDIT WHERE part_pk=p.source_part_pk) ");  
			queryStringBuffer.append("IS NULL  THEN GETDATE() ELSE (SELECT PART_IN_OUT_TIME FROM  DBO.PARTINOUT_STAGING_AUDIT WHERE part_pk=p.source_part_pk) ");
			queryStringBuffer.append("END) ");
			queryStringBuffer.append("AS PART_IN_OUT_TIME ");
			queryStringBuffer.append("FROM  DBO.PARTINOUT_STAGING_AUDIT P INNER JOIN PART_LOCATION PL "); 
			queryStringBuffer.append("ON P.PART_NO=PL.PART_NO AND P.RAN=PL.RAN AND P.LOCATION_DESTINATION=PL.LOCATION_ID ");
			queryStringBuffer.append("WHERE  p.TRANSACTION_TYPE='MOVE' and P.PART_NO='"+suggestedRanLocationPartNo.getPartNumber()+"' ");
			if(suggestedRanLocationPartNo.getPlant()!= null){
				plant = suggestedRanLocationPartNo.getPlant();
				queryStringBuffer.append(" AND SUBSTRING(PL.LOCATION_ID,1,1) = '"+suggestedRanLocationPartNo.getPlant()+"' ");
			}else{
				plant = "G";
				queryStringBuffer.append(" AND SUBSTRING(PL.LOCATION_ID,1,1) = 'G' ");
			}
			//Added plant condition to avoid of getting duplicate RAN - End		
			//Added By Meena - To get both T and K shops when shop is selected in handy as 'T' - Start
			if(suggestedRanLocationPartNo.getShop().charAt(0) != 'T') {
				queryStringBuffer.append(" AND SUBSTRING(PL.LOCATION_ID,2,1) = '"+suggestedRanLocationPartNo.getShop()+"' ");
			}else {
				queryStringBuffer.append(" AND SUBSTRING(PL.LOCATION_ID,2,1) IN ('T','K') ");
			}
			queryStringBuffer.append("AND SUBSTRING(P.RAN,1,7) NOT IN (SELECT RAN FROM DBO.RAN WHERE PLANT = '"+plant+"' ) AND CURRENT_QTY>0 AND P.STATUS IS NULL ORDER BY PART_IN_OUT_TIME ) b ");
			queryStringBuffer.append(" ) c ORDER BY c.PART_IN_OUT_TIME ASC ");			
			
			Query suggestedRanLocationByAuditquery = entityManager.createNativeQuery(queryStringBuffer.toString());
			List<Object[]> suggetedRanLocationByAuditList = suggestedRanLocationByAuditquery.getResultList();
			LOGGER.debug("suggetedRanLocationByAuditList Query "+queryStringBuffer.toString());
			LOGGER.debug("*** getSuggestedRANandLocationForPartNumberWHOut suggetedRanLocationByAuditList size: " + suggetedRanLocationByAuditList.size());	
						
				/*for (int indexCount = 0; indexCount < suggetedRanLocationByAuditList.size(); indexCount++) {*/
			for (Iterator<Object[]> j = suggetedRanLocationByAuditList.iterator(); j.hasNext();) {
				suggestedRanLocationForPartNo = new SuggestedRANLocationForPartNoDTO();
				int indexCount = 0;
						Object[] suggetedRanLocation = (Object[]) j.next();
						suggestedRanLocationForPartNo.setPartNumber((null ==  suggetedRanLocation[indexCount] ? "": suggetedRanLocation[indexCount].toString()));
						indexCount++;
						suggestedRanLocationForPartNo.setRan((null ==  suggetedRanLocation[indexCount] ? "": suggetedRanLocation[indexCount].toString()));
						indexCount++;
						suggestedRanLocationForPartNo.setLocation((null ==  suggetedRanLocation[indexCount] ? "": suggetedRanLocation[indexCount].toString()));
						indexCount++;
						if(null != suggetedRanLocation[indexCount]){
							suggestedRanLocationForPartNo.setQuantity((Integer) (null == suggetedRanLocation[indexCount] ? 0 : suggetedRanLocation[indexCount]));
							indexCount++;
						}
						if(suggetedRanLocationListAdd.size()<5)	{
						suggetedRanLocationListAdd.add(suggestedRanLocationForPartNo);
						}
				}
		}
		LOGGER.debug("*** suggetedRanLocationListAdd size: " + suggetedRanLocationListAdd.size());
		return suggetedRanLocationListAdd;
	}
	
	
	//Added for fifo suggestion override validation
	public FIFOSuggestionOverrideValidationDTO getFIFOSuggestionOverrideValidation(
			FIFOSuggestionOverrideInputDTO fIFOSuggestionOverrideDTO) {
		FIFOSuggestionOverrideValidationDTO fIFOSuggestionOverrideValidationDTO = new FIFOSuggestionOverrideValidationDTO();

		StringBuffer queryStringBuf = null;
		Query query = null;
		
		queryStringBuf= new StringBuffer();
		queryStringBuf.append("select count(*) from [dbo].[part_location]");
		queryStringBuf.append(" where LOCATION_ID = '"+fIFOSuggestionOverrideDTO.getLocation()+"'");
		queryStringBuf.append(" and PART_NO = '"+fIFOSuggestionOverrideDTO.getPartNumber()+"'");
		queryStringBuf.append(" and RAN  = '"+fIFOSuggestionOverrideDTO.getRan()+"'");
		
		query = entityManager.createNativeQuery(queryStringBuf.toString());
		int count = (Integer) query.getSingleResult();
		
		if(count > 0) {
			queryStringBuf= new StringBuffer();
			queryStringBuf.append("select CURRENT_QTY from [dbo].[part_location]");
			queryStringBuf.append(" where LOCATION_ID = '"+fIFOSuggestionOverrideDTO.getLocation()+"'");
			queryStringBuf.append(" and PART_NO = '"+fIFOSuggestionOverrideDTO.getPartNumber()+"'");
			queryStringBuf.append(" and RAN  = '"+fIFOSuggestionOverrideDTO.getRan()+"'");
			
			query = entityManager.createNativeQuery(queryStringBuf.toString());
			
			int ranCount = (Integer) query.getSingleResult();
			fIFOSuggestionOverrideValidationDTO.setRanCount(ranCount);
			fIFOSuggestionOverrideValidationDTO.setSuccFailMsg("S200");
		} else 	{
			fIFOSuggestionOverrideValidationDTO.setRanCount(0);
			fIFOSuggestionOverrideValidationDTO.setSuccFailMsg("F200");
		}
		
		return fIFOSuggestionOverrideValidationDTO;
	}
	
	public WhMovementRanValidationOutDTO getWhMovementRanValidation(
			WhMovementRanValidationInDTO whMovementRanValidationInDTO) {
		// TODO Auto-generated method stub
		
		WhMovementRanValidationOutDTO whMovementRanValidationOutDTO = new WhMovementRanValidationOutDTO();
		StringBuffer queryStringBuf = null;
		Query query = null;
		
		queryStringBuf= new StringBuffer();
		queryStringBuf.append("select count(*) from [dbo].[PARTINOUT_STAGING_AUDIT] A INNER JOIN PART_LOCATION PL");
		queryStringBuf.append("  ON PL.PART_NO=A.PART_NO AND PL.LOCATION_ID=A.LOCATION AND PL.RAN=A.RAN");
		queryStringBuf.append(" WHERE A.PART_NO='"+whMovementRanValidationInDTO.getPartNumber()+"'");
		queryStringBuf.append(" AND A.LOCATION='"+whMovementRanValidationInDTO.getLocation()+"'");
		queryStringBuf.append(" AND A.RAN='"+whMovementRanValidationInDTO.getRan()+"'");
		queryStringBuf.append(" AND A.TRANSACTION_TYPE='IN' AND PL.CURRENT_QTY >0 ");
		queryStringBuf.append(" AND A.PART_IN_OUT_TIME >DATEADD(year,-1,getdate()) ");
		
		query = entityManager.createNativeQuery(queryStringBuf.toString());
		String count = query.getSingleResult().toString();
		
		whMovementRanValidationOutDTO.setOutFlg(count);
		return whMovementRanValidationOutDTO;
	}
	
	public Set<RANSuggestionDTO> getRanListByPlant(String inputRan,RANDTO dto)
	{
		LOGGER.debug("*****IN getRanListByPlant bean" + inputRan);
		 Set<RANSuggestionDTO> ranSet = new HashSet<RANSuggestionDTO>();
		 Query query = entityManager.createNativeQuery("select distinct ran from Ran where plant='"+dto.getPlant()+"' and ran LIKE :val order by ran asc ");
		query.setParameter("val", inputRan + "%");
		query.setMaxResults(10);
		List<String> ranList = query.getResultList();
		LOGGER.debug("*****IN getRanListByPlant bean result" + ranList.size());
		   for(String ran : ranList){
	        	RANSuggestionDTO ranDTO = new RANSuggestionDTO();
	        	ranDTO.setText(ran);
	        	ranSet.add(ranDTO);
	        }
		 return ranSet;
	}
}
