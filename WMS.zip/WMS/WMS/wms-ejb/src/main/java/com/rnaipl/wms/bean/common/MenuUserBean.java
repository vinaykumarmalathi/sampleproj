package com.rnaipl.wms.bean.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.MenuDTO;
import com.rnaipl.wms.dto.common.MenuUserDTO;
import com.rnaipl.wms.entities.Menu;
import com.rnaipl.wms.entities.User;
import com.rnaipl.wms.util.WMSBeanConstants;

@Stateless
@LocalBean
public class MenuUserBean implements MenuUser {
	
	 private static final Logger LOGGER = Logger.getLogger(MenuUserBean.class);

	    @PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	    private EntityManager entityManager;


	
	public LinkedHashMap<Integer, MenuDTO>  getMenuForUser(String userId){
		LinkedHashMap<Integer, MenuDTO> menuMap = new LinkedHashMap();
		User user= entityManager.find(User.class, userId);
		//if(user != null){
			StringBuffer queryStringBuf = new StringBuffer();
			queryStringBuf.append(" SELECT m.*,u.USER_ID FROM MENU m");
			queryStringBuf.append(" LEFT JOIN (SELECT * from USER_MENU WHERE USER_ID='"+userId+"') u");
			queryStringBuf.append(" on m.MENU_ID = u.MENU_ID");
			queryStringBuf.append(" ORDER BY m.ORDER_NUMBER");
			LOGGER.debug("getMenuForUser --> queryStringBuf"+queryStringBuf.toString() );
			Query query = entityManager.createNativeQuery(queryStringBuf.toString());
			List<Object[]> menuList = query.getResultList();
			if (null != menuList && menuList.size() > 0) {
	            for (Iterator<Object[]> i = menuList.iterator(); i.hasNext();) {
		            int indexCount=0;
		            Object[] values = (Object[]) i.next();
					MenuDTO menuDTO = new MenuDTO();
					menuDTO.setMenuId(null == values[indexCount] ? "" : values[indexCount].toString());	               
		            indexCount++;	
		            menuDTO.setMenuName(null == values[indexCount] ? "" : values[indexCount].toString());	               
		            indexCount++;
		            menuDTO.setParentId((Integer.parseInt(values[indexCount].toString())));	               
		            indexCount++;
		            menuDTO.setMenuLevel((Integer)values[indexCount]);	               
		            indexCount++;
		            menuDTO.setOrderNumber((Integer)values[indexCount]);	               
		            indexCount++;
		            menuDTO.setPath(null == values[indexCount] ? "" : values[indexCount].toString());	               
		            indexCount++;
		            if(null != values[indexCount]){
			            menuDTO.setChecked(true); 
			            }
		            indexCount++;
					menuMap.put(Integer.parseInt(menuDTO.getMenuId()), menuDTO);
		            //menuMap.put(menuDTO.getOrderNumber(), menuDTO);
	            }
			}
		//}
		return menuMap; 
	}
	
	public LinkedList<MenuDTO>  getMenuTreeAsList(LinkedHashMap<Integer, MenuDTO> menuMap){
		LinkedList<MenuDTO> menuList = new LinkedList();
		for (Map.Entry<Integer, MenuDTO> entry : menuMap.entrySet()) {
			MenuDTO menuItem = entry.getValue();
			if(menuItem.getParentId()!=0){
	   			MenuDTO parent = menuMap.get(menuItem.getParentId());
	   			if(parent!=null){
		   			parent.addChild(menuItem);
	   			}
			}
			
			if(menuItem.getParentId()==0){
	 		    	menuList.add(menuItem)	;
	 		}
		}
		return menuList;
	}
	
	public void addUserMenu(MenuUserDTO userMenuDTO){
		User user= entityManager.find(User.class, userMenuDTO.getUserId());
		
		List<String> userMenu = userMenuDTO.getMenuList();
		List<Menu> menus = new ArrayList();
		if(user==null)
		{
			user=new User();
			user.setUserId(userMenuDTO.getUserId());
			user.setUserName(userMenuDTO.getUserId());
			user.setRole("1");
		}
		//if(user!=null){
			for(String userMenus : userMenu){
				Menu menu = new Menu();
				menu.setMenuId(userMenus);
				menus.add(menu);
			}
		//}
		LOGGER.debug("Adding  menu for  User " + user.getUserId());
		user.setMenus(menus);
		entityManager.merge(user);
	//	entityManager.persist(user);
	}
	
}
	
