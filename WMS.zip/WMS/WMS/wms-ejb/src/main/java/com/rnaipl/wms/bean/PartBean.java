package com.rnaipl.wms.bean;


import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.PartDTO;
import com.rnaipl.wms.dto.PartLocationDTO;
import com.rnaipl.wms.dto.PartLocationDownloadReportDTO;
import com.rnaipl.wms.dto.PartLocationSynchroInputDTO;
import com.rnaipl.wms.dto.PartLocationSynchroServiceDTO;
import com.rnaipl.wms.dto.PartNumberDTO;
import com.rnaipl.wms.dto.PartSearchDTO;
import com.rnaipl.wms.entities.Location;
import com.rnaipl.wms.entities.PartLocation;
import com.rnaipl.wms.entitiesPK.PartLocationPK;
import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSBeanUtil;

/**
 * 
 * @author TechM
 * 
 */
@Stateless
@LocalBean
public class PartBean  implements Part{

	private static final Logger LOGGER = Logger.getLogger(PartBean.class);

    @PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
    private EntityManager entityManager;

    /**
     * method to fetch all the part details
     */
    public List<PartDTO> getAllParts() {
        // TODO Auto-generated method stub
        LOGGER.debug("*****IN Get All Parts Bean ");
        List<PartDTO> parts = new ArrayList<PartDTO>();
        Query query = entityManager.createQuery("select p from Part p");     
        List<com.rnaipl.wms.entities.Part> partList = query.getResultList();
        LOGGER.debug("*****Part List Size"+partList.size());
        if(!partList.isEmpty() && partList.size() > 0 ){
	        for (com.rnaipl.wms.entities.Part part : partList) {
	        	PartDTO partDTO = new PartDTO();
	        	List<String> partLocations = new ArrayList<String>();
	        	partDTO.setCategory(part.getCategory());
	        	partDTO.setCreatedBy(part.getCreatedBy());
	        	partDTO.setCreatedOn(part.getCreatedOn());
	        	partDTO.setDepoCode(part.getDepoCode());
	        	partDTO.setDtlFlag(part.getDtlFlag());
	        	partDTO.setLeadTime(part.getLeadTime());
	        	//one-many relationship for parts & location implemented logic will be changed accordingly <TODO>
	        	for(com.rnaipl.wms.entities.Location location : part.getLocations()) {
	        		partLocations.add(location.getLocationId());
	        	}
	        	partDTO.setLocations(partLocations);
	        	partDTO.setPartName(part.getPartName());
	        	partDTO.setPartNumber(part.getPartNo());
	        	partDTO.setPartType(part.getPartType());
	        	partDTO.setRePackingFlag(part.getRepackingFlag());
	        	partDTO.setSafetyStock(part.getSafetyStock());
	        	partDTO.setSafetyStock(part.getSnp());
	        	partDTO.setSupplierCode(part.getSupplierCode());
	        	partDTO.setUpdatedBy(part.getUpdatedBy());
	        	partDTO.setUpdatedOn(part.getUpdatedOn());
	        	parts.add(partDTO);
	        }
        }
        LOGGER.debug("getAllParts() method Ends ");
        return parts;
        
    }
    
    /**
     * method to fetch all the part Numbers
     */
    public Set<PartNumberDTO> getPartNumbers(String partNumber) {
        // TODO Auto-generated method stub
        LOGGER.debug("*****IN Get All Parts Bean ");
        Set<PartNumberDTO> parts = new HashSet<PartNumberDTO>();
        Query query = entityManager.createQuery("select DISTINCT(p.partNo) from Part p where p.partNo LIKE :val");
        query.setParameter("val", partNumber + "%");
        query.setMaxResults(10);
        //Query query = entityManager.createQuery("select DISTINCET(l.locationId) from Location l join l.parts part where part.partNo LIKE :val").setParameter("val", "%" + partNumber + "%");
        List<String> partList = query.getResultList();
        LOGGER.debug("*****Part List Size"+partList.size());
        for(String part : partList){
        	PartNumberDTO partNumberDTO = new PartNumberDTO();
        	partNumberDTO.setText(part);
        	parts.add(partNumberDTO);
        }
        return parts;
        
    }
    
    public List<PartDTO> callProcedureQuery(){
    	LOGGER.debug("*** Before Calling Procedure execute"+ Calendar.getInstance().getTime());
        Query query = entityManager.createNativeQuery("exec temp_procedure");
        //List<PartinoutStaging> partList = query.getResultList();
        query.getResultList();
        query.executeUpdate();
        LOGGER.debug("*** After Calling Procedure"+ Calendar.getInstance().getTime());
        
        
        LOGGER.debug("getAllParts() method Ends ");
        //return parts;
        return null;
    }
    
    public List<PartLocationSynchroServiceDTO> getPartLocationSynchroService(PartLocationSynchroInputDTO partLocationSynchroInputDTO) {
		
    LOGGER.debug("In PartSynchro Service ENTRY StartTime -->" + System.currentTimeMillis());
    long startTime = System.currentTimeMillis();
    List<PartLocationSynchroServiceDTO> partLocationSynchroServiceDTOs = new ArrayList<PartLocationSynchroServiceDTO>();
   	List shopList = new ArrayList<String>();   	
   	StringBuffer queryStringBuf = new StringBuffer();
   	
   	if(partLocationSynchroInputDTO!=null && partLocationSynchroInputDTO.getShop()!=null)
 	{
   		shopList.add(partLocationSynchroInputDTO.getShop());
   		
   		/*if(plant == G){
   			if(partLocationSynchroInputDTO.getShop().equalsIgnoreCase("T"))
   	   		{
   	   			shopList.add("K");
   	   		}else{
   	   		shopList.add("c or B");
   	   		}
   		}else if(plant == D){
				if (partLocationSynchroInputDTO.getShop().trim().equalsIgnoreCase("A")) {
					shopList.add("B");
				} else if (partLocationSynchroInputDTO.getShop().trim().equalsIgnoreCase("B"))
					shopList.add("A");
			}
   		}*/
   		
   		
   		
   		if(partLocationSynchroInputDTO.getShop().equalsIgnoreCase("T"))
   		{
   			shopList.add("K");
   		}
   		if(partLocationSynchroInputDTO.getShop().trim().equalsIgnoreCase("A"))
   		{
   			shopList.add("B");
   		}
   		
 	}
  	 
   		queryStringBuf.append(" SELECT '' AS PART_NO,L.LOCATION_ID, 1 AS SNP, 1 AS SNIP,'' AS CATEGORY,'' AS SHELF_LIFE_PART FROM DBO.LOCATION L  ");
   		queryStringBuf.append("	WHERE LOCATION_ID NOT IN (SELECT DISTINCT LOCATION_ID FROM DBO.PART_LOCATION) ");	
   		
   	   	if(partLocationSynchroInputDTO!=null && partLocationSynchroInputDTO.getShop()!=null)
	   	{
	   		queryStringBuf.append(" AND SUBSTRING(L.LOCATION_ID, 2, 1) IN (:shops) ");
	   		
	   	}
   		queryStringBuf.append(" UNION ");
   		queryStringBuf.append(" SELECT DISTINCT P.PART_NO AS PART_NO, PL.LOCATION_ID AS LOCATION_ID, P.SNP AS SNP, P.SNIP AS SNIP, P.CATEGORY AS CATEGORY, ");
   		queryStringBuf.append(" P.SHELF_LIFE_PART AS SHELF_LIFE_PART");
	  	queryStringBuf.append(" FROM PART P, PART_LOCATION PL ");
	  	queryStringBuf.append(" WHERE P.PART_NO = PL.PART_NO  ");
	  	//queryStringBuf.append(" AND SNP!=0 AND SNP IS NOT NULL ");
	  	
	   	if(partLocationSynchroInputDTO!=null && partLocationSynchroInputDTO.getShop()!=null)
	   	{
	   		queryStringBuf.append(" AND SUBSTRING(PL.LOCATION_ID, 2, 1) IN (:shops) ");
	   		
	   	}
   	
        
        LOGGER.debug("Query :  " + queryStringBuf.toString());
   	
        Query query = entityManager.createNativeQuery(queryStringBuf.toString());
    	if(partLocationSynchroInputDTO!=null && partLocationSynchroInputDTO.getShop()!=null){
    		LOGGER.debug("*Shop Filtered" + partLocationSynchroInputDTO.getShop());
    		query.setParameter("shops", shopList);
    	}
        List<Object[]> partLocationSynchroService = query.getResultList();
        LOGGER.debug("partLocationSynchroService size " + partLocationSynchroService.size());
        
        if(null != partLocationSynchroService && partLocationSynchroService.size() > 0) {
            for (Iterator<Object[]> i = partLocationSynchroService.iterator(); i.hasNext();) {
            	int indexCount=0;    	
                Object[] values = (Object[]) i.next();
                PartLocationSynchroServiceDTO partLocationSynchroServiceDTO = new PartLocationSynchroServiceDTO();
                
                partLocationSynchroServiceDTO.setPartNumber((null == values[indexCount] ? "" : values[indexCount].toString()));
                indexCount++;
                partLocationSynchroServiceDTO.setLocationId((null == values[indexCount] ? "" : values[indexCount].toString()));
                indexCount++;
                partLocationSynchroServiceDTO.setSnp((Integer)(null == values[indexCount] ? 0 : values[indexCount]));
                indexCount++;
                partLocationSynchroServiceDTO.setSnip((Integer)(null == values[indexCount] ? 0 : values[indexCount]));
                indexCount++;
                partLocationSynchroServiceDTO.setCategory((null == values[indexCount] ? "" : values[indexCount].toString()));
                indexCount++;
                partLocationSynchroServiceDTO.setShelfLifePart((null == values[indexCount] ? "" : values[indexCount].toString()));
                partLocationSynchroServiceDTOs.add(partLocationSynchroServiceDTO)  ;  
            }
        }
   
    long timeTaken = System.currentTimeMillis() - startTime;
    LOGGER.fatal("Time taken for Part Synchro Service," + timeTaken); 
    
   	return partLocationSynchroServiceDTOs;
   }
    
	public List<PartLocationDownloadReportDTO> partDownload(PartSearchDTO part) {
		
	    List<PartLocationDownloadReportDTO> partLocationDownloadDataList = new ArrayList<PartLocationDownloadReportDTO>();
	    StringBuffer downloadQuery = new StringBuffer();
	    downloadQuery.append("SELECT  P.PART_TYPE, P.PART_NO, P.PART_NAME, P.SUPPLIER_CODE, P.DEPO_CODE, P.PART_CATEGORY, P.CATEGORY, P.SNP, P.SNIP, P.DEL_PLC, P.EOP_MARK, P.SHELF_LIFE_AGING,"
	    		+ "P.SHELF_LIFE_PART, P.SHELF_LIFE_PERIOD, ");
	    downloadQuery.append(" P.MIXED_MODULE, P.REPACKING_FLAG, P.REPACK_SNP, P.DOL_FLAG, P.DTL_FLAG, P.ADOPT_DATE, P.ABOLISH_DATE,PLQ.LOCATION_ID,PLQ.CURRENT_QTY ");
	    downloadQuery.append(" FROM DBO.PART P LEFT JOIN ");
	    downloadQuery.append(" (SELECT PL.PART_NO AS PART_NO,PL.LOCATION_ID AS LOCATION_ID,SUM(PL.CURRENT_QTY) AS CURRENT_QTY FROM DBO.PART_LOCATION PL GROUP BY PL.PART_NO,PL.LOCATION_ID) PLQ ");
	    downloadQuery.append(" ON P.PART_NO=PLQ.PART_NO ");
	    downloadQuery.append("WHERE 1=1");
	    if (null != part.getPlant() && !part.getPlant().equals("")) {
            downloadQuery.append(" AND SUBSTRING(PLQ.LOCATION_ID, 1, 1) = '" + part.getPlant() + "'");
        }
	    if (null != part.getShop() && !part.getShop().equals("")) {
            downloadQuery.append(" AND SUBSTRING(PLQ.LOCATION_ID, 2, 1) = '" + part.getShop() + "'");
        }
	    
	    Query query = entityManager.createNativeQuery(downloadQuery.toString());
	    List<Object[]> partLocations = query.getResultList();
	    LOGGER.debug("***Part Download List Size "  + partLocations.size());
	    int indexCount=0;
	    if (null != partLocations && partLocations.size() > 0) {
            for (Iterator<Object[]> i = partLocations.iterator(); i.hasNext();) {
            	indexCount=0;
                Object[] values = (Object[]) i.next();
                PartLocationDownloadReportDTO partLocationReportDto = new PartLocationDownloadReportDTO();
                partLocationReportDto.setPartType(null == values[indexCount] ? "" : values[indexCount].toString());
                indexCount++;
                partLocationReportDto.setPartNumber(null == values[indexCount] ? "" : values[indexCount].toString());
                indexCount++;
                partLocationReportDto.setPartName(null == values[indexCount] ? "" : values[indexCount].toString());
                indexCount++;
                partLocationReportDto.setSupplierCode(null == values[indexCount] ? "" : values[indexCount].toString());
                indexCount++;
                partLocationReportDto.setDepoCode(null == values[indexCount] ? "" : values[indexCount].toString());
                indexCount++;
                partLocationReportDto.setPartCategory(null == values[indexCount] ? "" : values[indexCount].toString());
                indexCount++;
                partLocationReportDto.setCategory(null == values[indexCount] ? "" : WMSBeanUtil.getCategoryDesc(values[indexCount].toString()));
                indexCount++;
                partLocationReportDto.setSnp((Integer) (null == values[indexCount] ? 0 : values[indexCount]));
                indexCount++;
                partLocationReportDto.setSnip((Integer) (null == values[indexCount] ? 0 : values[indexCount]));
                indexCount++;
                partLocationReportDto.setReceivingPort(null == values[indexCount] ? "" : values[indexCount].toString());
                indexCount++;
                partLocationReportDto.setEopMark(null == values[indexCount] ? "" : values[indexCount].toString());
                indexCount++;
                partLocationReportDto.setShelfLifeAging(null == values[indexCount] ? "" : values[indexCount].toString());
                indexCount++;
                partLocationReportDto.setShelfLifePart(null == values[indexCount] ? "" : values[indexCount].toString());
                indexCount++;
                partLocationReportDto.setShelfLifePeriod((Integer) (null == values[indexCount] ? 0 : values[indexCount]));
                indexCount++;
                partLocationReportDto.setMixedModule(null == values[indexCount] ? "" : values[indexCount].toString());
                indexCount++;
                partLocationReportDto.setRePackingFlag(null == values[indexCount] ? "" : values[indexCount].toString());
                indexCount++;
                partLocationReportDto.setRepackSNP((Integer) (null == values[indexCount] ? 0 : values[indexCount]));
                indexCount++;
                partLocationReportDto.setDolFlag(null == values[indexCount] ? "" : values[indexCount].toString());
                indexCount++;
                partLocationReportDto.setDtlFlag(null == values[indexCount] ? "" : values[indexCount].toString());              
                indexCount++;
                if(values[indexCount]!=null)
                {
                //	partLocationReportDto.setAdoptDateString();2014-06-07
                	partLocationReportDto.setAdoptDateString(values[indexCount].toString().substring(0,10));
                	
                }
                
                indexCount++;
                if(values[indexCount]!=null)
                {
                	partLocationReportDto.setAbolishDateString(values[indexCount].toString().substring(0,10));
                }
                
                indexCount++;
                partLocationReportDto.setLocationId(null == values[indexCount] ? "" : values[indexCount].toString());
                indexCount++;
             //   partLocationReportDto.setRan(null == values[indexCount] ? "" : values[indexCount].toString());
               // indexCount++;
                partLocationReportDto.setCurrentQty((Integer) (null == values[indexCount] ? 0 : values[indexCount]));
                indexCount++;
                partLocationReportDto.setTotalCapacity(0);
                
                
                partLocationDownloadDataList.add(partLocationReportDto);
            }

        }
	    
	    
    	return partLocationDownloadDataList;
    }

	public List<PartDTO> getPartSearchData(PartSearchDTO part) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
        LOGGER.debug("*****IN Get All Parts Bean ");
        List<PartDTO> parts = new LinkedList<PartDTO>();
        
        Query query = getPartSearchQuery(part, 2);
        query.setFirstResult(part.getStartIndex());
        query.setMaxResults(part.getEndIndex());
        
        List<com.rnaipl.wms.entities.Part> partList = query.getResultList();
        LOGGER.debug("*****Part List Size"+partList.size());
        for (com.rnaipl.wms.entities.Part partData : partList) {
        	PartDTO partDTO = new PartDTO();
          	partDTO.setPartNumber( partData.getPartNo());
          	partDTO.setPartName(partData.getPartName());          	
          	partDTO.setPartType(partData.getPartType());
          	partDTO.setCategory(partData.getCategory());
          	partDTO.setCategoryDesc(WMSBeanUtil.getCategoryDesc(partData.getCategory()));
          	partDTO.setSupplierCode(partData.getSupplierCode());
          	partDTO.setDepoCode(partData.getDepoCode());
          	partDTO.setSnp(partData.getSnp());
          	partDTO.setSnip(partData.getSnip());
          	partDTO.setDelPlc(partData.getDelPlc());
          	partDTO.setReceivingPort(partData.getDelPlc());
          	partDTO.setEopMark(partData.getEopMark());
          	partDTO.setMixedModule(partData.getMixedModule());
          	partDTO.setRePackingFlag(partData.getRepackingFlag());
          	partDTO.setRepackSNP(partData.getRepackSNP());
          	partDTO.setDolFlag(partData.getDolFlag());//requires change
        	partDTO.setDtlFlag(partData.getDtlFlag());
        	partDTO.setPcCode(partData.getPcCode());        	
        	partDTO.setAdoptDate(partData.getAdoptDate());        	
        	partDTO.setAbolishDate(partData.getAbolishDate());
        	partDTO.setShelfLifeAging(partData.getShelfLifeAging());
        	partDTO.setShelfLifePart(partData.getShelfLifePart());
        	partDTO.setShelfLifePeriod(partData.getShelfLifePeriod());
        	partDTO.setUpdatedOn(partData.getUpdatedOn());
        	partDTO.setChangeLog(partData.getChangeLog());
        	partDTO.setPartCategory(partData.getPartCategory());
        	partDTO.setNoOfLocations(partData.getLocations().size());
        //	LOGGER.debug("** No of location for part " + partData.getPartNo() + "-->" + );
        	
        //	Temporary to support old screenR
        	partDTO.setText(partData.getPartNo());
        	
        	parts.add(partDTO);
        }
        return parts;
	}
	
	public int getPartCount(PartSearchDTO part) {
        //List<PartDTO> parts = new ArrayList<PartDTO>();
        Query query = getPartSearchQuery(part, 1);
        Long partCount = (Long) query.getSingleResult();
		return partCount.intValue();
	}

	/**
	 * @param part
	 * @param flag
	 */
	private Query getPartSearchQuery(PartSearchDTO part, int flag) {
		StringBuffer searchQuery = new StringBuffer();
        boolean locConditions = false;
        if(!part.isUnreleasedParts() && ((part.getLocations() != null && !part.getLocations().equals("")) || (part.getPlant() != null && !part.getPlant().equals(""))
            	|| (part.getShop() != null && !part.getShop().equals("")) || (part.getLine() != null && !part.getLine().equals("")))){
        	locConditions = true;
        }
        if(2 == flag){
        	searchQuery.append("select part from Part part where part.partNo IN ( ");
            searchQuery.append("select distinct p.partNo from Part p ");
        }else{
        	searchQuery.append("select count(distinct p.partNo) from Part p");
        }
		if(locConditions){
        	 searchQuery.append(" , Location loc, PartLocation pl");
        }
        searchQuery.append(" WHERE 1=1");
        if(part.getPartName()!=null && !part.getPartName().equals("")){
        	searchQuery.append(" AND p.partName = :partName");
        }
        if(part.getPartNumber() != null && !part.getPartNumber().equals("")){
        	searchQuery.append(" AND p.partNo IN (:partNos)");
        }
        if(part.getPartType() != null && !part.getPartType().equals("")){
        	searchQuery.append(" AND p.partType = :partType");
        }
        if(part.getCategory() != null && !part.getCategory().equals("")){
        	searchQuery.append(" AND p.category = :category");
        }
        if(part.getSupplierCode() != null && !part.getSupplierCode().equals("")){
        	searchQuery.append(" AND p.supplierCode IN (:suppliers)");
        }
        if(locConditions){
        	searchQuery.append(" AND pl.id.partNo = p.partNo ")
			.append(" AND pl.id.locationId = loc.locationId ");
		        if(part.getLocations() != null && !part.getLocations().equals("")){
		        	searchQuery.append(" AND loc.locationId IN (:locations) ");
		        }
		        if(part.getPlant() != null && !part.getPlant().equals("")){
		        	searchQuery.append(" AND loc.plant.plantId = :plant ");
		        }
		        if(part.getShop() != null && !part.getShop().equals("")){
		        	searchQuery.append(" AND loc.shop.shopId = :shop ");
		        }
		        if(part.getLine() != null && !part.getLine().equals("")){
		        	searchQuery.append(" AND loc.line.lineId = :line ");
		        }
        }else if(part.isUnreleasedParts()){// An unreleased part - a part without location allocated or the updated on value is null
        	searchQuery.append(" AND (p.partNo NOT IN (SELECT pp.id.partNo FROM PartLocation pp ))");
        }
        if(2 == flag){
        	searchQuery.append(" ) ORDER BY part.partNo");
        }
        LOGGER.debug("Part Query ::: "+searchQuery.toString());
        Query query = entityManager.createQuery(searchQuery.toString());
        /*if(part.getPartName()!=null && !part.getPartName().equals("")){
        	query.setParameter("partName", part.getPartName());
        }*/
        if(part.getPartNumber() != null && !part.getPartNumber().equals("")){
        	query.setParameter("partNos", part.getPartList());
        }
        if(part.getPartType() != null && !part.getPartType().equals("")){
        	query.setParameter("partType", part.getPartType());
        }
        if(part.getSupplierCode() != null && !part.getSupplierCode().equals("")){
        	query.setParameter("suppliers", part.getSupplierCodeList());
        }
        if(part.getCategory() != null && !part.getCategory().equals("")){
        	query.setParameter("category", part.getCategory());
        }
        if(locConditions){
	        if(part.getLocations() != null && !part.getLocations().equals("")){
	        	query.setParameter("locations", part.getLocationList());
	        }
	        if(part.getPlant() != null && !part.getPlant().equals("")){
	        	query.setParameter("plant", part.getPlant());
	        }
	        if(part.getShop() != null && !part.getShop().equals("")){
	        	query.setParameter("shop", part.getShop());
	        }
	        if(part.getLine() != null && !part.getLine().equals("")){
	        	query.setParameter("line", part.getLine());
	        }
        }
       return query;
	}
	
	

	public String insertPart(PartDTO partDto) {
		// TODO Auto-generated method stub
		com.rnaipl.wms.entities.Part existPart = entityManager.find(com.rnaipl.wms.entities.Part.class, partDto.getPartNumber());
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		if(existPart != null) {
			return "1";
		} 
		com.rnaipl.wms.entities.Part part = new com.rnaipl.wms.entities.Part();
		part.setDelPlc(partDto.getDelPlc());
		part.setPcCode(partDto.getPcCode());
		part.setSnip(partDto.getSnip());
		part.setCategory(partDto.getCategory());
		part.setCreatedBy(partDto.getUserId());
		part.setCreatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
		part.setDepoCode(partDto.getDepoCode());
		part.setLeadTime(partDto.getLeadTime());
		part.setPartName(partDto.getPartName());
		part.setPartNo(partDto.getPartNumber().toUpperCase());
		part.setPartType(partDto.getPartType());
		part.setSafetyStock(partDto.getSafetyStock());
		part.setSnp(partDto.getSnp());
		part.setSupplierCode(partDto.getSupplierCode());
		part.setEopMark(partDto.getEopMark());
		part.setMixedModule(partDto.getMixedModule());
		part.setRepackingFlag(partDto.getRePackingFlag());
		part.setRepackSNP(partDto.getRepackSNP());
		part.setDtlFlag(partDto.getDtlFlag());
		part.setDolFlag(partDto.getDolFlag());
		part.setAbolishDate(null == partDto.getAbolishDate() ? null : new java.sql.Date((partDto.getAbolishDate()).getTime()));
		part.setAdoptDate(null == partDto.getAdoptDate() ? null : new java.sql.Date((partDto.getAdoptDate()).getTime()));
		part.setShelfLifeAging(partDto.getShelfLifeAging());
		part.setShelfLifePart(partDto.getShelfLifePart());
		part.setShelfLifePeriod(partDto.getShelfLifePeriod());
		part.setUpdatedBy(partDto.getUserId());
		part.setUpdatedOn(new Timestamp(date.getTime()));
		part.setPartCategory(partDto.getPartCategory());
		String changeLog = partDto.getUserId()+"##"+dateFormat.format(date)+"##"+partDto.getRemarks();	
		part.setChangeLog(changeLog);
		entityManager.persist(part);
		return "0";
	}
		
		
	
	public String updatePart(List<PartDTO> partDtos) {
		// TODO Auto-generated method stub
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		for(PartDTO partDto:partDtos){
			LOGGER.debug("partDto.getAbolishDate() ::: "+partDto.getAbolishDate());
			LOGGER.debug("partDto.getShelfLifePart() ::: "+partDto.getShelfLifePart());
			com.rnaipl.wms.entities.Part part = entityManager.find(com.rnaipl.wms.entities.Part.class, partDto.getPartNumber());
			if(part != null) {
				LOGGER.debug("part.getPartNo() ::: "+part.getPartNo());
				LOGGER.debug("part.getSnp() ::: "+part.getSnp());
				updatePart(part, partDto, date);
				//String remarks = null == partDto.getRemarks() ? "" : partDto.getComments();
				String changeLog = partDto.getUserId()+"##"+dateFormat.format(date)+"##"+partDto.getRemarks();			
				if(part.getChangeLog() != null) {
					part.setChangeLog(part.getChangeLog()+"^^"+changeLog);
				} else {
					part.setChangeLog(changeLog);
				}
				entityManager.merge(part); 
			}
		} 
		return "0";
	}
	

	
	public String deletePart(PartSearchDTO partDto) {
		// TODO Auto-generated method stub
		com.rnaipl.wms.entities.Part part = entityManager.find(com.rnaipl.wms.entities.Part.class, partDto.getPartNumber());
		if(part != null) {
			if(!part.getLocations().isEmpty() && part.getLocations().size() > 0 ) {
				// returns "1" if - part is allocatted to any location
				return "1";
			} else  {
				entityManager.remove(part);
				//if part is not allocated into any location return "0"
				return "0";
			}
		} else {
			//part is not in the database it will return "2"
			return "2";
		}
	}


	
	public PartSearchDTO getPartByPartNumber(String partNumber) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
        LOGGER.debug("*****IN Get All Parts Bean ");
        PartSearchDTO partDTO = null;
        com.rnaipl.wms.entities.Part part = entityManager.find(com.rnaipl.wms.entities.Part.class, partNumber);
        //Query query = entityManager.createQuery("select DISTINCET(l.locationId) from Location l join l.parts part where part.partNo LIKE :val").setParameter("val", "%" + partNumber + "%");
        if(part != null){
        	LOGGER.debug("Part exist in the database -- "+part.getPartNo());
        	partDTO = setPartData(part);
        }else{
        	partDTO = new PartSearchDTO();
        	partDTO.setStatus(2);
        	partDTO.setPartNumber(partNumber);
        }
        return partDTO;
	}

	private PartSearchDTO setPartData(com.rnaipl.wms.entities.Part part){
		PartSearchDTO partDTO = new PartSearchDTO();
		String locations = null;
    	List<String> partLocations = new ArrayList<String>();
		Map<String,Integer> locationCount = new HashMap<String, Integer>();
    	List<String> changeLogs = new ArrayList<String>();
    	partDTO.setCategory(part.getCategory());
    	partDTO.setCreatedBy(part.getCreatedBy());
    	partDTO.setCreatedOn(part.getCreatedOn());
    	partDTO.setDepoCode(part.getDepoCode());
    	partDTO.setDtlFlag(part.getDtlFlag());
    	partDTO.setLeadTime(part.getLeadTime());
    	partDTO.setStatus(0);
    	//one-many relationship for parts & location implemented logic will be changed accordingly <TODO>
    	if(!part.getLocations().isEmpty() && part.getLocations().size() > 0) {
	    	//Query query = entityManager.createQuery("Select p from PartLocation p where p.location.locationId IN (:locations) ");
	    	Query query = entityManager.createNativeQuery("SELECT LOCATION_ID,SUM(CURRENT_QTY) AS CURRENT_QTY  FROM dbo.PART_LOCATION WHERE PART_NO = :partNo GROUP BY LOCATION_ID");
	    	query.setParameter("partNo", part.getPartNo());
	    	List<Object[]> result = query.getResultList();
	    	if(!result.isEmpty() && result.size() > 0) {
	    		for (Iterator<Object[]> i = result.iterator(); i.hasNext();) {
	    			Object[] values = (Object[]) i.next();
	    			String location = (null == values[0] ? "" : values[0].toString());
	    			String locationType = location.charAt(3)+"";
	    			Integer currentQty = (null == values[1] ? new Integer(0) : (Integer)values[1]);
	    			/*In case of �F� or �S� locations, if the stock is zero, exclude them from the list*/
	    			if(("F".equals(locationType) || "S".equals(locationType))){
	    				if(0 != currentQty){
	    					locationCount.put(location, currentQty);
	    				}
	    			}else{
	    				locationCount.put(location, currentQty);
	    			}
		    	}
	    	}
    	}
    	partDTO.setLocationCount(locationCount);
    	partDTO.setPartName(part.getPartName());
    	partDTO.setPartNumber(part.getPartNo());
    	partDTO.setPartType(part.getPartType());
    	partDTO.setRePackingFlag(part.getRepackingFlag());
    	partDTO.setSafetyStock(part.getSafetyStock());
    	partDTO.setSnp(part.getSnp());
    	partDTO.setSupplierCode(part.getSupplierCode());
    	partDTO.setUpdatedBy(part.getUpdatedBy());
    	partDTO.setUpdatedOn(part.getUpdatedOn());
    	if(part.getChangeLog() != null) {
    		List<String> logs = Arrays.asList(part.getChangeLog().split("^^"));
    		partDTO.setLogs(logs);
    	}
    	return partDTO;
	}
	
	private void updatePart(
			com.rnaipl.wms.entities.Part part,PartDTO partDto, Date date) {
		
		part.setEopMark(partDto.getEopMark());
		part.setMixedModule(partDto.getMixedModule());
		part.setRepackingFlag(partDto.getRePackingFlag());
		part.setRepackSNP(partDto.getRepackSNP());
		part.setDtlFlag(partDto.getDtlFlag());
		part.setDolFlag(partDto.getDolFlag());
		part.setAbolishDate(null == partDto.getAbolishDate() ? null : new java.sql.Date((partDto.getAbolishDate()).getTime()));
		part.setAdoptDate(null == partDto.getAdoptDate() ? null : new java.sql.Date((partDto.getAdoptDate()).getTime()));
		part.setShelfLifeAging(partDto.getShelfLifeAging());
		part.setShelfLifePart(partDto.getShelfLifePart());
		part.setShelfLifePeriod(partDto.getShelfLifePeriod());
		part.setUpdatedBy(partDto.getUserId());
		part.setUpdatedOn(new Timestamp(date.getTime()));
		part.setCategory(partDto.getCategory());
		part.setSnp(partDto.getSnp());
		part.setSnip(partDto.getSnip());
		part.setPartCategory(partDto.getPartCategory());
		
	}

	public List<PartLocationSynchroServiceDTO> getPartLocationSynchroServiceAndroid(
			PartLocationSynchroInputDTO partLocationSynchroInputDTO) {		
	    LOGGER.debug("In PartSynchro Service Android ENTRY StartTime -->" + System.currentTimeMillis());
	    long startTime = System.currentTimeMillis();
	    List<PartLocationSynchroServiceDTO> partLocationSynchroServiceDTOs = new ArrayList<PartLocationSynchroServiceDTO>();
	   	List shopList = new ArrayList<String>();   	
	   	StringBuffer queryStringBuf = new StringBuffer();	   	
	   	
		if (partLocationSynchroInputDTO != null && partLocationSynchroInputDTO.getPlant() != null) {
			if (partLocationSynchroInputDTO.getPlant().trim().equalsIgnoreCase("G")) {
				shopList.add(partLocationSynchroInputDTO.getShop());
				if (partLocationSynchroInputDTO.getShop() != null
						&& partLocationSynchroInputDTO.getShop().equalsIgnoreCase("T")) {
					shopList.add("K");
				}
			} else if (partLocationSynchroInputDTO.getPlant().trim().equalsIgnoreCase("D")) {
				shopList.add(partLocationSynchroInputDTO.getShop());
				if (partLocationSynchroInputDTO.getShop() != null
						&& partLocationSynchroInputDTO.getShop().trim().equalsIgnoreCase("A")) {
					shopList.add("B");
				} else if (partLocationSynchroInputDTO.getShop() != null
						&& partLocationSynchroInputDTO.getShop().trim().equalsIgnoreCase("B"))
					shopList.add("A");
			}
		}
	  	 
	   		queryStringBuf.append(" SELECT '' AS PART_NO,L.LOCATION_ID, 1 AS SNP, 1 AS SNIP,'' AS CATEGORY,'' AS SHELF_LIFE_PART FROM DBO.LOCATION L  ");
	   		queryStringBuf.append("	WHERE LOCATION_ID NOT IN (SELECT DISTINCT LOCATION_ID FROM DBO.PART_LOCATION) ");	
	   		
	   		if(partLocationSynchroInputDTO!=null && partLocationSynchroInputDTO.getPlant()!=null)
		   	{
		   		queryStringBuf.append(" AND SUBSTRING(L.LOCATION_ID, 1, 1) = '"+partLocationSynchroInputDTO.getPlant()+"' ");
		   		
		   	}
	   	   	if(partLocationSynchroInputDTO!=null && partLocationSynchroInputDTO.getShop()!=null)
		   	{
		   		queryStringBuf.append(" AND SUBSTRING(L.LOCATION_ID, 2, 1) IN (:shops) ");
		   		
		   	}
	   		queryStringBuf.append(" UNION ");
	   		queryStringBuf.append(" SELECT DISTINCT P.PART_NO AS PART_NO, PL.LOCATION_ID AS LOCATION_ID, P.SNP AS SNP, P.SNIP AS SNIP, P.CATEGORY AS CATEGORY, ");
	   		queryStringBuf.append(" P.SHELF_LIFE_PART AS SHELF_LIFE_PART");
		  	queryStringBuf.append(" FROM PART P, PART_LOCATION PL ");
		  	queryStringBuf.append(" WHERE P.PART_NO = PL.PART_NO  ");
		  	//queryStringBuf.append(" AND SNP!=0 AND SNP IS NOT NULL ");
		  	
			if(partLocationSynchroInputDTO!=null && partLocationSynchroInputDTO.getShop()!=null)
		   	{
		   		queryStringBuf.append(" AND SUBSTRING(PL.LOCATION_ID, 1, 1) = '"+partLocationSynchroInputDTO.getPlant()+"' ");
		   	}
		  	
		   	if(partLocationSynchroInputDTO!=null && partLocationSynchroInputDTO.getShop()!=null)
		   	{
		   		queryStringBuf.append(" AND SUBSTRING(PL.LOCATION_ID, 2, 1) IN (:shops) ");
		   	}	   	
	        
	        LOGGER.debug("Query :  " + queryStringBuf.toString());
	   	
	        Query query = entityManager.createNativeQuery(queryStringBuf.toString());
	    	if(partLocationSynchroInputDTO!=null && partLocationSynchroInputDTO.getShop()!=null){
	    		LOGGER.debug("*Shop Filtered" + partLocationSynchroInputDTO.getShop());
	    		query.setParameter("shops", shopList);
	    	}
	        List<Object[]> partLocationSynchroService = query.getResultList();
	        LOGGER.debug("partLocationSynchroService size " + partLocationSynchroService.size());
	        
	        if(null != partLocationSynchroService && partLocationSynchroService.size() > 0) {
	            for (Iterator<Object[]> i = partLocationSynchroService.iterator(); i.hasNext();) {
	            	int indexCount=0;    	
	                Object[] values = (Object[]) i.next();
	                PartLocationSynchroServiceDTO partLocationSynchroServiceDTO = new PartLocationSynchroServiceDTO();
	                
	                partLocationSynchroServiceDTO.setPartNumber((null == values[indexCount] ? "" : values[indexCount].toString()));
	                indexCount++;
	                partLocationSynchroServiceDTO.setLocationId((null == values[indexCount] ? "" : values[indexCount].toString()));
	                indexCount++;
	                partLocationSynchroServiceDTO.setSnp((Integer)(null == values[indexCount] ? 0 : values[indexCount]));
	                indexCount++;
	                partLocationSynchroServiceDTO.setSnip((Integer)(null == values[indexCount] ? 0 : values[indexCount]));
	                indexCount++;
	                partLocationSynchroServiceDTO.setCategory((null == values[indexCount] ? "" : values[indexCount].toString()));
	                indexCount++;
	                partLocationSynchroServiceDTO.setShelfLifePart((null == values[indexCount] ? "" : values[indexCount].toString()));
	                partLocationSynchroServiceDTOs.add(partLocationSynchroServiceDTO)  ;  
	            }
	        }
	   
	    long timeTaken = System.currentTimeMillis() - startTime;
	    LOGGER.fatal("Time taken for Part Synchro Service," + timeTaken); 
	    
	   	return partLocationSynchroServiceDTOs;
	}
}
