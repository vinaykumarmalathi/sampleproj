package com.rnaipl.wms.bean;

import java.util.List;

import com.rnaipl.wms.dto.AgedAuditDTO;
import com.rnaipl.wms.dto.PartsInOutAuditSearchDTO;


public interface AgedAudit {

public List<AgedAuditDTO> getAgedAuditSearch(PartsInOutAuditSearchDTO PartsInOutAuditSearchDTO) throws Exception;
	
public int getAgedAuditSearchCount(PartsInOutAuditSearchDTO PartsInOutAuditSearchDTO);
}
