package com.rnaipl.wms.dto.ran;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Calendar;

/**
 * This class is to contain the details to be presented to user in presentation
 * layer for Plant related Data
 * 
 * @CreatedBy TechM
 * @CreatedOn 20-Apr-2016 
 */
public class AgedAgingRanDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String ran;
	private String partNo;
	private String lppd;
	private String mfgDate;
	private String stock;
	private String location;
	public String getRan() {
		return ran;
	}
	public void setRan(String ran) {
		this.ran = ran;
	}
	public String getPartNo() {
		return partNo;
	}
	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}
	public String getLppd() {
		return lppd;
	}
	public void setLppd(String lppd) {
		this.lppd = lppd;
	}
	public String getMfgDate() {
		return mfgDate;
	}
	public void setMfgDate(String mfgDate) {
		this.mfgDate = mfgDate;
	}
	public String getStock() {
		return stock;
	}
	public void setStock(String stock) {
		this.stock = stock;
	}
	
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	


	
	

}
