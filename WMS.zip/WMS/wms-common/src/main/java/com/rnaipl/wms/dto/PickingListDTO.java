package com.rnaipl.wms.dto;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="ArrayOfLINE_DETAILS")
@XmlAccessorType(XmlAccessType.FIELD)
public class PickingListDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2426638636947340504L;
	@XmlElement(name="LINE_DETAILS")
	private List<PickingLineDetailsDTO> pickingLineDetailsDTO;
	public List<PickingLineDetailsDTO> getPickingLineDetailsDTO() {
		return pickingLineDetailsDTO;
	}
	public void setPickingLineDetailsDTO(List<PickingLineDetailsDTO> pickingLineDetailsDTO) {
		this.pickingLineDetailsDTO = pickingLineDetailsDTO;
	}
	
	
	
}
