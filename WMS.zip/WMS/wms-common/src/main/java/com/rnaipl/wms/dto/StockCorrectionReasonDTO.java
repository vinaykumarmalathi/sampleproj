package com.rnaipl.wms.dto;

import java.io.Serializable;

/**
 * This class is to contain the details to be presented to user in presentation
 * layer for Plant related Data
 * 
 * @CreatedBy TechM
 * @CreatedOn 20-Apr-2016 
 */
public class StockCorrectionReasonDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String reasonId;
	private String reasonName;
	
	




	public String getReasonId() {
		return reasonId;
	}






	public void setReasonId(String reasonId) {
		this.reasonId = reasonId;
	}






	public String getReasonName() {
		return reasonName;
	}






	public void setReasonName(String reasonName) {
		this.reasonName = reasonName;
	}






	public static long getSerialversionuid() {
		return serialVersionUID;
	}






	@Override
	public String toString() {
		// TODO Auto-generated method stub
		StringBuilder builder = new StringBuilder();
        builder.append(reasonId+reasonName);
        return builder.toString();
	}
}
