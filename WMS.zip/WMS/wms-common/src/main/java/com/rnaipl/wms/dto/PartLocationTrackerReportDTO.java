package com.rnaipl.wms.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * This class have getters and setters for PartLocationDTO to fetch data from
 * Entity PartLocation and will carry into presentation layer.
 * 
 * @CreatedBy TechM
 * @CreatedOn 28-April-2016 11:32:58 am
 */
public class PartLocationTrackerReportDTO  implements Serializable{
	
	 private static final long serialVersionUID = 1L;
	
	private String partNo;
	private int wareHouseQty;
	private int overflowQty;
	private int lineQty;
	private int totalQty;
	private List<PartLocationTypeQtyDTO> partLocationTypeQty;
	private int recordCount;
	
	//added by arun for TC change
	private int otherQty;
	
	public int getOtherQty() {
		return otherQty;
	}
	public void setOtherQty(int otherQty) {
		this.otherQty = otherQty;
	}

	//
	
	
	/**
	 * 
	 */
	public PartLocationTrackerReportDTO() {
		partLocationTypeQty = new ArrayList<PartLocationTypeQtyDTO>();
	}
	/**
	 * @return
	 */
	public String getPartNo() {
		return partNo;
	}
	/**
	 * @param partNo
	 */
	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}
	/**
	 * @return
	 */
	public int getWareHouseQty() {
		return wareHouseQty;
	}
	/**
	 * @param wareHouseQty
	 */
	public void setWareHouseQty(int wareHouseQty) {
		this.wareHouseQty = wareHouseQty;
	}
	/**
	 * @return
	 */
	public int getOverflowQty() {
		return overflowQty;
	}
	/**
	 * @param overflowQty
	 */
	public void setOverflowQty(int overflowQty) {
		this.overflowQty = overflowQty;
	}
	/**
	 * @return
	 */
	public int getLineQty() {
		return lineQty;
	}
	/**
	 * @param lineQty
	 */
	public void setLineQty(int lineQty) {
		this.lineQty = lineQty;
	}
	/**
	 * @return
	 */
	public int getTotalQty() {
		return totalQty;
	}
	/**
	 * @param totalQty
	 */
	public void setTotalQty(int totalQty) {
		this.totalQty = totalQty;
	}
	/**
	 * @return
	 */
	public List<PartLocationTypeQtyDTO> getPartLocationTypeQty() {
		return partLocationTypeQty;
	}
	/**
	 * @param partLocationTypeQty
	 */
	public void setPartLocationTypeQty(
			List<PartLocationTypeQtyDTO> partLocationTypeQty) {
		this.partLocationTypeQty = partLocationTypeQty;
	}
	/**
	 * @return
	 */
	public int getRecordCount() {
		return recordCount;
	}
	/**
	 * @param recordCount
	 */
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}
	
	
	
	
}
