package com.rnaipl.wms.dto;

import java.io.Serializable;

/**
 * This class is to contain the details to be presented to user in presentation
 * layer for Plant related Data
 * 
 * @CreatedBy TechM
 * @CreatedOn 20-Apr-2016 
 */
public class SupplierDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String supplierId;
	private String supplierName;
	
		public String getSupplierId() {
		return supplierId;
	}

    public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

    public String getSupplierName() {
		return supplierName;
	}

    public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}





	@Override
	public String toString() {
		// TODO Auto-generated method stub
		StringBuilder builder = new StringBuilder();
        builder.append("SupplierDTO [supplierId=").append(supplierId).append(", supplierName=").append(supplierName).append("]");
        return builder.toString();
	}
}
