package com.rnaipl.wms.util;

import java.security.Key;
import java.util.Calendar;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;


public class CryptoUtil 
{
	private static final Logger LOGGER = Logger.getLogger(CryptoUtil.class);
  
	 public static String encrypt(String inputValue) throws Exception 
	    {
	         	         
	            String key = "NissanRenaultKey"; 
	            Key aesKey = new SecretKeySpec(key.getBytes(), "AES");
	            Cipher cipher = Cipher.getInstance("AES");
	            
	            cipher.init(Cipher.ENCRYPT_MODE, aesKey);
	            byte[] encrypted = cipher.doFinal(inputValue.getBytes());

	            StringBuilder sb = new StringBuilder();
	            for (byte b: encrypted) {
	                sb.append((char)b);
	            }
	            
	            byte[]   bytesEncoded = Base64.encodeBase64((sb.toString()).getBytes());
	            return replaceSpecialCharacters( new String(bytesEncoded));
	            /*return new String(bytesEncoded).replaceAll("#","");*/
	            	      
	    }
    
	 	private static String replaceSpecialCharacters(String inputString)
	 	{
	 		String replacedString = inputString.replaceAll("#", "");
	 		replacedString = replacedString.replaceAll("=", "");
	 		replacedString = replacedString.replaceAll("&", "");
	 		replacedString = replacedString.replaceAll("\\+", "");
	 		return replacedString;
	 		
	 	}
	 	
	 	public static long getKeyValidPeriod()
	     {
	     	Calendar calendar = Calendar.getInstance();
	     	calendar.add(Calendar.MINUTE, 2);
	     	return calendar.getTimeInMillis();
	     }
}