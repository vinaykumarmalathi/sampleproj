package com.rnaipl.wms.dto;

import java.util.List;

public class StockCorrectionDTO {

	private String partNo;
	
	private List<LocationSearchDTO> locations;
	
	private List<String> newLocations;

	public String getPartNo() {
		return partNo;
	}
	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}
	public List<LocationSearchDTO> getLocations() {
		return locations;
	}
	public void setLocations(List<LocationSearchDTO> locations) {
		this.locations = locations;
	}
	public List<String> getNewLocations() {
		return newLocations;
	}
	public void setNewLocations(List<String> newLocations) {
		this.newLocations = newLocations;
	}
	
}
