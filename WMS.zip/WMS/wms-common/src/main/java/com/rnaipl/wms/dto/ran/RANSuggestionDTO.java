package com.rnaipl.wms.dto.ran;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * This class is to contain the details to be presented to user in presentation
 * layer for Plant related Data
 * 
 * @CreatedBy TechM
 * @CreatedOn 20-Apr-2016 
 */
public class RANSuggestionDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	public RANSuggestionDTO() {};
	
	
	public RANSuggestionDTO(String ranId) {
		this.ranId = ranId;
	};
	
	private String ranId;	
	private String text;
	
	public String getRanId() {
		return ranId;
	}

	public void setRanId(String ranId) {
		this.ranId = ranId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}



	

}
