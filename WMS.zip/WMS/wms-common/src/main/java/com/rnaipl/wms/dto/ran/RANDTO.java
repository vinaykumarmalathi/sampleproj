package com.rnaipl.wms.dto.ran;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

/**
 * This class is to contain the details to be presented to user in presentation
 * layer for Plant related Data
 * 
 * @CreatedBy TechM
 * @CreatedOn 20-Apr-2016 
 */
public class RANDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String ranId;	
	private String ran;
	private String partNo;
	private String mfgDate;
	private String lppd;
	private Timestamp updatedDateTime;
	private int startIndex;
	private int endIndex;
	private int maxResult;
	private int isFullDownload;
	private int isForCount;
	private List<String> ranList;
	private List<String> partList;
	private String lppdType;
	private Date updatedDate;
	private String plant;
	private RANSuggestionDTO input;
	
	public RANSuggestionDTO getInput() {
		return input;
	}

	public void setInput(RANSuggestionDTO input) {
		this.input = input;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getRan() {
		return ran;
	}

	public void setRan(String ran) {
		this.ran = ran;
	}
	
	public String getRanId() {
		return ranId;
	}

	public void setRanId(String ranId) {
		this.ranId = ranId;
	}

	/*public static long getSerialversionuid() {
		return serialVersionUID;
	}*/

	public String getPartNo() {
		return partNo;
	}

	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}



	public String getMfgDate() {
		return mfgDate;
	}

	public void setMfgDate(String mfgDate) {
		this.mfgDate = mfgDate;
	}

	public String getLppd() {
		return lppd;
	}

	public void setLppd(String lppd) {
		this.lppd = lppd;
	}

	public Timestamp getUpdatedDateTime() {
		return updatedDateTime;
	}

	public void setUpdatedDateTime(Timestamp updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

	public int getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}



	public int getMaxResult() {
		return maxResult;
	}

	public void setMaxResult(int maxResult) {
		this.maxResult = maxResult;
	}

	public int getIsFullDownload() {
		return isFullDownload;
	}

	public void setIsFullDownload(int isFullDownload) {
		this.isFullDownload = isFullDownload;
	}

	public List<String> getRanList() {
		return ranList;
	}

	public void setRanList(List<String> ranList) {
		this.ranList = ranList;
	}

	public List<String> getPartList() {
		return partList;
	}

	public void setPartList(List<String> partList) {
		this.partList = partList;
	}

	public int getIsForCount() {
		return isForCount;
	}

	public void setIsForCount(int isForCount) {
		this.isForCount = isForCount;
	}

	public int getEndIndex() {
		return endIndex;
	}

	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}

	public String getLppdType() {
		return lppdType;
	}

	public void setLppdType(String lppdType) {
		this.lppdType = lppdType;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}




	

}
