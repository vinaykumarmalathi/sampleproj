package com.rnaipl.wms.dto;

import java.sql.Timestamp;

public class PickinglistDetailsDTO {
	private String partType;
	private String partNumber;
	private String location;
	private int noOfBoxes;
	private int snp;
	private int quantity;
	private int wip;
	private int remainingActualQty;
	private String eopMark;
	private String device;
	private String whOut;
	private String status;
	private String model;
	private String allocation;
	private String supplierMethod;
	private String lineStk;
    private String lineLoc;
    
    private int noOfOpenBoxes;
    private int noOfOpenQty;   
	
	
	public int getNoOfOpenBoxes() {
		return noOfOpenBoxes;
	}
	public void setNoOfOpenBoxes(int noOfOpenBoxes) {
		this.noOfOpenBoxes = noOfOpenBoxes;
	}
	public int getNoOfOpenQty() {
		return noOfOpenQty;
	}
	public void setNoOfOpenQty(int noOfOpenQty) {
		this.noOfOpenQty = noOfOpenQty;
	}
	public String getLineLoc() {
		return lineLoc;
	}
	public void setLineLoc(String lineLoc) {
		this.lineLoc = lineLoc;
	}	
	public String getPartType() {
		return partType;
	}
	public void setPartType(String partType) {
		this.partType = partType;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getNoOfBoxes() {
		return noOfBoxes;
	}
	public void setNoOfBoxes(int noOfBoxes) {
		this.noOfBoxes = noOfBoxes;
	}
	public int getSnp() {
		return snp;
	}
	public void setSnp(int snp) {
		this.snp = snp;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getWip() {
		return wip;
	}
	public void setWip(int wip) {
		this.wip = wip;
	}
	public int getRemainingActualQty() {
		return remainingActualQty;
	}
	public void setRemainingActualQty(int remainingActualQty) {
		this.remainingActualQty = remainingActualQty;
	}
	public String getEopMark() {
		return eopMark;
	}
	public void setEopMark(String eopMark) {
		this.eopMark = eopMark;
	}
	public String getDevice() {
		return device;
	}
	public void setDevice(String device) {
		this.device = device;
	}
	public String getWhOut() {
		return whOut;
	}
	public void setWhOut(String whOut) {
		this.whOut = whOut;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getAllocation() {
		return allocation;
	}
	public void setAllocation(String allocation) {
		this.allocation = allocation;
	}
	public String getSupplierMethod() {
		return supplierMethod;
	}
	public void setSupplierMethod(String supplierMethod) {
		this.supplierMethod = supplierMethod;
	}
	public String getLineStk() {
		return lineStk;
	}
	public void setLineStk(String lineStk) {
		this.lineStk = lineStk;
	}
	
}
