package com.rnaipl.wms.dto;

import java.io.Serializable;
import java.util.Date;

public class PartsInOutStagingDTO implements Serializable{
	
	private String partNumber;
	private String location;
	private String transactionType;
	private int count;
	private String ran;
	private String userId;
	private String deviceId;
	private Date partInOutTime;
	private PartsOutReasonDTO partsReasonCode;
	private long partPk;
	private int noOfBoxes;
	private String comments;
	private String reasonCode;
	private String reason;
	
	public int getNoOfBoxes() {
		return noOfBoxes;
	}
	public void setNoOfBoxes(int noOfBoxes) {
		this.noOfBoxes = noOfBoxes;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public long getPartPk() {
		return partPk;
	}
	public void setPartPk(long partPk) {
		this.partPk = partPk;
	}
	public String getReasonCode() {
		return reasonCode;
	}
	public PartsOutReasonDTO getPartsReasonCode() {
		return partsReasonCode;
	}
	public void setPartsReasonCode(PartsOutReasonDTO partsReasonCode) {
		this.partsReasonCode = partsReasonCode;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getRan() {
		return ran;
	}
	public void setRan(String ran) {
		this.ran = ran;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public Date getPartInOutTime() {
		return partInOutTime;
	}
	public void setPartInOutTime(Date partInOutTime) {
		this.partInOutTime = partInOutTime;
	}

}
