package com.rnaipl.wms.dto;

public class LineFeedHandyProcessDtlsDTO {

	private String deviceID;
	private boolean isProcessing;
	public String getDeviceID() {
		return deviceID;
	}
	public void setDeviceID(String deviceID) {
		this.deviceID = deviceID;
	}
	public boolean isProcessing() {
		return isProcessing;
	}
	public void setProcessing(boolean isProcessing) {
		this.isProcessing = isProcessing;
	}
	
	
}
