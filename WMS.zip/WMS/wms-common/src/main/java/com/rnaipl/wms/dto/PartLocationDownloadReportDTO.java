package com.rnaipl.wms.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PartLocationDownloadReportDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String partNumber;	
	private String partName;
	private String partType;
	private String category;
	private String supplierCode;
	private String depoCode;
	private int snp;
	private int snip;
	private String receivingPort;
	private String eopMark;
	private String mixedModule;
	private String rePackingFlag;
	private String dolFlag;
	private String dtlFlag;
	private int repackSNP;
	private String delPlc;
	private int leadTime;
	private int safetyStock;
	private Date createdOn;
	private String createdBy;
	private Date updatedOn;
	private String updatedBy;
	private String changeLog;		
	private String text;
	private String remarks;
	private String userId;
	private String pcCode;	
	private Date adoptDate;
	private Date abolishDate;
	private String adoptDateString;
	private String abolishDateString;
	private String shelfLifePart;
	private int shelfLifePeriod;
	
	private String locationId;
	private String ran;
	private int currentQty;
	private int totalCapacity;
	private String partCategory;

	public String getPartCategory() {
		return partCategory;
	}
	public void setPartCategory(String partCategory) {
		this.partCategory = partCategory;
	}
	//Added For aging calculation
	private String shelfLifeAging;		
	
	
	
	public String getShelfLifeAging() {
		return shelfLifeAging;
	}
	public void setShelfLifeAging(String shelfLifeAging) {
		this.shelfLifeAging = shelfLifeAging;
	}
	public Date getAdoptDate() {
		return adoptDate;
	}
	public void setAdoptDate(Date adoptDate) {
		this.adoptDate = adoptDate;
	}
	public Date getAbolishDate() {
		return abolishDate;
	}
	public void setAbolishDate(Date abolishDate) {
		this.abolishDate = abolishDate;
	}
	public int getShelfLifePeriod() {
		return shelfLifePeriod;
	}
	public void setShelfLifePeriod(int shelfLifePeriod) {
		this.shelfLifePeriod = shelfLifePeriod;
	}
	public String getPartType() {
		return partType;
	}
	public void setPartType(String partType) {
		this.partType = partType;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getPartName() {
		return partName;
	}
	public void setPartName(String partName) {
		this.partName = partName;
	}
	public String getSupplierCode() {
		return supplierCode;
	}
	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}
	public String getDepoCode() {
		return depoCode;
	}
	public void setDepoCode(String depoCode) {
		this.depoCode = depoCode;
	}
	public int getSnp() {
		return snp;
	}
	public void setSnp(int snp) {
		this.snp = snp;
	}
	public int getSnip() {
		return snip;
	}
	public void setSnip(int snip) {
		this.snip = snip;
	}
	public String getReceivingPort() {
		return receivingPort;
	}
	public void setReceivingPort(String receivingPort) {
		this.receivingPort = receivingPort;
	}
	public String getEopMark() {
		return eopMark;
	}
	public void setEopMark(String eopMark) {
		this.eopMark = eopMark;
	}
	public int getRepackSNP() {
		return repackSNP;
	}
	public void setRepackSNP(int repackSNP) {
		this.repackSNP = repackSNP;
	}

	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getLeadTime() {
		return leadTime;
	}
	public void setLeadTime(int leadTime) {
		this.leadTime = leadTime;
	}
	public int getSafetyStock() {
		return safetyStock;
	}
	public void setSafetyStock(int safetyStock) {
		this.safetyStock = safetyStock;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	
	public String getDelPlc() {
		return delPlc;
	}
	public void setDelPlc(String delPlc) {
		this.delPlc = delPlc;
	}
	
	
	public String getChangeLog() {
		return changeLog;
	}
	public void setChangeLog(String changeLog) {
		this.changeLog = changeLog;
	}
	
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getPcCode() {
		return pcCode;
	}
	public void setPcCode(String pcCode) {
		this.pcCode = pcCode;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getMixedModule() {
		return mixedModule;
	}
	public void setMixedModule(String mixedModule) {
		this.mixedModule = mixedModule;
	}
	public String getRePackingFlag() {
		return rePackingFlag;
	}
	public void setRePackingFlag(String rePackingFlag) {
		this.rePackingFlag = rePackingFlag;
	}
	public String getDolFlag() {
		return dolFlag;
	}
	public void setDolFlag(String dolFlag) {
		this.dolFlag = dolFlag;
	}
	public String getDtlFlag() {
		return dtlFlag;
	}
	public void setDtlFlag(String dtlFlag) {
		this.dtlFlag = dtlFlag;
	}
	public String getShelfLifePart() {
		return shelfLifePart;
	}
	public void setShelfLifePart(String shelfLifePart) {
		this.shelfLifePart = shelfLifePart;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public String getRan() {
		return ran;
	}
	public void setRan(String ran) {
		this.ran = ran;
	}
	public int getCurrentQty() {
		return currentQty;
	}
	public void setCurrentQty(int currentQty) {
		this.currentQty = currentQty;
	}
	public int getTotalCapacity() {
		return totalCapacity;
	}
	public void setTotalCapacity(int totalCapacity) {
		this.totalCapacity = totalCapacity;
	}
	public String getAdoptDateString() {
		return adoptDateString;
	}
	public void setAdoptDateString(String adoptDateString) {
		this.adoptDateString = adoptDateString;
	}
	public String getAbolishDateString() {
		return abolishDateString;
	}
	public void setAbolishDateString(String abolishDateString) {
		this.abolishDateString = abolishDateString;
	}
	
	
}
