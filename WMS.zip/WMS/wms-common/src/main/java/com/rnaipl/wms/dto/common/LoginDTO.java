package com.rnaipl.wms.dto.common;

public class LoginDTO {

	String userId;
	String encryptedKey;
	long validUntil;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getEncryptedKey() {
		return encryptedKey;
	}
	public void setEncryptedKey(String encryptedKey) {
		this.encryptedKey = encryptedKey;
	}
	public long getValidUntil() {
		return validUntil;
	}
	public void setValidUntil(long validUntil) {
		this.validUntil = validUntil;
	}

	
	
}
