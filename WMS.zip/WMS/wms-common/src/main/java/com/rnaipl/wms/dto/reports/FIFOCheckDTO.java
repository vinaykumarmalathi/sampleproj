package com.rnaipl.wms.dto.reports;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class FIFOCheckDTO implements Serializable{

	private String partNumber;
	private String location;
	private String transactionType;
	private int count;	
	private String userId;
	private String deviceId;
	private Date partInOutTime;
	private String pickedRan;
	private String correctRan;	
	private int noOfBoxes;	
	/*private String reasonCode;
	private String reason;*/
	private String comments;
	private String shift;
	
	private int snp;
	private Date scanTime;
//	private List<String> ranList;
	private Date pickedRanInTime;
	private Date correctRanInTime;
	private int ranDateDifference;
	
		
	
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public Date getPartInOutTime() {
		return partInOutTime;
	}
	public void setPartInOutTime(Date partInOutTime) {
		this.partInOutTime = partInOutTime;
	}
	public String getPickedRan() {
		return pickedRan;
	}
	public void setPickedRan(String pickedRan) {
		this.pickedRan = pickedRan;
	}
	public String getCorrectRan() {
		return correctRan;
	}
	public void setCorrectRan(String correctRan) {
		this.correctRan = correctRan;
	}
	public int getNoOfBoxes() {
		return noOfBoxes;
	}
	public void setNoOfBoxes(int noOfBoxes) {
		this.noOfBoxes = noOfBoxes;
	}

	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getShift() {
		return shift;
	}
	public void setShift(String shift) {
		this.shift = shift;
	}
	public int getSnp() {
		return snp;
	}
	public void setSnp(int snp) {
		this.snp = snp;
	}
	public Date getScanTime() {
		return scanTime;
	}
	public void setScanTime(Date scanTime) {
		this.scanTime = scanTime;
	}
	public Date getPickedRanInTime() {
		return pickedRanInTime;
	}
	public void setPickedRanInTime(Date pickedRanInTime) {
		this.pickedRanInTime = pickedRanInTime;
	}
	public Date getCorrectRanInTime() {
		return correctRanInTime;
	}
	public void setCorrectRanInTime(Date correctRanInTime) {
		this.correctRanInTime = correctRanInTime;
	}
	public int getRanDateDifference() {
		return ranDateDifference;
	}
	public void setRanDateDifference(int ranDateDifference) {
		this.ranDateDifference = ranDateDifference;
	}

	
	
	
}
