package com.rnaipl.wms.dto;

import java.io.Serializable;
import java.util.List;

public class MasterScreenDetailsDTO implements Serializable {

	private String plant;
	private String shopId;
	private String lineId;

	private String partNumber;
	private String location;
	private List<String> partList;
	private List<String> locationList;

	private String line;
	private String shop;
	private String partNo; // Part Number
	private String partType; // KD/LP
	private String model; // Model
	private String supplier; // Supplier Name
	private String zone; // Zone
	private String subzone; // Sub Zone
	private String lineLoc; // Line Location
	private String lineCapacity; // Line Capacity
	private String supplierMethod; // Supply Method
	private String safetyStock; // Safety Stock in Qty
	private String allocation; // Allocation
	private String stock; // System Stock
	private String usageCar;
	private String description;
	private String snip;
	private String frequency;// Frequency in hrs
	private String whLoc;
	private String hourRequirement;
	private String minFeed;
	private String distance;
	private String time;
	private String systemStock;
	private String wip; // WIP ( T&C)
	private String wipPaint; // WIP Paint
	private String wipTotal;
	private String shiftConsumption; // Shift Consumption
	
	private String beginDate;
	private String endDate;
	private String status;

	private int startIndex;
	private int endIndex;
	private int isFullDownload;

	public String getSystemStock() {
		return systemStock;
	}

	public void setSystemStock(String systemStock) {
		this.systemStock = systemStock;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getDistance() {
		return distance;
	}

	public void setDistance(String distance) {
		this.distance = distance;
	}

	public String getMinFeed() {
		return minFeed;
	}

	public void setMinFeed(String minFeed) {
		this.minFeed = minFeed;
	}

	public String getWhLoc() {
		return whLoc;
	}

	public void setWhLoc(String whLoc) {
		this.whLoc = whLoc;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getShop() {
		return shop;
	}

	public void setShop(String shop) {
		this.shop = shop;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getPartNo() {
		return partNo;
	}

	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}

	public String getPartType() {
		return partType;
	}

	public void setPartType(String partType) {
		this.partType = partType;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public String getLineLoc() {
		return lineLoc;
	}

	public void setLineLoc(String lineLoc) {
		this.lineLoc = lineLoc;
	}

	public String getLineCapacity() {
		return lineCapacity;
	}

	public void setLineCapacity(String lineCapacity) {
		this.lineCapacity = lineCapacity;
	}

	public String getHourRequirement() {
		return hourRequirement;
	}

	public void setHourRequirement(String hourRequirement) {
		this.hourRequirement = hourRequirement;
	}

	public String getSupplierMethod() {
		return supplierMethod;
	}

	public void setSupplierMethod(String supplierMethod) {
		this.supplierMethod = supplierMethod;
	}

	public String getSafetyStock() {
		return safetyStock;
	}

	public void setSafetyStock(String safetyStock) {
		this.safetyStock = safetyStock;
	}

	public String getAllocation() {
		return allocation;
	}

	public void setAllocation(String allocation) {
		this.allocation = allocation;
	}

	public String getStock() {
		return stock;
	}

	public void setStock(String stock) {
		this.stock = stock;
	}

	public String getWip() {
		return wip;
	}

	public void setWip(String wip) {
		this.wip = wip;
	}

	public String getWipPaint() {
		return wipPaint;
	}

	public void setWipPaint(String wipPaint) {
		this.wipPaint = wipPaint;
	}

	public String getShiftConsumption() {
		return shiftConsumption;
	}

	public void setShiftConsumption(String shiftConsumption) {
		this.shiftConsumption = shiftConsumption;
	}

	public int getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}

	public int getEndIndex() {
		return endIndex;
	}

	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}

	public String getSubzone() {
		return subzone;
	}

	public void setSubzone(String subzone) {
		this.subzone = subzone;
	}

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public String getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(String beginDate) {
		this.beginDate = beginDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public int getIsFullDownload() {
		return isFullDownload;
	}

	public void setIsFullDownload(int isFullDownload) {
		this.isFullDownload = isFullDownload;
	}

	public List<String> getPartList() {
		return partList;
	}

	public void setPartList(List<String> partList) {
		this.partList = partList;
	}

	public List<String> getLocationList() {
		return locationList;
	}

	public void setLocationList(List<String> locationList) {
		this.locationList = locationList;
	}

	public String getWipTotal() {
		return wipTotal;
	}

	public void setWipTotal(String wipTotal) {
		this.wipTotal = wipTotal;
	}

	public String getShopId() {
		return shopId;
	}

	public void setShopId(String shopId) {
		this.shopId = shopId;
	}

	public String getLineId() {
		return lineId;
	}

	public void setLineId(String lineId) {
		this.lineId = lineId;
	}

	public String getUsageCar() {
		return usageCar;
	}

	public void setUsageCar(String usageCar) {
		this.usageCar = usageCar;
	}

	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSnip() {
		return snip;
	}

	public void setSnip(String snip) {
		this.snip = snip;
	}

	@Override
	public String toString() {
		return "MasterScreenDetailsDTO [plant=" + plant + ", shopId=" + shopId + ", lineId=" + lineId + ", partNumber="
				+ partNumber + ", location=" + location + ", partList=" + partList + ", locationList=" + locationList
				+ ", line=" + line + ", shop=" + shop + ", partNo=" + partNo + ", partType=" + partType + ", model="
				+ model + ", supplier=" + supplier + ", zone=" + zone + ", subzone=" + subzone + ", lineLoc=" + lineLoc
				+ ", lineCapacity=" + lineCapacity + ", supplierMethod=" + supplierMethod + ", safetyStock="
				+ safetyStock + ", allocation=" + allocation + ", stock=" + stock + ", usageCar=" + usageCar
				+ ", description=" + description + ", snip=" + snip + ", frequency=" + frequency + ", whLoc=" + whLoc
				+ ", hourRequirement=" + hourRequirement + ", minFeed=" + minFeed + ", wip=" + wip + ", wipPaint="
				+ wipPaint + ", wipTotal=" + wipTotal + ", shiftConsumption=" + shiftConsumption + ", distance="
				+ distance + ", time=" + time + ", systemStock=" + systemStock + ", beginDate=" + beginDate
				+ ", endDate=" + endDate + ", status=" + status + ", startIndex=" + startIndex + ", endIndex="
				+ endIndex + ", isFullDownload=" + isFullDownload + "]";
	}

}
