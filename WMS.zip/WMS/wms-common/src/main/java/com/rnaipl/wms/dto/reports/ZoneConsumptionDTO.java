package com.rnaipl.wms.dto.reports;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class ZoneConsumptionDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String partNumber;
	private String partName;
	private String source;	
	private String pofZone;
	private String lastPickListTime;
	private String lastPickListSTS;
	private int lastPickListQTY;
	private String lastWHoutTIME;
	private int lastWhOUTQTY;
	private String zoneTactHISRY;
	private String zoneTactSHIFT;
	private int offLineQTY;
	private int lineStock;
	private int whStock;
	private int catsStock;
	private int mismatch;
	
	private String plant;
	private String shop;
	private String line;
	private String zone;
	private String userId;
	private String startIndex;
	private String endIndex;
	
    private List<String> partList;
    
    private Date beginDate;
	private Date endDate;    
	
	public Date getBeginDate() {
		return beginDate;
	}
	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public int getMismatch() {
		return mismatch;
	}
	public void setMismatch(int mismatch) {
		this.mismatch = mismatch;
	}
	public List<String> getPartList() {
		return partList;
	}
	public void setPartList(List<String> partList) {
		this.partList = partList;
	}
	
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getPartName() {
		return partName;
	}
	public void setPartName(String partName) {
		this.partName = partName;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getPofZone() {
		return pofZone;
	}
	public void setPofZone(String pofZone) {
		this.pofZone = pofZone;
	}
	public String getLastPickListTime() {
		return lastPickListTime;
	}
	public void setLastPickListTime(String lastPickListTime) {
		this.lastPickListTime = lastPickListTime;
	}
	public String getLastPickListSTS() {
		return lastPickListSTS;
	}
	public void setLastPickListSTS(String lastPickListSTS) {
		this.lastPickListSTS = lastPickListSTS;
	}
	public int getLastPickListQTY() {
		return lastPickListQTY;
	}
	public void setLastPickListQTY(int lastPickListQTY) {
		this.lastPickListQTY = lastPickListQTY;
	}
	public String getLastWHoutTIME() {
		return lastWHoutTIME;
	}
	public void setLastWHoutTIME(String lastWHoutTIME) {
		this.lastWHoutTIME = lastWHoutTIME;
	}
	public int getLastWhOUTQTY() {
		return lastWhOUTQTY;
	}
	public void setLastWhOUTQTY(int lastWhOUTQTY) {
		this.lastWhOUTQTY = lastWhOUTQTY;
	}
	public String getZoneTactHISRY() {
		return zoneTactHISRY;
	}
	public void setZoneTactHISRY(String zoneTactHISRY) {
		this.zoneTactHISRY = zoneTactHISRY;
	}
	public String getZoneTactSHIFT() {
		return zoneTactSHIFT;
	}
	public void setZoneTactSHIFT(String zoneTactSHIFT) {
		this.zoneTactSHIFT = zoneTactSHIFT;
	}
	public int getOffLineQTY() {
		return offLineQTY;
	}
	public void setOffLineQTY(int offLineQTY) {
		this.offLineQTY = offLineQTY;
	}
	public int getLineStock() {
		return lineStock;
	}
	public void setLineStock(int lineStock) {
		this.lineStock = lineStock;
	}
	public int getWhStock() {
		return whStock;
	}
	public void setWhStock(int whStock) {
		this.whStock = whStock;
	}
	public int getCatsStock() {
		return catsStock;
	}
	public void setCatsStock(int catsStock) {
		this.catsStock = catsStock;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public String getShop() {
		return shop;
	}
	public void setShop(String shop) {
		this.shop = shop;
	}
	public String getLine() {
		return line;
	}
	public void setLine(String line) {
		this.line = line;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getStartIndex() {
		return startIndex;
	}
	public void setStartIndex(String startIndex) {
		this.startIndex = startIndex;
	}
	public String getEndIndex() {
		return endIndex;
	}
	public void setEndIndex(String endIndex) {
		this.endIndex = endIndex;
	}
	
	
}
