package com.rnaipl.wms.dto;

import java.io.Serializable;

public class LocationTypeDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String getLocationType() {
		return locationType;
	}
	public void setLocationType(String locationType) {
		this.locationType = locationType;
	}
	public String getLocationTypeId() {
		return locationTypeId;
	}
	public void setLocationTypeId(String locationTypeId) {
		this.locationTypeId = locationTypeId;
	}
	private String locationType;
	private String locationTypeId;

}
