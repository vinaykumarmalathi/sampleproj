package com.rnaipl.wms.util;

public class WMSConstants {

	public static final String SUCCESS = "success";
	public static final String DATA_FOUND = "dataFound";
	public static final String TIMESTAMP_FORMAT = "dd-MM-yyyy-HH-mm-ss";
	public static final String INOUT_LOGFILE = "InOutLog";
	public static final String DEFAULT_RAN = "*";
	/*Added by Meena - to define the filename with current datetime */
	public static final String DATE_TIME_FORMAT_DATABASE = "yyyy-MM-dd hh:mm:ss.SSS";
	
	//PROD Movement
	/*public static final String UPLOAD_RAN_DESTINATION_PATH = "M:/WMS_BATCH_FILES/LIVE/RAN_UPLOAD/";
	public static final String TAGSHEET = "M:/WMS_BATCH_FILES/LIVE/TAG_SHEET.pdf";
	public static final String PICKINGLISTSHEET = "M:/WMS_BATCH_FILES/LIVE/PICKINGLIST/PICKING_LIST.pdf";*/
	
	//QA Movement
	public static final String UPLOAD_RAN_DESTINATION_PATH = "M:/WMS_BATCH_FILES/QA/RAN_UPLOAD/";
	public static final String TAGSHEET = "M:/WMS_BATCH_FILES/QA/TAG_SHEET.pdf";
	public static final String PICKINGLISTSHEET = "M:/WMS_BATCH_FILES/QA/PICKINGLIST/PICKING_LIST.pdf";
	
	public static final String DOWNLOAD_SEARCH_FORM_REQUIREMENT_PDF= "";
	public static final String AUDIT_MAXRECORDS_DOWNLOAD_ID = "4";
	public static final int AUDIT_MAXRECORDS_DOWNLOAD_DEFAULT =5000;
	 //ADDED FOR UAT REQ TO PROVIDE SAVE AS OPTION FOR DOWNLOAD 
	public static final String SERVICE_FILE_DOWNLOAD_NAME= "PickingListReport.pdf";
	
	//added for shortage alarm
	public static final String SHORTAGE_ALARM_ZONES= "SHORTAGE_ZONES";
	public static final String SHORTAGE_ALARM_WIPS= "SHORTAGE_WIPS";
	public static final String PLANT_TYPE_PV= "PV"; 
	public static final String METAL= "METAL";
	public static final String PA1= "PA1";
	public static final String PA2= "PA2";
	public static final String PBS= "PBS";
	public static final String TRIM= "TRIM";
	public static final String WMSCAL= "W";
	public static final String CATSCAL= "L";
	
	public static final String DOWNLOAD_LOGO= "DOWNLOAD_LOGO"; //"M:/WMS_BATCH_FILES/QA/IMG/rnaipl_logo.png";
	//Download
	/*public static final String SHORTAGE_ALARM_DOWNLOAD= "D://Public//upload//PV_FY18PV0722.xlsx";*/
	//public static final String SHORTAGE_ALARM_DOWNLOAD= "D://Public//upload//";
	
	public static final String PV_SA_WH_DOWNLOAD= "PV_SA_WH_DOWNLOAD";
	public static final String PV_SA_WHCATS_DOWNLOAD= "PV_SA_WHCATS_DOWNLOAD";
	public static final String PV_SA_MISSING_PARTS_DOWNLOAD= "PV_SA_MISSING_PARTS_DOWNLOAD";
	public static final String PV_SA_ALLPARTS_CATS_DOWNLOAD= "PV_SA_ALLPARTS_CATS_DOWNLOAD"; 
	
	//Ran upload plant cr
	public static final String UPLOAD_RAN_DESTINATION_PATH_PV = "M:/WMS_BATCH_FILES/QA/RAN_UPLOAD/PV/";
	public static final String UPLOAD_RAN_DESTINATION_PATH_PT = "M:/WMS_BATCH_FILES/QA/RAN_UPLOAD/PT/";
	//LIVE_RECEIPT 
	public static final String LI_RECEIPT_WMS= "WMS"; 
	public static final String LI_RECEIPT_CATS= "CATS"; 
	public static final String LI_RECEIPT_MISMATCH= "MISMATCH"; 
	/*public static final String LI_RECEIPT_ALL= "ALL"; 	*/
	
	public static final String CONTAINER_NO = "CONTAINER_NO";
	public static final String DNOTE_NO = "DNOTE_NO"; 	
	public static final String REC_PLACE = "REC_PLACE"; 
}
