package com.rnaipl.wms.dto;

import java.io.Serializable;

public class PartsOutReasonDTO implements Serializable{
	
	private String reasonCode;
	private String reason;
	
	public String getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}

}
