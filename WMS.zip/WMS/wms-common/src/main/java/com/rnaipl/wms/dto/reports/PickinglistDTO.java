package com.rnaipl.wms.dto.reports;

import java.util.Date;

public class PickinglistDTO {
	private String pickListnumber;
	private String plant;
	private String shop;
	private String zone;
	private String line;
	private String status;
	private Date beginDate;
	private Date endDate;
	
	private String shopId;
	private String shopName;
	private String shopList;
	
	private int startIndex;
	private int endIndex;
	private int isFullDownload;
	
	private int allocation;
	
	public int getStartIndex() {
		return startIndex;
	}
	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}
	public int getEndIndex() {
		return endIndex;
	}
	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}
	public int getIsFullDownload() {
		return isFullDownload;
	}
	public void setIsFullDownload(int isFullDownload) {
		this.isFullDownload = isFullDownload;
	}
	public String getPickListnumber() {
		return pickListnumber;
	}
	public void setPickListnumber(String pickListnumber) {
		this.pickListnumber = pickListnumber;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public String getShop() {
		return shop;
	}
	public void setShop(String shop) {
		this.shop = shop;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getLine() {
		return line;
	}
	public void setLine(String line) {
		this.line = line;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getBeginDate() {
		return beginDate;
	}
	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getShopId() {
		return shopId;
	}
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}
	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public String getShopList() {
		return shopList;
	}
	public void setShopList(String shopList) {
		this.shopList = shopList;
	}
	public int getAllocation() {
		return allocation;
	}
	public void setAllocation(int allocation) {
		this.allocation = allocation;
	}
	
}
