package com.rnaipl.wms.dto.reports;

import java.util.Date;

public class FIFOSuggestionDTO {
	private String partNumber;
	private String suggestedRan;
	private String suggestedLocation;
	//private String suggestedRanLppd;
	private Date suggestedRanLppd;
	private String actualRan;
	private String actualLocation;
	//private String actualRanLppd;
	private Date actualRanLppd;
	private int duration;
	private String reason;//added for reason code new field 
	private int snp;
	private int quantity;
	private Date scanTime;
	private Date partInOutTime; 
	private String deviceId;
	
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getSuggestedRan() {
		return suggestedRan;
	}
	public void setSuggestedRan(String suggestedRan) {
		this.suggestedRan = suggestedRan;
	}
	public String getSuggestedLocation() {
		return suggestedLocation;
	}
	public void setSuggestedLocation(String suggestedLocation) {
		this.suggestedLocation = suggestedLocation;
	}
	public Date getSuggestedRanLppd() {
		return suggestedRanLppd;
	}
	public void setSuggestedRanLppd(Date suggestedRanLppd) {
		this.suggestedRanLppd = suggestedRanLppd;
	}
	public String getActualRan() {
		return actualRan;
	}
	public void setActualRan(String actualRan) {
		this.actualRan = actualRan;
	}
	public String getActualLocation() {
		return actualLocation;
	}
	public void setActualLocation(String actualLocation) {
		this.actualLocation = actualLocation;
	}
	public Date getActualRanLppd() {
		return actualRanLppd;
	}
	public void setActualRanLppd(Date actualRanLppd) {
		this.actualRanLppd = actualRanLppd;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	
	//code for new filed in grid reason
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	//code for new filed in grid reason
	public int getSnp() {
		return snp;
	}
	public void setSnp(int snp) {
		this.snp = snp;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Date getScanTime() {
		return scanTime;
	}
	public void setScanTime(Date scanTime) {
		this.scanTime = scanTime;
	}
	public Date getPartInOutTime() {
		return partInOutTime;
	}
	public void setPartInOutTime(Date partInOutTime) {
		this.partInOutTime = partInOutTime;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	
}
