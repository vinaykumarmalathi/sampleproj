package com.rnaipl.wms.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class AgedAuditDTO implements Serializable{

	private String partNumber;
	private String location;
	private String transactionType;
	private int count;
	private String ran;
	private Date partInOutTime;
	private Date scanTime;
	private String shift;
	private Date lppd;
	private String deviceId;
	//private PartsOutReasonDTO partsReasonCode;
	//private String comments;
	//private String lppd;
	//private long partPk;
	//private int noOfBoxes;	
	//private String reasonCode;
	//private String reason;
	
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getRan() {
		return ran;
	}
	public void setRan(String ran) {
		this.ran = ran;
	}
	public Date getPartInOutTime() {
		return partInOutTime;
	}
	public void setPartInOutTime(Date partInOutTime) {
		this.partInOutTime = partInOutTime;
	}
	public Date getScanTime() {
		return scanTime;
	}
	public void setScanTime(Date scanTime) {
		this.scanTime = scanTime;
	}
	public String getShift() {
		return shift;
	}
	public void setShift(String shift) {
		this.shift = shift;
	}
	public Date getLppd() {
		return lppd;
	}
	public void setLppd(Date lppd) {
		this.lppd = lppd;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	/*public PartsOutReasonDTO getPartsReasonCode() {
		return partsReasonCode;
	}
	public void setPartsReasonCode(PartsOutReasonDTO partsReasonCode) {
		this.partsReasonCode = partsReasonCode;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getLppd() {
		return lppd;
	}
	public void setLppd(String lppd) {
		this.lppd = lppd;
	}*/
	/*public long getPartPk() {
		return partPk;
	}
	public void setPartPk(long partPk) {
		this.partPk = partPk;
	}
	public int getNoOfBoxes() {
		return noOfBoxes;
	}
	public void setNoOfBoxes(int noOfBoxes) {
		this.noOfBoxes = noOfBoxes;
	}
	public String getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}*/

	
	
}
