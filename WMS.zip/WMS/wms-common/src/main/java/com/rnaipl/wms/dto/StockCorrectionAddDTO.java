package com.rnaipl.wms.dto;

import java.io.Serializable;
import java.util.List;

public class StockCorrectionAddDTO implements Serializable {

	private long partId;

	private String partNo;
	private String partName;
	private String zone;
	private String subzone;

	private String lineStock;
	private String correction;
	private String modify;
	private String consideration;
	private String reason;
	private String shift;
	private String userId;

	private String remarks;

	private String date;

	public long getPartId() {
		return partId;
	}

	public void setPartId(long partId) {
		this.partId = partId;
	}

	public String getPartNo() {
		return partNo;
	}

	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}

	public String getPartName() {
		return partName;
	}

	public void setPartName(String partName) {
		this.partName = partName;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public String getSubzone() {
		return subzone;
	}

	public void setSubzone(String subzone) {
		this.subzone = subzone;
	}

	public String getLineStock() {
		return lineStock;
	}

	public void setLineStock(String lineStock) {
		this.lineStock = lineStock;
	}

	public String getCorrection() {
		return correction;
	}

	public void setCorrection(String correction) {
		this.correction = correction;
	}

	public String getConsideration() {
		return consideration;
	}

	public String getModify() {
		return modify;
	}

	public void setModify(String modify) {
		this.modify = modify;
	}

	public void setConsideration(String consideration) {
		this.consideration = consideration;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getShift() {
		return shift;
	}

	public void setShift(String shift) {
		this.shift = shift;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "StockCorrectionAddDTO [partNo=" + partNo + ", partName=" + partName + ", zone=" + zone + ", subzone="
				+ subzone + ", lineStock=" + lineStock + ", correction=" + correction + ", consideration="
				+ consideration + ", reason=" + reason + ", shift=" + shift + ", userId=" + userId + ", remarks="
				+ remarks + ", date=" + date + "]";
	}

}
