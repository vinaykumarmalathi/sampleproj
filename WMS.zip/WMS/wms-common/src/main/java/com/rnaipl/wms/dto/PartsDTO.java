package com.rnaipl.wms.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="PART_DETAIL")
@XmlAccessorType(XmlAccessType.FIELD)
public class PartsDTO implements Serializable{
	@XmlElement(name="STATUS")
	private int status;
	
	@XmlElement(name="PART_NO")
	private String partNumber;
	
	@XmlElement(name="PART_NAME")
	private String partName;
	
	@XmlElement(name="SNP")
	private int snp;
	
	@XmlElement(name="PART_TYPE")
	private String partType;
	
	@XmlElement(name="CATEGORY")
	private String category;
	
	@XmlElement(name="LEAD_TIME")
	private int leadTime;
	
	@XmlElement(name="SAFETY_STOCK")
	private int safetyStock;
	
	@XmlElement(name="SUPPLIER_CODE")
	private String supplierCode;
	
	@XmlElement(name="CREATED_ON")
	private Date createdOn;
	
	@XmlElement(name="CREATED_BY")
	private String createdBy;
	
	@XmlElement(name="UPDATED_ON")
	private Date updatedOn;
	
	@XmlElement(name="UPDATED_BY")
	private String updatedBy;
	
	@XmlElement(name="DEPOT_CODE")
	private String depoCode;
	
	@XmlElement(name="DTL_FLAG")
	private String dtlFlag;
	
	@XmlElement(name="REPACKING_FLAG")
	private String rePackingFlag;
	
	@XmlElement(name="USER_ID")
	private String userId;
	
	@XmlElement(name="COMMENTS")
	private String comments;
	
	@XmlElementWrapper(name = "LOGS")
    @XmlElement(name = "LOG")
	private List<String> logs;
	
	@XmlElementWrapper(name = "PART_LIST")
    @XmlElement(name = "PART")
	private List<String> partList;
	
	@XmlElementWrapper(name = "SUPPLIER_CODE_LIST")
    @XmlElement(name = "SUPPLIER_CODE")
	private List<String> supplierCodeList;
	
	
    @XmlElement(name = "LOCATIONS")
	private String locations;
	
    private List<String> LocationList;
    
    private String plant;
    private String shop;
    private String line;
    private boolean unreleasedParts;
    private String pcCode;
    
    
    
	@XmlElementWrapper(name = "LOCATION_COUNT")
    @XmlElement(name = "LOCATION_COUNT")
	private List<LocationCountDTO> locationCount;
    
    @XmlElement(name = "START_INDEX")
	private int startIndex;
    
    @XmlElement(name = "END_INDEX")
	private int endIndex;

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getPartName() {
		return partName;
	}

	public void setPartName(String partName) {
		this.partName = partName;
	}

	public int getSnp() {
		return snp;
	}

	public void setSnp(int snp) {
		this.snp = snp;
	}

	public String getPartType() {
		return partType;
	}

	public void setPartType(String partType) {
		this.partType = partType;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getLeadTime() {
		return leadTime;
	}

	public void setLeadTime(int leadTime) {
		this.leadTime = leadTime;
	}

	public int getSafetyStock() {
		return safetyStock;
	}

	public void setSafetyStock(int safetyStock) {
		this.safetyStock = safetyStock;
	}

	public String getSupplierCode() {
		return supplierCode;
	}

	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getDepoCode() {
		return depoCode;
	}

	public void setDepoCode(String depoCode) {
		this.depoCode = depoCode;
	}

	public String getDtlFlag() {
		return dtlFlag;
	}

	public void setDtlFlag(String dtlFlag) {
		this.dtlFlag = dtlFlag;
	}

	public String getRePackingFlag() {
		return rePackingFlag;
	}

	public void setRePackingFlag(String rePackingFlag) {
		this.rePackingFlag = rePackingFlag;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public List<String> getLogs() {
		return logs;
	}

	public void setLogs(List<String> logs) {
		this.logs = logs;
	}

	public List<String> getPartList() {
		return partList;
	}

	public void setPartList(List<String> partList) {
		this.partList = partList;
	}

	public List<String> getSupplierCodeList() {
		return supplierCodeList;
	}

	public void setSupplierCodeList(List<String> supplierCodeList) {
		this.supplierCodeList = supplierCodeList;
	}

	public String getLocations() {
		return locations;
	}

	public void setLocations(String locations) {
		this.locations = locations;
	}

	public List<String> getLocationList() {
		return LocationList;
	}

	public void setLocationList(List<String> locationList) {
		LocationList = locationList;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getShop() {
		return shop;
	}

	public void setShop(String shop) {
		this.shop = shop;
	}

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public boolean isUnreleasedParts() {
		return unreleasedParts;
	}

	public void setUnreleasedParts(boolean unreleasedParts) {
		this.unreleasedParts = unreleasedParts;
	}

	public String getPcCode() {
		return pcCode;
	}

	public void setPcCode(String pcCode) {
		this.pcCode = pcCode;
	}

	public List<LocationCountDTO> getLocationCount() {
		return locationCount;
	}

	public void setLocationCount(List<LocationCountDTO> locationCount) {
		this.locationCount = locationCount;
	}

	public int getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}

	public int getEndIndex() {
		return endIndex;
	}

	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}

}
