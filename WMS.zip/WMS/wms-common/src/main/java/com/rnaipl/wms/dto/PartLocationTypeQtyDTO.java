package com.rnaipl.wms.dto;

public class PartLocationTypeQtyDTO {

		
private String wareHouseQty;
private String overflowQty;
private String lineQty;
private boolean childRecord;

//added by arun for T&C CR
private String otherQty;

public String getOtherQty() {
	return otherQty;
}
public void setOtherQty(String otherQty) {
	this.otherQty = otherQty;
}
//
/**
 * @return
 */
public String getWareHouseQty() {
	return wareHouseQty;
}
/**
 * @param wareHouseQty
 */
public void setWareHouseQty(String wareHouseQty) {
	this.wareHouseQty = wareHouseQty;
}
/**
 * @return
 */
public String getOverflowQty() {
	return overflowQty;
}
/**
 * @param overflowQty
 */
public void setOverflowQty(String overflowQty) {
	this.overflowQty = overflowQty;
}
/**
 * @return
 */
public String getLineQty() {
	return lineQty;
}
/**
 * @param lineQty
 */
public void setLineQty(String lineQty) {
	this.lineQty = lineQty;
}

/**
 * @return
 */
public boolean isChildRecord() {
	return childRecord;
}
/**
 * @param childRecord
 */
public void setChildRecord(boolean childRecord) {
	this.childRecord = childRecord;
}
		
}
