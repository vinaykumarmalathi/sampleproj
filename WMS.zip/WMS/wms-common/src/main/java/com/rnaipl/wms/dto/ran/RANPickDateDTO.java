package com.rnaipl.wms.dto.ran;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Calendar;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * This class is to contain the details to be presented to user in presentation
 * layer for Plant related Data
 * 
 * @CreatedBy TechM
 * @CreatedOn 20-Apr-2016 
 */
@XmlRootElement(name = "ranlastpickdate")
public class RANPickDateDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String RAN;
	//private String partNo;
	private String LPPD
	;
	@XmlElement
	public String getRAN() {
		return RAN;
	}
	public void setRAN(String rAN) {
		RAN = rAN;
	}
	@XmlElement
	public String getLPPD() {
		return LPPD;
	}
	public void setLPPD(String lPPD) {
		LPPD = lPPD;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	



	
	

}
