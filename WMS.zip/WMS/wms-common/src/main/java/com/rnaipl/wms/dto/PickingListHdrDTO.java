package com.rnaipl.wms.dto;

public class PickingListHdrDTO {
	
	private String pickListnumber;
	private String line;
	private String shop;
	private String zone;
	private String creationTime;
	private String status;
	private int totalNoOfParts;
	private int totalNoOfBox;
	private String allocation;
	
	public String getPickListnumber() {
		return pickListnumber;
	}
	public void setPickListnumber(String pickListnumber) {
		this.pickListnumber = pickListnumber;
	}
	public String getLine() {
		return line;
	}
	public void setLine(String line) {
		this.line = line;
	}
	public String getShop() {
		return shop;
	}
	public void setShop(String shop) {
		this.shop = shop;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getCreationTime() {
		return creationTime;
	}
	public void setCreationTime(String creationTime) {
		this.creationTime = creationTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getTotalNoOfParts() {
		return totalNoOfParts;
	}
	public void setTotalNoOfParts(int totalNoOfParts) {
		this.totalNoOfParts = totalNoOfParts;
	}
	public int getTotalNoOfBox() {
		return totalNoOfBox;
	}
	public void setTotalNoOfBox(int totalNoOfBox) {
		this.totalNoOfBox = totalNoOfBox;
	}
	public String getAllocation() {
		return allocation;
	}
	public void setAllocation(String allocation) {
		this.allocation = allocation;
	}
	
	
	

}
