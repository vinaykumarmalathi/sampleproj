package com.rnaipl.wms.dto;

import java.io.Serializable;
import java.util.List;

public class PartLocationDTO implements Serializable {

    private int totalCapactity;
    private int currentQty;
    private String ran;
    private String partNo;
    private String locationId;
    private String locationType;
    private String shop;
    private String plant;
    private String line;
    private String section;
    private int startIndex;
    private int endIndex;
    private List<String> partList;
    private List<String> locationList;
    private List<String> ranList;
    private String mapType;
    private int isFullDownload;
    
    public List<String> getLocationList() {
		return locationList;
	}

	public void setLocationList(List<String> locationList) {
		this.locationList = locationList;
	}

	public int getTotalCapactity() {
        return totalCapactity;
    }

    public void setTotalCapactity(int totalCapactity) {
        this.totalCapactity = totalCapactity;
    }

    public int getCurrentQty() {
        return currentQty;
    }

    public void setCurrentQty(int availableCapacity) {
        this.currentQty = availableCapacity;
    }

    public String getRan() {
        return ran;
    }

    public void setRan(String ran) {
        this.ran = ran;
    }

    /**
     * @return the partNo
     */
    public String getPartNo() {
        return partNo;
    }

    /**
     * @param partNo
     *            the partNo to set
     */
    public void setPartNo(String partNo) {
        this.partNo = partNo;
    }

    /**
     * @return the locationId
     */
    public String getLocationId() {
        return locationId;
    }

    /**
     * @param locationId
     *            the locationId to set
     */
    public void setLocationId(String locationId) {
        this.locationId = locationId;
    }

    /**
     * @return the locationType
     */
    public String getLocationType() {
        return locationType;
    }

    /**
     * @param locationType the locationType to set
     */
    public void setLocationType(String locationType) {
        this.locationType = locationType;
    }

    
    
	/**
	 * @return
	 */
	public String getShop() {
		return shop;
	}

	/**
	 * @param shop
	 */
	public void setShop(String shop) {
		this.shop = shop;
	}

	/**
	 * @return
	 */
	public String getPlant() {
		return plant;
	}

	/**
	 * @param plant
	 */
	public void setPlant(String plant) {
		this.plant = plant;
	}

	/**
	 * @return
	 */
	public String getLine() {
		return line;
	}

	/**
	 * @param line
	 */
	public void setLine(String line) {
		this.line = line;
	}

	/**
	 * @return
	 */
	public String getSection() {
		return section;
	}

	/**
	 * @param section
	 */
	public void setSection(String section) {
		this.section = section;
	}

	/**
	 * @return
	 */
	public int getStartIndex() {
		return startIndex;
	}

	/**
	 * @param startIndex
	 */
	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}

	/**
	 * @return
	 */
	public int getEndIndex() {
		return endIndex;
	}

	/**
	 * @param endIndex
	 */
	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}


	/**
	 * @return
	 */
	public List<String> getPartList() {
		return partList;
	}

	/**
	 * @param partList
	 */
	public void setPartList(List<String> partList) {
		this.partList = partList;
	}

	public List<String> getRanList() {
		return ranList;
	}

	public void setRanList(List<String> ranList) {
		this.ranList = ranList;
	}

	public String getMapType() {
		return mapType;
	}

	public void setMapType(String mapType) {
		this.mapType = mapType;
	}

	public int getIsFullDownload() {
		return isFullDownload;
	}

	public void setIsFullDownload(int isFullDownload) {
		this.isFullDownload = isFullDownload;
	}

	
}
