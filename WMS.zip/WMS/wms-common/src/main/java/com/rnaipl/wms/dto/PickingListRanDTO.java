package com.rnaipl.wms.dto;

public class PickingListRanDTO {
	
	private String pickListnumber;
	private String partNo;
	private String location;
	private String ranNo;
	private int qty;
	private int totalNoOpenBox;
	private int partOrder;
	private int ranOrder;
	private int ageingDays;
	
	
	public int getAgeingDays() {
		return ageingDays;
	}
	public void setAgeingDays(int ageingDays) {
		this.ageingDays = ageingDays;
	}
	public String getPickListnumber() {
		return pickListnumber;
	}
	public void setPickListnumber(String pickListnumber) {
		this.pickListnumber = pickListnumber;
	}
	public String getPartNo() {
		return partNo;
	}
	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getRanNo() {
		return ranNo;
	}
	public void setRanNo(String ranNo) {
		this.ranNo = ranNo;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public int getTotalNoOpenBox() {
		return totalNoOpenBox;
	}
	public void setTotalNoOpenBox(int totalNoOpenBox) {
		this.totalNoOpenBox = totalNoOpenBox;
	}
	public int getPartOrder() {
		return partOrder;
	}
	public void setPartOrder(int partOrder) {
		this.partOrder = partOrder;
	}
	public int getRanOrder() {
		return ranOrder;
	}
	public void setRanOrder(int ranOrder) {
		this.ranOrder = ranOrder;
	}
}
