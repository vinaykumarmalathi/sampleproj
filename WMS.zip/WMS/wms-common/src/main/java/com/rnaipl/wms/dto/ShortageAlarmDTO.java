/**
 * 
 */
package com.rnaipl.wms.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author z023761
 *
 */
public class ShortageAlarmDTO implements Serializable{	
	      
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//search filter varables
	private String plant;	
	private String shop;
	private String line;
	private String zone;
	private String partType;
	private String wip;
	private String partNumber;
	private String supCode;
	private String depotCode;
	private String pcCode;
	private String calLogic;
	private String shortageType;
	private Boolean shortageTypeR;
	private Boolean shortageTypeY;
	private Boolean shortageTypeG;
	private String fromDate;
	private String toDate;
	private Date lastWmsCalDate;
	private Date lastCatsCalDate;
	
	private String lastWmsCalStr;
	private String lastCatsCalStr;
	
	//session and index variables
	private String userId;
	private String sessionId;
	private Integer startIndex;
	private Integer endIndex;
	
	//search result variables
	private String partName;
	private String supName;
	private Integer totWip;
	private Integer tcf;
	private Integer pbs;
	private Integer pa2;
	private Integer pa1;
	private Integer metal;
	private Date grossDate;
	private Integer grossQty;
	private Date lastWhOut;
	private Integer lastWhOutQty;
	private Integer catsStk;
	private Integer wmsStock;
	private Integer lsStock;
	private String eopMark;
	private Integer eopFlagQty;
	private Integer holdQty;
	private Integer undeliveredQty;
	private Integer pendingRanQty;
	
	//color logic calculation variables
	private String metalClr;
	private String pa1Clr;
	private String pa2Clr;
	private String pbsClr;
	private String tcfClr;
	
	//autocomplete logic variables
	private List<String> partList;
	private List<String> supplierList;
	private List<String> depoList;
	private List<String> pcList;
	
	//download logic variables
	private String downloadName;
	private String downloadPath;
	private String flag;
	private Boolean isFullDownload;
	
	//total wip and snp variables	
	private Integer trimWip;
	private Integer pbsWip;
	private Integer pa2Wip;
	private Integer pa1Wip;
	private Integer metalWip;
	private Integer snep;
	private Integer snip;
	
	//ADDED FOR UAT REQ TO MERGE T&K SHOP DROP DOWN -START
	private String shopList;
	private String shopId;
	private String shopName;
			
	//Added for getting lines by shop
	private String lineList;
	private String lineId;
	private String lineName;
	
	private String maxGrossDateStr;

	public Integer getSnep() {
		return snep;
	}

	public void setSnep(Integer snep) {
		this.snep = snep;
	}

	public Integer getSnip() {
		return snip;
	}

	public void setSnip(Integer snip) {
		this.snip = snip;
	}

	public String getMaxGrossDateStr() {
		return maxGrossDateStr;
	}

	public void setMaxGrossDateStr(String maxGrossDateStr) {
		this.maxGrossDateStr = maxGrossDateStr;
	}

	public String getLineList() {
		return lineList;
	}

	public void setLineList(String lineList) {
		this.lineList = lineList;
	}

	public String getLineId() {
		return lineId;
	}

	public void setLineId(String lineId) {
		this.lineId = lineId;
	}

	public String getLineName() {
		return lineName;
	}

	public void setLineName(String lineName) {
		this.lineName = lineName;
	}

	public String getShopList() {
		return shopList;
	}

	public void setShopList(String shopList) {
		this.shopList = shopList;
	}

	public String getShopId() {
		return shopId;
	}

	public void setShopId(String shopId) {
		this.shopId = shopId;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	
	public Integer getTrimWip() {
		return trimWip;
	}

	public void setTrimWip(Integer trimWip) {
		this.trimWip = trimWip;
	}

	public Integer getPbsWip() {
		return pbsWip;
	}

	public void setPbsWip(Integer pbsWip) {
		this.pbsWip = pbsWip;
	}

	public Integer getPa2Wip() {
		return pa2Wip;
	}

	public void setPa2Wip(Integer pa2Wip) {
		this.pa2Wip = pa2Wip;
	}

	public Integer getPa1Wip() {
		return pa1Wip;
	}

	public void setPa1Wip(Integer pa1Wip) {
		this.pa1Wip = pa1Wip;
	}

	public Integer getMetalWip() {
		return metalWip;
	}

	public void setMetalWip(Integer metalWip) {
		this.metalWip = metalWip;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getDownloadName() {
		return downloadName;
	}

	public void setDownloadName(String downloadName) {
		this.downloadName = downloadName;
	}

	public String getDownloadPath() {
		return downloadPath;
	}

	public void setDownloadPath(String downloadPath) {
		this.downloadPath = downloadPath;
	}

	public List<String> getSupplierList() {
		return supplierList;
	}

	public void setSupplierList(List<String> supplierList) {
		this.supplierList = supplierList;
	}

	public List<String> getDepoList() {
		return depoList;
	}

	public void setDepoList(List<String> depoList) {
		this.depoList = depoList;
	}

	public List<String> getPcList() {
		return pcList;
	}

	public void setPcList(List<String> pcList) {
		this.pcList = pcList;
	}

	public List<String> getPartList() {
		return partList;
	}

	public void setPartList(List<String> partList) {
		this.partList = partList;
	}

	public String getPartType() {
		return partType;
	}

	public void setPartType(String partType) {
		this.partType = partType;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getPartName() {
		return partName;
	}

	public void setPartName(String partName) {
		this.partName = partName;
	}

	public String getPcCode() {
		return pcCode;
	}

	public void setPcCode(String pcCode) {
		this.pcCode = pcCode;
	}

	public String getSupName() {
		return supName;
	}

	public void setSupName(String supName) {
		this.supName = supName;
	}

	public String getDepotCode() {
		return depotCode;
	}

	public void setDepotCode(String depotCode) {
		this.depotCode = depotCode;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public Integer getTotWip() {
		return totWip;
	}

	public void setTotWip(Integer totWip) {
		this.totWip = totWip;
	}

	public Integer getTcf() {
		return tcf;
	}

	public void setTcf(Integer tcf) {
		this.tcf = tcf;
	}

	public Integer getPbs() {
		return pbs;
	}

	public void setPbs(Integer pbs) {
		this.pbs = pbs;
	}

	public Integer getPa2() {
		return pa2;
	}

	public void setPa2(Integer pa2) {
		this.pa2 = pa2;
	}

	public Integer getPa1() {
		return pa1;
	}

	public void setPa1(Integer pa1) {
		this.pa1 = pa1;
	}

	public Integer getMetal() {
		return metal;
	}

	public void setMetal(Integer metal) {
		this.metal = metal;
	}

	public Integer getCatsStk() {
		return catsStk;
	}

	public void setCatsStk(Integer catsStk) {
		this.catsStk = catsStk;
	}

	public Integer getWmsStock() {
		return wmsStock;
	}

	public void setWmsStock(Integer wmsStock) {
		this.wmsStock = wmsStock;
	}

	public Integer getLsStock() {
		return lsStock;
	}

	public void setLsStock(Integer lsStock) {
		this.lsStock = lsStock;
	}

	public String getEopMark() {
		return eopMark;
	}

	public void setEopMark(String eopMark) {
		this.eopMark = eopMark;
	}

	public Integer getEopFlagQty() {
		return eopFlagQty;
	}

	public void setEopFlagQty(Integer eopFlagQty) {
		this.eopFlagQty = eopFlagQty;
	}

	public Integer getHoldQty() {
		return holdQty;
	}

	public void setHoldQty(Integer holdQty) {
		this.holdQty = holdQty;
	}

	public Integer getUndeliveredQty() {
		return undeliveredQty;
	}

	public void setUndeliveredQty(Integer undeliveredQty) {
		this.undeliveredQty = undeliveredQty;
	}

	public Integer getPendingRanQty() {
		return pendingRanQty;
	}

	public void setPendingRanQty(Integer pendingRanQty) {
		this.pendingRanQty = pendingRanQty;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getShop() {
		return shop;
	}

	public void setShop(String shop) {
		this.shop = shop;
	}

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public String getSupCode() {
		return supCode;
	}

	public void setSupCode(String supCode) {
		this.supCode = supCode;
	}

	public String getShortageType() {
		return shortageType;
	}

	public void setShortageType(String shortageType) {
		this.shortageType = shortageType;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getCalLogic() {
		return calLogic;
	}

	public void setCalLogic(String calLogic) {
		this.calLogic = calLogic;
	}


	public Boolean getIsFullDownload() {
		return isFullDownload;
	}

	public void setIsFullDownload(Boolean isFullDownload) {
		this.isFullDownload = isFullDownload;
	}

	public Integer getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(Integer startIndex) {
		this.startIndex = startIndex;
	}

	public Integer getEndIndex() {
		return endIndex;
	}

	public void setEndIndex(Integer endIndex) {
		this.endIndex = endIndex;
	}

	public String getWip() {
		return wip;
	}

	public void setWip(String wip) {
		this.wip = wip;
	}

	public Date getGroosDate() {
		return grossDate;
	}

	public void setGroosDate(Date groosDate) {
		this.grossDate = groosDate;
	}

	public Integer getGrossQty() {
		return grossQty;
	}

	public void setGrossQty(Integer grossQty) {
		this.grossQty = grossQty;
	}

	public Date getLastWhOut() {
		return lastWhOut;
	}

	public void setLastWhOut(Date lastWhOut) {
		this.lastWhOut = lastWhOut;
	}

	public Integer getLastWhOutQty() {
		return lastWhOutQty;
	}

	public void setLastWhOutQty(Integer lastWhOutQty) {
		this.lastWhOutQty = lastWhOutQty;
	}


	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getMetalClr() {
		return metalClr;
	}

	public void setMetalClr(String metalClr) {
		this.metalClr = metalClr;
	}

	public String getPa1Clr() {
		return pa1Clr;
	}

	public void setPa1Clr(String pa1Clr) {
		this.pa1Clr = pa1Clr;
	}

	public String getPa2Clr() {
		return pa2Clr;
	}

	public void setPa2Clr(String pa2Clr) {
		this.pa2Clr = pa2Clr;
	}

	public String getPbsClr() {
		return pbsClr;
	}

	public void setPbsClr(String pbsClr) {
		this.pbsClr = pbsClr;
	}

	public String getTcfClr() {
		return tcfClr;
	}

	public void setTcfClr(String tcfClr) {
		this.tcfClr = tcfClr;
	}

	public Boolean getShortageTypeR() {
		return shortageTypeR;
	}

	public void setShortageTypeR(Boolean shortageTypeR) {
		this.shortageTypeR = shortageTypeR;
	}

	public Boolean getShortageTypeY() {
		return shortageTypeY;
	}

	public void setShortageTypeY(Boolean shortageTypeY) {
		this.shortageTypeY = shortageTypeY;
	}

	public Boolean getShortageTypeG() {
		return shortageTypeG;
	}

	public void setShortageTypeG(Boolean shortageTypeG) {
		this.shortageTypeG = shortageTypeG;
	}

	public Date getGrossDate() {
		return grossDate;
	}

	public void setGrossDate(Date grossDate) {
		this.grossDate = grossDate;
	}
	
	public Date getLastWmsCalDate() {
		return lastWmsCalDate;
	}

	public void setLastWmsCalDate(Date lastWmsCalDate) {
		this.lastWmsCalDate = lastWmsCalDate;
	}

	public Date getLastCatsCalDate() {
		return lastCatsCalDate;
	}

	public void setLastCatsCalDate(Date lastCatsCalDate) {
		this.lastCatsCalDate = lastCatsCalDate;
	}

	public String getLastWmsCalStr() {
		return lastWmsCalStr;
	}

	public void setLastWmsCalStr(String lastWmsCalStr) {
		this.lastWmsCalStr = lastWmsCalStr;
	}

	public String getLastCatsCalStr() {
		return lastCatsCalStr;
	}

	public void setLastCatsCalStr(String lastCatsCalStr) {
		this.lastCatsCalStr = lastCatsCalStr;
	}	
}