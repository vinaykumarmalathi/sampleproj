package com.rnaipl.wms.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "partlocation")
public class PartLocationSynchroServiceDTO implements Serializable{
	
	private String partNumber;
	private int snp;
	private int snip;
	private String locationId;
	private String category;
	private String shelfLifePart;
	
	@XmlElement
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	@XmlElement
	public int getSnp() {
		return snp;
	}
	public void setSnp(int snp) {
		this.snp = snp;
	}
	@XmlElement
	public int getSnip() {
		return snip;
	}
	public void setSnip(int snip) {
		this.snip = snip;
	}
	@XmlElement
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	
	@XmlElement
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	
	@XmlElement
	public String getShelfLifePart() {
		return shelfLifePart;
	}
	public void setShelfLifePart(String shelfLifePart) {
		this.shelfLifePart = shelfLifePart;
	}
	
	@Override
	public String toString() {
		return "PartLocationSynchroServiceDTO [partNumber=" + partNumber
				+ ", snp=" + snp + ", snip=" + snip + ", locationId=" + locationId + "]";
	}

}
