package com.rnaipl.wms.dto.reports;

import java.util.List;

import com.rnaipl.wms.dto.PickinglistDetailsDTO;

public class PickinglistResultsDTO {
	private String pickListnumber;
	private String line;
	private String shop;
	private String zone;
	private String whOut;
	private String creationTime;
	private String closureTime;
	private String status;
	private int totalNoOfParts;
	private int totalNoOfBox;
	private String deviceId;
	private String allocation;
	private List<PickinglistDetailsDTO> detailsDTOList;
	
	
	public String getPickListnumber() {
		return pickListnumber;
	}
	public void setPickListnumber(String pickListnumber) {
		this.pickListnumber = pickListnumber;
	}
	public String getLine() {
		return line;
	}
	public void setLine(String line) {
		this.line = line;
	}
	public String getShop() {
		return shop;
	}
	public void setShop(String shop) {
		this.shop = shop;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	
	public String getWhOut() {
		return whOut;
	}
	public void setWhOut(String whOut) {
		this.whOut = whOut;
	}
	public String getCreationTime() {
		return creationTime;
	}
	public void setCreationTime(String creationTime) {
		this.creationTime = creationTime;
	}
	public String getClosureTime() {
		return closureTime;
	}
	public void setClosureTime(String closureTime) {
		this.closureTime = closureTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getTotalNoOfParts() {
		return totalNoOfParts;
	}
	public void setTotalNoOfParts(int totalNoOfParts) {
		this.totalNoOfParts = totalNoOfParts;
	}
	public int getTotalNoOfBox() {
		return totalNoOfBox;
	}
	public void setTotalNoOfBox(int totalNoOfBox) {
		this.totalNoOfBox = totalNoOfBox;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public List<PickinglistDetailsDTO> getDetailsDTOList() {
		return detailsDTOList;
	}
	public void setDetailsDTOList(List<PickinglistDetailsDTO> detailsDTOList) {
		this.detailsDTOList = detailsDTOList;
	}
	public String getAllocation() {
		return allocation;
	}
	public void setAllocation(String allocation) {
		this.allocation = allocation;
	}
	
	
}
