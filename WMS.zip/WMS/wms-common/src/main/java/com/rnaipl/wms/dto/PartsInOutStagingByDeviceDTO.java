package com.rnaipl.wms.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="LocalDBScanedDetails")
@XmlAccessorType(XmlAccessType.FIELD)
public class PartsInOutStagingByDeviceDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@XmlElement(name="PART_NO")
	private String partNumber;
	
	@XmlElement(name="LOCATION")
	private String location;
	
	@XmlElement(name="TRANSACTION_TYPE")
	private String transactionType;
	
	@XmlElement(name="COUNT")
	private int count;
	
	@XmlElement(name="RAN")
	private String ran;
	
	@XmlElement(name="USER_ID")
	private String userId;
	
	@XmlElement(name="DEVICE_ID")
	private String deviceId;
	
	@XmlElement(name="PART_IN_OUT_TIME")
	private Date partInOutTime;
	
	@XmlElement(name="NO_OF_BOXES")
	private int noOfBoxes;
	
	@XmlElement(name="comments")
	private String comments;
	
	@XmlElement(name="REASON_CODE")
	private String reasonCode;
	
	@XmlElement(name="reason")
	private String reason;
	
	@XmlElement(name="SCANTIME")
	private String scanTime;	
	
	@XmlElement(name="SNP")
	private int snp;
	
	@XmlElement(name="SUGGESTED_LOC")
	private String suggestedLocation;
	
	@XmlElement(name="SUGGESTED_RAN")
	private String suggestedRan;
	
	@XmlElement(name="LOCATION_DESTINATION")
	private String locationDestination;
	
	//added for deviation resoncode
	@XmlElement(name="DEVIATION_REASON")
	private String deviationResonCode;
	
	//added for pickinglist
	@Column(name="PICKLIST_NO")
	private String pickListNo;
	
	public String getPickListNo() {
		return pickListNo;
	}

	public void setPickListNo(String pickListNo) {
		this.pickListNo = pickListNo;
	}

	public String getDeviationResonCode() {
		return deviationResonCode;
	}
	public void setDeviationResonCode(String deviationResonCode) {
		this.deviationResonCode = deviationResonCode;
	}
	//end
	
	public int getNoOfBoxes() {
		return noOfBoxes;
	}
	public void setNoOfBoxes(int noOfBoxes) {
		this.noOfBoxes = noOfBoxes;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getReasonCode() {
		return reasonCode;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getRan() {
		return ran;
	}
	public void setRan(String ran) {
		this.ran = ran;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public Date getPartInOutTime() {
		return partInOutTime;
	}
	public void setPartInOutTime(Date partInOutTime) {
		this.partInOutTime = partInOutTime;
	}
	public String getScanTime() {
		return scanTime;
	}
	public void setScanTime(String scanTime) {
		this.scanTime = scanTime;
	}
	public int getSnp() {
		return snp;
	}
	public void setSnp(int snp) {
		this.snp = snp;
	}
	public String getSuggestedLocation() {
		return suggestedLocation;
	}
	public void setSuggestedLocation(String suggestedLocation) {
		this.suggestedLocation = suggestedLocation;
	}
	public String getSuggestedRan() {
		return suggestedRan;
	}
	public void setSuggestedRan(String suggestedRan) {
		this.suggestedRan = suggestedRan;
	}
	public String getLocationDestination() {
		return locationDestination;
	}
	public void setLocationDestination(String locationDestination) {
		this.locationDestination = locationDestination;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
