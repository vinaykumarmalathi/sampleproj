package com.rnaipl.wms.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class LocationDTO implements Serializable{
	
	private String plant;	
	private String shop;
	private String line;
	private String section;
	private String zone;
	private String series;
	private String locationSeries1;
	private String locationSeries2;
	private String level;
	private String cellId;
	private String locationLevel;
	private String userId;
	private String comments;
	//Added by Meena
	private String remarks;
	
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getLocationLevel() {
		return locationLevel;
	}
	public void setLocationLevel(String locationLevel) {
		this.locationLevel = locationLevel;
	}
	private List<String> parts ;
	private Map<String,Integer> partCount;
	
	public Map<String, Integer> getPartCount() {
		return partCount;
	}
	public void setPartCount(Map<String, Integer> partCount) {
		this.partCount = partCount;
	}
	public List<String> getParts() {
		return parts;
	}
	public void setParts(List<String> parts) {
		this.parts = parts;
	}
	private String locationId;
	private String LocationType;	
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public String getLocationType() {
		return LocationType;
	}
	public void setLocationType(String locationType) {
		LocationType = locationType;
	}
	
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public String getShop() {
		return shop;
	}
	public void setShop(String shop) {
		this.shop = shop;
	}
	public String getLine() {
		return line;
	}
	public void setLine(String line) {
		this.line = line;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getSeries() {
		return series;
	}
	public void setSeries(String series) {
		this.series = series;
	}
	public String getLocationSeries1() {
		return locationSeries1;
	}
	public void setLocationSeries1(String locationSeries1) {
		this.locationSeries1 = locationSeries1;
	}
	public String getLocationSeries2() {
		return locationSeries2;
	}
	public void setLocationSeries2(String locationSeries2) {
		this.locationSeries2 = locationSeries2;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getCellId() {
		return cellId;
	}
	public void setCellId(String cellId) {
		this.cellId = cellId;
	}
	
	
	


}
