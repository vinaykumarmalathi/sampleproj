package com.rnaipl.wms.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/*AJ00482484 : LIVE Receipt Change : START*/
public class LiveReceiptQtyMismatchDTO implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String ran;	
	private String plant;
	private String shop;
	private String line;
	private String zone;	
	private String partNumber;
	
	private String liveReceiptPartNumber;
	private String liveReceiptQuantity;
	private Date fromDate;
	private Date toDate;
	private Date auditFromDate;
	private Date auditToDate;	
	private Date fromTime;
	private Date toTime;		
	
	private int startIndex;
	private int endIndex;
	private int isFullDownload;
	
	private List<String> ranList;
	private List<String> partList;
	private List<String> supList;	
	private List<String> contNoList;
	private List<String> dNoteNoList;
	private List<String> recPlaceList;
	
	
	/*private Date liveReceiptUpdatedTime;*/
	private String liveReceiptUpdatedTime;
	
	private String auditRan;
	private String auditPartNumber;
	private int auditQuantity;
	/*private Date auditScanTime;*/
	private String auditScanTime;
	private BigDecimal auditPartPk;
	
	private String partType;
	private String location;
	private String supplier;
	private int snp;
	private int boxRecWms;
	private int boxRecCats;
	private int boxMismatch;
	private String processCode;
	private String dNote;
	private int dNoteQty;
	private int qtyMismatch;
	private String remarks;
	private String receipt;	
	private String containerNo;
	private String recPlace;
	private String colName;
	private PartNumberDTO input;
	
	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}
	
	public List<String> getContNoList() {
		return contNoList;
	}

	public void setContNoList(List<String> contNoList) {
		this.contNoList = contNoList;
	}

	public List<String> getdNoteNoList() {
		return dNoteNoList;
	}

	public void setdNoteNoList(List<String> dNoteNoList) {
		this.dNoteNoList = dNoteNoList;
	}

	public List<String> getRecPlaceList() {
		return recPlaceList;
	}

	public void setRecPlaceList(List<String> recPlaceList) {
		this.recPlaceList = recPlaceList;
	}
	
	public PartNumberDTO getInput() {
		return input;
	}

	public void setInput(PartNumberDTO input) {
		this.input = input;
	}

	public String getColName() {
		return colName;
	}

	public void setColName(String colName) {
		this.colName = colName;
	}

	public List<String> getSupList() {
		return supList;
	}

	public void setSupList(List<String> supList) {
		this.supList = supList;
	}
	
	public Date getFromTime() {
		return fromTime;
	}

	public void setFromTime(Date fromTime) {
		this.fromTime = fromTime;
	}

	public Date getToTime() {
		return toTime;
	}

	public void setToTime(Date toTime) {
		this.toTime = toTime;
	}

	public String getRecPlace() {
		return recPlace;
	}

	public void setRecPlace(String recPlace) {
		this.recPlace = recPlace;
	}
	
	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}
	
	public String getShop() {
		return shop;
	}

	public void setShop(String shop) {
		this.shop = shop;
	}

	public String getPartType() {
		return partType;
	}

	public void setPartType(String partType) {
		this.partType = partType;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	/*public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}*/

	public int getSnp() {
		return snp;
	}

	public void setSnp(int snp) {
		this.snp = snp;
	}

	public int getBoxRecWms() {
		return boxRecWms;
	}

	public void setBoxRecWms(int boxRecWms) {
		this.boxRecWms = boxRecWms;
	}

	public int getBoxRecCats() {
		return boxRecCats;
	}

	public void setBoxRecCats(int boxRecCats) {
		this.boxRecCats = boxRecCats;
	}

	public int getBoxMismatch() {
		return boxMismatch;
	}

	public void setBoxMismatch(int boxMismatch) {
		this.boxMismatch = boxMismatch;
	}

	public String getProcessCode() {
		return processCode;
	}

	public void setProcessCode(String processCode) {
		this.processCode = processCode;
	}

	public String getdNote() {
		return dNote;
	}

	public void setdNote(String dNote) {
		this.dNote = dNote;
	}

	public int getdNoteQty() {
		return dNoteQty;
	}

	public void setdNoteQty(int dNoteQty) {
		this.dNoteQty = dNoteQty;
	}

	public int getQtyMismatch() {
		return qtyMismatch;
	}

	public void setQtyMismatch(int qtyMismatch) {
		this.qtyMismatch = qtyMismatch;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getReceipt() {
		return receipt;
	}

	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}

	public String getContainerNo() {
		return containerNo;
	}

	public void setContainerNo(String containerNo) {
		this.containerNo = containerNo;
	}

	public String getRan() {
		return ran;
	}

	public void setRan(String ran) {
		this.ran = ran;
	}
	
	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getLiveReceiptPartNumber() {
		return liveReceiptPartNumber;
	}

	public void setLiveReceiptPartNumber(String liveReceiptPartNumber) {
		this.liveReceiptPartNumber = liveReceiptPartNumber;
	}


	public String getLiveReceiptQuantity() {
		return liveReceiptQuantity;
	}

	public void setLiveReceiptQuantity(String liveReceiptQuantity) {
		this.liveReceiptQuantity = liveReceiptQuantity;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public Date getAuditFromDate() {
		return auditFromDate;
	}

	public void setAuditFromDate(Date auditFromDate) {
		this.auditFromDate = auditFromDate;
	}

	public Date getAuditToDate() {
		return auditToDate;
	}

	public void setAuditToDate(Date auditToDate) {
		this.auditToDate = auditToDate;
	}

	public int getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}

	public int getEndIndex() {
		return endIndex;
	}

	public String getAuditRan() {
		return auditRan;
	}

	public void setAuditRan(String auditRan) {
		this.auditRan = auditRan;
	}

	public String getAuditPartNumber() {
		return auditPartNumber;
	}

	public void setAuditPartNumber(String auditPartNumber) {
		this.auditPartNumber = auditPartNumber;
	}

	public int getAuditQuantity() {
		return auditQuantity;
	}

	public void setAuditQuantity(int auditQuantity) {
		this.auditQuantity = auditQuantity;
	}

	public String getAuditScanTime() {
		return auditScanTime;
	}

	public void setAuditScanTime(String auditScanTime) {
		this.auditScanTime = auditScanTime;
	}

	public BigDecimal getAuditPartPk() {
		return auditPartPk;
	}

	public void setAuditPartPk(BigDecimal auditPartPk) {
		this.auditPartPk = auditPartPk;
	}

	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}

	public int getIsFullDownload() {
		return isFullDownload;
	}

	public void setIsFullDownload(int isFullDownload) {
		this.isFullDownload = isFullDownload;
	}

	public List<String> getRanList() {
		return ranList;
	}

	public void setRanList(List<String> ranList) {
		this.ranList = ranList;
	}

	public List<String> getPartList() {
		return partList;
	}

	public void setPartList(List<String> partList) {
		this.partList = partList;
	}


	public String getLiveReceiptUpdatedTime() {
		return liveReceiptUpdatedTime;
	}

	public void setLiveReceiptUpdatedTime(String liveReceiptUpdatedTime) {
		this.liveReceiptUpdatedTime = liveReceiptUpdatedTime;
	}
	
}
/*AJ00482484 : LIVE Receipt Change : END*/
