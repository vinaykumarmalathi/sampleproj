package com.rnaipl.wms.dto;

import java.io.Serializable;

public class PartLocationCorrectionDTO implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long correctQty;
    private long sourceQty;
    
    private String partNo;
    private String sourceLocation;
    private String correctedLocation;
    private String comments;
    private String userId;
    private String ran;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public long getCorrectQty() {
		return correctQty;
	}
	public void setCorrectQty(long correctQty) {
		this.correctQty = correctQty;
	}
	public long getSourceQty() {
		return sourceQty;
	}
	public void setSourceQty(long sourceQty) {
		this.sourceQty = sourceQty;
	}
	public String getPartNo() {
		return partNo;
	}
	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}
	public String getSourceLocation() {
		return sourceLocation;
	}
	public void setSourceLocation(String sourceLocation) {
		this.sourceLocation = sourceLocation;
	}
	public String getCorrectedLocation() {
		return correctedLocation;
	}
	public void setCorrectedLocation(String correctedLocation) {
		this.correctedLocation = correctedLocation;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getRan() {
		return ran;
	}
	public void setRan(String ran) {
		this.ran = ran;
	}
    
    
}
