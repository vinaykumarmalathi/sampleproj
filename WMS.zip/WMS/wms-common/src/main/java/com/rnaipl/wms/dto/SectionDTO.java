package com.rnaipl.wms.dto;

import java.io.Serializable;

/**
 * This class is to contain the details to be presented to user in presentation
 * layer for Plant related Data
 * 
 * @CreatedBy TechM
 * @CreatedOn 20-Apr-2016 
 */
public class SectionDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String sectionId;
	private String sectionName;
	
	

	


	public String getSectionId() {
		return sectionId;
	}






	public void setSectionId(String sectionId) {
		this.sectionId = sectionId;
	}






	public String getSectionName() {
		return sectionName;
	}






	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}






	@Override
	public String toString() {
		// TODO Auto-generated method stub
		StringBuilder builder = new StringBuilder();
        builder.append("sectionDTO [sectionId=").append(sectionId).append(", sectionName=").append(sectionName).append("]");
        return builder.toString();
	}
}
