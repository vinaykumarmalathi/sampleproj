package com.rnaipl.wms.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class PITCumulativeReportDTO  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String plant;
	private String shop;
	private String recount;
	private String deviceId;
	private List<String> partList;
	private List<String> locationList;
	private List<String> ranList;
	private String partNumber;
	private String location;
	private String ran;
	private String scanned;
		
	private Integer startIndex;
	private Integer endIndex;
	private Integer isFullDownload;
	
	private String transactionId;
	private Integer snp;
	private Integer noOfBoxes;
	private String openQuantity;
	private String totalQuantity;
	private Date dateTime;
	private String transactionType;
	private String isUpdated;
	private Integer commentsFlag;
	private String comments;
	private String wmsStockQuantity;
	private String stockDifference;
	
	private Date fromDate;
	private Date toDate;
	
	private Date updatedDateTime;
	
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public String getShop() {
		return shop;
	}
	public void setShop(String shop) {
		this.shop = shop;
	}
	public String getRecount() {
		return recount;
	}
	public void setRecount(String recount) {
		this.recount = recount;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public List<String> getPartList() {
		return partList;
	}
	public void setPartList(List<String> partList) {
		this.partList = partList;
	}
	public List<String> getLocationList() {
		return locationList;
	}
	public void setLocationList(List<String> locationList) {
		this.locationList = locationList;
	}
	public List<String> getRanList() {
		return ranList;
	}
	public void setRanList(List<String> ranList) {
		this.ranList = ranList;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public Integer getSnp() {
		return snp;
	}
	public void setSnp(Integer snp) {
		this.snp = snp;
	}
	public Integer getNoOfBoxes() {
		return noOfBoxes;
	}
	public void setNoOfBoxes(Integer noOfBoxes) {
		this.noOfBoxes = noOfBoxes;
	}
	public String getOpenQuantity() {
		return openQuantity;
	}
	public void setOpenQuantity(String openQuantity) {
		this.openQuantity = openQuantity;
	}
	public String getTotalQuantity() {
		return totalQuantity;
	}
	public void setTotalQuantity(String totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public Date getDateTime() {
		return dateTime;
	}
	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getIsUpdated() {
		return isUpdated;
	}
	public void setIsUpdated(String isUpdated) {
		this.isUpdated = isUpdated;
	}
	public Integer getCommentsFlag() {
		return commentsFlag;
	}
	public void setCommentsFlag(Integer commentsFlag) {
		this.commentsFlag = commentsFlag;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getWmsStockQuantity() {
		return wmsStockQuantity;
	}
	public void setWmsStockQuantity(String wmsStockQuantity) {
		this.wmsStockQuantity = wmsStockQuantity;
	}
	public String getStockDifference() {
		return stockDifference;
	}
	public void setStockDifference(String stockDifference) {
		this.stockDifference = stockDifference;
	}
	public String getRan() {
		return ran;
	}
	public void setRan(String ran) {
		this.ran = ran;
	}
	public Integer getStartIndex() {
		return startIndex;
	}
	public void setStartIndex(Integer startIndex) {
		this.startIndex = startIndex;
	}
	public Integer getEndIndex() {
		return endIndex;
	}
	public void setEndIndex(Integer endIndex) {
		this.endIndex = endIndex;
	}
	public Integer getIsFullDownload() {
		return isFullDownload;
	}
	public void setIsFullDownload(Integer isFullDownload) {
		this.isFullDownload = isFullDownload;
	}
	public Date getUpdatedDateTime() {
		return updatedDateTime;
	}
	public void setUpdatedDateTime(Date updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}
	public String getScanned() {
		return scanned;
	}
	public void setScanned(String scanned) {
		this.scanned = scanned;
	}



}
