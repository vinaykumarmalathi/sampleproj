package com.rnaipl.wms.dto;

import java.io.Serializable;

/**
 * This class is to contain the details to be presented to user in presentation
 * layer for Plant related Data
 * 
 * @CreatedBy TechM
 * @CreatedOn 20-Apr-2016 
 */
public class PlantDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String plantId;
	private String plantName;
	
	/**
	 * 
	 * @return plantId
	 */
	public String getPlantId() {
		return plantId;
	}
	
	/**
	 * 
	 * @param plantId
	 * 				plantId to set
	 */
	public void setPlantId(String plantId) {
		this.plantId = plantId;
	}
	
	/**
	 * 
	 * @return the plantName
	 */
	public String getPlantName() {
		return plantName;
	}
	
	/**
	 * 
	 * @param plantName - set the plantName
	 */
	public void setPlantName(String plantName) {
		this.plantName = plantName;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		StringBuilder builder = new StringBuilder();
        builder.append("PlantDTO [plantId=").append(plantId).append(", plantName=").append(plantName).append("]");
        return builder.toString();
	}
}
