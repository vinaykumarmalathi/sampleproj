package com.rnaipl.wms.exception;

/**
 * This is the exception class to be used in case of any errors caused during
 * processing business logic in WMS service or WMS ejb bean layer
 * 
 * <p>
 * It extends {@link WMSRuntimeException} the base Exception class for WMS
 * application.
 * 
 * @CreatedBy TechM
 * @CreatedOn 11-Apr-2016 10:44:04 am
 */
@SuppressWarnings("serial")
public class WMSEJBException extends WMSRuntimeException {

    /**
     * Instantiates a new WMS Service exception.
     * 
     * @param message
     *            the message
     * @param exception
     *            {@link Throwable} cause
     * @see RuntimeException#RuntimeException(String, Throwable)
     */
    public WMSEJBException(final String message, final Throwable exception) {
        super(message, exception);
    }

    /**
     * Instantiates a new WMS Service exception.
     * 
     * @param message
     *            the message
     * @see RuntimeException#RuntimeException(String)
     */
    public WMSEJBException(final String message) {
        super(message);
    }

    /**
     * Instantiates a new WMS Service exception.
     * 
     * @param exception
     *            {@link Throwable} cause
     * @see RuntimeException#RuntimeException(Throwable)
     */
    public WMSEJBException(final Throwable exception) {
        super(exception);
    }

}
