package com.rnaipl.wms.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonProperty;

import com.lowagie.text.Phrase;

public class TagSheetDTO implements Serializable{
	private static final long serialVersionUID = 1L;
	@JsonProperty("PARTNUMBER")
	private String partNumber;
	@JsonProperty("LOCATION")
	private String location;
	@JsonProperty("SNP")
	private String snp;
	@JsonProperty("NO_OF_BOXES")
	private String noOfBoxes;
	@JsonProperty("OPENQUANTITY")
	private String openQty;
	@JsonProperty("TOTALQUANTITY")
	private String totalQty;
	@JsonProperty("DEVICE_ID")
	private String deviceId;
	@JsonProperty("TRANSACTION_TYPE")
	private String txnType;

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	
	public String getSnp() {
		return snp;
	}

	public void setSnp(String snp) {
		this.snp = snp;
	}

	public String getNoOfBoxes() {
		return noOfBoxes;
	}

	public void setNoOfBoxes(String noOfBoxes) {
		this.noOfBoxes = noOfBoxes;
	}

	public String getOpenQty() {
		return openQty;
	}

	public void setOpenQty(String openQty) {
		this.openQty = openQty;
	}

	public String getTotalQty() {
		return totalQty;
	}

	public void setTotalQty(String totalQty) {
		this.totalQty = totalQty;
	}

	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getTxnType() {
		return txnType;
	}
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}
	
	
/*	private String partNumber;
	private String location;
	private int snp;
	
	
	
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getSnp() {
		return snp;
	}
	public void setSnp(int snp) {
		this.snp = snp;
	}*/
	
	
	

	
}
