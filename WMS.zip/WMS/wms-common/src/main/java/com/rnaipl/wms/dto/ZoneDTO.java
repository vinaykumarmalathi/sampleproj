package com.rnaipl.wms.dto;

import java.io.Serializable;

/**
 * This class is to contain the details to be presented to user in presentation
 * layer for Plant related Data
 * 
 * @CreatedBy TechM
 * @CreatedOn 20-Apr-2016 
 */
public class ZoneDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String zoneId;
	private String zoneName;

	public String getZoneId() {
		return zoneId;
	}
	public void setZoneId(String zoneId) {
		this.zoneId = zoneId;
	}
	public String getZoneName() {
		return zoneName;
	}
	public void setZoneName(String zoneName) {
		this.zoneName = zoneName;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		StringBuilder builder = new StringBuilder();
        builder.append("ZoneDTO [zoneId=").append(zoneId).append(", zoneName=").append(zoneName).append("]");
        return builder.toString();
	}
}
