package com.rnaipl.wms.dto;

import java.io.Serializable;

/**
 * This class is to contain the details to be presented to user in presentation
 * layer for Plant related Data
 * 
 * @CreatedBy TechM
 * @CreatedOn 20-Apr-2016 
 */
public class LineDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String lineId;
	private String lineName;
	
	

	public String getLineId() {
		return lineId;
	}



	public void setLineId(String lineId) {
		this.lineId = lineId;
	}



	public String getLineName() {
		return lineName;
	}



	public void setLineName(String lineName) {
		this.lineName = lineName;
	}



	@Override
	public String toString() {
		// TODO Auto-generated method stub
		StringBuilder builder = new StringBuilder();
        builder.append("LineDTO [lineId=").append(lineId).append(", lineName=").append(lineName).append("]");
        return builder.toString();
	}
}
