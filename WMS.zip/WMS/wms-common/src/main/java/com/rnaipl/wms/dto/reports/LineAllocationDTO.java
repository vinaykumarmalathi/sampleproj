package com.rnaipl.wms.dto.reports;

public class LineAllocationDTO {
	
	private String line;
	private String allocation;
	public String getLine() {
		return line;
	}
	public void setLine(String line) {
		this.line = line;
	}
	public String getAllocation() {
		return allocation;
	}
	public void setAllocation(String allocation) {
		this.allocation = allocation;
	}
}
