package com.rnaipl.wms.dto.ran;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

@XmlRootElement(name = "WhMovementRanValidationOutDTO")
public class WhMovementRanValidationOutDTO implements Serializable{
	
	private String outFlg;
	
	
	public WhMovementRanValidationOutDTO() {
		this.outFlg="";
	
	}

	@XmlElement
	public String getOutFlg() {
		return outFlg;
	}


	public void setOutFlg(String outFlg) {
		this.outFlg = outFlg;
	}

	
	
}
