package com.rnaipl.wms.dto;

import java.util.Date;
import java.util.List;

public class MissingPartsDTO {
	
	private String partNumber;
	private String fileName;
	private Date fromDate;
	private Date toDate;
	
	private List<String> partList;
	
	private int startIndex;
	private int endIndex;
	private int isFullDownload;
	
	private Date liveReceiptUpdatedTime;
	
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public int getStartIndex() {
		return startIndex;
	}
	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}
	public int getEndIndex() {
		return endIndex;
	}
	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}
	public int getIsFullDownload() {
		return isFullDownload;
	}
	public void setIsFullDownload(int isFullDownload) {
		this.isFullDownload = isFullDownload;
	}
	public List<String> getPartList() {
		return partList;
	}
	public void setPartList(List<String> partList) {
		this.partList = partList;
	}
	public Date getLiveReceiptUpdatedTime() {
		return liveReceiptUpdatedTime;
	}
	public void setLiveReceiptUpdatedTime(Date liveReceiptUpdatedTime) {
		this.liveReceiptUpdatedTime = liveReceiptUpdatedTime;
	}

}
