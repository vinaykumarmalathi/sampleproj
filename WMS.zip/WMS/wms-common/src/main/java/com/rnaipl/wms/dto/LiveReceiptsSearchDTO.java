package com.rnaipl.wms.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/*AJ00482484 : LIVE Receipt Change : START*/

@XmlRootElement(name = "liveReceiptDetails")
public class LiveReceiptsSearchDTO {
	

	private String partNumber;
	private String ranExist;
	private int qty;

	
	public LiveReceiptsSearchDTO(){
		
	}
	
	public LiveReceiptsSearchDTO( String partNumber, int qty, String ranExist){
	
		this.partNumber = partNumber;
		this.qty = qty;
		this.ranExist = ranExist;
	}
	
	
	@XmlElement
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	

	@XmlElement
	public int getQuantity() {
		return qty;
	}
	public void setQuantity(int qty) {
		this.qty = qty;
	}
	

	@XmlElement
	public String getRanExist() {
		return ranExist;
	}

	public void setRanExist(String ranExist) {
		this.ranExist = ranExist;
	}

	public String toString(){
		return getPartNumber()+","+getQuantity()+","+getRanExist();
	}

}
/*AJ00482484 : LIVE Receipt Change : END*/
