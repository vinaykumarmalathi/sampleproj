package com.rnaipl.wms.dto.ran;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="QUNANTITY_DETAIL")
@XmlAccessorType(XmlAccessType.FIELD)
public class WhMovementRanValidationInDTO implements Serializable {
	

	
	@XmlElement(name="PART_NO")
	private String partNumber;

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	
	@XmlElement(name="LOCATION")
	private String location;

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
	@XmlElement(name="RAN")
	private String ran;

	public String getRan() {
		return ran;
	}

	public void setRan(String ran) {
		this.ran = ran;
	}
	
}
