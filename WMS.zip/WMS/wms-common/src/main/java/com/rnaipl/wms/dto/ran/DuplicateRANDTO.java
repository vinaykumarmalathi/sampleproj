package com.rnaipl.wms.dto.ran;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.rnaipl.wms.dto.PartsOutReasonDTO;

public class DuplicateRANDTO implements Serializable{

	private String partNumber;
	private String location;
	private String transactionType;
	private String count;
	private String ran;
	private String userId;
	private String deviceId;
	private String partInOutTime;
	private String noOfBoxes;	
	private String reasonCode;
	private String reason;
	private String comments;
	private String shift;	
	private String snp;
	private String scanTime;
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getRan() {
		return ran;
	}
	public void setRan(String ran) {
		this.ran = ran;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getPartInOutTime() {
		return partInOutTime;
	}
	public void setPartInOutTime(String partInOutTime) {
		this.partInOutTime = partInOutTime;
	}
	public String getNoOfBoxes() {
		return noOfBoxes;
	}
	public void setNoOfBoxes(String noOfBoxes) {
		this.noOfBoxes = noOfBoxes;
	}
	public String getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getShift() {
		return shift;
	}
	public void setShift(String shift) {
		this.shift = shift;
	}
	public String getSnp() {
		return snp;
	}
	public void setSnp(String snp) {
		this.snp = snp;
	}
	public String getScanTime() {
		return scanTime;
	}
	public void setScanTime(String scanTime) {
		this.scanTime = scanTime;
	}
	
	
	
	

	
	
	
}
