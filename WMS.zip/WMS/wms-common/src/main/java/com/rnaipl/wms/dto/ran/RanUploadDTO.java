package com.rnaipl.wms.dto.ran;

import java.util.Date;

public class RanUploadDTO {
	int runId;
	String plant;
	Date startTime;
	Date endTime;
	int status;
	String fileName;
    int error;
    String procedureError;
    String procedureErrorMsg;
    int totalNoOfRecordUploaded;
    
	
	public int getRunId() {
		return runId;
	}
	public void setRunId(int runId) {
		this.runId = runId;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public int getError() {
		return error;
	}
	public void setError(int error) {
		this.error = error;
	}
	public String getProcedureError() {
		return procedureError;
	}
	public void setProcedureError(String procedureError) {
		this.procedureError = procedureError;
	}
	public String getProcedureErrorMsg() {
		return procedureErrorMsg;
	}
	public void setProcedureErrorMsg(String procedureErrorMsg) {
		this.procedureErrorMsg = procedureErrorMsg;
	}
	public int getTotalNoOfRecordUploaded() {
		return totalNoOfRecordUploaded;
	}
	public void setTotalNoOfRecordUploaded(int totalNoOfRecordUploaded) {
		this.totalNoOfRecordUploaded = totalNoOfRecordUploaded;
	}
	//plant field addition
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	


}
