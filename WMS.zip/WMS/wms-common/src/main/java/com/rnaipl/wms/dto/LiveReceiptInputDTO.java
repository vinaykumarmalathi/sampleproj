package com.rnaipl.wms.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="RAN_DETAIL")
@XmlAccessorType(XmlAccessType.FIELD)
public class LiveReceiptInputDTO {
	
	@XmlElement(name="PLANT")
	private String plant;
	
	@XmlElement(name="RAN_NO")
	private String ran;
	
	@XmlElement(name="SHOP")
	private String shop;

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getRan() {
		return ran;
	}

	public void setRan(String ran) {
		this.ran = ran;
	}

	public String getShop() {
		return shop;
	}

	public void setShop(String shop) {
		this.shop = shop;
	}

}
