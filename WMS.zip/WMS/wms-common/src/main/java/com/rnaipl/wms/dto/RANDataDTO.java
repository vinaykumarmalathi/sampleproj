package com.rnaipl.wms.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class RANDataDTO implements Serializable {
	
	private String ran;
	private String partNos;
	private List<String> ranList;
	private List<String> partNoList;
	private Date lppd;
	private int startIndex;
	private int endIndex;
	
	public String getRan() {
		return ran;
	}
	public void setRan(String ran) {
		this.ran = ran;
	}
	public String getPartNos() {
		return partNos;
	}
	public void setPartNos(String partNos) {
		this.partNos = partNos;
	}
	public List<String> getRanList() {
		return ranList;
	}
	public void setRanList(List<String> ranList) {
		this.ranList = ranList;
	}
	public List<String> getPartNoList() {
		return partNoList;
	}
	public void setPartNoList(List<String> partNoList) {
		this.partNoList = partNoList;
	}
	public Date getLppd() {
		return lppd;
	}
	public void setLppd(Date lppd) {
		this.lppd = lppd;
	}
	public int getStartIndex() {
		return startIndex;
	}
	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}
	public int getEndIndex() {
		return endIndex;
	}
	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}
	
	

}
