package com.rnaipl.wms.dto.reports;


import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name = "FIFOSuggestionOverrideValidationDTO")
public class FIFOSuggestionOverrideValidationDTO implements Serializable{

	private String succFailMsg;
	private int ranCount;
	
	@XmlElement
	public String getSuccFailMsg() {
		return succFailMsg;
	}
	public void setSuccFailMsg(String succFailMsg) {
		this.succFailMsg = succFailMsg;
	}
	
	@XmlElement
	public int getRanCount() {
		return ranCount;
	}
	public void setRanCount(int ranCount) {
		this.ranCount = ranCount;
	}
	
	

}

