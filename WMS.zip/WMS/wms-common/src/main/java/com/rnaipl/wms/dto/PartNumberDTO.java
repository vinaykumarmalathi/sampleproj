package com.rnaipl.wms.dto;

import java.io.Serializable;

public class PartNumberDTO implements Serializable{
	
	public PartNumberDTO() {};
	
	public PartNumberDTO(String text) {
		this.text = text;
	};

	private String text;

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

}
