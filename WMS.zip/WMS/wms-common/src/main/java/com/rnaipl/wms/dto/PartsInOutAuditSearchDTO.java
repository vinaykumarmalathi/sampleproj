package com.rnaipl.wms.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class PartsInOutAuditSearchDTO implements Serializable{

	private String partNumber;
	private String location;
	private String transactionType;
	private int count;
	private String ran;
	private String userId;
	private String deviceId;
	private Date partInOutTime;
	private PartsOutReasonDTO partsReasonCode;
	private long partPk;
	private int noOfBoxes;	
	private String reasonCode;
	private String reason;
	private String comments;
	private Date fromDate;
	private Date toDate;
	private int startIndex;
	private int endIndex;
	private String shift;
	private int isFullDownload;
	private List<String> partList;
	private List<String> locationList;
	private String shop;
	private String plant;
	private String line;
	private String section;
	private int snp;
	private Date scanTime;
	private List<String> ranList;
	private String suggestedLocation;
	private String suggestedRan;
	private String locationDestination;
	
	
	public String getShop() {
		return shop;
	}
	public void setShop(String shop) {
		this.shop = shop;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public String getLine() {
		return line;
	}
	public void setLine(String line) {
		this.line = line;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public int getIsFullDownload() {
		return isFullDownload;
	}
	public void setIsFullDownload(int isFullDownload) {
		this.isFullDownload = isFullDownload;
	}
	public List<String> getPartList() {
		return partList;
	}
	public void setPartList(List<String> partList) {
		this.partList = partList;
	}
	public List<String> getLocationList() {
		return locationList;
	}
	public void setLocationList(List<String> locationList) {
		this.locationList = locationList;
	}
	public String getShift() {
		return shift;
	}
	public void setShift(String shift) {
		this.shift = shift;
	}
	public int getStartIndex() {
		return startIndex;
	}
	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}
	public int getEndIndex() {
		return endIndex;
	}
	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getRan() {
		return ran;
	}
	public void setRan(String ran) {
		this.ran = ran;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public Date getPartInOutTime() {
		return partInOutTime;
	}
	public void setPartInOutTime(Date partInOutTime) {
		this.partInOutTime = partInOutTime;
	}
	public PartsOutReasonDTO getPartsReasonCode() {
		return partsReasonCode;
	}
	public void setPartsReasonCode(PartsOutReasonDTO partsReasonCode) {
		this.partsReasonCode = partsReasonCode;
	}
	public long getPartPk() {
		return partPk;
	}
	public void setPartPk(long partPk) {
		this.partPk = partPk;
	}
	public int getNoOfBoxes() {
		return noOfBoxes;
	}
	public void setNoOfBoxes(int noOfBoxes) {
		this.noOfBoxes = noOfBoxes;
	}
	
	public String getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public int getSnp() {
		return snp;
	}
	public void setSnp(int snp) {
		this.snp = snp;
	}
	public Date getScanTime() {
		return scanTime;
	}
	public void setScanTime(Date scanTime) {
		this.scanTime = scanTime;
	}
	public List<String> getRanList() {
		return ranList;
	}
	public void setRanList(List<String> ranList) {
		this.ranList = ranList;
	}
	public String getSuggestedLocation() {
		return suggestedLocation;
	}
	public void setSuggestedLocation(String suggestedLocation) {
		this.suggestedLocation = suggestedLocation;
	}
	public String getSuggestedRan() {
		return suggestedRan;
	}
	public void setSuggestedRan(String suggestedRan) {
		this.suggestedRan = suggestedRan;
	}
	public String getLocationDestination() {
		return locationDestination;
	}
	public void setLocationDestination(String locationDestination) {
		this.locationDestination = locationDestination;
	}
	
	
}
