package com.rnaipl.wms.dto.ran;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

@XmlRootElement(name = "SuggestedRANLocationForPartNoDTO")
public class SuggestedRANLocationForPartNoDTO implements Serializable{
	
	private String partNumber;
	private String ran;	
	private String location;
	private int quantity;
	private int ageddays;
	
	
	
	public SuggestedRANLocationForPartNoDTO() {
		this.partNumber="";
		this.ran="";
		this.location="";
	}
	@XmlElement
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	@XmlElement
	public String getRan() {
		return ran;
	}
	public void setRan(String ran) {
		this.ran = ran;
	}
	
	@XmlElement
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	@XmlElement
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@XmlElement
	public int getAgeddays() {
		return ageddays;
	}
	public void setAgeddays(int ageddays) {
		this.ageddays = ageddays;
	}
	
	
	
}
