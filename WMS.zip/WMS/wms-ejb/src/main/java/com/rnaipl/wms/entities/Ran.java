package com.rnaipl.wms.entities;

import java.io.Serializable;

import javax.persistence.*;

import com.rnaipl.wms.entitiesPK.RanPK;

import java.sql.Timestamp;


/**
 * The persistent class for the RAN database table.
 * 
 */
@Entity
@Table(name="RAN")
@NamedQuery(name="Ran.findAll", query="SELECT r FROM Ran r")
public class Ran implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RanPK id;

	@Column(name="LPPD")
	private Timestamp lppd;

	@Column(name="MFG_DATE")
	private Timestamp mfgDate;

	@Column(name="UPDATED_DATETIME")
	private Timestamp updatedDatetime;
	
	@Column(name="PLANT")
	private String plant;

	public String getPlant() {
		return this.plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public Ran() {
	}

	public RanPK getId() {
		return this.id;
	}

	public void setId(RanPK id) {
		this.id = id;
	}

	public Timestamp getLppd() {
		return this.lppd;
	}

	public void setLppd(Timestamp lppd) {
		this.lppd = lppd;
	}

	public Timestamp getMfgDate() {
		return this.mfgDate;
	}

	public void setMfgDate(Timestamp mfgDate) {
		this.mfgDate = mfgDate;
	}

	public Timestamp getUpdatedDatetime() {
		return this.updatedDatetime;
	}

	public void setUpdatedDatetime(Timestamp updatedDatetime) {
		this.updatedDatetime = updatedDatetime;
	}

}