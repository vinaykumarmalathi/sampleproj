package com.rnaipl.wms.bean;

import java.util.List;

import com.rnaipl.wms.dto.PartLocationCorrectionDTO;
import com.rnaipl.wms.dto.PartLocationDTO;
import com.rnaipl.wms.dto.StockCorrectionDTO;

/**
 * 
 * @author TechM
 * 
 */
public interface PartLocation {
    
    /**
     * It will retrive all the PartLocation details information from database
     * 
     * @return - list of PartLocationDTO object
     */
    List<PartLocationDTO> getPartLocations(PartLocationDTO partLoc);
    List<PartLocationDTO> downloadPartLocations(PartLocationDTO partLoc);
    
    
    int getPartLocationCount(PartLocationDTO partLoc);

    /**
     * @param partLocCorrDTO
     */
   // void updatePartLocation(List<PartLocationCorrectionDTO> partLocCorrDTOs);
    
    //As per JPA query stockCorrection report generated , It will be added in future <TODO>
    //List<StockCorrectionDTO> getStockCorrectionList(PartLocationDTO partLoc);
}
