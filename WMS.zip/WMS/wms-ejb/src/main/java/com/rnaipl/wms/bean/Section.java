package com.rnaipl.wms.bean;

import java.util.List;

import com.rnaipl.wms.dto.PlantDTO;
import com.rnaipl.wms.dto.SectionDTO;

/**
 * 
 * @author TechM
 *
 */
public interface Section {
	
	/**
	 * It will retrive all the plant details information from database
	 * @return - list of PlantDTO object
	 */
	public List<SectionDTO> getAllSections();
}
