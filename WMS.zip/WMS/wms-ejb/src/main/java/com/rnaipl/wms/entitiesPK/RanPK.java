package com.rnaipl.wms.entitiesPK;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the RAN database table.
 * 
 */
@Embeddable
public class RanPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="RAN")
	private String ran;

	@Column(name="PART_NO")
	private String partNo;

	public RanPK() {
	}
	public String getRan() {
		return this.ran;
	}
	public void setRan(String ran) {
		this.ran = ran;
	}
	public String getPartNo() {
		return this.partNo;
	}
	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof RanPK)) {
			return false;
		}
		RanPK castOther = (RanPK)other;
		return 
			this.ran.equals(castOther.ran)
			&& this.partNo.equals(castOther.partNo);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.ran.hashCode();
		hash = hash * prime + this.partNo.hashCode();
		
		return hash;
	}
}