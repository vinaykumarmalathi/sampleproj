package com.rnaipl.wms.bean.reports;

import java.util.List;

import com.rnaipl.wms.dto.reports.FIFOSuggestionDTO;
import com.rnaipl.wms.dto.reports.FIFOSuggestionOverrideDTO;

public interface FIFOSuggestionOverride {
	
	public List<FIFOSuggestionDTO> getFIFOSuggestion(FIFOSuggestionOverrideDTO fifoSuggestionOverrideDTO) throws Exception;
	
}
