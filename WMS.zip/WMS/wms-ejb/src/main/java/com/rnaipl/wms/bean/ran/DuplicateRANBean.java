	package com.rnaipl.wms.bean.ran;

import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.ran.DuplicateRANDTO;
import com.rnaipl.wms.dto.ran.DuplicateRANInputDTO;
import com.rnaipl.wms.entities.PartinOutStagingAudit;
import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSBeanUtil;

@Stateless
@LocalBean
public class DuplicateRANBean implements DuplicateRAN {

	private static final Logger LOGGER = Logger
			.getLogger(DuplicateRANBean.class);

	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;
	
	public List<DuplicateRANDTO> getDuplicateRANs(DuplicateRANInputDTO duplicateRANInputDTO) throws Exception { 
		
		
		List<DuplicateRANDTO> duplicateRANDTOList = new ArrayList<DuplicateRANDTO>();
		StringBuffer queryStringBuf = new StringBuffer();
	
		
		queryStringBuf.append(" SELECT PA.PART_NO,PA.LOCATION, PA.TRANSACTION_TYPE,PA.COUNT,PA.RAN,PA.USER_ID,PA.DEVICE_ID,CONVERT(VARCHAR(20),PA.PART_IN_OUT_TIME,20) as PART_IN_OUT_TIME,PA.REASON_CODE,PA.COMMENTS,CONVERT(VARCHAR(20),PA.SCAN_TIME,20) as SCAN_TIME,PA.SNP,PA.NO_OF_BOXES ");  
		queryStringBuf.append(" FROM DBO.PARTINOUT_STAGING_AUDIT PA INNER JOIN  ");
		queryStringBuf.append(" ( ");
		queryStringBuf.append(" SELECT P.RAN,P.TRANSACTION_TYPE,SUBSTRING(LOCATION,1,4) AS PSLC ");		
		queryStringBuf.append(" FROM DBO.PARTINOUT_STAGING_AUDIT P WHERE RAN!='*'  AND P.TRANSACTION_TYPE!='MOVE'  ");
		queryStringBuf.append(" GROUP BY P.RAN,P.TRANSACTION_TYPE,SUBSTRING(LOCATION,1,4)  ");
		queryStringBuf.append(" HAVING COUNT(*)>1 ");
		queryStringBuf.append(" ) DUPLICATE_RAN   ");
		queryStringBuf.append(" ON PA.RAN=DUPLICATE_RAN.RAN AND PA.TRANSACTION_TYPE=DUPLICATE_RAN.TRANSACTION_TYPE  AND SUBSTRING(PA.LOCATION,1,4)=DUPLICATE_RAN.PSLC ");
		queryStringBuf.append(" WHERE 1=1 ");
		queryStringBuf.append(WMSBeanUtil.createQueryParamForDuplicateRANSearch(duplicateRANInputDTO));
		queryStringBuf.append(" ORDER BY PA.RAN ");
		//queryStringBuf.append(" ORDER BY p.partInOutTime DESC");
		LOGGER.debug("Duplicate RAN Query" +queryStringBuf.toString());
		Query query = entityManager.createNativeQuery(queryStringBuf.toString());
		
		
		
		if (null != duplicateRANInputDTO.getPartNumber() && !duplicateRANInputDTO.getPartNumber().equalsIgnoreCase("")) {
			query.setParameter("partNos", duplicateRANInputDTO.getPartList());
        }
		if (null != duplicateRANInputDTO.getLocation() && !duplicateRANInputDTO.getLocation().equalsIgnoreCase("")) {
			query.setParameter("locationNos", duplicateRANInputDTO.getLocationList());
        }
		if (null != duplicateRANInputDTO.getRan() && !duplicateRANInputDTO.getRan().equalsIgnoreCase("")) {
			query.setParameter("rans", duplicateRANInputDTO.getRanList());
        }
		
		 if(!duplicateRANInputDTO.isDownloadAllRecords()){
			 query.setFirstResult(duplicateRANInputDTO.getStartIndex());
				query.setMaxResults(duplicateRANInputDTO.getEndIndex());
		 }
	
		
		List<Object[]> duplicateRANList = query.getResultList();
		
		LOGGER.debug("Duplicate RAN List Size " +duplicateRANList.size() );
		if (null != duplicateRANList && duplicateRANList.size() > 0) {
			for (Iterator<Object[]> i = duplicateRANList.iterator(); i.hasNext();) {
				
				Object[] duplicateRan = (Object[]) i.next();
				DuplicateRANDTO duplicateRANDTO = setPartsInOutData(duplicateRan);
				duplicateRANDTOList.add(duplicateRANDTO);
			}

		}

		LOGGER.debug("*** getPartsAuditSearch -- Location* EXIT");
		return duplicateRANDTOList;

	}

   
 	private DuplicateRANDTO setPartsInOutData(Object[]  duplicateRan) throws Exception{

		DuplicateRANDTO duplicateRANDTO = new DuplicateRANDTO();
		String shiftName ="";
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
		try {
			int indexCount=0;
			Date date = new Date();
			
			
			//agedAgingRanDTO.setRan((null == values[indexCount] ? "" : values[indexCount].toString()));	
			duplicateRANDTO.setPartNumber((null ==  duplicateRan[indexCount] ? "": duplicateRan[indexCount].toString()));
			indexCount++;
			duplicateRANDTO.setLocation((null ==  duplicateRan[indexCount] ? "": duplicateRan[indexCount].toString()));
			indexCount++;
			duplicateRANDTO.setTransactionType((null ==  duplicateRan[indexCount] ? "": duplicateRan[indexCount].toString()));
			indexCount++;
			duplicateRANDTO.setCount((null ==  duplicateRan[indexCount] ? "": duplicateRan[indexCount].toString()));
			indexCount++;
			duplicateRANDTO.setRan((null ==  duplicateRan[indexCount] ? "": duplicateRan[indexCount].toString()));
			indexCount++;
			duplicateRANDTO.setUserId((null ==  duplicateRan[indexCount] ? "": duplicateRan[indexCount].toString()));
			indexCount++;
			duplicateRANDTO.setDeviceId((null ==  duplicateRan[indexCount] ? "": duplicateRan[indexCount].toString()));
			indexCount++;
			duplicateRANDTO.setPartInOutTime((null ==  duplicateRan[indexCount] ? "": duplicateRan[indexCount].toString()));
			indexCount++;
			duplicateRANDTO.setReasonCode((null ==  duplicateRan[indexCount] ? "": duplicateRan[indexCount].toString()));			
			duplicateRANDTO.setReason((null ==  duplicateRan[indexCount] ? "": duplicateRan[indexCount].toString()));
			indexCount++;
			duplicateRANDTO.setComments((null ==  duplicateRan[indexCount] ? "": duplicateRan[indexCount].toString()));
			indexCount++;
			duplicateRANDTO.setScanTime((null ==  duplicateRan[indexCount] ? "": duplicateRan[indexCount].toString()));
			indexCount++;
			duplicateRANDTO.setSnp((null ==  duplicateRan[indexCount] ? "": duplicateRan[indexCount].toString()));
			indexCount++;
			duplicateRANDTO.setNoOfBoxes((null ==  duplicateRan[indexCount] ? "": duplicateRan[indexCount].toString()));
			
	/*		shiftName = WMSBeanUtil.getShift(partsAuditData.getScanTime().getHours(),
					partsAuditData.getScanTime().getMinutes(),partsAuditData.getScanTime().getSeconds());			
			duplicateRANDTO.setShift(shiftName);
			*/
			
		
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error(e);
			throw e;
		}
		return duplicateRANDTO;

	}
	

	
}
