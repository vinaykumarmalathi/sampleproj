package com.rnaipl.wms.bean.reports;

import java.util.List;

import com.rnaipl.wms.dto.PartsInOutAuditErrorDTO;
import com.rnaipl.wms.dto.PartsInOutAuditSearchDTO;
import com.rnaipl.wms.dto.reports.FIFOCheckDTO;
import com.rnaipl.wms.dto.reports.FIFOCheckInputDTO;

public interface FIFOCheck {
	
		
	public List<FIFOCheckDTO> getFIFONotFollowed(FIFOCheckInputDTO fifoCheckInputDTO) throws Exception;
	
	//public int getFIFONotFollowedCount(FIFOCheckInputDTO fifoCheckInputDTO);
	
}
