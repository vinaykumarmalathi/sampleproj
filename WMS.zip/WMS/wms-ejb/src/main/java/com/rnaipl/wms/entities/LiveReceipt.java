package com.rnaipl.wms.entities;

import java.io.Serializable;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/*AJ00482484 : LIVE Receipt Change : START*/

@Entity
@Table(name="LIVE_RECEIPT")
@NamedQuery(name="LiveReceipt.findAll", query="SELECT l FROM LiveReceipt l")
public class LiveReceipt implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="SEQ_NO")
	private BigInteger seqNo;
	
	@Column(name="RAN")
	private String ran;
	
	@Column(name="PART_NO")
	private String partNumber;
	
	@Column(name="QUANTITY")
	private int qty;
	
	@Column(name="UPDATED_DATETIME")
	private Timestamp updatedDatetime;
	
	@Column(name="filename")
	private String fileName;
	
	public BigInteger getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(BigInteger seqNo) {
		this.seqNo = seqNo;
	}
	public String getRan() {
		return ran;
	}
	public void setRan(String ran) {
		this.ran = ran;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	
	public int getQuantity() {
		return qty;
	}
	public void setQuantity(int qty) {
		this.qty = qty;
	}
	public Timestamp getUpdatedDatetime() {
		return updatedDatetime;
	}
	public void setUpdatedDatetime(Timestamp updatedDatetime) {
		this.updatedDatetime = updatedDatetime;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
/*AJ00482484 : LIVE Receipt Change : END*/