package com.rnaipl.wms.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the FIFO_CHECK database table.
 * 
 */
@Entity
@Table(name="FIFO_CHECK")
@NamedQuery(name="FifoCheck.findAll", query="SELECT f FROM FifoCheck f")
public class FifoCheck implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="FIFO_PK")
	private long fifoPk;

	@Column(name="COMMENTS")
	private String comments;

	@Column(name="CORRECT_RAN")
	private String correctRan;

	@Column(name="[COUNT]")
	private int count;

	@Column(name="DEVICE_ID")
	private String deviceId;

	@Column(name="LOCATION")
	private String location;

	@Column(name="NO_OF_BOXES")
	private int noOfBoxes;

	@Column(name="PART_IN_OUT_TIME")
	private Timestamp partInOutTime;

	@Column(name="PART_NO")
	private String partNo;

	@Column(name="PICKED_RAN")
	private String pickedRan;

	@Column(name="REASON_CODE")
	private String reasonCode;

	@Column(name="SCAN_TIME")
	private Timestamp scanTime;

	@Column(name="SNP")
	private int snp;

	@Column(name="USER_ID")
	private String userId;
	
	@Column(name="PICKED_RAN_INTIME")
	private Timestamp pickedRanIntime;
	
	@Column(name="CORRECT_RAN_INTIME")
	private Timestamp correctRanIntime;
	

	public FifoCheck() {
	}

	public long getFifoPk() {
		return this.fifoPk;
	}

	public void setFifoPk(long fifoPk) {
		this.fifoPk = fifoPk;
	}

	public String getComments() {
		return this.comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getCorrectRan() {
		return this.correctRan;
	}

	public void setCorrectRan(String correctRan) {
		this.correctRan = correctRan;
	}

	public int getCount() {
		return this.count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getDeviceId() {
		return this.deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getLocation() {
		return this.location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public int getNoOfBoxes() {
		return this.noOfBoxes;
	}

	public void setNoOfBoxes(int noOfBoxes) {
		this.noOfBoxes = noOfBoxes;
	}

	public Timestamp getPartInOutTime() {
		return this.partInOutTime;
	}

	public void setPartInOutTime(Timestamp partInOutTime) {
		this.partInOutTime = partInOutTime;
	}

	public String getPartNo() {
		return this.partNo;
	}

	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}

	public String getPickedRan() {
		return this.pickedRan;
	}

	public void setPickedRan(String pickedRan) {
		this.pickedRan = pickedRan;
	}

	public String getReasonCode() {
		return this.reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public Timestamp getScanTime() {
		return this.scanTime;
	}

	public void setScanTime(Timestamp scanTime) {
		this.scanTime = scanTime;
	}

	public int getSnp() {
		return this.snp;
	}

	public void setSnp(int snp) {
		this.snp = snp;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Timestamp getPickedRanIntime() {
		return pickedRanIntime;
	}

	public void setPickedRanIntime(Timestamp pickedRanIntime) {
		this.pickedRanIntime = pickedRanIntime;
	}

	public Timestamp getCorrectRanIntime() {
		return correctRanIntime;
	}

	public void setCorrectRanIntime(Timestamp correctRanIntime) {
		this.correctRanIntime = correctRanIntime;
	}

	
}