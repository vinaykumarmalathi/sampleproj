package com.rnaipl.wms.bean;

import java.util.List;
import java.util.Set;

import com.rnaipl.wms.dto.LocationDTO;
import com.rnaipl.wms.dto.PartDTO;
import com.rnaipl.wms.dto.PartLocationDTO;
import com.rnaipl.wms.dto.PartNumberDTO;
import com.rnaipl.wms.dto.PartSearchDTO;

public interface Location {

	public Set<PartNumberDTO> getLocation(String locationID);
	
	public List<PartNumberDTO> getLocationSearchData(PartLocationDTO location);
	
	public String insertLocation(LocationDTO location);
	
	public String updateLocation(LocationDTO location);
	
	public LocationDTO getLocationByLocationId(String locationId);

	public String deleteLocation(LocationDTO locationDto);

	public int getLocationCount(PartLocationDTO locationDto);
}
