package com.rnaipl.wms.entities;

import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the PLANT database table.
 * 
 */
@Entity
@Table(name="PLANT")
@NamedQuery(name="Plant.findAll", query="SELECT p FROM Plant p")
public class Plant implements Serializable {
	private static final long serialVersionUID = 1L;
	
	/*private Set<Shop> shops = new HashSet<Shop>(0);*/
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="PLANT_ID")
	private String plantId;

	@Column(name="PLANT_NAME")
	private String plantName;
	

	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "PLANT_SHOP", joinColumns = { @JoinColumn(name = "PLANT_ID") }, inverseJoinColumns = { @JoinColumn(name = "SHOP_ID") })
	private List<Shop> shops;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "PLANT_LINE", joinColumns = { @JoinColumn(name = "PLANT_ID") }, inverseJoinColumns = { @JoinColumn(name = "LINE_ID") })
	private List<Line> lines;
	
	public Plant() {
	}

	public String getPlantId() {
		return this.plantId;
	}

	public void setPlantId(String plantId) {
		this.plantId = plantId;
	}

	public String getPlantName() {
		return this.plantName;
	}

	public void setPlantName(String plantName) {
		this.plantName = plantName;
	}
	
	public List<Shop> getShops() {
		return shops;
	}

	public void setShops(List<Shop> shops) {
		this.shops = shops;
	}

	public List<Line> getLines() {
		return lines;
	}

	public void setLines(List<Line> lines) {
		this.lines = lines;
	}
	
	


}