package com.rnaipl.wms.entitiesPK;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The primary key class for the USER_MENU database table.
 * 
 */
@Embeddable
public class PartLocationPK implements Serializable {
    // default serial version id, required for serializable classes.
    private static final long serialVersionUID = 1L;

    @Column(name = "PART_NO", insertable = false, updatable = false)
    private String partNo;

    @Column(name = "LOCATION_ID", insertable = false, updatable = false)
    private String locationId;
    
    @Column(name = "RAN", insertable = false, updatable = false)
    private String ran;

    public PartLocationPK() {
    }

    public String getPartNo() {
        return partNo;
    }

    public void setPartNo(String partNo) {
        this.partNo = partNo;
    }

    public String getLocationId() {
        return locationId;
    }

    public void setLocationId(String locationId) {
        this.locationId = locationId;
    }
    

    public String getRan() {
		return ran;
	}

	public void setRan(String ran) {
		this.ran = ran;
	}

	/*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((locationId == null) ? 0 : locationId.hashCode());
        result = prime * result + ((partNo == null) ? 0 : partNo.hashCode());
        result = prime * result + ((ran == null) ? 0 : ran.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        PartLocationPK other = (PartLocationPK) obj;
        if (locationId == null) {
            if (other.locationId != null)
                return false;
        } else if (!locationId.equals(other.locationId))
            return false;
        if (partNo == null) {
            if (other.partNo != null)
                return false;
        } else if (!partNo.equals(other.partNo))
            return false;
        
        if (ran == null) {
            if (other.ran != null)
                return false;
        } else if (!ran.equals(other.ran))
            return false;
        return true;
    }

}