package com.rnaipl.wms.bean.reports;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.reports.ZoneConsumptionDTO;
import com.rnaipl.wms.util.WMSBeanConstants;


@Stateless
@LocalBean
public class ZoneConsumptionBean implements IZoneConsumption  {

	private static final Logger LOGGER = Logger.getLogger(ZoneConsumptionBean.class);
	
	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;
	
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

	public List<ZoneConsumptionDTO> getZoneList(ZoneConsumptionDTO zoneConsumptionDTO, String dwnloadFLg) {
		
		List<ZoneConsumptionDTO> ZoneConsumptionDTOList = new ArrayList<ZoneConsumptionDTO>();
		String chooseZone = "";	
		StringBuffer querySql = new StringBuffer();
		
		if (dwnloadFLg.equalsIgnoreCase("N")) {
			querySql.append(
					" SELECT M.LINE, M.SHOP, M.ZONE, M.PART_NO, Convert(varchar(19),H.LAST_PK_LST_TIME,120) as LAST_PK_LST_TIME , H.LAST_PK_LST_QTY, H.LAST_PK_LST_STATUS ")
					.append(" ,Convert(varchar(19),H.LAST_WHOUT_TIME,120) as LAST_WHOUT_TIME , H.LAST_WHOUT_QTY, Convert(varchar(19),H.TACT_TIME,120) as TACT_TIME, H.CON_QTY ")
					.append(" ,H.LINE_STK, H.WH_STK, H.CATS_STK,M.PART_TYPE,P.PART_NAME,MISMATCH,M.LINE_LOC ")
					.append(" FROM [dbo].[TBL_LNFD_STK_MASTER] M , [dbo].[TBL_LNFD_CONSUMPTION_HSTRY] H , PART P ")
					.append(" WHERE M.LNFD_ID = H.LNFD_ID AND M.PART_NO = P.PART_NO ").append(" AND M.SHOP = :shop ");
		} else {
			querySql.append(
					" SELECT top 5000 M.LINE, M.SHOP, M.ZONE, M.PART_NO, Convert(varchar(19),H.LAST_PK_LST_TIME,120) as LAST_PK_LST_TIME, H.LAST_PK_LST_QTY, H.LAST_PK_LST_STATUS ")
					.append(" ,Convert(varchar(19),H.LAST_WHOUT_TIME,120) as LAST_WHOUT_TIME , H.LAST_WHOUT_QTY, Convert(varchar(19),H.TACT_TIME,120) as TACT_TIME , H.CON_QTY ")
					.append(" ,H.LINE_STK, H.WH_STK, H.CATS_STK,M.PART_TYPE,P.PART_NAME,MISMATCH,M.LINE_LOC ")
					.append(" FROM [dbo].[TBL_LNFD_STK_MASTER] M , [dbo].[TBL_LNFD_CONSUMPTION_HSTRY] H , PART P ")
					.append(" WHERE M.LNFD_ID = H.LNFD_ID AND M.PART_NO = P.PART_NO ").append(" AND M.SHOP = :shop ");
		}
		
		if (zoneConsumptionDTO.getZone() != null && zoneConsumptionDTO.getZone() != "")	{
			querySql.append(" AND M.ZONE  = :zone ");
		}
		if (zoneConsumptionDTO.getLine() != null && zoneConsumptionDTO.getLine() != "")	{
			querySql.append(" AND M.LINE = :line ");
		}
		if (zoneConsumptionDTO.getPartNumber() != null && zoneConsumptionDTO.getPartNumber() != "")	{
			querySql.append(" AND M.Part_NO IN (:partNums)");
		}
		if (checkNull(zoneConsumptionDTO.getBeginDate())) {
			LOGGER.debug("zoneConsumptionDTO.getBeginDate() : "+dateFormat.format(zoneConsumptionDTO.getBeginDate()));
			querySql.append(" AND (Convert(varchar(10),H.TACT_TIME,120)>=:FromDate ");
		}		
		if (checkNull(zoneConsumptionDTO.getEndDate())) {
			LOGGER.debug("zoneConsumptionDTO.getEndDate() : "+dateFormat.format(zoneConsumptionDTO.getEndDate()));
			querySql.append(" AND Convert(varchar(10),H.TACT_TIME,120)<=:ToDate) " );
		}		
		if(dwnloadFLg.equalsIgnoreCase("N"))	{
			querySql.append(" ORDER BY H.TACT_TIME DESC OFFSET "+zoneConsumptionDTO.getStartIndex()+" ROWS FETCH NEXT "+zoneConsumptionDTO.getEndIndex()+" ROWS ONLY ");	
		} else {
			querySql.append(" ORDER BY H.TACT_TIME DESC ");
		}
		Query query = entityManager.createNativeQuery(querySql.toString());
		
		query.setParameter("shop", zoneConsumptionDTO.getShop().charAt(0));
		
		if (zoneConsumptionDTO.getZone() != null && zoneConsumptionDTO.getZone() != "")	{
			chooseZone = getZone(zoneConsumptionDTO.getZone());
			query.setParameter("zone", chooseZone);
		}
		if (zoneConsumptionDTO.getLine() != null && zoneConsumptionDTO.getLine() != "")	{
			query.setParameter("line", zoneConsumptionDTO.getLine());
		}
		if (zoneConsumptionDTO.getPartNumber() != null && !zoneConsumptionDTO.getPartNumber().trim().equals("")) {
			query.setParameter("partNums", zoneConsumptionDTO.getPartList());
		}
		if (checkNull(zoneConsumptionDTO.getBeginDate())) {
			query.setParameter("FromDate", dateFormat.format(zoneConsumptionDTO.getBeginDate()));
		}		
		if (checkNull(zoneConsumptionDTO.getEndDate())) {
			query.setParameter("ToDate", dateFormat.format(zoneConsumptionDTO.getEndDate()));
		}		
		
		LOGGER.debug("Query " + querySql.toString());
		
		List<Object[]> objectsArrayList = query.getResultList();
		
		String status = "";
		
		if (objectsArrayList != null && objectsArrayList.size() > 0) {
			
			for (Object[] objectsArray : objectsArrayList) {
				ZoneConsumptionDTO pickinglistResultsDTO = new ZoneConsumptionDTO();
				
				pickinglistResultsDTO.setLine(null == objectsArray[0] ?"":objectsArray[0].toString());
				pickinglistResultsDTO.setShop(null == objectsArray[1] ?"":objectsArray[1].toString());
				pickinglistResultsDTO.setZone(null == objectsArray[2] ?"":objectsArray[2].toString());
				pickinglistResultsDTO.setPartNumber(null == objectsArray[3] ?"":objectsArray[3].toString());
				pickinglistResultsDTO.setLastPickListTime((null == objectsArray[4] ?"":objectsArray[4].toString()));
				pickinglistResultsDTO.setLastPickListQTY((Integer)(null == objectsArray[5] ?0:objectsArray[5]));
				
				//pickinglistResultsDTO.setLastPickListSTS((null == objectsArray[6] ?"":objectsArray[6].toString()));
			
                if(objectsArray[6]==null){
                    status = "";
                }else if(objectsArray[6].toString().equals("C")){
                    status = "Closed";
                }else if(objectsArray[6].toString().equals("O")){
                    status = "Open";
                }else if(objectsArray[6].toString().equals("P")){
                    status = "Partial";   
                }
				
                pickinglistResultsDTO.setLastPickListSTS(status);
                
				pickinglistResultsDTO.setLastWHoutTIME((null == objectsArray[7] ?"":objectsArray[7].toString()));
				pickinglistResultsDTO.setLastWhOUTQTY((Integer)(null == objectsArray[8] ?0:objectsArray[8]));

				pickinglistResultsDTO.setZoneTactHISRY((null == objectsArray[9] ?"":objectsArray[9].toString()) );
				pickinglistResultsDTO.setOffLineQTY((Integer)(null == objectsArray[10] ?0:objectsArray[10]));
				
				pickinglistResultsDTO.setLineStock((Integer)(null == objectsArray[11] ?0:objectsArray[11]));
				pickinglistResultsDTO.setWhStock((Integer)(null == objectsArray[12] ?0:objectsArray[12]));
				pickinglistResultsDTO.setCatsStock((Integer)(null == objectsArray[13] ?0:objectsArray[13]));
				pickinglistResultsDTO.setSource((null == objectsArray[14] ? "" :objectsArray[14].toString()));
				pickinglistResultsDTO.setPartName((null == objectsArray[15] ? "" :objectsArray[15].toString()));
				pickinglistResultsDTO.setMismatch((Integer)(null == objectsArray[16] ?0:objectsArray[16]));
				pickinglistResultsDTO.setPofZone((null == objectsArray[17] ? "" :objectsArray[17].toString()));
				ZoneConsumptionDTOList.add(pickinglistResultsDTO);
			}
		}
		
		return ZoneConsumptionDTOList;
	}
	
	private boolean checkNull(Object object) {
		return object != null;
	}

	public int getZoneListCount(ZoneConsumptionDTO zoneConsumptionDTO) {
		// TODO Auto-generated method stub
		
		LOGGER.debug("zone " + zoneConsumptionDTO.getZone());
		LOGGER.debug("shop " + zoneConsumptionDTO.getShop());
		LOGGER.debug("line " + zoneConsumptionDTO.getLine());
		LOGGER.debug("partNO " + zoneConsumptionDTO.getPartNumber());
		
		StringBuffer querySql = new StringBuffer();
		String chooseZone = "";	
		
		querySql.append(" SELECT COUNT(*) ") 
		.append(" FROM [dbo].[TBL_LNFD_STK_MASTER] M , [dbo].[TBL_LNFD_CONSUMPTION_HSTRY] H ")
		.append(" WHERE M.LNFD_ID = H.LNFD_ID ")
		.append(" AND M.SHOP = :shop ");
		
		if (zoneConsumptionDTO.getZone() != null && zoneConsumptionDTO.getZone() != "")	{
			querySql.append(" AND M.ZONE  = :zone ");
		}
		if (zoneConsumptionDTO.getLine() != null && zoneConsumptionDTO.getLine() != "")	{
			querySql.append(" AND M.LINE = :line ");
		}
		if (zoneConsumptionDTO.getPartNumber() != null && zoneConsumptionDTO.getPartNumber() != "")	{
			querySql.append(" AND M.Part_NO IN (:partNums)");
		}
		if (checkNull(zoneConsumptionDTO.getBeginDate())) {
			LOGGER.debug("zoneConsumptionDTO.getBeginDate() : "+dateFormat.format(zoneConsumptionDTO.getBeginDate()));
			querySql.append(" AND (Convert(varchar(10),H.TACT_TIME,120)>=:FromDate ");
		}		
		if (checkNull(zoneConsumptionDTO.getEndDate())) {
			LOGGER.debug("zoneConsumptionDTO.getEndDate() : "+dateFormat.format(zoneConsumptionDTO.getEndDate()));
			querySql.append(" AND Convert(varchar(10),H.TACT_TIME,120)<=:ToDate) " );
		}		
		
		Query query = entityManager.createNativeQuery(querySql.toString());
		
		query.setParameter("shop", zoneConsumptionDTO.getShop().charAt(0));
		
		if (zoneConsumptionDTO.getZone() != null && zoneConsumptionDTO.getZone() != "")	{
			chooseZone = getZone(zoneConsumptionDTO.getZone());
			query.setParameter("zone", chooseZone);
		}
		if (zoneConsumptionDTO.getLine() != null && zoneConsumptionDTO.getLine() != "")	{
			query.setParameter("line", zoneConsumptionDTO.getLine());
		}
		if (zoneConsumptionDTO.getPartNumber() != null && !zoneConsumptionDTO.getPartNumber().trim().equals("")) {
			query.setParameter("partNums", zoneConsumptionDTO.getPartList());
		}
		if (checkNull(zoneConsumptionDTO.getBeginDate())) {
			query.setParameter("FromDate", dateFormat.format(zoneConsumptionDTO.getBeginDate()));
		}		
		if (checkNull(zoneConsumptionDTO.getEndDate())) {
			query.setParameter("ToDate", dateFormat.format(zoneConsumptionDTO.getEndDate()));
		}	
		
		LOGGER.debug("Query " + querySql.toString());		
		return  (Integer)query.getSingleResult();		
	}
	
	public String getZone(String zoneName){
		String chooseZone = "";
		if (zoneName != null && zoneName != "")	{
			if(zoneName.toString().equalsIgnoreCase("Pre Final")){
				chooseZone = "PRE FINAL";
			}else if(zoneName.toString().equalsIgnoreCase("C/T")){
				chooseZone = "CHASIS";
			}else if(zoneName.toString().equalsIgnoreCase("U/F")){
				chooseZone = "UF";
			}else if(zoneName.toString().equalsIgnoreCase("Trim B")){
				chooseZone = "TRIM-B";
			}else if(zoneName.toString().equalsIgnoreCase("Trim A")){
				chooseZone = "TRIM-A";
			}
		}	
		return chooseZone;
	}
	
}
