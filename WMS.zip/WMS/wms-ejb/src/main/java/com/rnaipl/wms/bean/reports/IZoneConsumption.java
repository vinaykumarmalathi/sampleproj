package com.rnaipl.wms.bean.reports;

import java.util.List;

import com.rnaipl.wms.dto.ZoneDTO;
import com.rnaipl.wms.dto.reports.PickinglistDTO;
import com.rnaipl.wms.dto.reports.PickinglistResultsDTO;
import com.rnaipl.wms.dto.reports.ZoneConsumptionDTO;

public interface IZoneConsumption {

	public int getZoneListCount(ZoneConsumptionDTO zoneConsumptionDTO);
	
	public List<ZoneConsumptionDTO> getZoneList(ZoneConsumptionDTO zoneConsumptionDTO, String dwnloadFLg);


}
