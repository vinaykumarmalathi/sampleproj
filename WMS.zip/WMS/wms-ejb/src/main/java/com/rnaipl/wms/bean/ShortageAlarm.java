/**
 * 
 */
package com.rnaipl.wms.bean;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import com.rnaipl.wms.dto.LocationByPartDTO;
import com.rnaipl.wms.dto.PartNumberDTO;
import com.rnaipl.wms.dto.ShortageAlarmDTO;

/**
 * @author z023761
 *
 */
public interface ShortageAlarm {

	public int getShortageAlmListCount(ShortageAlarmDTO shortageAlarmDTO);

	public List<ShortageAlarmDTO> getShortageAlmList(ShortageAlarmDTO shortageAlarmDTO);

	public List<ShortageAlarmDTO> getShortageAlmDownload(ShortageAlarmDTO shortageAlarmDTO);

	/* public void getShortageAlmDownload(String filepath) throws IOException; */

	public void downloadFile(String fileName) throws IOException;

	public Set<PartNumberDTO> getPartNumbers(String partNumber);

	public Set<PartNumberDTO> getSupplierList(String supplierCode);

	public Set<PartNumberDTO> getDepoCodeList(String depoCode);

	public Set<PartNumberDTO> getPcCodeList(String pcCode);

	public List<PartNumberDTO> getAllZones();

	public List<PartNumberDTO> getWips();

	public ShortageAlarmDTO getDownloadNameFmDB(String downloadName);

	public ShortageAlarmDTO getLstCalTime(String plant);

	public ShortageAlarmDTO getUserForAllPartsCoverage(String loggedInUserId);

	public List<LocationByPartDTO> getLocationsByPartNo(String partNo);

	public List<ShortageAlarmDTO> getShopByPlantId(String plantId);

	public List<ShortageAlarmDTO> getlinesByShopId(String shopId);

	public int getMaxDate() ;

}
