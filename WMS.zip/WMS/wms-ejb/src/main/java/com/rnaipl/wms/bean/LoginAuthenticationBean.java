package com.rnaipl.wms.bean;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.security.auth.login.FailedLoginException;

import org.apache.log4j.Logger;
import org.mindrot.jbcrypt.BCrypt;

import com.rnaipl.wms.entities.Login;
import com.rnaipl.wms.util.WMSBeanConstants;

@Stateless
@LocalBean
public class LoginAuthenticationBean implements LoginAuthentication {

	private static final Logger LOGGER = Logger
			.getLogger(LoginAuthenticationBean.class);
	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;

	private boolean succeeded;

	public int loginuser(String userName, String password) {
		LOGGER.debug("*** In LoginAuthentication Bean Class" + userName + "--"
				+ password);
		int result = 0;
		List<Login> users = entityManager
				.createQuery("select u from Login u where u.username=:username")
				.setParameter("username", userName).getResultList();

		if (users.isEmpty() || users.size() == 0) {
			LOGGER.debug("** USer Does not exist");
			return -1;
		} else {
			Login login = users.get(0);
			if (BCrypt.checkpw(password, login.getPassword())) {
				LOGGER.debug("** USer Password is correct");
				return 1;
			} else {

				LOGGER.debug("** USer Password is not correct");
				return 0;
			}

		}
	}

}
