package com.rnaipl.wms.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the LOCATION_HISTORY database table.
 * 
 */
@Entity
@Table(name="LOCATION_HISTORY")
@NamedQuery(name="LocationHistory.findAll", query="SELECT h FROM LocationHistory h")	
public class LocationHistory implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private int id;		
	
	@Column(name="LOCATION_ID")
	private String locationId;
	
	@Column(name="LOCATION_TYPE")
	private String locationType;	
	
	@Column(name="REMARKS")
	private String remarks;	
	
	@Column(name="DELETED_BY")
	private String deletedBy;
	
	@Column(name="DELETED_ON")
	private Timestamp deletedOn;	
	
	public Timestamp getDeletedOn() {
		return deletedOn;
	}
	public void setDeletedOn(Timestamp deletedOn) {
		this.deletedOn = deletedOn;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public String getLocationType() {
		return locationType;
	}
	public void setLocationType(String locationType) {
		this.locationType = locationType;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(String deletedBy) {
		this.deletedBy = deletedBy;
	}
	
}
