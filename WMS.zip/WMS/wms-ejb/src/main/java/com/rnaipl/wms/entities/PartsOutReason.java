package com.rnaipl.wms.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the PARTS_OUT_REASON database table.
 * 
 */
@Entity
@Table(name="PARTS_OUT_REASON")
@NamedQuery(name="PartsOutReason.findAll", query="SELECT p FROM PartsOutReason p")
public class PartsOutReason implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="REASON_CODE")
	private String reasonCode;

	@Column(name="REASON")
	private String reason;

	public PartsOutReason() {
	}

	public String getReasonCode() {
		return this.reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getReason() {
		return this.reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

}