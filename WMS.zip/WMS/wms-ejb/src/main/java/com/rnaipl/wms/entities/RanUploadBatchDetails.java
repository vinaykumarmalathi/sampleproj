package com.rnaipl.wms.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="RAN_UPLOAD_BATCH_DETAILS")
@NamedQuery(name="RanUploadBatchDetails.findAll", query="SELECT rd FROM RanUploadBatchDetails rd")
public class RanUploadBatchDetails implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="RUN_ID")
	private int runId;
	
	@Column(name="START_TIME")
	private Timestamp startTime;
	
	@Column(name="END_TIME")
	private Timestamp endTime;
	
	@Column(name="STATUS")
	private int status;
	
	@Column(name="FILE_NAME")
	private String fileName;

	public int getRunId() {
		return runId;
	}

	public void setRunId(int runId) {
		this.runId = runId;
	}

	public Timestamp getStartTime() {
		return startTime;
	}

	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}

	public Timestamp getEndTime() {
		return endTime;
	}

	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
