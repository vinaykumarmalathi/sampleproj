package com.rnaipl.wms.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="TBL_PICKINGLIST_STAGING_JOB")
public class PickingList implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4311603773296506910L;

	/**
	 * 
	 */
	
	
	public PickingList() {
		
	}
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private long id;
	
	
	@Column(name="Pick_List_ID")
	private String pickListID;

	@Column(name="Tot_No_of_Boxes")
	private int totalNumberOfBoxes;
	
	@Column(name="Tot_No_Of_Quantity")
	private int totalNumberOfQuantity;
	
	@Column(name="ShopName")
	private String shopName;
	
	@Column(name="Zone")
	private String zone;
	
	@Column(name="Detail_Device_TranID")
	private String detailDeviceTranID;
	
	@Column(name="PartNumber")
	private String partNumber;
	
	@Column(name="No_of_Boxes")
	private int numberOfBoxes;
	
	@Column(name="SNP")
	private int snp;
	
	@Column(name="Total_Quantity")
	private int totalQuantity;
	
	@Column(name="DeviceID")
	private String deviceID;
	
	@Column(name="Scan_Time")
	private Timestamp scanTime;

	public String getPickListID() {
		return pickListID;
	}

	public void setPickListID(String pickListID) {
		this.pickListID = pickListID;
	}

	public int getTotalNumberOfBoxes() {
		return totalNumberOfBoxes;
	}

	public void setTotalNumberOfBoxes(int totalNumberOfBoxes) {
		this.totalNumberOfBoxes = totalNumberOfBoxes;
	}

	public int getTotalNumberOfQuantity() {
		return totalNumberOfQuantity;
	}

	public void setTotalNumberOfQuantity(int totalNumberOfQuantity) {
		this.totalNumberOfQuantity = totalNumberOfQuantity;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public String getDetailDeviceTranID() {
		return detailDeviceTranID;
	}

	public void setDetailDeviceTranID(String detailDeviceTranID) {
		this.detailDeviceTranID = detailDeviceTranID;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public int getNumberOfBoxes() {
		return numberOfBoxes;
	}

	public void setNumberOfBoxes(int numberOfBoxes) {
		this.numberOfBoxes = numberOfBoxes;
	}

	public int getSnp() {
		return snp;
	}

	public void setSnp(int snp) {
		this.snp = snp;
	}

	public int getTotalQuantity() {
		return totalQuantity;
	}

	public void setTotalQuantity(int totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	public String getDeviceID() {
		return deviceID;
	}

	public void setDeviceID(String deviceID) {
		this.deviceID = deviceID;
	}

	public Timestamp getScanTime() {
		return scanTime;
	}

	public void setScanTime(Timestamp scanTime) {
		this.scanTime = scanTime;
	}
	
	
	

}
