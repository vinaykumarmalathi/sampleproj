package com.rnaipl.wms.entities;

import java.io.Serializable;

import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the PARTINOUT_STAGING_ERROR database table.
 * 
 */
@Entity
@Table(name="PARTINOUT_STAGING_ERROR")
@NamedQuery(name="PartinoutStagingError.findAll", query="SELECT p FROM PartinoutStagingError p")
public class PartinoutStagingError implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PART_PK")
	private long partPk;

	@Column(name="COMMENTS")
	private String comments;

	@Column(name="[COUNT]")
	private int count;

	@Column(name="DEVICE_ID")
	private String deviceId;

	@Column(name="LOCATION")
	private String location;

	@Column(name="PART_IN_OUT_TIME")
	private Timestamp partInOutTime;

	@Column(name="PART_NO")
	private String partNo;

	@Column(name="RAN")
	private String ran;

	@OneToOne
	@JoinColumn(name = "REASON_CODE" , referencedColumnName = "REASON_CODE")
	private PartsOutReason reasonCode;

	@Column(name="TRANSACTION_TYPE")
	private String transactionType;

	@Column(name="USER_ID")
	private String userId;
	
	@Column(name="ERROR_CODE")
	private int errorCode;
	
	@Column(name="SUGGESTED_LOCATION")
	private String suggestedLocation;
	
	@Column(name="SUGGESTED_RAN")
	private String suggestedRan;
	

	@Column(name="LOCATION_DESTINATION")
	private String locationDestination;
	
	

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public PartinoutStagingError() {
	}

	public long getPartPk() {
		return this.partPk;
	}

	public void setPartPk(long partPk) {
		this.partPk = partPk;
	}

	public String getComments() {
		return this.comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public int getCount() {
		return this.count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getDeviceId() {
		return this.deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getLocation() {
		return this.location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Timestamp getPartInOutTime() {
		return this.partInOutTime;
	}

	public void setPartInOutTime(Timestamp partInOutTime) {
		this.partInOutTime = partInOutTime;
	}

	public String getPartNo() {
		return this.partNo;
	}

	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}

	public String getRan() {
		return this.ran;
	}

	public void setRan(String ran) {
		this.ran = ran;
	}


	public PartsOutReason getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(PartsOutReason reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getTransactionType() {
		return this.transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSuggestedLocation() {
		return suggestedLocation;
	}

	public void setSuggestedLocation(String suggestedLocation) {
		this.suggestedLocation = suggestedLocation;
	}

	public String getSuggestedRan() {
		return suggestedRan;
	}

	public void setSuggestedRan(String suggestedRan) {
		this.suggestedRan = suggestedRan;
	}

	public String getLocationDestination() {
		return locationDestination;
	}

	public void setLocationDestination(String locationDestination) {
		this.locationDestination = locationDestination;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	

}