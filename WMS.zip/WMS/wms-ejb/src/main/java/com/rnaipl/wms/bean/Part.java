package com.rnaipl.wms.bean;

import java.util.List;
import java.util.Set;

import com.rnaipl.wms.dto.PartDTO;
import com.rnaipl.wms.dto.PartLocationDownloadReportDTO;
import com.rnaipl.wms.dto.PartLocationSynchroInputDTO;
import com.rnaipl.wms.dto.PartLocationSynchroServiceDTO;
import com.rnaipl.wms.dto.PartNumberDTO;
import com.rnaipl.wms.dto.PartSearchDTO;

public interface Part {

	public List<PartDTO> getAllParts();
	
	public List<PartLocationSynchroServiceDTO> getPartLocationSynchroService( PartLocationSynchroInputDTO partLocationSynchroInputDTO);
	
	public List<PartLocationSynchroServiceDTO> getPartLocationSynchroServiceAndroid( PartLocationSynchroInputDTO partLocationSynchroInputDTO);
	
	public Set<PartNumberDTO> getPartNumbers(String partNumber);
	
	public List<PartDTO> getPartSearchData(PartSearchDTO part);
	
	public String insertPart(PartDTO partDto);
	
	public String updatePart(List<PartDTO> part);
	
	public String deletePart(PartSearchDTO part);

	public PartSearchDTO getPartByPartNumber(String partNumber);
	
	public int getPartCount(PartSearchDTO part);
	
	public List<PartLocationDownloadReportDTO> partDownload(PartSearchDTO part);
	
	
}
