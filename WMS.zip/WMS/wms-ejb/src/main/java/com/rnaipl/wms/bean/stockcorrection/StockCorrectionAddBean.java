package com.rnaipl.wms.bean.stockcorrection;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.StockCorrectionAddDTO;
import com.rnaipl.wms.entities.StockCorrectionAddEntity;
import com.rnaipl.wms.util.WMSBeanConstants;

/**
 * 
 * @author TechM
 * 
 */
@Stateless
@LocalBean
public class StockCorrectionAddBean implements StockCorrectionAdd {

	private static final Logger LOGGER = Logger.getLogger(StockCorrectionAddBean.class);

	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;

	public List<StockCorrectionAddDTO> addStockCorrection(List<StockCorrectionAddDTO> stockAddDTO) {

		LOGGER.debug("addStockCorrection 1 - Starts " + stockAddDTO.size());

		for (StockCorrectionAddDTO stock : stockAddDTO) {

			StockCorrectionAddEntity stockEntity = new StockCorrectionAddEntity();
			stockEntity.setPartNo(stock.getPartNo());
			stockEntity.setLineStock(stock.getLineStock());
			stockEntity.setCorrectionStock(stock.getCorrection());
			stockEntity.setConsiderFlag(stock.getConsideration());
			stockEntity.setShift(stock.getShift());
			stockEntity.setRemarks(stock.getRemarks());

			LOGGER.debug("*Part number" + stockEntity.getPartNo());
			LOGGER.debug("*LineStock" + stockEntity.getLineStock());
			LOGGER.debug("*correction stock" + stockEntity.getCorrectionStock());
			LOGGER.debug("*shift" + stockEntity.getShift());
			LOGGER.debug("*Consederation" + stockEntity.getConsiderFlag());
			LOGGER.debug("*Remarks" + stockEntity.getRemarks());

			entityManager.persist(stockEntity);
			LOGGER.debug("*Part pk" + stockEntity.getPartPk());
			stock.setPartId(stockEntity.getPartPk());

		}

		LOGGER.debug("addStockCorrection 1 - end ");
		return stockAddDTO;
	}

	public void deleteStockCorrection(List<StockCorrectionAddDTO> stockDTOs) {

		LOGGER.debug("deleteStockCorrection 1 - Starts " + stockDTOs.size());

		Query query = entityManager
				.createQuery("DELETE FROM TBL_LNFD_STK_CORRECTION_TEST WHERE PART_PK = :partId");

		for (StockCorrectionAddDTO stock : stockDTOs) {

			query.setParameter("partId", stock.getPartId());
			int res = query.executeUpdate();
			
			LOGGER.debug("*Deleted rows " + res);

		}

		LOGGER.debug("deleteStockCorrection 1 - end ");

	}

}
