package com.rnaipl.wms.bean.stockcorrection;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.StockCorrectionAddDTO;
import com.rnaipl.wms.entities.StockCorrectionAddEntity;
import com.rnaipl.wms.util.WMSBeanConstants;

/**
 * 
 * @author TechM
 * 
 */
@Stateless
@LocalBean
public class StockCorrectionAddBean implements StockCorrectionAdd {

	private static final Logger LOGGER = Logger.getLogger(StockCorrectionAddBean.class);

	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;

	public List<StockCorrectionAddDTO> addStockCorrection(List<StockCorrectionAddDTO> stockAddDTO) {

		LOGGER.debug("addStockCorrection 1 - Starts " + stockAddDTO.size());

		for (StockCorrectionAddDTO stock : stockAddDTO) {

			StockCorrectionAddEntity stockEntity = new StockCorrectionAddEntity();
			stockEntity.setPartNo(stock.getPartNo());
			stockEntity.setLineStock(stock.getLineStock());
			stockEntity.setCorrectionStock(stock.getCorrection());
			stockEntity.setConsiderFlag(stock.getConsideration());
			stockEntity.setShift(stock.getShift());
			stockEntity.setRemarks(stock.getRemarks());

			stockEntity.setReason(stock.getReason());
			stockEntity.setLineFeedId(stock.getLineFeedId());
			stockEntity.setUserId(stock.getUserId());
			
			LOGGER.debug("*Part number " + stockEntity.getPartNo());
			LOGGER.debug("*LineStock " + stockEntity.getLineStock());
			LOGGER.debug("*correction stock " + stockEntity.getCorrectionStock());
			LOGGER.debug("*shift " + stockEntity.getShift());
			LOGGER.debug("*Consederation " + stockEntity.getConsiderFlag());
			LOGGER.debug("*Remarks " + stockEntity.getRemarks());
			LOGGER.debug("*Reason " + stockEntity.getRemarks());
			LOGGER.debug("*line feed id " + stockEntity.getLineFeedId());
			LOGGER.debug("*userid " + stockEntity.getUserId());
			

			entityManager.persist(stockEntity);
			LOGGER.debug("*Part pk" + stockEntity.getPartPk());
			stock.setPartId(stockEntity.getPartPk());

		}

		LOGGER.debug("addStockCorrection 1 - end ");
		return stockAddDTO;
	}

	public void updateStock(List<StockCorrectionAddDTO> stockDTO) {

		LOGGER.debug("updateStock 1 - start ");

		for (StockCorrectionAddDTO stock : stockDTO) {

			if (stock.getModify() != null && stock.getModify().length() > 0) {

				if (Integer.parseInt(stock.getModify()) == 1) {
					Query query = entityManager.createNativeQuery(
							"UPDATE [dbo].[TBL_LNFD_STK_MASTER_TEST] SET PREV_LINE_STK=STOCK, STOCK=(STOCK+:correction) WHERE PART_NO=:partNo ");
					query.setParameter("correction", stock.getCorrection());
					query.setParameter("partNo", stock.getPartNo());

					int res = query.executeUpdate();

					LOGGER.debug("*updated rows " + res);

				} else if (Integer.parseInt(stock.getModify()) == 2) {
					Query query = entityManager.createNativeQuery(
							"UPDATE [dbo].[TBL_LNFD_STK_MASTER_TEST] SET PREV_LINE_STK=STOCK, STOCK=(STOCK-:correction) WHERE PART_NO=:partNo ");
					query.setParameter("correction", stock.getCorrection());
					query.setParameter("partNo", stock.getPartNo());

					int res = query.executeUpdate();

					LOGGER.debug("*updated rows " + res);
				}

			}

		}

		LOGGER.debug("updateStock 1 - end ");

	}

	public void deleteStockCorrection(List<StockCorrectionAddDTO> stockDTOs) {

		LOGGER.debug("deleteStockCorrection 1 - Starts " + stockDTOs.size());

		for (StockCorrectionAddDTO stock : stockDTOs) {

			Query query = entityManager
					.createNativeQuery("DELETE FROM dbo.TBL_LNFD_STK_CORRECTION_TEST WHERE PART_PK = :partId");

			query.setParameter("partId", stock.getPartId());
			int res = query.executeUpdate();

			LOGGER.debug("*Deleted rows " + res);

		}

		LOGGER.debug("deleteStockCorrection 1 - end ");

	}

	public boolean checkPartNumber(StockCorrectionAddDTO stockDTO) {

		LOGGER.debug("checkPartNumber 1 - start " + stockDTO.getPartNo());

		String querySql = "SELECT LNFD_ID, PART_TYPE, ZONE, SUB_ZONE, STOCK FROM dbo.TBL_LNFD_STK_MASTER_TEST WHERE PART_NO = :partNo ";

		Query query = entityManager.createNativeQuery(querySql.toString());
		query.setParameter("partNo", stockDTO.getPartNo());
		boolean found = false;
		List<Object[]> searchResults = query.getResultList();
		if (null != searchResults && searchResults.size() > 0) {
			for (int i = 0; i < searchResults.size(); i++) {
				Object[] details = searchResults.get(i);
				stockDTO.setLineFeedId(null == details[0] ? 0 : Long.parseLong(details[0].toString()));
				stockDTO.setPartName(null == details[1] ? "" : details[1].toString());
				stockDTO.setZone(null == details[2] ? "" : details[2].toString());
				stockDTO.setSubzone(null == details[3] ? "" : details[3].toString());
				stockDTO.setLineStock(null == details[4] ? "" : details[4].toString());

				found = true;
			}
		}
		LOGGER.debug("checkPartNumber 1 - end " + stockDTO.getPartName());
		return found;
	}

}
