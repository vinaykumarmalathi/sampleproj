package com.rnaipl.wms.entities;

import java.io.Serializable;

import javax.persistence.*;

import com.rnaipl.wms.entities.Line;
import com.rnaipl.wms.entities.LocationType;
import com.rnaipl.wms.entities.Plant;
import com.rnaipl.wms.entities.Section;
import com.rnaipl.wms.entities.Shop;

import java.util.List;


/**
 * The persistent class for the LOCATION_TYPE database table.
 * 
 */
@Entity
@Table(name="LOCATION")
@NamedQuery(name="Location.findAll", query="SELECT l FROM Location l")
public class Location implements Serializable {
	/*public List<PartLocation> getPartLocation() {
		return partLocation;
	}

	public void setPartLocation(List<PartLocation> partLocation) {
		this.partLocation = partLocation;
	}*/



	private static final long serialVersionUID = 1L;


	/*@OneToMany(mappedBy="location", fetch=FetchType.LAZY)	
	private List<PartLocation> partLocation;*/
	
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LOCATION_ID")
	private String locationId;

	@OneToOne
	@JoinColumn(name = "LOCATION_TYPE" , referencedColumnName="LOCATIONTYPE_ID")
	private LocationType locationType;

	@OneToOne
	@JoinColumn(name = "PLANT" , referencedColumnName="PLANT_ID")
	private Plant plant;
	
	@OneToOne
	@JoinColumn(name = "SHOP" , referencedColumnName="SHOP_ID")
	private Shop shop;
	
	@OneToOne
	@JoinColumn(name = "LINE" , referencedColumnName="LINE_ID")
	private Line line;
	
	@OneToOne
	@JoinColumn(name = "SECTION" , referencedColumnName="SECTION_ID")
	private Section section;
	
	@Column(name="ZONE")
	private String zone;
	
	@Column(name="SERIES")
	private String series;
	
	@Column(name="LOCATION_SERIES1")
	private String locationSeries1;
	
	@Column(name="LOCATION_SERIES2")
	private String locationSeries2;
	
	@Column(name="CELL_ID")
	private String cellId;
	
	@Column(name="LOCATION_LEVEL")
	private String locationLevel;
	
	@Lob
	@Column(name="CHANGE_LOG")
	private String changeLog;
	
	
	
	
	@ManyToMany
	    @JoinTable(
	        name="PART_LOCATION"
	        , joinColumns={
	            @JoinColumn(name="LOCATION_ID")
	            }
	        , inverseJoinColumns={
	            @JoinColumn(name="PART_NO")
	            }
	        )
	private List<Part> parts;
	
	
	
	public List<Part> getParts() {
		return parts;
	}

	public void setParts(List<Part> parts) {
		this.parts = parts;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}


	public LocationType getLocationType() {
		return locationType;
	}

	public void setLocationType(LocationType locationType) {
		this.locationType = locationType;
	}

	public Plant getPlant() {
		return plant;
	}

	public void setPlant(Plant plant) {
		this.plant = plant;
	}

	public Shop getShop() {
		return shop;
	}

	public void setShop(Shop shop) {
		this.shop = shop;
	}

	public Line getLine() {
		return line;
	}

	public void setLine(Line line) {
		this.line = line;
	}

	public Section getSection() {
		return section;
	}

	public void setSection(Section section) {
		this.section = section;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public String getSeries() {
		return series;
	}

	public void setSeries(String series) {
		this.series = series;
	}

	public String getLocationSeries1() {
		return locationSeries1;
	}

	public void setLocationSeries1(String locationSeries1) {
		this.locationSeries1 = locationSeries1;
	}

	public String getLocationSeries2() {
		return locationSeries2;
	}

	public void setLocationSeries2(String locationSeries2) {
		this.locationSeries2 = locationSeries2;
	}

	public String getCellId() {
		return cellId;
	}

	public void setCellId(String cellId) {
		this.cellId = cellId;
	}

	public String getLocationLevel() {
		return locationLevel;
	}

	public void setLocationLevel(String locationLevel) {
		this.locationLevel = locationLevel;
	}
	public Location() {
	}
	
	public String getChangeLog() {
		return changeLog;
	}

	public void setChangeLog(String changeLog) {
		this.changeLog = changeLog;
	}

}