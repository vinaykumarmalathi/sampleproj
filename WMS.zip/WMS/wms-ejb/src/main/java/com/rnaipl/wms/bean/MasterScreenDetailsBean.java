package com.rnaipl.wms.bean;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.MasterScreenDetailsDTO;
import com.rnaipl.wms.util.WMSBeanConstants;

@Stateless

@LocalBean

public class MasterScreenDetailsBean implements com.rnaipl.wms.bean.MasterScreenDetails {

	private static final Logger LOGGER = Logger.getLogger(MasterScreenDetailsBean.class);

	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)

	private EntityManager entityManager;

	private boolean checkEmpty(String str) {

		if (str != null && !str.toString().trim().equalsIgnoreCase("") && str.length() > 0) {

			return true;

		}

		return false;

	}

	public int getMasterListCount(MasterScreenDetailsDTO masterScreenDTO) {

		LOGGER.debug("Entering getMasterListCount bean");
		int noOfRecords = 0;
		try {
			Map<String, Object> map = new LinkedHashMap<String, Object>();

			String querySql = "SELECT COUNT(*) FROM dbo.TBL_LNFD_STK_MASTER_TEST WHERE 1=1 ";

			querySql = querySql + createWhereClause(masterScreenDTO, map);

			LOGGER.debug("Count Query : " + querySql.toString());

			Query query = entityManager.createNativeQuery(querySql);

			if (null != masterScreenDTO.getPartNumber() && !masterScreenDTO.getPartNumber().equalsIgnoreCase("")) {
				query.setParameter("partNos", masterScreenDTO.getPartList());
			}

			if (null != masterScreenDTO.getLocation() && !masterScreenDTO.getLocation().equalsIgnoreCase("")) {
				query.setParameter("locationNos", masterScreenDTO.getLocationList());
			}

			noOfRecords = (Integer) query.getSingleResult();

			LOGGER.debug("recordCount : " + noOfRecords);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return noOfRecords;
	}

	private String createWhereClause(MasterScreenDetailsDTO masterScreenDTO, Map<String, Object> map) {

		StringBuffer queryBuffer = new StringBuffer();

		if (checkEmpty(masterScreenDTO.getLine())) {

			queryBuffer.append(" AND upper(LINE)='" + masterScreenDTO.getLine().toUpperCase() + "'");

		}

		if (checkEmpty(masterScreenDTO.getShop())) {

			queryBuffer.append(" AND upper(SHOP)='" + masterScreenDTO.getShop().toUpperCase() + "'");

		}

		if (checkEmpty(masterScreenDTO.getZone())) {

			queryBuffer.append(" AND upper(ZONE)='" + masterScreenDTO.getZone().toUpperCase() + "'");

		}

		if (checkEmpty(masterScreenDTO.getSubzone())) {

			queryBuffer.append(" AND upper(SUB_ZONE)='" + masterScreenDTO.getSubzone().toUpperCase() + "'");

		}

		if (checkEmpty(masterScreenDTO.getAllocation())) {

			queryBuffer.append(" AND upper(ALLOCATION)='" + masterScreenDTO.getAllocation().toUpperCase() + "'");

		}

		if (checkEmpty(masterScreenDTO.getSupplier())) {

			queryBuffer.append(" AND upper(SUPPLIER_METHOD)='" + masterScreenDTO.getSupplier().toUpperCase() + "'");

		}

		if (masterScreenDTO.getLocation() != null && !masterScreenDTO.getLocation().equals("")) {

			queryBuffer.append(" AND WH_LOC IN (:locationNos)");

		}

		if (masterScreenDTO.getPartNumber() != null && !masterScreenDTO.getPartNumber().equals("")) {

			queryBuffer.append(" AND PART_NO IN (:partNos)");

		}

		return queryBuffer.toString();

	}

	public List<MasterScreenDetailsDTO> getMasterScreenDetails(MasterScreenDetailsDTO location) {

		LOGGER.debug("*****IN Get getMasterScreenDetails Bean ");

		List<MasterScreenDetailsDTO> masterDetails = new ArrayList<MasterScreenDetailsDTO>();

		List<Object[]> searchResults = new ArrayList<Object[]>();

		if (location.getIsFullDownload() == 1) {
			searchResults = masterScreenSearchData(location, false);
		} else {
			searchResults = masterScreenSearchData(location, true);
		}

		if (null != searchResults && searchResults.size() > 0) {

			for (int i = 0; i < searchResults.size(); i++) {

				MasterScreenDetailsDTO master = new MasterScreenDetailsDTO();
				Object[] missingPartDetails = searchResults.get(i);
				
				master.setPartNo(null == missingPartDetails[0] ? "" : missingPartDetails[0].toString());
				master.setPartType(null == missingPartDetails[1] ? "" : missingPartDetails[1].toString());
				master.setSupplier(null == missingPartDetails[2] ? "" : missingPartDetails[2].toString());
				master.setModel(null == missingPartDetails[3] ? "" : missingPartDetails[3].toString());
				master.setUsageCar(null == missingPartDetails[4] ? "" : missingPartDetails[4].toString());
				master.setDescription(null == missingPartDetails[5] ? "" : missingPartDetails[5].toString());
				master.setSnip(null == missingPartDetails[6] ? "" : missingPartDetails[6].toString());
				master.setZone(null == missingPartDetails[7] ? "" : missingPartDetails[7].toString());
				master.setSubzone(null == missingPartDetails[8] ? "" : missingPartDetails[8].toString());
				master.setFrequency(null == missingPartDetails[9] ? "" : missingPartDetails[9].toString());
				master.setWhLoc(null == missingPartDetails[10] ? "" : missingPartDetails[10].toString());
				master.setLineLoc(null == missingPartDetails[11] ? "" : missingPartDetails[11].toString());
				master.setLineCapacity(null == missingPartDetails[12] ? "" : missingPartDetails[12].toString());
				master.setMinFeed(null == missingPartDetails[13] ? "" : missingPartDetails[13].toString());
				master.setSupplierMethod(null == missingPartDetails[14] ? "" : missingPartDetails[14].toString());
				master.setSafetyStock(null == missingPartDetails[15] ? "" : missingPartDetails[15].toString());
				master.setAllocation(null == missingPartDetails[16] ? "" : missingPartDetails[16].toString());
				master.setDistance(null == missingPartDetails[17] ? "" : missingPartDetails[17].toString());
				master.setTime(null == missingPartDetails[18] ? "" : missingPartDetails[18].toString());
				master.setSystemStock(null == missingPartDetails[19] ? "" : missingPartDetails[19].toString());
				master.setWip(null == missingPartDetails[20] ? "" : missingPartDetails[20].toString());
				master.setWipPaint(null == missingPartDetails[21] ? "" : missingPartDetails[21].toString());
				master.setWipTotal(null == missingPartDetails[22] ? "" : missingPartDetails[22].toString());
				master.setShiftConsumption(null == missingPartDetails[23] ? "" : missingPartDetails[23].toString());
				
				masterDetails.add(master);

			}

		}

		return masterDetails;

	}

	private List<Object[]> masterScreenSearchData(MasterScreenDetailsDTO masterScreenDTO, boolean isIndexCheck) {

		Map<String, Object> map = new LinkedHashMap<String, Object>();

		StringBuffer countQuery = new StringBuffer();

		countQuery.append(
				"SELECT PART_NO, PART_TYPE,SUPPLIER_METHOD,MODEL,USAGE_CAR,DESCRIPTION,SNIP,ZONE,SUB_ZONE,FREQUENCY,WH_LOC,LINE_LOC,LINE_CAP,MIN_FEED,");
		countQuery.append(" SUP_NAME, SAFETY_STOCK, ALLOCATION,DISTANCE,TIME,SYS_STOCK,WIP_TC,WIP_Paint,WIP_Total,SHIFT_CON ");
		countQuery.append(" FROM TBL_LNFD_STK_MASTER_TEST WHERE 1=1  ");

		countQuery.append(createWhereClause(masterScreenDTO, map));

		countQuery.append(" ORDER BY PART_NO");

		LOGGER.debug("Query " + countQuery.toString());

		Query query = entityManager.createNativeQuery(countQuery.toString());

		if (null != masterScreenDTO.getPartNumber() && !masterScreenDTO.getPartNumber().equalsIgnoreCase("")) {
			query.setParameter("partNos", masterScreenDTO.getPartList());
		}

		if (null != masterScreenDTO.getLocation() && !masterScreenDTO.getLocation().equalsIgnoreCase("")) {
			query.setParameter("locationNos", masterScreenDTO.getLocationList());
		}

		if (isIndexCheck == true) {
			query.setFirstResult(masterScreenDTO.getStartIndex());
			query.setMaxResults(masterScreenDTO.getEndIndex());
		}
		List<Object[]> results = query.getResultList();
		return results;

	}

}
