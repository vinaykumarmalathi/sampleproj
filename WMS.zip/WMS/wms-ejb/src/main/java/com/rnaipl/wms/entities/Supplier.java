package com.rnaipl.wms.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the [SECTION] database table.
 * 
 */
@Entity
@Table(name = "SUPPLIER")
//@NamedQuery(name = "Supplier.findAll", query = "SELECT s FROM SUPPLIER s")
public class Supplier implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "SUPPLIER_ID")
	private String supplierId;

	@Column(name = "SUPPLIER_NAME")
	private String supplierName;

	public Supplier() {
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

}