package com.rnaipl.wms.bean;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.MissingPartsDTO;
import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSBeanUtil;

public class MissingPartsBean implements MissingParts{
	private static final Logger LOGGER = Logger.getLogger(MissingPartsBean.class);
	
	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
    private EntityManager entityManager;

	
	public List<MissingPartsDTO> getMissingPartsList(MissingPartsDTO missingPartDTO) throws Exception {
		LOGGER.debug("*****In getMissingPartsList bean****" );
		
		List<MissingPartsDTO> missingPartsList = new ArrayList<MissingPartsDTO>();
		
		StringBuffer queryStringBuf = new StringBuffer();
		queryStringBuf.append(getQuery(missingPartDTO));
		
		Query query = entityManager.createNativeQuery(queryStringBuf.toString());
		LOGGER.debug("*****Query Generated getMissingPartsList() == " + queryStringBuf.toString() );
		
		List<Object[]> queryDatas = query.getResultList();
		LOGGER.debug("getMissingPartsList() == Missing Part Data size ==  " + queryDatas.size());
		
		if(missingPartDTO.getIsFullDownload()!=1){
			query.setFirstResult(missingPartDTO.getStartIndex());
			query.setMaxResults(missingPartDTO.getEndIndex());
		}
		
		if (null != queryDatas && queryDatas.size() > 0) {
			for(int i = 0; i<queryDatas.size(); i++){
				MissingPartsDTO mpdto = new MissingPartsDTO();
				Object[] missingPartDetails = queryDatas.get(i);
				
				int indexCount = 0;
				mpdto.setPartNumber((null == missingPartDetails[indexCount]?"":missingPartDetails[indexCount].toString()));
				
				indexCount++;
				mpdto.setFileName((null == missingPartDetails[indexCount]?"":missingPartDetails[indexCount].toString()));
				
				indexCount++;
				mpdto.setLiveReceiptUpdatedTime((Timestamp) missingPartDetails[indexCount]);
				
				missingPartsList.add(mpdto);
			}
		}
		return missingPartsList;
	}

	
	public int getMissingPartsListCount(MissingPartsDTO missingPartDTO) throws Exception {
		LOGGER.debug("*****In getMissingPartsListCount bean****" );
		
		StringBuffer queryStringBuf = new StringBuffer();
		queryStringBuf.append(getQuery(missingPartDTO));
		
		Query query = entityManager.createNativeQuery(queryStringBuf.toString());
		LOGGER.debug("*****Query Generated getMissingPartsListCount() == " + queryStringBuf.toString() );
		
		List<Object[]> queryDatas = query.getResultList();
		LOGGER.debug("getMissingPartsListCount() == Missing Part Data size ==  " + queryDatas.size());
		
		return queryDatas.size();
	}
	
	private String getQuery(MissingPartsDTO missingPartDTO){
		
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		StringBuffer query = new StringBuffer();
		query.append("SELECT DISTINCT PART_NO, filename, UPDATED_DATETIME FROM DBO.LIVE_RECEIPT WHERE PART_NO NOT IN(SELECT PART_NO FROM DBO.PART)");
		
		if(null != missingPartDTO.getPartList() && missingPartDTO.getPartList().size() > 0){
			String partString = queryStr(missingPartDTO.getPartList());
			LOGGER.debug("Missing Part Number Search Input Part Numbers == "+partString);
			query.append(" AND PART_NO IN ("); query.append(partString);  query.append(")");
		}
		
		if (missingPartDTO.getFromDate() != null	|| missingPartDTO.getToDate() != null) {
			
			Map<String,Date> shiftTimes  = WMSBeanUtil.getShiftTime("",missingPartDTO.getFromDate(),missingPartDTO.getToDate());
			
			missingPartDTO.setFromDate(shiftTimes.get("fromDate"));
			missingPartDTO.setToDate(shiftTimes.get("toDate"));
			
			LOGGER.debug("Live Receipt From Date -> "+ dateFormatter.format(missingPartDTO.getFromDate()));
			LOGGER.debug("Live Receipt To Date -> "+ dateFormatter.format(missingPartDTO.getToDate()));
			
			query.append(" AND UPDATED_DATETIME >= '"+ dateFormatter.format(missingPartDTO.getFromDate()) + "'");
			query.append(" AND UPDATED_DATETIME < '"+ dateFormatter.format(missingPartDTO.getToDate()) + "'");
		}
		
		LOGGER.debug("Query Generated for Missing Parts == "+query.toString());
		
		return query.toString();
	}
	
	private String queryStr(List<String> queryStr){
		String result = "";
		for(String str : queryStr){
			result = result + "'"+str+"',";
		}
		result = result.substring(0, result.length()-1);
		return result;
	}

}
