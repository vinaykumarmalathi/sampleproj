package com.rnaipl.wms.bean.ran;

import java.util.List;
import java.util.Set;

import com.rnaipl.wms.dto.LineDTO;
import com.rnaipl.wms.dto.PartLocationSynchroInputDTO;
import com.rnaipl.wms.dto.PlantDTO;
import com.rnaipl.wms.dto.ran.AgedAgingRanDTO;
import com.rnaipl.wms.dto.ran.AgedAgingRanInputDTO;
import com.rnaipl.wms.dto.ran.RANDTO;	
import com.rnaipl.wms.dto.ran.RANSuggestionDTO;
import com.rnaipl.wms.dto.ran.RANPickDateDTO;
import com.rnaipl.wms.dto.ran.SuggestedRANLocationForPartNoDTO;
import com.rnaipl.wms.dto.ran.SuggestedRanLocationDTO;
import com.rnaipl.wms.dto.reports.FIFOSuggestionOverrideInputDTO;
import com.rnaipl.wms.dto.reports.FIFOSuggestionOverrideValidationDTO;
import com.rnaipl.wms.dto.ran.WhMovementRanValidationInDTO;
import com.rnaipl.wms.dto.ran.WhMovementRanValidationOutDTO;

/**
 * 
 * @author TechM
 *
 */
public interface RAN {
	
	/**
	 * It will retrive all the plant details information from database
	 * @return - list of PlantDTO object
	 */
	public List<String> getAllRans();
	public Set<RANSuggestionDTO> getRan(String ran);
	public List<RANPickDateDTO> getAllRANLastPickDate(PartLocationSynchroInputDTO inputDto);
	public String checkAgedRAN(List<String> ranList);
	public SuggestedRANLocationForPartNoDTO getSuggestedRANandLocationForPartNumberWHOut(SuggestedRanLocationDTO suggestedRanLocationPartNo);
	public List<RANDTO> getRanList(RANDTO ranDTO);
	public FIFOSuggestionOverrideValidationDTO getFIFOSuggestionOverrideValidation(FIFOSuggestionOverrideInputDTO fIFOSuggestionOverrideDTO);
	public WhMovementRanValidationOutDTO getWhMovementRanValidation(WhMovementRanValidationInDTO whMovementRanValidationInDTO);
//	public List<AgedAgingRanDTO> getAgedAgingRAN(AgedAgingRanInputDTO agedAgingRanInputDTO);
	public Set<RANSuggestionDTO> getRanListByPlant(String input,RANDTO dto);
	public List<SuggestedRANLocationForPartNoDTO> getSuggestedRANandLocationForPartNumberWHOutTC(SuggestedRanLocationDTO suggestedRanLocationPartNo);
	
	
	
}

