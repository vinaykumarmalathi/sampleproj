package com.rnaipl.wms.bean.ran;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.ran.AgedAgingRanDTO;
import com.rnaipl.wms.dto.ran.AgedAgingRanInputDTO;
import com.rnaipl.wms.util.WMSBeanConstants;

/**
 * 
 * @author TechM
 * 
 */
@Stateless
@LocalBean
public class AgedRANBean implements AgedRAN {

	private static final Logger LOGGER = Logger.getLogger(AgedRANBean.class);

    @PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
    private EntityManager entityManager;

	
	public List<AgedAgingRanDTO> getAgedAgingRAN(AgedAgingRanInputDTO agedAgingRanInputDTO)
	{
			LOGGER.debug("*****In getAllRANLastPickDate bean" );
			StringBuffer queryStringBuf = new StringBuffer();
			 List<AgedAgingRanDTO> agedAgingRanDTOs = new ArrayList<AgedAgingRanDTO>();
			 //RETRIEVE THE RAN, IF ITS NOT AVAILABLE IN THE CURRENT QTY IS NOT 0 OR IF ITS NOT AVAILABLE IN PART LOCATION I.E STILL NOT IN WAREHOUSE
	        queryStringBuf.append("  SELECT R.RAN,R.PART_NO,R.MFG_DATE,R.LPPD,PL.LOCATION_ID,SUM(PL.CURRENT_QTY) AS STOCK FROM DBO.RAN R LEFT JOIN DBO.PART_LOCATION PL ON R.RAN=SUBSTRING(PL.RAN,1,7) AND R.PART_NO=PL.PART_NO");	        
	        queryStringBuf.append(" LEFT JOIN DBO.PART P ON P.PART_NO=R.PART_NO WHERE (PL.CURRENT_QTY>0 OR PL.CURRENT_QTY IS NULL) AND R.LPPD IS NOT NULL AND P.SHELF_LIFE_PART = 'Yes' ");
	        
	        if(agedAgingRanInputDTO.getReportType()!=null && agedAgingRanInputDTO.getReportType().equalsIgnoreCase("1"))//Aged RAN
	        {
	        	queryStringBuf.append(" AND R.LPPD <(GETDATE()-1)");
	        }
	        else if(agedAgingRanInputDTO.getReportType()!=null && agedAgingRanInputDTO.getReportType().equalsIgnoreCase("2"))//Aging RAN
	        {
	        	queryStringBuf.append(" AND (R.LPPD >= CONVERT(VARCHAR(10),(:fromDate),110) AND R.LPPD <= CONVERT(VARCHAR(10),(:toDate),110))");
	        }
	        
	        if (null != agedAgingRanInputDTO.getPlant() && !agedAgingRanInputDTO.getPlant().equals("")) {
	            queryStringBuf.append(" AND SUBSTRING(PL.LOCATION_ID, 1, 1) = '" + agedAgingRanInputDTO.getPlant() + "'");
	        }
	        if (null != agedAgingRanInputDTO.getShop() && !agedAgingRanInputDTO.getShop().equals("")) {
	            queryStringBuf.append(" AND SUBSTRING(PL.LOCATION_ID, 2, 1) = '" + agedAgingRanInputDTO.getShop() + "'");
	        }
	        if (null != agedAgingRanInputDTO.getLine() && !agedAgingRanInputDTO.getLine().equals("")) {
	            queryStringBuf.append(" AND SUBSTRING(PL.LOCATION_ID, 3, 1) = '" + agedAgingRanInputDTO.getLine() + "'");
	        }
	        if (null != agedAgingRanInputDTO.getSection() && !agedAgingRanInputDTO.getSection().equals("")) {
	            queryStringBuf.append(" AND SUBSTRING(PL.LOCATION_ID, 4, 1) = '" + agedAgingRanInputDTO.getSection() + "'");
	        }
	        if (null != agedAgingRanInputDTO.getPartNo() && !agedAgingRanInputDTO.getPartNo().equals("")) {
	            queryStringBuf.append(" AND  R.PART_NO IN (:partNos)");
	        }
	     
	        if (null != agedAgingRanInputDTO.getRan() && !agedAgingRanInputDTO.getRan().equals("")) {
	        	queryStringBuf.append(" AND  R.RAN IN (:rans)");
	        }
	        if (null != agedAgingRanInputDTO.getLocation() && !agedAgingRanInputDTO.getLocation().equals("")) {
	        	queryStringBuf.append(" AND  PL.LOCATION_ID IN (:locations)");
	        }
	        if(agedAgingRanInputDTO.getReportType()!=null && agedAgingRanInputDTO.getReportType().equalsIgnoreCase("2"))
	        {
	        	//CONVERT TO YYYY/MM/DD FORMAT BEFORE COMPARISON
	        	queryStringBuf.append(" AND CONVERT(VARCHAR(10),LPPD,111) >='"+agedAgingRanInputDTO.getFromDate().trim() +"'" );
	        }
	        if(agedAgingRanInputDTO.getReportType()!=null && agedAgingRanInputDTO.getReportType().equalsIgnoreCase("2"))
	        {
	        	//CONVERT TO YYYY/MM/DD FORMAT BEFORE COMPARISON
	        	queryStringBuf.append(" AND CONVERT(VARCHAR(10),LPPD,111) <='"+agedAgingRanInputDTO.getToDate().trim() +"'" );
	        }
	        
	        //GROUP BY - To show sum of current qty available in different location
	        queryStringBuf.append(" GROUP BY R.RAN,R.PART_NO,R.MFG_DATE,R.LPPD,PL.LOCATION_ID");
	        queryStringBuf.append(" ORDER BY R.RAN");
	        

	        
	        Query query = entityManager.createNativeQuery(queryStringBuf.toString());
	        
	        LOGGER.debug("*Aging RAN Report Quert " + queryStringBuf);
	        
	        //If the request is for not for total record count or download full report then filter records for pagination.
	        if(!agedAgingRanInputDTO.isRequestForCount() && !agedAgingRanInputDTO.isDownload()){	        	
	        	
	        	query.setFirstResult(agedAgingRanInputDTO.getStartIndex());
	        	query.setMaxResults(agedAgingRanInputDTO.getMaxResult());
	        }
	        if (null != agedAgingRanInputDTO.getPartNo() && !agedAgingRanInputDTO.getPartNo().equalsIgnoreCase("")) {
	        	
	            query.setParameter("partNos", agedAgingRanInputDTO.getPartList());
	        }
	     
	        if (null != agedAgingRanInputDTO.getRan() && !agedAgingRanInputDTO.getRan().equalsIgnoreCase("")) {
	        	
	            query.setParameter("rans", agedAgingRanInputDTO.getRanList());
	        }
	        
	        if (null != agedAgingRanInputDTO.getLocation() && !agedAgingRanInputDTO.getLocation().equalsIgnoreCase("")) {
	        	
	            query.setParameter("locations", agedAgingRanInputDTO.getLocationList());
	        }
	        if(agedAgingRanInputDTO.getReportType()!=null && agedAgingRanInputDTO.getReportType().equalsIgnoreCase("2"))
	        {
	        	query.setParameter("fromDate", agedAgingRanInputDTO.getFromDate());
	        	query.setParameter("toDate", agedAgingRanInputDTO.getToDate());
	        }
	        
	        List<Object[]> agedAgingRANList = query.getResultList();
	      
	        if (null != agedAgingRANList && agedAgingRANList.size() > 0) {
	            for (Iterator<Object[]> i = agedAgingRANList.iterator(); i.hasNext();) {
	            	int indexCount=0;
	                Object[] values = (Object[]) i.next();
	                AgedAgingRanDTO agedAgingRanDTO = new AgedAgingRanDTO();
	                
	                agedAgingRanDTO.setRan((null == values[indexCount] ? "" : values[indexCount].toString()));	               
	                indexCount++;	                
	                agedAgingRanDTO.setPartNo((null == values[indexCount] ? "" : values[indexCount].toString()));
	                indexCount++;
	                agedAgingRanDTO.setMfgDate((null == values[indexCount] ? "" : values[indexCount].toString().substring(0,10)));
	                indexCount++;
	                agedAgingRanDTO.setLppd((null == values[indexCount] ? "" : values[indexCount].toString().substring(0,10)));
	                indexCount++;
	                agedAgingRanDTO.setLocation((null == values[indexCount] ? "" : values[indexCount].toString()));
	                indexCount++;
	                agedAgingRanDTO.setStock((null == values[indexCount] ? "" : values[indexCount].toString()));
	                
	               
	                agedAgingRanDTOs.add(agedAgingRanDTO);
	            }

	        }
	        
	        
	        return agedAgingRanDTOs;
	}

}
