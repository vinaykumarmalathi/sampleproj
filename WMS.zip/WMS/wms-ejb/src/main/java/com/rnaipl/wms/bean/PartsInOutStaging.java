package com.rnaipl.wms.bean;

import java.text.ParseException;
import java.util.List;

import com.rnaipl.wms.dto.PartsInOutStagingByDeviceDTO;
import com.rnaipl.wms.dto.PartsInOutStagingDTO;

public interface PartsInOutStaging {
	
	/**
	 * 
	 * @param partsInOutInfo
	 * @return
	 */
	/*public void insertPartsInOutStaging(PartsInOutStagingDTO partsInOutInfo);*/
	
	/**
	 * 
	 * @param partsInOutInfo
	 * @throws ParseException 
	 */
	public int insertPartsInOutStaging(List<PartsInOutStagingByDeviceDTO> partsInOutInfoList);
	
	/**
	 * 
	 * @param partsInOutAudit - passing locationId as input param
	 * @return
	 */
	public List<PartsInOutStagingDTO> getPartsInOutAuditByLocaiton(PartsInOutStagingDTO partsInOutAudit);
	
	//public void executeStoreProcedure();
	
}
