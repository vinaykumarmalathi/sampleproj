package com.rnaipl.wms.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.rnaipl.wms.entitiesPK.PartLocationPK;;




/**
 * The persistent class for the USER_MENU database table.
 * 
 */
@Entity
@Table(name="PART_LOCATION")
@NamedQuery(name="PartLocation.findAll", query="SELECT u FROM PartLocation u")
public class PartLocation implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PartLocationPK id;

	@Column(name="CURRENT_QTY")
	private int currentQty;
	
/*	@Column(name="RAN")
	private String ran;*/

	@Column(name="TOTAL_CAPACITY")
	private int totalCapacity;

	@ManyToOne
	@JoinColumn(name="PART_NO",insertable=false,updatable=false)		
	private Part part;

	@ManyToOne
	@JoinColumn(name="LOCATION_ID",insertable=false,updatable=false)
	private Location location;
		
	
	public int getCurrentQty() {
			return currentQty;
		}

		public void setCurrentQty(int currentQty) {
			this.currentQty = currentQty;
		}

		public int getTotalCapacity() {
			return totalCapacity;
		}

		public void setTotalCapacity(int totalCapacity) {
			this.totalCapacity = totalCapacity;
		}

		public Part getPart() {
			return part;
		}

		public void setPart(Part part) {
			this.part = part;
		}

		public Location getLocation() {
			return location;
		}

		public void setLocation(Location location) {
			this.location = location;
		}

	public PartLocation() {
	}

	public PartLocationPK getId() {
		return this.id;
	}

	public void setId(PartLocationPK id) {
		this.id = id;
	}



/*	public String getRan() {
		return this.ran;
	}

	public void setRan(String ran) {
		this.ran = ran;
	}*/

	

}