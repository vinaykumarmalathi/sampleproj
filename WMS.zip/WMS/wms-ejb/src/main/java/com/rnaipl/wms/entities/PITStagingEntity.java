package com.rnaipl.wms.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/*AJ00482484 -- PIT Automation -- START */

/**
 * The persistent class for the PARTINOUT_STAGING database table.
 * 
 */
@Entity
@Table(name="PIT_STAGING")
@NamedQuery(name="PITStagingEntity.findAll", query="SELECT pit FROM PITStagingEntity pit")
public class PITStagingEntity implements Serializable{

	private static final long serialVersionUID = 1L;
	
	public PITStagingEntity(){
		
	}
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="PIT_PK")
	private long pitPk;
	
	@Column(name="TRANSACTION_ID")
	private String transactionId;
	
	@Column(name="PART_NO")
	private String partNumber;
	
	@Column(name="LOCATION")
	private String location;
	
	@Column(name="RAN")
	private String ran;
	
	@Column(name="SNP")
	private int snp;
	
	@Column(name="NO_OF_BOXES")
	private int numberOfBoxes;
	
	@Column(name="OPEN_QUANTITY")
	private int openQuantity;
	
	@Column(name="TOTAL_QUANTITY")
	private int totalQuantity;
	
	@Column(name="DATE_TIME")
	private Timestamp dateTime;
	
	@Column(name="DEVICE_ID")
	private String deviceId;
	
	@Column(name="TRANSACTION_TYPE")
	private String transactionType;
	
	@Column(name="ISUPDATED")
	private String isUpdated;
	
	@Column(name="COMMENTS_FLAG")
	private int commentsFlag;
	
	@Column(name="COMMENTS")
	private String comments;

	public long getPitPk() {
		return pitPk;
	}
	public void setPitPk(long pitPk) {
		this.pitPk = pitPk;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getRan() {
		return ran;
	}
	public void setRan(String ran) {
		this.ran = ran;
	}
	public int getSnp() {
		return snp;
	}
	public void setSnp(int snp) {
		this.snp = snp;
	}
	public int getNumberOfBoxes() {
		return numberOfBoxes;
	}
	public void setNumberOfBoxes(int numberOfBoxes) {
		this.numberOfBoxes = numberOfBoxes;
	}
	public int getOpenQuantity() {
		return openQuantity;
	}
	public void setOpenQuantity(int openQuantity) {
		this.openQuantity = openQuantity;
	}
	public int getTotalQuantity() {
		return totalQuantity;
	}
	public void setTotalQuantity(int totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
	public Timestamp getDateTime() {
		return dateTime;
	}
	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getIsUpdated() {
		return isUpdated;
	}
	public void setIsUpdated(String isUpdated) {
		this.isUpdated = isUpdated;
	}
	public int getCommentsFlag() {
		return commentsFlag;
	}
	public void setCommentsFlag(int commentsFlag) {
		this.commentsFlag = commentsFlag;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
}

/*AJ00482484 -- PIT Automation -- START */
