package com.rnaipl.wms.bean;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.PlantDTO;
import com.rnaipl.wms.dto.SectionDTO;
import com.rnaipl.wms.entities.Section;
import com.rnaipl.wms.util.WMSBeanConstants;

/**
 * 
 * @author TechM
 * 
 */
@Stateless
@LocalBean
public class SectionBean implements com.rnaipl.wms.bean.Section {

	private static final Logger LOGGER = Logger.getLogger(SectionBean.class);

    @PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
    private EntityManager entityManager;

    /**
     * This method fetch the value from the database
     * 
     * @return - list of PlantDTO
     */
    private List<PlantDTO> getTempPlantsList() {
        // TODO Auto-generated method stub
        List<PlantDTO> plants = new ArrayList<PlantDTO>();

        PlantDTO plant = new PlantDTO();
        plant.setPlantId("plant001");
        plant.setPlantName("Body Plant");
        plants.add(plant);

        plant = new PlantDTO();
        plant.setPlantId("plant002");
        plant.setPlantName("T&D Plant");
        plants.add(plant);

        plant = new PlantDTO();
        plant.setPlantId("plant003");
        plant.setPlantName("Metal Plant");
        plants.add(plant);

        plant = new PlantDTO();
        plant.setPlantId("plant004");
        plant.setPlantName("Container Plant");
        plants.add(plant);

        plant = new PlantDTO();
        plant.setPlantId("plant005");
        plant.setPlantName("Warehouse Plant");
        plants.add(plant);

        return plants;
    }

    public List<SectionDTO> getAllSections() {
        LOGGER.debug("getAllSections() method starts ");
        List<SectionDTO> sectionDTOs = new ArrayList<SectionDTO>();
        Query query = entityManager.createQuery("select p from Section p ORDER BY p.sectionName");
        List<Section> sections = query.getResultList();
        for (Section section : sections) {
            SectionDTO sectionDTO = new SectionDTO();
            sectionDTO.setSectionId(section.getSectionId());
            sectionDTO.setSectionName(section.getSectionName());
            sectionDTOs.add(sectionDTO);
        }
        LOGGER.debug("getAllPlants() method Ends ");
        return sectionDTOs;
    }

}
