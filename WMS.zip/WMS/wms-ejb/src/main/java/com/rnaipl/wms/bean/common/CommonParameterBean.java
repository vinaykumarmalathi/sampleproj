package com.rnaipl.wms.bean.common;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;

import com.rnaipl.wms.util.WMSBeanConstants;

@Stateless
@LocalBean
public class CommonParameterBean implements CommonParameter {
	
	 private static final Logger LOGGER = Logger.getLogger(CommonParameterBean.class);

	    @PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	    private EntityManager entityManager;

		public String getParamValueById(String id) {
			
			LOGGER.debug("**Inside Common Parameter"+ id);
			if(id==null){
				return null;
			}
			com.rnaipl.wms.entities.CommonParameter commonParamter=entityManager.find(com.rnaipl.wms.entities.CommonParameter.class, id);
			return commonParamter.getValue();
		}


	
	
	
}
	
