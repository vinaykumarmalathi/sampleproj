package com.rnaipl.wms.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/*AJ00482484 -- PIT Automation -- START */

/**
 * The persistent class for the PARTINOUT_STAGING database table.
 * 
 */
@Entity
@Table(name = "TBL_LNFD_STK_CORRECTION_TEST")
@NamedQuery(name = "StockCorrectionAddEntity.findAll", query = "SELECT l FROM StockCorrectionAddEntity l")
public class StockCorrectionAddEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	public StockCorrectionAddEntity() {

	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PART_PK")
	private long partPk;

	@Column(name = "LNFD_ID")
	private long lineFeedId;

	@Column(name = "PART_NO")
	private String partNo;

	@Column(name = "LINE_STK")
	private String lineStock;

	@Column(name = "CORRECTION_STK")
	private String correctionStock;

	@Column(name = "SHIFT")
	private String shift;

	@Column(name = "CONSIDER_FLG")
	private String considerFlag;

	@Column(name = "REMARKS")
	private String remarks;

	public long getPartPk() {
		return partPk;
	}

	public void setPartPk(long partPk) {
		this.partPk = partPk;
	}

	public long getLineFeedId() {
		return lineFeedId;
	}

	public void setLineFeedId(long lineFeedId) {
		this.lineFeedId = lineFeedId;
	}

	public String getPartNo() {
		return partNo;
	}

	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}

	public String getLineStock() {
		return lineStock;
	}

	public void setLineStock(String lineStock) {
		this.lineStock = lineStock;
	}

	public String getCorrectionStock() {
		return correctionStock;
	}

	public void setCorrectionStock(String correctionStock) {
		this.correctionStock = correctionStock;
	}

	public String getShift() {
		return shift;
	}

	public void setShift(String shift) {
		this.shift = shift;
	}

	public String getConsiderFlag() {
		return considerFlag;
	}

	public void setConsiderFlag(String considerFlag) {
		this.considerFlag = considerFlag;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}

/* AJ00482484 -- PIT Automation -- START */
