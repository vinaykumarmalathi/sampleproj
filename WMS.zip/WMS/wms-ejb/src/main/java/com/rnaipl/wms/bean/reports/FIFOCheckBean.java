package com.rnaipl.wms.bean.reports;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.PartsInOutAuditSearchDTO;
import com.rnaipl.wms.dto.reports.FIFOCheckDTO;
import com.rnaipl.wms.dto.reports.FIFOCheckInputDTO;
import com.rnaipl.wms.entities.FifoCheck;
import com.rnaipl.wms.entities.PartinOutStagingAudit;
import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSBeanUtil;

@Stateless
@LocalBean
public class FIFOCheckBean implements FIFOCheck {

	private static final Logger LOGGER = Logger
			.getLogger(FIFOCheckBean.class);

	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;
	
	//List<FIFOCheckDTO> getFIFONotFollowed(FIFOCheckInputDTO fifoCheckInputDTO)
	public List<FIFOCheckDTO> getFIFONotFollowed(FIFOCheckInputDTO fifoCheckInputDTO) throws Exception { 
		
		
		List<FIFOCheckDTO> fifoCheckDTOs = new ArrayList<FIFOCheckDTO>();

		StringBuffer queryStringBuf = new StringBuffer();
		queryStringBuf.append("select p from FifoCheck p");
		queryStringBuf.append(" WHERE 1=1 ");
		queryStringBuf.append(WMSBeanUtil.createQueryParamForFIFOCheck(fifoCheckInputDTO));
		queryStringBuf.append(" ORDER BY p.partInOutTime DESC");

		Query query = entityManager
				.createQuery(queryStringBuf.toString());
		
		if (null != fifoCheckInputDTO.getPartNumber() && !fifoCheckInputDTO.getPartNumber().equalsIgnoreCase("")) {
			query.setParameter("partNos", fifoCheckInputDTO.getPartList());
        }
		if (null != fifoCheckInputDTO.getLocation() && !fifoCheckInputDTO.getLocation().equalsIgnoreCase("")) {
			query.setParameter("locationNos", fifoCheckInputDTO.getLocationList());
        }
		if (null != fifoCheckInputDTO.getRan() && !fifoCheckInputDTO.getRan().equalsIgnoreCase("")) {
			query.setParameter("rans", fifoCheckInputDTO.getRanList());
        }
		LOGGER.debug("FIFO Data Query " + queryStringBuf.toString());
		
		if(!fifoCheckInputDTO.isDownload()){
			query.setFirstResult(fifoCheckInputDTO.getStartIndex());
			query.setMaxResults(fifoCheckInputDTO.getEndIndex());
		}
		
		List<FifoCheck> queryDatas = query.getResultList();
		LOGGER.debug("FIFO Data size " + queryDatas.size());

		if (null != queryDatas && queryDatas.size() > 0) {
			for (FifoCheck values : queryDatas) {
							
				FIFOCheckDTO fifoCheckDTO = setPartsInOutData(values);
				fifoCheckDTOs.add(fifoCheckDTO);
			}

		}

		LOGGER.debug("*** getPartsAuditSearch -- Location* EXIT");
		return fifoCheckDTOs;

	}

	/*public int getPartInOutAuditSearchCount(PartsInOutAuditSearchDTO partsInOutAudit){
		StringBuffer queryStringBuf = new StringBuffer();
		queryStringBuf.append("select count(p) from PartinOutStagingAudit p");
		queryStringBuf.append(" WHERE 1=1");
		queryStringBuf.append(WMSBeanUtil.createQueryParamForAuditSearch(partsInOutAudit));
		
		LOGGER.debug("Query Count :  " + queryStringBuf.toString());
        Query query1 = entityManager.createQuery(queryStringBuf.toString());
        
        if (null != partsInOutAudit.getPartNumber() && !partsInOutAudit.getPartNumber().equalsIgnoreCase("")) {
        	query1.setParameter("partNos", partsInOutAudit.getPartList());
        }
        if (null != partsInOutAudit.getLocation() && !partsInOutAudit.getLocation().equalsIgnoreCase("")) {
        	query1.setParameter("locationNos", partsInOutAudit.getLocationList());
        }
    	if (null != partsInOutAudit.getRan() && !partsInOutAudit.getRan().equalsIgnoreCase("")) {
    		query1.setParameter("rans", partsInOutAudit.getRanList());
        }
        Long noOfRecords = (Long) query1.getSingleResult();
        LOGGER.debug("recordCount :  " + noOfRecords);

        return noOfRecords.intValue();
		
	}*/
	
   
 	private FIFOCheckDTO setPartsInOutData(FifoCheck fifoCheck) throws Exception{

		FIFOCheckDTO fifoCheckDTO = new FIFOCheckDTO();
		String shiftName ="";
		int dateDifference=0;
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
		try {
			fifoCheckDTO.setPartNumber((null == fifoCheck.getPartNo() ? ""
					: fifoCheck.getPartNo().toString()));
			fifoCheckDTO.setLocation((null == fifoCheck.getLocation() ? ""
					: fifoCheck.getLocation().toString()));
			/*fifoCheckDTO.setTransactionType((null == fifoCheck.getTransactionType() ? ""
					: fifoCheck.getTransactionType().toString()));*/
			fifoCheckDTO.setCount(fifoCheck.getCount());
			//fifoCheckDTO.setRan((null == fifoCheck.getRan() ? "" : fifoCheck.getRan().toString()));
			fifoCheckDTO.setPickedRan((null == fifoCheck.getPickedRan() ? "" : fifoCheck.getPickedRan()));
			fifoCheckDTO.setCorrectRan((null == fifoCheck.getCorrectRan() ? "" : fifoCheck.getCorrectRan()));
			fifoCheckDTO.setUserId((null == fifoCheck.getUserId() ? ""
					: fifoCheck.getUserId().toString()));
			fifoCheckDTO.setDeviceId((null == fifoCheck.getDeviceId() ? ""
					: fifoCheck.getDeviceId().toString()));

			fifoCheckDTO.setPartInOutTime(null == fifoCheck.getPartInOutTime() ? null
					: fifoCheck.getPartInOutTime());

			/*fifoCheckDTO.setReasonCode((null == fifoCheck.getReasonCode() ? ""
					: fifoCheck.getReasonCode().getReasonCode()));*/
			fifoCheckDTO.setComments((null == fifoCheck.getComments() ? ""
					: fifoCheck.getComments().toString()));
			/*fifoCheckDTO.setReason((null == fifoCheck.getReasonCode() ? ""
					: fifoCheck.getReasonCode().getReason().toString()));*/
			
			shiftName = WMSBeanUtil.getShift(fifoCheck.getScanTime().getHours(),
					fifoCheck.getScanTime().getMinutes(),fifoCheck.getScanTime().getSeconds());			
			fifoCheckDTO.setShift(shiftName);
			
			fifoCheckDTO.setScanTime(null == fifoCheck.getScanTime() ? null
					: fifoCheck.getScanTime());
			fifoCheckDTO.setSnp(fifoCheck.getSnp());
			fifoCheckDTO.setNoOfBoxes(fifoCheck.getNoOfBoxes());
			fifoCheckDTO.setPickedRanInTime(fifoCheck.getPickedRanIntime());
			fifoCheckDTO.setCorrectRanInTime(fifoCheck.getCorrectRanIntime());
			dateDifference=getDaysBetween(fifoCheckDTO.getPickedRanInTime(),fifoCheckDTO.getCorrectRanInTime());	
			fifoCheckDTO.setRanDateDifference(dateDifference);
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error(e);
			throw e;
		}
		return fifoCheckDTO;

	}
	
 	 public static int getDaysBetween(Date date1, Date date2)
 	  {
 	    return (int) TimeUnit.MILLISECONDS.toDays(date1.getTime()- date2.getTime());
 	  }
	
}
