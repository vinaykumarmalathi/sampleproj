package com.rnaipl.wms.bean.ran;

import java.util.List;

import com.rnaipl.wms.dto.ran.RanUploadDTO;
import com.rnaipl.wms.dto.ran.RanUploadErrorDTO;

public interface RanUpload {
	public List<RanUploadDTO> getRanUploadData();
	//public void triggerJob(String fileName);
	public List<Integer> isRanUploadInProgress();
	public List<RanUploadErrorDTO> getRanDownloadDetails(int runId);
	public void triggerJob(String uploadFileName);
	public String getUploadDestinationPath();
	//parametrized ran upload path
	public String getParamUploadDestinationPath(String param);
}
