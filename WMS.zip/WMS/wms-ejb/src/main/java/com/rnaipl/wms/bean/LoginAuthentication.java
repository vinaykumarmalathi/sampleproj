package com.rnaipl.wms.bean;

import java.util.List;

import javax.security.auth.login.FailedLoginException;


public interface LoginAuthentication  {
	
	/**
	 * It retrieves all Section details which are available in database.
	 * @return 
	 * 
	 * @return list - List of UserDTO objects
	 * @throws FailedLoginException 
	 */

	public abstract int loginuser(String username, String password) ;

}
