package com.rnaipl.wms.util;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.enterprise.context.ApplicationScoped;

import org.apache.log4j.Logger;





import com.rnaipl.wms.dto.PartDTO;
import com.rnaipl.wms.dto.PartLocationCorrectionDTO;
import com.rnaipl.wms.dto.PartsInOutAuditErrorDTO;
import com.rnaipl.wms.dto.PartsInOutAuditSearchDTO;
import com.rnaipl.wms.dto.ran.DuplicateRANInputDTO;
import com.rnaipl.wms.dto.reports.FIFOCheckInputDTO;
import com.rnaipl.wms.dto.reports.FIFOSuggestionOverrideDTO;
import com.rnaipl.wms.entities.Part;
import com.rnaipl.wms.entities.PartinoutStaging;
/**
 * Util Class 
 * 
 * @CreatedBy TechM
 * @CreatedOn 17-may-2016 04:05:02 pm
 */
@ApplicationScoped
public class WMSBeanUtil {
	
	private static final Logger LOGGER = Logger
			.getLogger(WMSBeanUtil.class);

	/**
	 * @param partsInOutInfo
	 * @return
	 */
	public static PartinoutStaging conversionFromPartLocCorrDTOToBean(PartLocationCorrectionDTO PartLocCorrDTO, String transactionType){
		PartinoutStaging partInOutBean = new PartinoutStaging();
		partInOutBean.setPartNo(PartLocCorrDTO.getPartNo());
		
		partInOutBean.setPartInOutTime(new Timestamp(System.currentTimeMillis()));
		if(transactionType.equalsIgnoreCase(WMSBeanConstants.TRANSACTION_TYPE_OUT)){
			partInOutBean.setLocation(PartLocCorrDTO.getSourceLocation());
			
		}
		if(transactionType.equalsIgnoreCase(WMSBeanConstants.TRANSACTION_TYPE_IN)){
			partInOutBean.setLocation(PartLocCorrDTO.getCorrectedLocation());			
		}
		if(transactionType.equalsIgnoreCase(WMSBeanConstants.TRANSACTION_TYPE_MOVE)){
			partInOutBean.setLocation(PartLocCorrDTO.getSourceLocation());
			partInOutBean.setLocationDestination(PartLocCorrDTO.getCorrectedLocation());
		}
		
		
		partInOutBean.setRan(PartLocCorrDTO.getRan());
		partInOutBean.setCount((int)PartLocCorrDTO.getCorrectQty());
		partInOutBean.setTransactionType(transactionType);
		partInOutBean.setComments(PartLocCorrDTO.getComments());
		partInOutBean.setUserId(PartLocCorrDTO.getUserId());
		partInOutBean.setScanTime(partInOutBean.getPartInOutTime());
		partInOutBean.setSnp(0);
		
		return partInOutBean;
	}
	
	public static PartDTO getPartMasterData(Part part){
		PartDTO partDTO = new PartDTO();
    	List<String> partLocations = new ArrayList<String>();
    	partDTO.setCategory(part.getCategory());
    	partDTO.setCreatedBy(part.getCreatedBy());
    	partDTO.setCreatedOn(part.getCreatedOn());
    	partDTO.setDepoCode(part.getDepoCode());
    	partDTO.setDtlFlag(part.getDtlFlag());
    	partDTO.setLeadTime(part.getLeadTime());
    	//one-many relationship for parts & location implemented logic will be changed accordingly <TODO>
    	for(com.rnaipl.wms.entities.Location location : part.getLocations()) {
    		partLocations.add(location.getLocationId());
    	}
    	partDTO.setLocations(partLocations);
    	partDTO.setPartName(part.getPartName());
    	partDTO.setPartNumber(part.getPartNo());
    	partDTO.setPartType(part.getPartType());
    	partDTO.setRePackingFlag(part.getRepackingFlag());
    	partDTO.setSafetyStock(part.getSafetyStock());
    	partDTO.setSafetyStock(part.getSnp());
    	partDTO.setSupplierCode(part.getSupplierCode());
    	partDTO.setUpdatedBy(part.getUpdatedBy());
    	partDTO.setUpdatedOn(part.getUpdatedOn());
    	partDTO.setLeadTime(part.getLeadTime());
		return partDTO;
	}
	
	public static Map<String,Date> getShiftTime(String shift, Date fromDate, Date toDate) {
		// TODO Auto-generated method stub
		Map<String,Date> shiftTime = new HashMap<String, Date>();
		Calendar fromCal = Calendar.getInstance();
		Calendar toCal = Calendar.getInstance();
		fromCal.setTime(trim(fromDate));
		toCal.setTime(trim(toDate));
		if(shift == null || shift.isEmpty()) {
			fromCal.set(Calendar.HOUR_OF_DAY,07);
			fromCal.set(Calendar.MINUTE, 00);
			fromCal.set(Calendar.SECOND, 01);
			
			toCal.set(Calendar.DAY_OF_MONTH,toCal.get(Calendar.DAY_OF_MONTH )+ 1);
			toCal.set(Calendar.HOUR_OF_DAY,07);
			toCal.set(Calendar.MINUTE, 00);
			toCal.set(Calendar.SECOND, 01);
			
		} else if(shift.equalsIgnoreCase("A")){
			fromCal.set(Calendar.HOUR_OF_DAY,07);
			fromCal.set(Calendar.MINUTE, 00);
			fromCal.set(Calendar.SECOND, 01);
			
			toCal.set(Calendar.HOUR_OF_DAY,15);
			toCal.set(Calendar.MINUTE, 30);
			toCal.set(Calendar.SECOND, 01);
			
		} else if (shift.equalsIgnoreCase("B")) {
			fromCal.set(Calendar.HOUR_OF_DAY,15);
			fromCal.set(Calendar.MINUTE, 30);
			fromCal.set(Calendar.SECOND,01);
			
			toCal.set(Calendar.DAY_OF_MONTH,toCal.get(Calendar.DAY_OF_MONTH )+ 1);
			toCal.set(Calendar.HOUR_OF_DAY,00);
			toCal.set(Calendar.MINUTE, 00);
			toCal.set(Calendar.SECOND, 01);
			
		} else if (shift.equalsIgnoreCase("C")) {
			fromCal.set(Calendar.DAY_OF_MONTH,fromCal.get(Calendar.DAY_OF_MONTH )+ 1);
			fromCal.set(Calendar.HOUR_OF_DAY,00);
			fromCal.set(Calendar.MINUTE, 00);
			fromCal.set(Calendar.SECOND, 01);
			
			toCal.set(Calendar.DAY_OF_MONTH,toCal.get(Calendar.DAY_OF_MONTH )+ 1);
			toCal.set(Calendar.HOUR_OF_DAY,07);
			toCal.set(Calendar.MINUTE, 00);
			toCal.set(Calendar.SECOND, 01);
		} 
		LOGGER.debug( "From Time -- " + fromCal.getTime() + "-ToTime -"+toCal.getTime() + "shift -->" + shift);
		shiftTime.put("fromDate", fromCal.getTime());
		shiftTime.put("toDate", toCal.getTime());
		return shiftTime;
	}
	

	public static String getShift(int hours, int minutes, int seconds) {
		
		
		String shiftName="";
		
		Calendar transactionTime = Calendar.getInstance();		
		Calendar shiftAStart = Calendar.getInstance();
		Calendar shiftAEnd = Calendar.getInstance();
		Calendar shiftBStart = Calendar.getInstance();
		Calendar shiftBEnd = Calendar.getInstance();			
		Calendar shiftCStart = Calendar.getInstance();
		Calendar shiftCEnd = Calendar.getInstance();
		
		
		
		transactionTime.set(Calendar.HOUR_OF_DAY,hours);
		transactionTime.set(Calendar.MINUTE, minutes);
		transactionTime.set(Calendar.SECOND, seconds);

		
		shiftAStart.set(Calendar.HOUR_OF_DAY,07);
		shiftAStart.set(Calendar.MINUTE, 00);
		shiftAStart.set(Calendar.SECOND, 01);
		shiftAEnd.set(Calendar.HOUR_OF_DAY,15);   //07:01 to 15:30   
		shiftAEnd.set(Calendar.MINUTE, 30);       //15:31 to 00:00
		shiftAEnd.set(Calendar.SECOND, 01);
		
		
		shiftBStart.set(Calendar.HOUR_OF_DAY,15);
		shiftBStart.set(Calendar.MINUTE, 30);
		shiftBStart.set(Calendar.SECOND,01);	
		shiftBEnd.set(Calendar.DAY_OF_MONTH,shiftBEnd.get(Calendar.DAY_OF_MONTH )+ 1);
		shiftBEnd.set(Calendar.HOUR_OF_DAY,00);
		shiftBEnd.set(Calendar.MINUTE, 00);
		shiftBEnd.set(Calendar.SECOND, 01);
		
		shiftCStart.set(Calendar.DAY_OF_MONTH,shiftCStart.get(Calendar.DAY_OF_MONTH )+ 1);
		shiftCStart.set(Calendar.HOUR_OF_DAY,00);
		shiftCStart.set(Calendar.MINUTE, 00);
		shiftCStart.set(Calendar.SECOND, 01);
		
		shiftCEnd.set(Calendar.DAY_OF_MONTH,shiftCEnd.get(Calendar.DAY_OF_MONTH )+ 1);
		shiftCEnd.set(Calendar.HOUR_OF_DAY,07);
		shiftCEnd.set(Calendar.MINUTE, 00);
		shiftCEnd.set(Calendar.SECOND, 01);
		

		
		if(transactionTime.compareTo(shiftAStart)<0)
		{
			transactionTime.set(Calendar.DAY_OF_MONTH,transactionTime.get(Calendar.DAY_OF_MONTH )+ 1);
		}
		
		
		
		if(transactionTime.compareTo(shiftAStart)>=0 && transactionTime.compareTo(shiftAEnd)<0){
			shiftName= "A";
		}
		else if(transactionTime.compareTo(shiftBStart)>=0 && transactionTime.compareTo(shiftBEnd)<0){
			shiftName= "B";
		}
		else if(transactionTime.compareTo(shiftCStart)>=0 && transactionTime.compareTo(shiftCEnd)<0){
			shiftName= "C";
		}
		
	
	
		return shiftName;
}

	
	
	public static StringBuffer createQueryParamForAuditSearch(PartsInOutAuditSearchDTO partsInOutAudit) {
		
		StringBuffer queryStringBuf = new StringBuffer();
		if (null != partsInOutAudit.getLocation()
				&& !partsInOutAudit.getLocation().equals("")) {
			queryStringBuf.append(" AND (p.location IN (:locationNos) or p.locationDestination IN (:locationNos))");
		}
		if (null != partsInOutAudit.getPartNumber()
				&& !partsInOutAudit.getPartNumber().equals("")) {
			queryStringBuf.append(" AND p.partNo IN (:partNos)");
		}
		if (null != partsInOutAudit.getRan()
				&& !partsInOutAudit.getRan().equals("")) {
			queryStringBuf.append(" AND p.ran IN (:rans)");
		}
		if (null != partsInOutAudit.getTransactionType()
				&& !partsInOutAudit.getTransactionType().equals("")) {
			queryStringBuf.append(" AND p.transactionType = '"
					+ partsInOutAudit.getTransactionType() + "'");
		}
		if (null != partsInOutAudit.getPlant()
				&& !partsInOutAudit.getPlant().equals("")) {
			queryStringBuf.append(" AND SUBSTRING(p.location,1,1) = '"
					+ partsInOutAudit.getPlant() + "'");
		}
		if (null != partsInOutAudit.getShop()
				&& !partsInOutAudit.getShop().equals("")) {
			queryStringBuf.append(" AND SUBSTRING(p.location,2,1) = '"
					+ partsInOutAudit.getShop() + "'");
		}
		if (null != partsInOutAudit.getLine()
				&& !partsInOutAudit.getLine().equals("")) {
			queryStringBuf.append(" AND SUBSTRING(p.location,3,1) = '"
					+ partsInOutAudit.getLine() + "'");
		}
		if (null != partsInOutAudit.getSection()
				&& !partsInOutAudit.getSection().equals("")) {
			queryStringBuf.append(" AND SUBSTRING(p.location,4,1) = '"
					+ partsInOutAudit.getSection() + "'");
		}
		if (null != partsInOutAudit.getDeviceId()
				&& !partsInOutAudit.getDeviceId().equals("")) {
			queryStringBuf.append(" AND p.deviceId like '%"
					+ partsInOutAudit.getDeviceId() + "%'");
		}

		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		if (partsInOutAudit.getFromDate() != null
				|| partsInOutAudit.getToDate() != null) {
			Map<String,Date> shiftTimes  = WMSBeanUtil.getShiftTime(partsInOutAudit.getShift(),partsInOutAudit.getFromDate(),partsInOutAudit.getToDate());
		
			/*partsInOutAudit.setFromDate(shiftTimes.get("fromDate"));  
			partsInOutAudit.setToDate(shiftTimes.get("toDate")); 
			LOGGER.debug("** From Date -> "+ dateFormatter.format(partsInOutAudit.getFromDate()));
			LOGGER.debug("** To Date -> "+ dateFormatter.format(partsInOutAudit.getToDate()));
			queryStringBuf.append(" and p.scanTime >= '"+ dateFormatter.format(partsInOutAudit.getFromDate()) + "'");
			queryStringBuf.append(" and p.scanTime < '"+ dateFormatter.format(partsInOutAudit.getToDate()) + "'");*/
			
			queryStringBuf.append(" and p.scanTime >= '"+ dateFormatter.format(shiftTimes.get("fromDate")) + "'");
			queryStringBuf.append(" and p.scanTime < '"+ dateFormatter.format(shiftTimes.get("toDate")) + "'");
			

		}
		return queryStringBuf;
	}
	
	public static Date trim(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.MILLISECOND, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.HOUR, 0);

        return calendar.getTime();
    }
	
	public static StringBuffer createQueryParamForPartInOutError(PartsInOutAuditErrorDTO partsInOutAuditError) {
		
		StringBuffer queryStringBuf = new StringBuffer();
		if (null != partsInOutAuditError.getLocation()
				&& !partsInOutAuditError.getLocation().equals("")) {
			queryStringBuf.append(" AND ( p.location IN (:locationNos) or  p.locationDestination IN (:locationNos) )");
		}
		if (null != partsInOutAuditError.getPartNumber()
				&& !partsInOutAuditError.getPartNumber().equals("")) {
			queryStringBuf.append(" AND p.partNo IN (:partNos)");
		}
		if (null != partsInOutAuditError.getRan()
				&& !partsInOutAuditError.getRan().equals("")) {
			queryStringBuf.append(" AND p.ran IN (:rans)");
		}
		if (null != partsInOutAuditError.getTransactionType()
				&& !partsInOutAuditError.getTransactionType().equals("")) {
			queryStringBuf.append(" AND p.transactionType = '"
					+ partsInOutAuditError.getTransactionType() + "'");
		}
		if (null != String.valueOf(partsInOutAuditError.getErrorCode())
				&& partsInOutAuditError.getErrorCode() != 0) {
			queryStringBuf.append(" AND p.errorCode = '"
					+ partsInOutAuditError.getErrorCode() + "'");
		}
	/*	if (null != partsInOutAuditError.getRan() && !partsInOutAuditError.getRan().equals("")) {
			queryStringBuf.append(" AND p.ran = '"
					+ partsInOutAuditError.getRan() + "'");
		}*/
		if (null != partsInOutAuditError.getPlant()
				&& !partsInOutAuditError.getPlant().equals("")) {
			queryStringBuf.append(" AND SUBSTRING(p.location,1,1) = '"
					+ partsInOutAuditError.getPlant() + "'");
		}
		if (null != partsInOutAuditError.getShop()
				&& !partsInOutAuditError.getShop().equals("")) {
			queryStringBuf.append(" AND SUBSTRING(p.location,2,1) = '"
					+ partsInOutAuditError.getShop() + "'");
		}
		if (null != partsInOutAuditError.getLine()
				&& !partsInOutAuditError.getLine().equals("")) {
			queryStringBuf.append(" AND SUBSTRING(p.location,3,1) = '"
					+ partsInOutAuditError.getLine() + "'");
		}
		if (null != partsInOutAuditError.getSection()
				&& !partsInOutAuditError.getSection().equals("")) {
			queryStringBuf.append(" AND SUBSTRING(p.location,4,1) = '"
					+ partsInOutAuditError.getSection() + "'");
		}
		
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		if (partsInOutAuditError.getFromDate() != null
				|| partsInOutAuditError.getToDate() != null) {
			Map<String,Date> shiftTimes  = WMSBeanUtil.getShiftTime(partsInOutAuditError.getShift(),partsInOutAuditError.getFromDate(),partsInOutAuditError.getToDate());
		
			partsInOutAuditError.setFromDate(shiftTimes.get("fromDate"));  
			partsInOutAuditError.setToDate(shiftTimes.get("toDate")); 
			LOGGER.debug("** dateFormatter.format(cal) "
					+ dateFormatter.format(partsInOutAuditError.getFromDate()));
			
			queryStringBuf.append(" and p.partInOutTime >= '"+ dateFormatter.format(partsInOutAuditError.getFromDate()) + "'");
			queryStringBuf.append(" and p.partInOutTime < '"+ dateFormatter.format(partsInOutAuditError.getToDate()) + "'");
			
			/*
			queryStringBuf
					.append(" and p.partInOutTime BETWEEN '"
							+ dateFormatter.format(partsInOutAuditError
									.getFromDate()) + "'");
			queryStringBuf.append(" AND '"
					+ dateFormatter.format(partsInOutAuditError.getToDate()) + "'");*/

		}
		return queryStringBuf;
	}
	
	public static StringBuffer createQueryParamForAgedAudit(PartsInOutAuditSearchDTO partsInOutAudit) {
		
		StringBuffer queryStringBuf = new StringBuffer();
		if (null != partsInOutAudit.getLocation()
				&& !partsInOutAudit.getLocation().equals("")) {
			queryStringBuf.append(" AND  P.LOCATION IN (:locationNos)");
		}
		if (null != partsInOutAudit.getPartNumber()
				&& !partsInOutAudit.getPartNumber().equals("")) {
			queryStringBuf.append(" AND  P.PART_NO IN (:partNos)");
		}
		if (null != partsInOutAudit.getRan()
				&& !partsInOutAudit.getRan().equals("")) {
			queryStringBuf.append(" AND P.RAN IN (:rans)");
		}
		/*if (null != partsInOutAudit.getTransactionType()
				&& !partsInOutAudit.getTransactionType().equals("")) {
			queryStringBuf.append(" AND p.transactionType = '"
					+ partsInOutAudit.getTransactionType() + "'");
		}*/
		if (null != partsInOutAudit.getPlant()
				&& !partsInOutAudit.getPlant().equals("")) {
			queryStringBuf.append(" AND SUBSTRING(P.LOCATION, 1, 1) = '"
					+ partsInOutAudit.getPlant() + "'");
		}
		if (null != partsInOutAudit.getShop()
				&& !partsInOutAudit.getShop().equals("")) {
			queryStringBuf.append(" AND SUBSTRING(P.LOCATION, 2, 1) = '"
					+ partsInOutAudit.getShop() + "'");
		}
		if (null != partsInOutAudit.getLine()
				&& !partsInOutAudit.getLine().equals("")) {
			queryStringBuf.append(" AND SUBSTRING(P.LOCATION, 3, 1) = '"
					+ partsInOutAudit.getLine() + "'");
		}
		if (null != partsInOutAudit.getSection()
				&& !partsInOutAudit.getSection().equals("")) {
			queryStringBuf.append(" AND SUBSTRING(P.LOCATION, 4, 1) = '"
					+ partsInOutAudit.getSection() + "'");
		}
		if (null != partsInOutAudit.getDeviceId()
				&& !partsInOutAudit.getDeviceId().equals("")) {
			queryStringBuf.append(" AND P.DEVICE_ID like '%"
					+ partsInOutAudit.getDeviceId() + "%'");
		}

		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		if (partsInOutAudit.getFromDate() != null
				|| partsInOutAudit.getToDate() != null) {
			Map<String,Date> shiftTimes  = WMSBeanUtil.getShiftTime(partsInOutAudit.getShift(),partsInOutAudit.getFromDate(),partsInOutAudit.getToDate());
		
			partsInOutAudit.setFromDate(shiftTimes.get("fromDate"));  
			partsInOutAudit.setToDate(shiftTimes.get("toDate")); 
			LOGGER.debug("** From Date -> "+ dateFormatter.format(partsInOutAudit.getFromDate()));
			LOGGER.debug("** To Date -> "+ dateFormatter.format(partsInOutAudit.getToDate()));
			queryStringBuf.append(" and P.SCAN_TIME >= '"+ dateFormatter.format(partsInOutAudit.getFromDate()) + "'");
			queryStringBuf.append(" and P.SCAN_TIME < '"+ dateFormatter.format(partsInOutAudit.getToDate()) + "'");
			

		}
		return queryStringBuf;
	}
	
	public static Date  stringtoDateConversion(String date,String format) 
	{
		Date convertedDate=null;
		if(date==null || format==null)
				return null;
		try{
		DateFormat formatter = new SimpleDateFormat(format);
		convertedDate= formatter.parse(date);
		}
		catch(Exception e)
		{
			LOGGER.error("*Error in Date conversion" ,e);
		}
		return convertedDate;
		
	}
public static StringBuffer createQueryParamForDuplicateRANSearch(DuplicateRANInputDTO duplicateRANInputDTO) {
		
		StringBuffer queryStringBuf = new StringBuffer();
		if (null != duplicateRANInputDTO.getLocation()
				&& !duplicateRANInputDTO.getLocation().equals("")) {
			queryStringBuf.append(" AND PA.LOCATION IN (:locationNos)");
		}
		if (null != duplicateRANInputDTO.getPartNumber()
				&& !duplicateRANInputDTO.getPartNumber().equals("")) {
			queryStringBuf.append(" AND PA.PART_NO IN (:partNos)");
		}
		if (null != duplicateRANInputDTO.getRan()
				&& !duplicateRANInputDTO.getRan().equals("")) {
			queryStringBuf.append(" AND PA.RAN IN (:rans)");
		}
		if (null != duplicateRANInputDTO.getTransactionType()
				&& !duplicateRANInputDTO.getTransactionType().equals("")) {
			queryStringBuf.append(" AND PA.TRANSACTION_TYPE = '"
					+ duplicateRANInputDTO.getTransactionType() + "'");
		}
		if (null != duplicateRANInputDTO.getPlant()
				&& !duplicateRANInputDTO.getPlant().equals("")) {
			queryStringBuf.append(" AND SUBSTRING(PA.location,1,1) = '"
					+ duplicateRANInputDTO.getPlant() + "'");
		}
		if (null != duplicateRANInputDTO.getShop()
				&& !duplicateRANInputDTO.getShop().equals("")) {
			queryStringBuf.append(" AND SUBSTRING(PA.location,2,1) = '"
					+ duplicateRANInputDTO.getShop() + "'");
		}
		if (null != duplicateRANInputDTO.getLine()
				&& !duplicateRANInputDTO.getLine().equals("")) {
			queryStringBuf.append(" AND SUBSTRING(PA.location,3,1) = '"
					+ duplicateRANInputDTO.getLine() + "'");
		}
		if (null != duplicateRANInputDTO.getSection()
				&& !duplicateRANInputDTO.getSection().equals("")) {
			queryStringBuf.append(" AND SUBSTRING(PA.location,4,1) = '"
					+ duplicateRANInputDTO.getSection() + "'");
		}
		if (null != duplicateRANInputDTO.getDeviceId()
				&& !duplicateRANInputDTO.getDeviceId().equals("")) {
			queryStringBuf.append(" AND PA.DEVICE_ID like '%"
					+ duplicateRANInputDTO.getDeviceId() + "%'");
		}

		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		if (duplicateRANInputDTO.getFromDate() != null
				|| duplicateRANInputDTO.getToDate() != null) {
			Map<String,Date> shiftTimes  = WMSBeanUtil.getShiftTime(duplicateRANInputDTO.getShift(),duplicateRANInputDTO.getFromDate(),duplicateRANInputDTO.getToDate());
		
			duplicateRANInputDTO.setFromDate(shiftTimes.get("fromDate"));  
			duplicateRANInputDTO.setToDate(shiftTimes.get("toDate")); 
			LOGGER.debug("** From Date -> "+ dateFormatter.format(duplicateRANInputDTO.getFromDate()));
			LOGGER.debug("** To Date -> "+ dateFormatter.format(duplicateRANInputDTO.getToDate()));
			queryStringBuf.append(" and CONVERT(VARCHAR(20),PA.SCAN_TIME,20) >= '"+ dateFormatter.format(duplicateRANInputDTO.getFromDate()) + "'");
			queryStringBuf.append(" and CONVERT(VARCHAR(20),PA.SCAN_TIME,20) < '"+ dateFormatter.format(duplicateRANInputDTO.getToDate()) + "'");
			

		}
		return queryStringBuf;
	}
public static StringBuffer createQueryParamForFIFOCheck(FIFOCheckInputDTO fifCheckInputDTO) {
	
	StringBuffer queryStringBuf = new StringBuffer();
	if (null != fifCheckInputDTO.getLocation()
			&& !fifCheckInputDTO.getLocation().equals("")) {
		queryStringBuf.append(" AND p.location IN (:locationNos)");
	}
	if (null != fifCheckInputDTO.getPartNumber()
			&& !fifCheckInputDTO.getPartNumber().equals("")) {
		queryStringBuf.append(" AND p.partNo IN (:partNos)");
	}
	if (null != fifCheckInputDTO.getRan()
			&& !fifCheckInputDTO.getRan().equals("")) {
		queryStringBuf.append(" AND p.pickedRan IN (:rans)");
	}
	if (null != fifCheckInputDTO.getTransactionType()
			&& !fifCheckInputDTO.getTransactionType().equals("")) {
		queryStringBuf.append(" AND p.transactionType = '"
				+ fifCheckInputDTO.getTransactionType() + "'");
	}
	if (null != fifCheckInputDTO.getPlant()
			&& !fifCheckInputDTO.getPlant().equals("")) {
		queryStringBuf.append(" AND SUBSTRING(p.location,1,1) = '"
				+ fifCheckInputDTO.getPlant() + "'");
	}
	if (null != fifCheckInputDTO.getShop()
			&& !fifCheckInputDTO.getShop().equals("")) {
		queryStringBuf.append(" AND SUBSTRING(p.location,2,1) = '"
				+ fifCheckInputDTO.getShop() + "'");
	}
	if (null != fifCheckInputDTO.getLine()
			&& !fifCheckInputDTO.getLine().equals("")) {
		queryStringBuf.append(" AND SUBSTRING(p.location,3,1) = '"
				+ fifCheckInputDTO.getLine() + "'");
	}
	if (null != fifCheckInputDTO.getSection()
			&& !fifCheckInputDTO.getSection().equals("")) {
		queryStringBuf.append(" AND SUBSTRING(p.location,4,1) = '"
				+ fifCheckInputDTO.getSection() + "'");
	}
	if (null != fifCheckInputDTO.getDeviceId()
			&& !fifCheckInputDTO.getDeviceId().equals("")) {
		queryStringBuf.append(" AND p.deviceId like '%"
				+ fifCheckInputDTO.getDeviceId() + "%'");
	}

	SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	if (fifCheckInputDTO.getFromDate() != null
			|| fifCheckInputDTO.getToDate() != null) {
		Map<String,Date> shiftTimes  = WMSBeanUtil.getShiftTime(fifCheckInputDTO.getShift(),fifCheckInputDTO.getFromDate(),fifCheckInputDTO.getToDate());
	
		fifCheckInputDTO.setFromDate(shiftTimes.get("fromDate"));  
		fifCheckInputDTO.setToDate(shiftTimes.get("toDate")); 
		LOGGER.debug("** From Date -> "+ dateFormatter.format(fifCheckInputDTO.getFromDate()));
		LOGGER.debug("** To Date -> "+ dateFormatter.format(fifCheckInputDTO.getToDate()));
		queryStringBuf.append(" and p.scanTime >= '"+ dateFormatter.format(fifCheckInputDTO.getFromDate()) + "'");
		queryStringBuf.append(" and p.scanTime < '"+ dateFormatter.format(fifCheckInputDTO.getToDate()) + "'");
		

	}
	return queryStringBuf;
}

public static StringBuffer createQueryParamForFIFOSuggestion(FIFOSuggestionOverrideDTO fifoSuggestionOverrideDTO) {
	
	StringBuffer queryStringBuf = new StringBuffer();
	if (null != fifoSuggestionOverrideDTO.getLocation()
			&& !fifoSuggestionOverrideDTO.getLocation().equals("")) {
		queryStringBuf.append(" AND PA.LOCATION IN (:locationNos)");
	}
	if (null != fifoSuggestionOverrideDTO.getPartNumber()
			&& !fifoSuggestionOverrideDTO.getPartNumber().equals("")) {
		queryStringBuf.append(" AND PA.PART_NO IN (:partNos)");
	}
	if (null != fifoSuggestionOverrideDTO.getRan()
			&& !fifoSuggestionOverrideDTO.getRan().equals("")) {
		queryStringBuf.append(" AND PA.RAN IN (:rans)");
	}
	if (null != fifoSuggestionOverrideDTO.getPlant()
			&& !fifoSuggestionOverrideDTO.getPlant().equals("")) {
		queryStringBuf.append(" AND SUBSTRING(PA.LOCATION,1,1) = '"
				+ fifoSuggestionOverrideDTO.getPlant() + "'");
	}
	if (null != fifoSuggestionOverrideDTO.getShop()
			&& !fifoSuggestionOverrideDTO.getShop().equals("")) {
		queryStringBuf.append(" AND SUBSTRING(PA.LOCATION,2,1) = '"
				+ fifoSuggestionOverrideDTO.getShop() + "'");
	}
	if (null != fifoSuggestionOverrideDTO.getLine()
			&& !fifoSuggestionOverrideDTO.getLine().equals("")) {
		queryStringBuf.append(" AND SUBSTRING(PA.LOCATION,3,1) = '"
				+ fifoSuggestionOverrideDTO.getLine() + "'");
	}
	if (null != fifoSuggestionOverrideDTO.getSection()
			&& !fifoSuggestionOverrideDTO.getSection().equals("")) {
		queryStringBuf.append(" AND SUBSTRING(PA.LOCATION,4,1) = '"
				+ fifoSuggestionOverrideDTO.getSection() + "'");
	}
	if (null != fifoSuggestionOverrideDTO.getDeviceId()
			&& !fifoSuggestionOverrideDTO.getDeviceId().equals("")) {
		queryStringBuf.append(" AND PA.DEVICE_ID like '%"
				+ fifoSuggestionOverrideDTO.getDeviceId() + "%'");
	}

	SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	if (fifoSuggestionOverrideDTO.getFromDate() != null
			|| fifoSuggestionOverrideDTO.getToDate() != null) {
		Map<String,Date> shiftTimes  = WMSBeanUtil.getShiftTime(fifoSuggestionOverrideDTO.getShift(),fifoSuggestionOverrideDTO.getFromDate(),fifoSuggestionOverrideDTO.getToDate());
	
		fifoSuggestionOverrideDTO.setFromDate(shiftTimes.get("fromDate"));  
		fifoSuggestionOverrideDTO.setToDate(shiftTimes.get("toDate")); 
		LOGGER.debug("** From Date -> "+ dateFormatter.format(fifoSuggestionOverrideDTO.getFromDate()));
		LOGGER.debug("** To Date -> "+ dateFormatter.format(fifoSuggestionOverrideDTO.getToDate()));
		queryStringBuf.append(" and PA.SCAN_TIME >= '"+ dateFormatter.format(fifoSuggestionOverrideDTO.getFromDate()) + "'");
		queryStringBuf.append(" and PA.SCAN_TIME < '"+ dateFormatter.format(fifoSuggestionOverrideDTO.getToDate()) + "'");
	}
	return queryStringBuf;
}

	public static String getCategoryDesc(String categoryCode){
		String categoryDesc="";
		if(categoryCode!=null){
			if(categoryCode.toUpperCase().equals("D"))
			{
				categoryDesc="Direct";
			}
			else if(categoryCode.toUpperCase().equals("R"))
			{
				categoryDesc="Repacking";
			}
			else if(categoryCode.toUpperCase().equals("B"))
			{
				categoryDesc="Bulk";
			}
			else if(categoryCode.toUpperCase().equals("C"))
			{
				categoryDesc="Consignee";
			}
			else
			{
				categoryDesc=categoryCode;
			}
						
		}
		else
		{
			categoryDesc=categoryCode;
		}
		return categoryDesc;
	}
	
	public static String getErrorReason(String errorCode){
		
		String errorReason="";
		if(errorCode!=null){
			if(errorCode.equals("1"))
			{
				errorReason="Invalid Part";
			}
			else if(errorCode.equals("2"))
			{
				errorReason="Invalid RAN";
			}
			else if(errorCode.equals("3"))
			{
				errorReason="Invalid Manufacturing Date";
			}
			else if(errorCode.equals("4"))
			{
				errorReason="Duplicate Record";
			}
			else if(errorCode.equals("5")){
				errorReason="Old RAN still available";
			}
			else
			{
				errorReason=errorCode;
			}
		}else{
			errorReason="NA";
		}
		return errorReason;
	}
	
	
}




