package com.rnaipl.wms.entities;

import java.io.Serializable;

import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the PARTINOUT_STAGING database table.
 * 
 */
@Entity
@Table(name="PARTINOUT_STAGING")
@NamedQuery(name="PartinoutStaging.findAll", query="SELECT p FROM PartinoutStaging p")
public class PartinoutStaging implements Serializable {
	private static final long serialVersionUID = 1L;
	
	public PartinoutStaging() {
	}

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="PART_PK")
	private long partPk;

	@Column(name="COUNT")
	private int count;

	@Column(name="DEVICE_ID")
	private String deviceId;

	@Column(name="LOCATION")
	private String location;

	@Column(name="PART_IN_OUT_TIME")
	private Timestamp partInOutTime;

	@Column(name="PART_NO")
	private String partNo;

	@Column(name="RAN")
	private String ran;
	
	/*@Column(name="REASON_CODE")
	private String reasonCode;*/

	@Column(name="TRANSACTION_TYPE")
	private String transactionType;

	@Column(name="USER_ID")
	private String userId;
	
	@Column(name="COMMENTS")
	private String comments;
	
	@Column(name="NO_OF_BOXES")
	private int noOfBoxes;
	
	@OneToOne
	@JoinColumn(name = "REASON_CODE" , referencedColumnName = "REASON_CODE")
	private PartsOutReason reasonCode;
	
	@Column(name="SNP")
	private int snp;
	
	@Column(name="SCAN_TIME")
	private Timestamp scanTime;
	
	@Column(name="SUGGESTED_LOCATION")
	private String suggestedLocation;
	
	@Column(name="SUGGESTED_RAN")
	private String suggestedRan;
	
	@Column(name="LOCATION_DESTINATION")
	private String locationDestination;
	
	//added for deviation resoncode
	@Column(name="DEVIATION_REASONCODEID")
	private String deviationResonCode;
	
	@Column(name="PICKLIST_NO")
	private String pickListNo;
	
	
	public String getPickListNo() {
		return pickListNo;
	}

	public void setPickListNo(String pickListNo) {
		this.pickListNo = pickListNo;
	}

	public String getDeviationResonCode() {
		return deviationResonCode;
	}

	public void setDeviationResonCode(String deviationResonCode) {
		this.deviationResonCode = deviationResonCode;
	}
	//

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public int getNoOfBoxes() {
		return noOfBoxes;
	}

	public void setNoOfBoxes(int noOfBoxes) {
		this.noOfBoxes = noOfBoxes;
	}

	public long getPartPk() {
		return this.partPk;
	}

	public void setPartPk(long partPk) {
		this.partPk = partPk;
	}

	public int getCount() {
		return this.count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getDeviceId() {
		return this.deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getLocation() {
		return this.location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Timestamp getPartInOutTime() {
		return this.partInOutTime;
	}

	public void setPartInOutTime(Timestamp partInOutTime) {
		this.partInOutTime = partInOutTime;
	}

	public String getPartNo() {
		return this.partNo;
	}

	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}

	public String getRan() {
		return this.ran;
	}

	public void setRan(String ran) {
		this.ran = ran;
	}

/*	public String getReasonCode() {
		return this.reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
*/
	public String getTransactionType() {
		return this.transactionType;
	}

	public PartsOutReason getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(PartsOutReason reasonCode) {
		this.reasonCode = reasonCode;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getSnp() {
		return snp;
	}

	public void setSnp(int snp) {
		this.snp = snp;
	}

	public Timestamp getScanTime() {
		return scanTime;
	}

	public void setScanTime(Timestamp scanTime) {
		this.scanTime = scanTime;
	}

	public String getSuggestedLocation() {
		return suggestedLocation;
	}

	public void setSuggestedLocation(String suggestedLocation) {
		this.suggestedLocation = suggestedLocation;
	}

	public String getSuggestedRan() {
		return suggestedRan;
	}

	public void setSuggestedRan(String suggestedRan) {
		this.suggestedRan = suggestedRan;
	}

	public String getLocationDestination() {
		return locationDestination;
	}

	public void setLocationDestination(String locationDestination) {
		this.locationDestination = locationDestination;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}