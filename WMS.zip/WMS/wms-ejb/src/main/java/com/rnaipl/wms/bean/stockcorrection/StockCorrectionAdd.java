package com.rnaipl.wms.bean.stockcorrection;

import java.util.List;

import com.rnaipl.wms.dto.StockCorrectionAddDTO;

/**
 * 
 * @author TechM
 * 
 */
public interface StockCorrectionAdd {


	public List<StockCorrectionAddDTO> addStockCorrection(List<StockCorrectionAddDTO> partLocCorrDTOs);
	
	public void deleteStockCorrection(List<StockCorrectionAddDTO> partLocCorrDTOs);

}
