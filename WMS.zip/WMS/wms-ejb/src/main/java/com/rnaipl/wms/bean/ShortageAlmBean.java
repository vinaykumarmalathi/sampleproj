/**
 * 
 */
package com.rnaipl.wms.bean;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.ejb.EJBException;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;
import javax.ws.rs.ext.Provider;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.LocationByPartDTO;
import com.rnaipl.wms.dto.PartNumberDTO;
import com.rnaipl.wms.dto.ShortageAlarmDTO;
import com.rnaipl.wms.entities.PartLocation;
import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSConstants;

/**
 * @author z023761
 *
 */
@Stateless
@LocalBean
@Provider
public class ShortageAlmBean implements ShortageAlarm {

	private static final Logger LOGGER = Logger.getLogger(ShortageAlmBean.class);

	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;

	@Context
	HttpServletResponse response;

	/*
	 * To get the list of total records of shortage alarm table -
	 * TBL_ShortageAlarm_PV_CUR_Final - START
	 */
	public int getShortageAlmListCount(ShortageAlarmDTO shortageAlarmDTO) {
		int noOfRecords = 0;
		try {

			LOGGER.debug("****Plant : " + shortageAlarmDTO.getPlant());
			LOGGER.debug("****Shop : " + shortageAlarmDTO.getShop());
			LOGGER.debug("****Line : " + shortageAlarmDTO.getLine());
			LOGGER.debug("****Zone : " + shortageAlarmDTO.getZone());
			LOGGER.debug("****Part Type : " + shortageAlarmDTO.getPartType());
			LOGGER.debug("****Wip : " + shortageAlarmDTO.getWip());
			LOGGER.debug("****Part No : " + shortageAlarmDTO.getPartNumber());
			LOGGER.debug("****sup Code : " + shortageAlarmDTO.getSupCode());
			LOGGER.debug("****Depot Code : " + shortageAlarmDTO.getDepotCode());
			LOGGER.debug("****Pc Code : " + shortageAlarmDTO.getPcCode());
			LOGGER.debug("****Calc Logic : " + shortageAlarmDTO.getCalLogic());
			LOGGER.debug("****Shortage Type Red : " + shortageAlarmDTO.getShortageTypeR());
			LOGGER.debug("****Shortage Type Yellow : " + shortageAlarmDTO.getShortageTypeY());
			LOGGER.debug("****Shortage Type Green : " + shortageAlarmDTO.getShortageTypeG());
			LOGGER.debug("****From Date : " + shortageAlarmDTO.getFromDate());
			LOGGER.debug("****To Date : " + shortageAlarmDTO.getToDate());
			LOGGER.debug("****Start Index : " + shortageAlarmDTO.getStartIndex());
			LOGGER.debug("****End Index : " + shortageAlarmDTO.getEndIndex());

			StringBuffer selectQuery = new StringBuffer();

			if (shortageAlarmDTO.getPlant() != null && !shortageAlarmDTO.getPlant().isEmpty()
					&& shortageAlarmDTO.getPlant().equalsIgnoreCase(WMSConstants.PLANT_TYPE_PV)) {
				selectQuery.append(" SELECT count(*) FROM [dbo].TBL_ShortageAlarm_PV_CUR_Final WHERE 1=1  ");
			} else {
				selectQuery.append(" SELECT count(*) FROM [dbo].TBL_ShortageAlarm_PV_CUR_Final WHERE 1=1  ");
			}

			if (shortageAlarmDTO.getShop() != null && !shortageAlarmDTO.getShop().trim().isEmpty()) {
				if (shortageAlarmDTO.getShop().charAt(0) != 'T') {
					selectQuery.append(" AND SHOP IN ('" + shortageAlarmDTO.getShop().charAt(0) + "')");
				} else {
					selectQuery.append(" AND substring(SHOP,1,1) IN ('T','K') ");
				}
			}

			if (shortageAlarmDTO.getLine() != null && !shortageAlarmDTO.getLine().trim().isEmpty()) {
				/*
				 * selectQuery.append(" and LINE IN ('"+shortageAlarmDTO.getLine().trim().charAt
				 * (0)+"') ");
				 */
				selectQuery.append(" and LINE like ('%" + shortageAlarmDTO.getLine().trim().charAt(0) + "%') ");
			}

			if (shortageAlarmDTO.getZone() != null && !shortageAlarmDTO.getZone().trim().isEmpty()) {
				selectQuery.append(" and LS_ZoneCode = '" + shortageAlarmDTO.getZone().trim() + "' ");
			}

			if (shortageAlarmDTO.getPartType() != null && !shortageAlarmDTO.getPartType().trim().isEmpty()) {
				selectQuery.append(" and PartType = '" + shortageAlarmDTO.getPartType().trim() + "' ");
			}

			// Method to get the clr to pass in the query filter
			String clr = getClr(shortageAlarmDTO.getShortageTypeR(), shortageAlarmDTO.getShortageTypeY(),
					shortageAlarmDTO.getShortageTypeG());

			// Colour filter for until condition
			if (shortageAlarmDTO.getWip() != null
					&& shortageAlarmDTO.getCalLogic().trim().equalsIgnoreCase(WMSConstants.WMSCAL)) {
				// if wip selected we are enabling the colour filter based on the selected
				// colour
				if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.METAL)) {
					selectQuery.append(" and( WMS_METAL_CLR IN (" + clr + ") ");
					selectQuery.append(" or WMS_PA1_CLR IN (" + clr + ") ");
					selectQuery.append(" or WMS_PA2_CLR IN (" + clr + ") ");
					selectQuery.append(" or WMS_PBS_CLR IN (" + clr + ") ");
					selectQuery.append(" or WMS_TRIM_CLR IN (" + clr + ")) ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.PA1)) {
					selectQuery.append(" and (WMS_PA1_CLR IN (" + clr + ") ");
					selectQuery.append(" or WMS_PA2_CLR IN (" + clr + ") ");
					selectQuery.append(" or WMS_PBS_CLR IN (" + clr + ") ");
					selectQuery.append(" or WMS_TRIM_CLR IN (" + clr + ")) ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.PA2)) {
					selectQuery.append(" and (WMS_PA2_CLR IN (" + clr + ") ");
					selectQuery.append(" or WMS_PBS_CLR IN (" + clr + ") ");
					selectQuery.append(" or WMS_TRIM_CLR IN (" + clr + ")) ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.PBS)) {
					selectQuery.append(" and (WMS_PBS_CLR IN (" + clr + ") ");
					selectQuery.append(" or WMS_TRIM_CLR IN (" + clr + ")) ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.TRIM)) {
					selectQuery.append(" and WMS_TRIM_CLR IN (" + clr + ") ");
				}
			}

			if (shortageAlarmDTO.getWip() != null
					&& shortageAlarmDTO.getCalLogic().trim().equalsIgnoreCase(WMSConstants.CATSCAL)) {
				// if wip selected we are enabling the colour filter based on the selected
				// colour
				if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.METAL)) {
					selectQuery.append(" and (CATS_METAL_CLR IN (" + clr + ") ");
					selectQuery.append(" or CATS_PA1_CLR IN (" + clr + ") ");
					selectQuery.append(" or CATS_PA2_CLR IN (" + clr + ") ");
					selectQuery.append(" or CATS_PBS_CLR IN (" + clr + ") ");
					selectQuery.append(" or CATS_TRIM_CLR IN (" + clr + ")) ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.PA1)) {
					selectQuery.append(" and (CATS_PA1_CLR IN (" + clr + ") ");
					selectQuery.append(" or CATS_PA2_CLR IN (" + clr + ") ");
					selectQuery.append(" or CATS_PBS_CLR IN (" + clr + ") ");
					selectQuery.append(" or CATS_TRIM_CLR IN (" + clr + ")) ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.PA2)) {
					selectQuery.append(" and (CATS_PA2_CLR IN (" + clr + ") ");
					selectQuery.append(" or CATS_PBS_CLR IN (" + clr + ") ");
					selectQuery.append(" or CATS_TRIM_CLR IN (" + clr + ")) ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.PBS)) {
					selectQuery.append(" and ((CATS_PBS_CLR IN (" + clr + ") ");
					selectQuery.append(" or CATS_TRIM_CLR IN (" + clr + "))");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.TRIM)) {
					selectQuery.append(" and CATS_TRIM_CLR IN (" + clr + ") ");
				}
			}

			if (shortageAlarmDTO.getPartNumber() != null && !shortageAlarmDTO.getPartNumber().trim().equals("")) {
				selectQuery.append(" AND Part_NO IN (:partNums)");
			}

			if (shortageAlarmDTO.getSupCode() != null && !shortageAlarmDTO.getSupCode().trim().equals("")) {
				selectQuery.append(" AND SupplierCode IN (:SupCodes)");
			}

			if (shortageAlarmDTO.getDepotCode() != null && !shortageAlarmDTO.getDepotCode().trim().equals("")) {
				selectQuery.append(" AND depocode IN (:depoCodes)");
			}

			if (shortageAlarmDTO.getPcCode() != null && !shortageAlarmDTO.getPcCode().trim().equals("")) {
				selectQuery.append(" AND pc_code IN (:pcCodes)");
			}

			/*
			 * if (shortageAlarmDTO.getFromDate()!= null && shortageAlarmDTO.getToDate()!=
			 * null ) { if(shortageAlarmDTO.getCalLogic().equalsIgnoreCase("W")) {
			 * selectQuery.
			 * append(" AND  (WMS_GROSS_DATE is null or (WMS_GROSS_DATE between '"
			 * +shortageAlarmDTO.getFromDate()+"' and '"+shortageAlarmDTO.getToDate()+"')) "
			 * ); }else { selectQuery.
			 * append(" AND (CATS_GROSS_DATE is null or (CATS_GROSS_DATE between '"
			 * +shortageAlarmDTO.getFromDate()+"' and '"+shortageAlarmDTO.getToDate()+"')) "
			 * ); } }
			 */

			/*
			 * if (shortageAlarmDTO.getFromDate() != null && shortageAlarmDTO.getToDate() !=
			 * null) { if (!shortageAlarmDTO.getShortageTypeG()) { if
			 * (shortageAlarmDTO.getCalLogic().equalsIgnoreCase("W")) { selectQuery.
			 * append(" AND (WMS_GROSS_DATE is null or (WMS_GROSS_DATE between '" +
			 * shortageAlarmDTO.getFromDate() + "' and '" + shortageAlarmDTO.getToDate() +
			 * "')) "); } else { selectQuery.
			 * append(" AND (CATS_GROSS_DATE is null or (CATS_GROSS_DATE between '" +
			 * shortageAlarmDTO.getFromDate() + "' and '" + shortageAlarmDTO.getToDate() +
			 * "')) "); } } }
			 */

			/*
			 * if (shortageAlarmDTO.getFromDate() != null && shortageAlarmDTO.getToDate() !=
			 * null) { if (shortageAlarmDTO.getShortageTypeG()) { if
			 * (shortageAlarmDTO.getCalLogic().equalsIgnoreCase("W")) {
			 * selectQuery.append(" AND (WMS_GROSS_DATE is null  or (WMS_GROSS_DATE >= '" +
			 * shortageAlarmDTO.getToDate() + "')) "); } else {
			 * selectQuery.append(" AND (CATS_GROSS_DATE is null or (CATS_GROSS_DATE >= '" +
			 * shortageAlarmDTO.getToDate() + "')) "); } }else { if
			 * (shortageAlarmDTO.getCalLogic().equalsIgnoreCase("W")) { selectQuery.
			 * append(" AND (WMS_GROSS_DATE is null or (WMS_GROSS_DATE between '" +
			 * shortageAlarmDTO.getFromDate() + "' and '" + shortageAlarmDTO.getToDate() +
			 * "')) "); }else { selectQuery.
			 * append(" AND (CATS_GROSS_DATE is null or (CATS_GROSS_DATE between '" +
			 * shortageAlarmDTO.getFromDate() + "' and '" + shortageAlarmDTO.getToDate() +
			 * "')) "); } } }
			 */

			if (shortageAlarmDTO.getFromDate() != null && shortageAlarmDTO.getToDate() != null) {
				if (shortageAlarmDTO.getShortageTypeG()) {
					if (shortageAlarmDTO.getCalLogic().equalsIgnoreCase("W")) {
						selectQuery.append(" AND (WMS_GROSS_DATE is null or (WMS_GROSS_DATE between '"
								+ shortageAlarmDTO.getFromDate() + "' and '" + shortageAlarmDTO.getToDate()
								+ "') or WMS_GROSS_DATE >= '" + shortageAlarmDTO.getToDate() + "') ");
					} else {
						selectQuery.append(" AND (CATS_GROSS_DATE is null or (CATS_GROSS_DATE between '"
								+ shortageAlarmDTO.getFromDate() + "' and '" + shortageAlarmDTO.getToDate()
								+ "') or CATS_GROSS_DATE >= '" + shortageAlarmDTO.getToDate() + "') ");
					}
				} else {
					if (shortageAlarmDTO.getCalLogic().equalsIgnoreCase("W")) {
						selectQuery.append(" AND (WMS_GROSS_DATE is null or (WMS_GROSS_DATE between '"
								+ shortageAlarmDTO.getFromDate() + "' and '" + shortageAlarmDTO.getToDate() + "')) ");
					} else {
						selectQuery.append(" AND (CATS_GROSS_DATE is null or (CATS_GROSS_DATE between '"
								+ shortageAlarmDTO.getFromDate() + "' and '" + shortageAlarmDTO.getToDate() + "')) ");
					}
				}
			}

			LOGGER.debug("Test Query; " + selectQuery.toString());
			Query query2 = entityManager.createNativeQuery(selectQuery.toString());
			LOGGER.debug("Before exectution of the query");

			if (shortageAlarmDTO.getPartNumber() != null && !shortageAlarmDTO.getPartNumber().equals("")) {
				LOGGER.debug("PartNumber List : " + shortageAlarmDTO.getPartList());
				query2.setParameter("partNums", shortageAlarmDTO.getPartList());
			}
			if (shortageAlarmDTO.getSupCode() != null && !shortageAlarmDTO.getSupCode().equals("")) {
				LOGGER.debug("Supplier List : " + shortageAlarmDTO.getSupplierList());
				query2.setParameter("SupCodes", shortageAlarmDTO.getSupplierList());
			}
			if (shortageAlarmDTO.getDepotCode() != null && !shortageAlarmDTO.getDepotCode().equals("")) {
				LOGGER.debug("depoList : " + shortageAlarmDTO.getDepoList());
				query2.setParameter("depoCodes", shortageAlarmDTO.getDepoList());
			}
			if (shortageAlarmDTO.getPcCode() != null && !shortageAlarmDTO.getPcCode().equals("")) {
				LOGGER.debug("pccode List : " + shortageAlarmDTO.getPcCode());
				query2.setParameter("pcCodes", shortageAlarmDTO.getPcList());
			}

			noOfRecords = (Integer) query2.getSingleResult();
			LOGGER.debug("recordCount :  " + noOfRecords);
		} catch (Exception e) {
			LOGGER.debug("error" + e);
		}
		return noOfRecords;
	}
	/*
	 * To get the list of total records of shortage alarm table -
	 * TBL_ShortageAlarm_PV_CUR_Final - End
	 */

	/*
	 * To get the list of records of shortage alarm table -
	 * TBL_ShortageAlarm_PV_CUR_Final - START
	 */
	public List<ShortageAlarmDTO> getShortageAlmList(ShortageAlarmDTO shortageAlarmDTO) {
		List<ShortageAlarmDTO> shortageAlarmListDTO = null;
		ShortageAlarmDTO shortageAlarmResultDTO = null;
		try {
			int startIndex = shortageAlarmDTO.getStartIndex();
			int endIndex = shortageAlarmDTO.getEndIndex();			
			StringBuffer selectQuery = new StringBuffer();
			
			selectQuery.append(" SELECT ");
			selectQuery.append(" PartType, Part_NO, PC_Code, PartName, CONCAT(SupplierCode,' - ',SupplierName), ");
			selectQuery.append(" DepoCode, LS_ZoneCode, ");
			selectQuery.append(" snp,snip, Trim_WIP, PBS_WIP, PA2_WIP,PA1_WIP,METAL_WIP,Total_WIP , ");
			selectQuery.append(" CATS_Stock,WMS_QTY,LINE_QTY, ");
			selectQuery.append(" EOP_Mark,EOP_Flag_Qty, Hold_Qty, Undelivered_Qty,Pending_Qty, ");
			selectQuery.append(" LS_WH_OUT,LS_WH_DATE, ");			
			
			if(shortageAlarmDTO.getCalLogic().equalsIgnoreCase("W"))	{
				selectQuery.append(" WMS_TCF, WMS_PBS, WMS_PA2, WMS_PA1, WMS_METAL, ");
				selectQuery.append(" WMS_TRIM_CLR, WMS_PBS_CLR, WMS_PA2_CLR, WMS_PA1_CLR, WMS_METAL_CLR, ");
				selectQuery.append(" WMS_GROSS_DATE, WMS_GROSS_QTY ");
				
			}else {
				selectQuery.append(" CATS_TCF, CATS_PBS, CATS_PA2, CATS_PA1, CATS_METAL, ");
				selectQuery.append(" CATS_TRIM_CLR, CATS_PBS_CLR, CATS_PA2_CLR, CATS_PA1_CLR, CATS_METAL_CLR, ");
				selectQuery.append(" CATS_GROSS_DATE, CATS_GROSS_QTY ");
			}
			
			if(shortageAlarmDTO.getPlant()!=null && !shortageAlarmDTO.getPlant().isEmpty() && shortageAlarmDTO.getPlant().trim().equalsIgnoreCase(WMSConstants.PLANT_TYPE_PV)){
				selectQuery.append(" FROM TBL_ShortageAlarm_PV_CUR_Final WHERE 1=1 ");
			} else {
				selectQuery.append(" FROM TBL_ShortageAlarm_PV_CUR_Final WHERE 1=1 ");
			}
			
			if(shortageAlarmDTO.getShop()!=null && !shortageAlarmDTO.getShop().trim().isEmpty()){
				if (shortageAlarmDTO.getShop().charAt(0) != 'T' )	{					
					selectQuery.append(" AND SHOP IN ('" + shortageAlarmDTO.getShop().charAt(0) + "')");			
				} else {				
					/*selectQuery.append(" AND SHOP IN ('T','K')");*/
					selectQuery.append(" AND substring(SHOP,1,1) IN ('T','K') ");
				}
				//selectQuery.append(" and SHOP IN '"+shortageAlarmDTO.getShop().trim()+"' ");
			}
		
			if(shortageAlarmDTO.getLine()!=null && !shortageAlarmDTO.getLine().trim().isEmpty()){
				/*selectQuery.append(" and LINE IN '"+shortageAlarmDTO.getLine().trim().charAt(0)+"' ");*/
				selectQuery.append(" and LINE like ('%"+ shortageAlarmDTO.getLine().trim().charAt(0) +"%') ");
			}
			
			if(shortageAlarmDTO.getZone()!=null && !shortageAlarmDTO.getZone().isEmpty()){
				selectQuery.append(" and LS_ZoneCode = '"+shortageAlarmDTO.getZone().trim()+"' ");
			}
			
			if(shortageAlarmDTO.getPartType()!=null && !shortageAlarmDTO.getPartType().isEmpty()){
				selectQuery.append(" and PartType = '"+shortageAlarmDTO.getPartType().trim()+"' ");
			}
			
		
			String clr = getClr(shortageAlarmDTO.getShortageTypeR(), shortageAlarmDTO.getShortageTypeY(), shortageAlarmDTO.getShortageTypeG());
			
			/*if(shortageAlarmDTO.getWip()!=null && shortageAlarmDTO.getCalLogic().trim().equalsIgnoreCase(WMSConstants.WMSCAL) ){	
				//if wip selected we are enabling the colour filter based on the selected colour
				if(shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.METAL))	{
					selectQuery.append(" and WMS_METAL_CLR IN ("+clr+") ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.PA1)) {
					selectQuery.append(" and WMS_PA1_CLR IN ("+clr+") ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.PA2)) {
					selectQuery.append(" and WMS_PA2_CLR IN ("+clr+") ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.PBS)) {
					selectQuery.append(" and WMS_PBS_CLR IN ("+clr+") ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.TRIM)) {
					selectQuery.append(" and WMS_TRIM_CLR IN ("+clr+") ");
				}
			} 
			
			
			if(shortageAlarmDTO.getWip()!=null && shortageAlarmDTO.getCalLogic().trim().equalsIgnoreCase(WMSConstants.CATSCAL) ){
				//if wip selected we are enabling the colour filter based on the selected colour
				if(shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.METAL))	{
					selectQuery.append(" and CATS_METAL_CLR IN ("+clr+") ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.PA1)) {
					selectQuery.append(" and CATS_PA1_CLR IN ("+clr+") ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.PA2)) {
					selectQuery.append(" and CATS_PA2_CLR IN ("+clr+") ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.PBS)) {
					selectQuery.append(" and CATS_PBS_CLR IN ("+clr+") ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.TRIM)) {
					selectQuery.append(" and CATS_TRIM_CLR IN ("+clr+") ");
				}	
			} */
			
			//Colour filter for until condition
			if(shortageAlarmDTO.getWip()!=null && shortageAlarmDTO.getCalLogic().trim().equalsIgnoreCase(WMSConstants.WMSCAL) ){	
				//if wip selected we are enabling the colour filter based on the selected colour
				if(shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.METAL))	{
					selectQuery.append(" and( WMS_METAL_CLR IN ("+clr+") ");
					selectQuery.append(" or WMS_PA1_CLR IN ("+clr+") ");
					selectQuery.append(" or WMS_PA2_CLR IN ("+clr+") ");
					selectQuery.append(" or WMS_PBS_CLR IN ("+clr+") ");
					selectQuery.append(" or WMS_TRIM_CLR IN ("+clr+")) ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.PA1)) {
					selectQuery.append(" and (WMS_PA1_CLR IN ("+clr+") ");
					selectQuery.append(" or WMS_PA2_CLR IN ("+clr+") ");
					selectQuery.append(" or WMS_PBS_CLR IN ("+clr+") ");
					selectQuery.append(" or WMS_TRIM_CLR IN ("+clr+")) ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.PA2)) {
					selectQuery.append(" and (WMS_PA2_CLR IN ("+clr+") ");
					selectQuery.append(" or WMS_PBS_CLR IN ("+clr+") ");
					selectQuery.append(" or WMS_TRIM_CLR IN ("+clr+")) ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.PBS)) {
					selectQuery.append(" and (WMS_PBS_CLR IN ("+clr+") ");
					selectQuery.append(" or WMS_TRIM_CLR IN ("+clr+")) ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.TRIM)) {
					selectQuery.append(" and WMS_TRIM_CLR IN ("+clr+") ");
				}
			} 
			
			
			if(shortageAlarmDTO.getWip()!=null && shortageAlarmDTO.getCalLogic().trim().equalsIgnoreCase(WMSConstants.CATSCAL) ){
				//if wip selected we are enabling the colour filter based on the selected colour
				if(shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.METAL))	{
					selectQuery.append(" and (CATS_METAL_CLR IN ("+clr+") ");
					selectQuery.append(" or CATS_PA1_CLR IN ("+clr+") ");
					selectQuery.append(" or CATS_PA2_CLR IN ("+clr+") ");
					selectQuery.append(" or CATS_PBS_CLR IN ("+clr+") ");
					selectQuery.append(" or CATS_TRIM_CLR IN ("+clr+")) ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.PA1)) {
					selectQuery.append(" and (CATS_PA1_CLR IN ("+clr+") ");
					selectQuery.append(" or CATS_PA2_CLR IN ("+clr+") ");
					selectQuery.append(" or CATS_PBS_CLR IN ("+clr+") ");
					selectQuery.append(" or CATS_TRIM_CLR IN ("+clr+")) ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.PA2)) {
					selectQuery.append(" and (CATS_PA2_CLR IN ("+clr+") ");
					selectQuery.append(" or CATS_PBS_CLR IN ("+clr+") ");
					selectQuery.append(" or CATS_TRIM_CLR IN ("+clr+")) ");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.PBS)) {
					selectQuery.append(" and ((CATS_PBS_CLR IN ("+clr+") ");
					selectQuery.append(" or CATS_TRIM_CLR IN ("+clr+"))");
				} else if (shortageAlarmDTO.getWip().equalsIgnoreCase(WMSConstants.TRIM)) {
					selectQuery.append(" and CATS_TRIM_CLR IN ("+clr+") ");
				}	
			} 
			
			if (shortageAlarmDTO.getPartNumber()!= null && !shortageAlarmDTO.getPartNumber().trim().equals("")) {
				selectQuery.append(" AND Part_NO IN (:partNums)");
			}
			
			if (shortageAlarmDTO.getSupCode()!= null && !shortageAlarmDTO.getSupCode().trim().equals("")) {
				selectQuery.append(" AND SupplierCode IN (:SupCodes)");
			}
			
			if (shortageAlarmDTO.getDepotCode()!= null && !shortageAlarmDTO.getDepotCode().trim().equals("")) {
				selectQuery.append(" AND depocode IN (:depoCodes)");
			}
			
			if (shortageAlarmDTO.getPcCode()!= null && !shortageAlarmDTO.getPcCode().trim().equals("")) {
				selectQuery.append(" AND pc_code IN (:pcCodes)");
			}			
			
			/*if (shortageAlarmDTO.getFromDate()!= null && shortageAlarmDTO.getToDate()!= null ) {
				if(shortageAlarmDTO.getCalLogic().equalsIgnoreCase("W"))	{
					selectQuery.append(" AND (WMS_GROSS_DATE is null or (WMS_GROSS_DATE between '"+shortageAlarmDTO.getFromDate()+"' and '"+shortageAlarmDTO.getToDate()+"')) ");
				}else {
					selectQuery.append(" AND (CATS_GROSS_DATE is null or (CATS_GROSS_DATE between '"+shortageAlarmDTO.getFromDate()+"' and '"+shortageAlarmDTO.getToDate()+"')) ");
				}
			}*/
			
			
			if (shortageAlarmDTO.getFromDate() != null && shortageAlarmDTO.getToDate() != null) {
				if (shortageAlarmDTO.getShortageTypeG()) {
					if (shortageAlarmDTO.getCalLogic().equalsIgnoreCase("W")) {						
						selectQuery.append(" AND (WMS_GROSS_DATE is null or (WMS_GROSS_DATE between '"
								+ shortageAlarmDTO.getFromDate() + "' and '" + shortageAlarmDTO.getToDate() + "') or WMS_GROSS_DATE >= '"+shortageAlarmDTO.getToDate()+"') ");
					} else {
						selectQuery.append(" AND (CATS_GROSS_DATE is null or (CATS_GROSS_DATE between '"
								+ shortageAlarmDTO.getFromDate() + "' and '" + shortageAlarmDTO.getToDate() + "') or CATS_GROSS_DATE >= '"+shortageAlarmDTO.getToDate()+"') ");
					}
				}else {
					if (shortageAlarmDTO.getCalLogic().equalsIgnoreCase("W")) {
						selectQuery.append(" AND (WMS_GROSS_DATE is null or (WMS_GROSS_DATE between '"
								+ shortageAlarmDTO.getFromDate() + "' and '" + shortageAlarmDTO.getToDate() + "')) ");
					}else {
						selectQuery.append(" AND (CATS_GROSS_DATE is null or (CATS_GROSS_DATE between '"
								+ shortageAlarmDTO.getFromDate() + "' and '" + shortageAlarmDTO.getToDate() + "')) ");
					}
				}
			}
			
			/*if (shortageAlarmDTO.getFromDate() != null && shortageAlarmDTO.getToDate() != null) {
				if (shortageAlarmDTO.getWip()==null && !shortageAlarmDTO.getShortageTypeG()) {
					if (shortageAlarmDTO.getCalLogic().equalsIgnoreCase("W")) {
						selectQuery.append(" AND (WMS_GROSS_DATE is null or (WMS_GROSS_DATE between '"
								+ shortageAlarmDTO.getFromDate() + "' and '" + shortageAlarmDTO.getToDate() + "')) ");
					} else {
						selectQuery.append(" AND (CATS_GROSS_DATE is null or (CATS_GROSS_DATE between '"
								+ shortageAlarmDTO.getFromDate() + "' and '" + shortageAlarmDTO.getToDate() + "')) ");
					}
				}else if(shortageAlarmDTO.getWip()!=null && shortageAlarmDTO.getShortageTypeG()){
					if (shortageAlarmDTO.getCalLogic().equalsIgnoreCase("W")) {
						selectQuery.append(" AND (WMS_GROSS_DATE <= '" + shortageAlarmDTO.getToDate() + "') ");
					} else {
						selectQuery.append(" AND (CATS_GROSS_DATE <= '" + shortageAlarmDTO.getToDate() + "') ");
					}
				}
			}*/
			
		
			
			if(shortageAlarmDTO.getIsFullDownload())
			{
				startIndex=0;
				String endIndexQuery = "select count(*) from TBL_ShortageAlarm_PV_CUR_Final where 1=1";
				Query query = entityManager.createNativeQuery(endIndexQuery.toString());
				endIndex = (Integer) query.getSingleResult();	
			}
			
			if (shortageAlarmDTO.getCalLogic().equalsIgnoreCase("W")) {	
				//selectQuery.append(" order by WMS_GROSS_DATE OFFSET " );
				selectQuery.append(" order by CASE WHEN WMS_TRIM_CLR = 'R' THEN '1' " );
				selectQuery.append(" WHEN WMS_TRIM_CLR = 'Y' THEN '2' " );
				selectQuery.append(" ELSE WMS_TRIM_CLR END, " );
				selectQuery.append(" CASE WHEN WMS_PBS_CLR = 'R' THEN '1' " );
				selectQuery.append(" WHEN WMS_PBS_CLR = 'Y' THEN '2' " );
				selectQuery.append(" ELSE WMS_PBS_CLR END, " );
				selectQuery.append(" CASE WHEN WMS_PA2_CLR = 'R' THEN '1' " );
				selectQuery.append(" WHEN WMS_PA2_CLR = 'Y' THEN '2' " );
				selectQuery.append(" ELSE WMS_PA2_CLR END, " );
				selectQuery.append(" CASE WHEN WMS_PA1_CLR = 'R' THEN '1' " );
				selectQuery.append(" WHEN WMS_PA1_CLR = 'Y' THEN '2' " );
				selectQuery.append(" ELSE WMS_PA1_CLR END, " );
				selectQuery.append(" CASE WHEN WMS_METAL_CLR = 'R' THEN '1' " );
				selectQuery.append(" WHEN WMS_METAL_CLR = 'Y' THEN '2' " );
				selectQuery.append(" ELSE WMS_METAL_CLR END,WMS_GROSS_DATE OFFSET " );
			}else {
				//selectQuery.append(" order by CATS_GROSS_DATE OFFSET OFFSET" );
				selectQuery.append(" order by CASE WHEN CATS_TRIM_CLR = 'R' THEN '1' " );
				selectQuery.append(" WHEN CATS_TRIM_CLR = 'Y' THEN '2' " );
				selectQuery.append(" ELSE CATS_TRIM_CLR END, " );
				selectQuery.append(" CASE WHEN CATS_PBS_CLR = 'R' THEN '1' " );
				selectQuery.append(" WHEN CATS_PBS_CLR = 'Y' THEN '2' " );
				selectQuery.append(" ELSE CATS_PBS_CLR END, " );
				selectQuery.append(" CASE WHEN CATS_PA2_CLR = 'R' THEN '1' " );
				selectQuery.append(" WHEN CATS_PA2_CLR = 'Y' THEN '2' " );
				selectQuery.append(" ELSE CATS_PA2_CLR END, " );
				selectQuery.append(" CASE WHEN CATS_PA1_CLR = 'R' THEN '1' " );
				selectQuery.append(" WHEN CATS_PA1_CLR = 'Y' THEN '2' " );
				selectQuery.append(" ELSE CATS_PA1_CLR END, " );
				selectQuery.append(" CASE WHEN CATS_METAL_CLR = 'R' THEN '1' " );
				selectQuery.append(" WHEN CATS_METAL_CLR = 'Y' THEN '2' " );
				selectQuery.append(" ELSE CATS_METAL_CLR END,CATS_GROSS_DATE OFFSET  " );
			}
			
			selectQuery.append(	startIndex );
			selectQuery.append(" ROWS FETCH NEXT "); 
			selectQuery.append( endIndex );
			selectQuery.append(" ROWS only ");
			
			LOGGER.debug("Query :  " + selectQuery.toString());
			
			Query query = entityManager.createNativeQuery(selectQuery.toString());
			
			if (shortageAlarmDTO.getPartNumber() != null && !shortageAlarmDTO.getPartNumber().trim().equals("")) {
				query.setParameter("partNums", shortageAlarmDTO.getPartList());
			}
			if (shortageAlarmDTO.getSupCode() != null && !shortageAlarmDTO.getSupCode().trim().equals("")) {
				query.setParameter("SupCodes", shortageAlarmDTO.getSupplierList());
			}
			if (shortageAlarmDTO.getDepotCode() != null && !shortageAlarmDTO.getDepotCode().trim().equals("")) {
				query.setParameter("depoCodes", shortageAlarmDTO.getDepoList());
			}
			if (shortageAlarmDTO.getPcCode() != null && !shortageAlarmDTO.getPcCode().trim().equals("")) {
				query.setParameter("pcCodes", shortageAlarmDTO.getPcList());
			}
			List<Object[]> shortageAlmList = query.getResultList();
						
			if (null != shortageAlmList && shortageAlmList.size() > 0) {

				shortageAlarmListDTO = new ArrayList<ShortageAlarmDTO>();

				for (Iterator<Object[]> i = shortageAlmList.iterator(); i.hasNext();) {

					int indexCount = 0;

					shortageAlarmResultDTO = new ShortageAlarmDTO();

					Object[] values = (Object[]) i.next();

					shortageAlarmResultDTO.setPartType(values[indexCount] == null ? "" : values[indexCount].toString());
					indexCount++;
					shortageAlarmResultDTO.setPartNumber((values[indexCount] == null ? "" : values[indexCount].toString()));
					indexCount++;
					shortageAlarmResultDTO.setPcCode((values[indexCount] == null ? "" : values[indexCount].toString()));
					indexCount++;
					shortageAlarmResultDTO.setPartName((values[indexCount] == null ? "" : values[indexCount].toString()));
					indexCount++;
					shortageAlarmResultDTO.setSupName((values[indexCount] == null ? "" : values[indexCount].toString()));
					indexCount++;
					shortageAlarmResultDTO.setDepotCode((values[indexCount] == null ? "" : values[indexCount].toString()));
					indexCount++;
					shortageAlarmResultDTO.setZone((values[indexCount] == null ? "" : values[indexCount].toString()));
					indexCount++;	
					shortageAlarmResultDTO.setSnep((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setSnip((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setTrimWip((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setPbsWip((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setPa2Wip((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setPa1Wip((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setMetalWip((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setTotWip((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;				
					shortageAlarmResultDTO.setCatsStk((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setWmsStock((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setLsStock((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setEopMark((values[indexCount] == null ? "" : values[indexCount].toString()));
					indexCount++;
					shortageAlarmResultDTO.setEopFlagQty((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setHoldQty((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setUndeliveredQty((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setPendingRanQty((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setLastWhOutQty((Integer) (null == values[indexCount] ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setLastWhOut((Date)(values[indexCount] == null ? null : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setTcf((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setPbs((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setPa2((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setPa1((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setMetal((Integer) (values[indexCount] == null ? 0 : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setTcfClr((values[indexCount] == null ? null : values[indexCount].toString()));
					indexCount++;
					shortageAlarmResultDTO.setPbsClr((values[indexCount] == null ? null : values[indexCount].toString()));
					indexCount++;
					shortageAlarmResultDTO.setPa2Clr((values[indexCount] == null ? null : values[indexCount].toString()));
					indexCount++;
					shortageAlarmResultDTO.setPa1Clr((values[indexCount] == null ? null : values[indexCount].toString()));
					indexCount++;
					shortageAlarmResultDTO.setMetalClr((values[indexCount] == null ? null : values[indexCount].toString()));
					indexCount++;
					shortageAlarmResultDTO.setGrossDate((Date)(values[indexCount] == null ? null : values[indexCount]));
					indexCount++;
					shortageAlarmResultDTO.setGrossQty((Integer) (null == values[indexCount] ? 0 : values[indexCount]));
					indexCount++;


					shortageAlarmListDTO.add(shortageAlarmResultDTO);					
				}
			}
			LOGGER.debug("**In search ends");
			LOGGER.debug("List size in bean :"+shortageAlarmListDTO.size());
			
		} catch (Exception e) {
			LOGGER.debug("Exception occured while getting the search data : " + e);
			e.printStackTrace();
		}
		return shortageAlarmListDTO;
	}

	// METHOD TO FETCH THE COLOUR CODES
	public char getClr(String zone, String shop) {
		char clr;
		StringBuffer queryStringBuf2 = new StringBuffer();
		queryStringBuf2.append("SELECT ColorCode ");
		queryStringBuf2.append(" FROM TBL_ShortageAlarm_ColorCode");
		queryStringBuf2.append(" WHERE ZoneCode = '" + zone + "' AND ShopName = '" + shop + "' AND Category = '"
				+ WMSConstants.PLANT_TYPE_PV + "' ");
		LOGGER.debug("Query :  " + queryStringBuf2.toString());
		Query query2 = entityManager.createNativeQuery(queryStringBuf2.toString());
		clr = (Character) query2.getSingleResult();
		return clr;
	}

	/*
	 * To get the list of total records of shortage alarm table -
	 * TBL_ShortageAlarm_PV_CUR_Final - END
	 */

	// METHOD TO DOWNLOAD THE FILES
	public void downloadFile(String fileName) throws IOException {
		java.io.FileInputStream fileInputStream = null;
		PrintWriter out = null;
		ShortageAlarmDTO dto = new ShortageAlarmDTO();
		try {
			LOGGER.debug("**downloadFile " + fileName);
			LOGGER.debug("**response :  " + response);
			out = response.getWriter();
			Query query = entityManager
					.createNativeQuery("select value from COMMON_PARAMETER where name = '" + fileName + "'");
			LOGGER.debug("query to get download name : " + query.toString());
			dto.setDownloadPath((String) query.getSingleResult());
			String filepath = dto.getDownloadPath();
			response.addHeader("x-filename", fileName);
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
			fileInputStream = new java.io.FileInputStream(filepath + fileName);
			LOGGER.debug("**filepath  :  " + (filepath + fileName));
			int i;
			while ((i = fileInputStream.read()) != -1) {
				out.write(i);
			}
		} catch (FileNotFoundException ex) {
			LOGGER.error("File Not Found in the path" + ex);
		} catch (EJBException ejbe) {
			LOGGER.error("download file Service -- > downloading file  Exception : ", ejbe);

		} finally {
			if (fileInputStream != null) {
				fileInputStream.close();
			}
			if (out != null) {
				out.close();
			}
		}
	}

	/**
	 * method to fetch all the part Numbers
	 */
	public Set<PartNumberDTO> getPartNumbers(String partNumber) {
		// TODO Auto-generated method stub
		LOGGER.debug("*****IN Get All Parts from Shortage alarm bean ");
		Set<PartNumberDTO> parts = new HashSet<PartNumberDTO>();
		Query query = entityManager.createNativeQuery(
				"select DISTINCT(part_NO) from TBL_ShortageAlarm_PV_CUR_Final where part_NO LIKE :val order by part_NO asc");
		query.setParameter("val", partNumber + "%");
		query.setMaxResults(10);
		List<String> partList = query.getResultList();
		for (String part : partList) {
			PartNumberDTO partNumberDTO = new PartNumberDTO();
			partNumberDTO.setText(part);
			parts.add(partNumberDTO);
		}
		return parts;
	}

	/**
	 * method to fetch all the supplier codes
	 */
	public Set<PartNumberDTO> getSupplierList(String supplierCode) {
		// TODO Auto-generated method stub
		LOGGER.debug("*****IN Get All supplier codes from Shortage alarm bean ");
		Set<PartNumberDTO> supplierList = new HashSet<PartNumberDTO>();
		Query query = entityManager
				.createNativeQuery("select DISTINCT(SupplierCode) from TBL_ShortageAlarm_PV_CUR_Final where "
						+ "(SupplierCode!='' and SupplierCode is not null) and SupplierCode LIKE :val order by SupplierCode asc");
		query.setParameter("val", supplierCode + "%");
		query.setMaxResults(10);
		List<String> partList = query.getResultList();
		for (String sup : partList) {
			PartNumberDTO supplierDTO = new PartNumberDTO();
			supplierDTO.setText(sup);
			supplierList.add(supplierDTO);
		}
		return supplierList;
	}

	/**
	 * method to fetch all the depo codes
	 */
	public Set<PartNumberDTO> getDepoCodeList(String depoCode) {
		// TODO Auto-generated method stub
		LOGGER.debug("*****IN Get All supplier codes from Shortage alarm bean ");
		Set<PartNumberDTO> depoCodeList = new HashSet<PartNumberDTO>();
		Query query = entityManager.createNativeQuery(
				"select DISTINCT(Depot_Code) as depoList from [TBL_DEPOT_DETAILS] where (Depot_Code+'-'+Depot_Name) LIKE :val");
		query.setParameter("val", "%" + depoCode + "%");
		query.setMaxResults(10);
		List<String> depoList = query.getResultList();
		for (String depCode : depoList) {
			PartNumberDTO depoCodeDTO = new PartNumberDTO();
			depoCodeDTO.setText(depCode);
			depoCodeList.add(depoCodeDTO);
		}
		return depoCodeList;
	}

	/**
	 * method to fetch all the zones
	 */
	public List<PartNumberDTO> getAllZones() {
		String value = WMSConstants.SHORTAGE_ALARM_ZONES;
		Query query = entityManager
				.createNativeQuery("select name from COMMON_PARAMETER where value ='" + value + "' order by name asc ");
		LOGGER.debug("query to get zones : " + query.toString());
		List<PartNumberDTO> finalZoneList = new ArrayList<PartNumberDTO>();
		List<String> zoneList = query.getResultList();
		for (String zoneVal : zoneList) {
			PartNumberDTO zoneDTO = new PartNumberDTO();
			zoneDTO.setText(zoneVal);
			finalZoneList.add(zoneDTO);
		}
		return finalZoneList;
	}

	/**
	 * method to fetch all the wip data
	 */
	public List<PartNumberDTO> getWips() {
		String value = WMSConstants.SHORTAGE_ALARM_WIPS;
		Query query = entityManager
				.createNativeQuery("select name from COMMON_PARAMETER where value ='" + value + "' order by name asc ");
		LOGGER.debug("query to get zones : " + query.toString());
		List<PartNumberDTO> finalWipList = new ArrayList<PartNumberDTO>();
		List<String> WipList = query.getResultList();
		for (String wipVal : WipList) {
			PartNumberDTO wipDTO = new PartNumberDTO();
			wipDTO.setText(wipVal);
			finalWipList.add(wipDTO);
		}
		return finalWipList;
	}

	/**
	 * method to fetch all the pc-codes
	 */
	public Set<PartNumberDTO> getPcCodeList(String pcCode) {
		// TODO Auto-generated method stub
		LOGGER.debug("*****IN Get All pc-codes from Shortage alarm bean ");
		Set<PartNumberDTO> pcCodeList = new HashSet<PartNumberDTO>();
		Query query = entityManager.createNativeQuery(
				"select distinct(PC_Code) from [TBL_ShortageAlarm_Exclusion_Master] where (PC_Code!='' and PC_Code is not null) "
						+ "and PC_Code LIKE :val order by PC_Code asc");
		query.setParameter("val", "%" + pcCode + "%");
		query.setMaxResults(10);
		List<String> PcList = query.getResultList();
		for (String pcCode1 : PcList) {
			PartNumberDTO pcCodeDTO = new PartNumberDTO();
			pcCodeDTO.setText(pcCode1);
			pcCodeList.add(pcCodeDTO);
		}
		return pcCodeList;
	}

	/**
	 * method to fetch color codes
	 */
	public String getClr(Boolean clrR, Boolean clrY, Boolean clrG) {
		String clr = null;
		/*
		 * LOGGER.debug("*****Clr Red :"+clrR); LOGGER.debug("*****Clr yellow :"+clrY);
		 * LOGGER.debug("*****Clr green :"+clrG);
		 */
		if (clrR) {
			clr = "'R'";
		}
		if (clrY) {
			clr = "'Y'";
		}
		if (clrG) {
			clr = "'G'";
		}
		if (clrR && clrY) {
			clr = "'R','Y'";
		}
		if (clrR && clrG) {
			clr = "'R','G'";
		}
		if (clrY && clrG) {
			clr = "'Y','G'";
		}
		if (clrR && clrY && clrG) {
			clr = "'R','Y','G'";
		}
		return clr;
	}

	/**
	 * method to get download name from DB
	 */
	public ShortageAlarmDTO getDownloadNameFmDB(String downloadName) {
		ShortageAlarmDTO dto = new ShortageAlarmDTO();
		try {
			Query query = entityManager
					.createNativeQuery("select value from COMMON_PARAMETER where name like '" + downloadName + "'");
			LOGGER.debug("query to get download name : " + query.toString());
			dto.setDownloadName((String) query.getSingleResult());
			LOGGER.debug("get download Name : " + dto.getDownloadName());
		} catch (Exception e) {
			LOGGER.debug("error" + e);
		}
		return dto;
	}

	/**
	 * method to enable/disable allparts cats coverage button based on the user
	 */
	public ShortageAlarmDTO getUserForAllPartsCoverage(String loggedInUserId) {
		ShortageAlarmDTO dto = new ShortageAlarmDTO();
		try {
			Query query = entityManager
					.createNativeQuery("select USER_ID from TBL_SHORTAGE_ALARM_USER where USER_ID = '" + loggedInUserId
							+ "' and STATUS_CODE=1 ");
			dto.setUserId((String) query.getSingleResult());
			LOGGER.debug("get userID : " + dto.getUserId());
		} catch (Exception e) {
			LOGGER.debug("error" + e);
		}
		return dto;
	}

	/**
	 * method to fetch last calculation date and time
	 */
	public ShortageAlarmDTO getLstCalTime(String plant) {
		ShortageAlarmDTO dto = new ShortageAlarmDTO();
		try {
			Query query = entityManager.createNativeQuery(
					"SELECT TOP 1 TIME_S FROM TBL_RUN_TIME WHERE PROCEDURE_NAME='USP_GET_SHORTAGEALARM_DETAILS' AND COMMENTS='END' ORDER BY TIME_S DESC");
			dto.setLastWmsCalDate((Date) query.getSingleResult());
			Query query1 = entityManager.createNativeQuery(
					"SELECT TOP 1 TIME_S FROM TBL_RUN_TIME WHERE PROCEDURE_NAME='USP_UPDATE_WMS_ShortageAlarm' AND COMMENTS='END' ORDER BY TIME_S DESC");
			dto.setLastCatsCalDate((Date) query1.getSingleResult());
		} catch (Exception e) {
			LOGGER.debug("error" + e);
		}
		return dto;
	}

	public List<ShortageAlarmDTO> getShortageAlmDownload(ShortageAlarmDTO shortageAlarmDTO) {
		LOGGER.debug("***Entering Download method of Shortage alarm");
		List<ShortageAlarmDTO> downloadShortageAlmList = null;
		try {
			downloadShortageAlmList = getShortageAlmList(shortageAlarmDTO);
		} catch (Exception e) {
			LOGGER.debug("error" + e);
		}
		return downloadShortageAlmList;
	}

	// To get locations based on the part numbers in popup
	public List<LocationByPartDTO> getLocationsByPartNo(String partNo) {
		List<LocationByPartDTO> result = new ArrayList<LocationByPartDTO>();
		LocationByPartDTO dto = null;
		/*
		 * Query query = entityManager
		 * .createQuery("select p from PartLocation p where p.part.partNo = :partNo");
		 */
		Query query = entityManager.createQuery(
				"select p.location_id,current_qty from PartLocation p where substring(p.location_id,2,1) in ('T','K') and p.part.partNo = :partNo");
		query.setParameter("partNo", partNo);
		List<PartLocation> locationList = query.getResultList();
		if (!locationList.isEmpty() && locationList.size() > 0) {
			for (PartLocation entity : locationList) {
				dto = new LocationByPartDTO();
				dto.setLocationId(entity.getLocation().getLocationId());
				dto.setCurrentQty(entity.getCurrentQty());
				/*
				 * dto.setTotalCapacity(entity.getTotalCapacity());
				 * dto.setRan(entity.getId().getRan());
				 */
				result.add(dto);
			}
		}
		return result;
	}

	/**
	 * This method call getAllShops() to get the all the shops list
	 * 
	 * @return - list of ShopDTO
	 */
	public List<ShortageAlarmDTO> getShopByPlantId(String plantId) {
		// TODO Auto-generated method stub
		LOGGER.debug("getAllShops() method starts ");
		List<ShortageAlarmDTO> shopDTOs = new ArrayList<ShortageAlarmDTO>();
		List<ShortageAlarmDTO> modShopDTOs = new ArrayList<ShortageAlarmDTO>();
		Query query = entityManager.createNativeQuery(
				"select a.shop_id,s.shop_name  from PLANT_SHOP_SA a left outer join shop_SA s on a.SHOP_ID=s.SHOP_ID where a.PLANT_ID='"
						+ plantId + "' order by s.shop_name ");
		List<Object[]> shopList = query.getResultList();
		String temp = "";
		ShortageAlarmDTO shortageAlarmResultDTO = null;

		if (null != shopList && shopList.size() > 0) {
			shopDTOs = new ArrayList<ShortageAlarmDTO>();
			for (Iterator<Object[]> i = shopList.iterator(); i.hasNext();) {
				int indexCount = 0;
				shortageAlarmResultDTO = new ShortageAlarmDTO();
				Object[] values = (Object[]) i.next();
				shortageAlarmResultDTO.setShopId((values[indexCount] == null ? "" : values[indexCount].toString()));
				indexCount++;
				shortageAlarmResultDTO.setShopName((values[indexCount] == null ? "" : values[indexCount].toString()));
				indexCount++;
				shortageAlarmResultDTO
						.setShopList(shortageAlarmResultDTO.getShopId() + " - " + shortageAlarmResultDTO.getShopName());
				indexCount++;
				shopDTOs.add(shortageAlarmResultDTO);
			}
		}
		/*for (ShortageAlarmDTO shop : shopDTOs) {
			ShortageAlarmDTO shopDTO = new ShortageAlarmDTO();
			if (shop.getShopId().equalsIgnoreCase("T") || shop.getShopId().equalsIgnoreCase("K")) {
				temp = temp + shop.getShopId() + " - " + shop.getShopName() + " & ";
			} else {
				shopDTO.setShopId(shop.getShopId());
				shopDTO.setShopName(shop.getShopName());
				shopDTO.setShopList(shop.getShopId() + " - " + shop.getShopName());
				modShopDTOs.add(shopDTO);
			}
		}
		if (temp != "") {
			int index = temp.lastIndexOf('&');
			ShortageAlarmDTO shortagealmDTO = new ShortageAlarmDTO();
			shortagealmDTO.setShopId("T','K");
			shortagealmDTO.setShopList(temp.substring(0, (index - 1)));
			modShopDTOs.add(shortagealmDTO);
		}*/
		LOGGER.debug("getAllShops() method Ends ");
		return shopDTOs;
	}

	/**
	 * method to fetch lined based on ShopId
	 */
	public List<ShortageAlarmDTO> getlinesByShopId(String shopId) {
		LOGGER.debug("getAllLines() method starts ");
		List<ShortageAlarmDTO> lineDTOs = new ArrayList<ShortageAlarmDTO>();
		try {
			StringBuffer selectQuery = new StringBuffer();
			selectQuery.append(
					" select a.line_id,l.line_name  from shop_line_SA a left outer join line_SA l on a.LINE_ID=l.LINE_ID where 1=1  ");
			if (shopId.trim().toString() != null && shopId.trim().equalsIgnoreCase("T")) {
				selectQuery.append(" AND substring(a.SHOP_ID,1,1) IN ('T','K') ");
			} else {
				selectQuery.append(" AND a.SHOP_ID IN ('" + shopId + "') ");
			}
			selectQuery.append(" ORDER BY a.line_id ");
			LOGGER.debug("Query to get lines based on shop : " + selectQuery.toString());
			Query query = entityManager.createNativeQuery(selectQuery.toString());
			List<Object[]> lineList = query.getResultList();
			if (null != lineList && lineList.size() > 0) {
				lineDTOs = new ArrayList<ShortageAlarmDTO>();
				for (Iterator<Object[]> i = lineList.iterator(); i.hasNext();) {
					int indexCount = 0;
					ShortageAlarmDTO shortageAlarmLineDTO = new ShortageAlarmDTO();
					Object[] values = (Object[]) i.next();
					shortageAlarmLineDTO.setLineId((values[indexCount] == null ? "" : values[indexCount].toString()));
					indexCount++;
					shortageAlarmLineDTO.setLineName((values[indexCount] == null ? "" : values[indexCount].toString()));
					indexCount++;
					shortageAlarmLineDTO
							.setLineList(shortageAlarmLineDTO.getLineId() + " - " + shortageAlarmLineDTO.getLineName());
					indexCount++;
					lineDTOs.add(shortageAlarmLineDTO);
				}
			}
		} catch (Exception e) {
			LOGGER.debug("error" + e);
		}
		return lineDTOs;
	}

	/**
	 * method to fetch max of gross date
	 */
	public int getMaxDate() {
		int dayCount = 0;
		try {
			Query query = entityManager.createNativeQuery(
					"select datediff(day,getDate(),max(date)) from [dbo].[TBL_MS_Gross_PV_DayWise_CUR]");
			dayCount = ((Integer) query.getSingleResult());
		} catch (Exception e) {
			LOGGER.debug("error" + e);
		}
		return dayCount;
	}
}