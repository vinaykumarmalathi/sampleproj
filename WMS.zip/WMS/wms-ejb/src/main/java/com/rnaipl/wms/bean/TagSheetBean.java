package com.rnaipl.wms.bean;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSConstants;

@Stateless
@LocalBean
public class TagSheetBean implements TagSheet{
	private static final Logger LOGGER = Logger.getLogger(TagSheetBean.class);

	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;
	public String getTagSheetPath(){
		String tagSheetPath="";
		try{
			Query query = entityManager.createNativeQuery("SELECT VALUE FROM COMMON_PARAMETER WHERE ID = '2'");
			tagSheetPath = (String) query.getSingleResult();
			if(tagSheetPath.equals("null") || tagSheetPath==null || tagSheetPath.equals("")){
				tagSheetPath = WMSConstants.TAGSHEET;
			}
		}
		catch(Exception e){
			LOGGER.error("TagSheetBean--> getTagSheetPath",e);
			tagSheetPath = WMSConstants.TAGSHEET;
		}
		return tagSheetPath;
	}
}