package com.rnaipl.wms.bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.MessageDriven;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.AgedAuditDTO;
import com.rnaipl.wms.dto.PartsInOutAuditSearchDTO;
import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSBeanUtil;


@Stateless
@LocalBean
public class AgedAuditBean implements AgedAudit {

	private static final Logger LOGGER = Logger
			.getLogger(PartsInOutAuditSearchBean.class);

	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;
	
	public List<AgedAuditDTO> getAgedAuditSearch(PartsInOutAuditSearchDTO partsInOutAudit) throws Exception { 
		 
		LOGGER.debug("*** getAgedAuditSearch *Entry");
		List<AgedAuditDTO> agedAuditDtos = new ArrayList<AgedAuditDTO>();
		StringBuffer queryStringBuf = new StringBuffer();

		if(partsInOutAudit.getTransactionType().equalsIgnoreCase("1")){
			queryStringBuf.append("SELECT P.PART_NO,P.LOCATION,P.RAN,P.TRANSACTION_TYPE,P.COUNT,P.DEVICE_ID,P.PART_IN_OUT_TIME,P.SCAN_TIME,R.LPPD AS RANEXPIRY ");
			queryStringBuf.append("FROM DBO.PARTINOUT_STAGING_AUDIT P INNER JOIN  DBO.RAN R ON SUBSTRING(P.RAN,1,7) = R.RAN AND P.PART_NO=R.PART_NO WHERE P.RAN!='*' AND P.TRANSACTION_TYPE='IN'");
			queryStringBuf.append("AND R.LPPD IS NOT NULL AND P.SCAN_TIME>R.LPPD AND P.DEVICE_ID!='' AND P.DEVICE_ID IS NOT NULL");
			}
			
			else{
			queryStringBuf.append("SELECT P.PART_NO,P.LOCATION,P.RAN,P.TRANSACTION_TYPE,P.COUNT,P.DEVICE_ID,P.PART_IN_OUT_TIME,P.SCAN_TIME,R.LPPD AS RANEXPIRY ");
			queryStringBuf.append("FROM DBO.PARTINOUT_STAGING_AUDIT P INNER JOIN  DBO.RAN R ON  SUBSTRING(P.RAN,1,7) = R.RAN AND P.PART_NO=R.PART_NO WHERE P.RAN!='*' AND P.TRANSACTION_TYPE='OUT'");
			queryStringBuf.append("AND P.REASON_CODE='9' AND P.DEVICE_ID!='' AND P.DEVICE_ID IS NOT NULL");
			}
		
		queryStringBuf.append(WMSBeanUtil.createQueryParamForAgedAudit(partsInOutAudit));
		
		/*SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
	    if (partsInOutAudit.getFromDate() != null) {
			//queryStringBuf.append(" and P.SCAN_TIME >= dateadd(dd,-1, '"+ dateFormatter.format(partsInOutAudit.getFromDate()) + "')");
	    	queryStringBuf.append(" and P.SCAN_TIME >= '"+ dateFormatter.format(partsInOutAudit.getFromDate()) + " 00:00:00'");
			LOGGER.debug("*** getAgedAuditSearch from date----->"+ dateFormatter.format(partsInOutAudit.getFromDate()));
		}

		if(partsInOutAudit.getToDate() != null)
		{
			//queryStringBuf.append(" and P.SCAN_TIME < dateadd(dd,1,'"+ dateFormatter.format(partsInOutAudit.getToDate()) + "')");
			queryStringBuf.append(" and P.SCAN_TIME <='"+ dateFormatter.format(partsInOutAudit.getToDate()) + " 23:59:59'");
			LOGGER.debug("*** getAgedAuditSearch to date----->"+ dateFormatter.format(partsInOutAudit.getToDate()));
		}

		if (null != partsInOutAudit.getPlant() && !partsInOutAudit.getPlant().equals("")) {
	            queryStringBuf.append(" AND SUBSTRING(P.LOCATION, 1, 1) = '" + partsInOutAudit.getPlant() + "'");
	    }
	    if (null != partsInOutAudit.getShop() && !partsInOutAudit.getShop().equals("")) {
	            queryStringBuf.append(" AND SUBSTRING(P.LOCATION, 2, 1) = '" + partsInOutAudit.getShop() + "'");
	    }
	    if (null != partsInOutAudit.getLine() && !partsInOutAudit.getLine().equals("")) {
	            queryStringBuf.append(" AND SUBSTRING(P.LOCATION, 3, 1) = '" + partsInOutAudit.getLine() + "'");
	    }
	    if (null !=partsInOutAudit.getSection() && !partsInOutAudit.getSection().equals("")) {
	            queryStringBuf.append(" AND SUBSTRING(P.LOCATION, 4, 1) = '" + partsInOutAudit.getSection() + "'");
	    }
        if (null != partsInOutAudit.getLocation() && !partsInOutAudit.getLocation().equals("")) {
            queryStringBuf.append(" AND  P.LOCATION IN (:locationNos)");
        }
        if (null != partsInOutAudit.getPartNumber() && !partsInOutAudit.getPartNumber().equals("")) {
            queryStringBuf.append(" AND  P.PART_NO IN (:partNos)");
        }
        if (null != partsInOutAudit.getRan() && !partsInOutAudit.getRan().equals("")) {
            queryStringBuf.append(" AND  P.RAN IN (:rans)");
        }*/
		
		Query query = entityManager.createNativeQuery(queryStringBuf.toString());
		if (null != partsInOutAudit.getPartNumber() && !partsInOutAudit.getPartNumber().equalsIgnoreCase("")) {
			query.setParameter("partNos", partsInOutAudit.getPartList());
        }
		if (null != partsInOutAudit.getLocation() && !partsInOutAudit.getLocation().equalsIgnoreCase("")) {
			query.setParameter("locationNos", partsInOutAudit.getLocationList());
        }
		if (null != partsInOutAudit.getRan() && !partsInOutAudit.getRan().equalsIgnoreCase("")) {
			query.setParameter("rans", partsInOutAudit.getRanList());
        }
		
		LOGGER.debug("Aged Audit Query " + queryStringBuf.toString());
		
		if(partsInOutAudit.getIsFullDownload()!=1){
			query.setFirstResult(partsInOutAudit.getStartIndex());
			query.setMaxResults(partsInOutAudit.getEndIndex());
		}
		
		 List<Object[]> queryDatas = query.getResultList();
		LOGGER.debug("Aged Audit size " + queryDatas.size());

		if (null != queryDatas && queryDatas.size() > 0) {
			 for (Iterator<Object[]> i = queryDatas.iterator(); i.hasNext();) {
	            	int indexCount=0;
	                Object[] values = (Object[]) i.next();
	                AgedAuditDTO agedAuditDTO = new AgedAuditDTO();
	                agedAuditDTO.setPartNumber((null == values[indexCount] ? "" : values[indexCount].toString()));	      
	                indexCount++;	                
	                agedAuditDTO.setLocation((null == values[indexCount] ? "" : values[indexCount].toString()));
	                indexCount++;
	                agedAuditDTO.setRan((null == values[indexCount] ? "" : values[indexCount].toString()));
	                indexCount++;
	                agedAuditDTO.setTransactionType((null == values[indexCount] ? "" : values[indexCount].toString()));
	                indexCount++;
	                agedAuditDTO.setCount((Integer)(null == values[indexCount] ? "" : values[indexCount]));
		            indexCount++;
		            agedAuditDTO.setDeviceId((null == values[indexCount] ? "" : values[indexCount].toString()));	      
	                indexCount++;	 
	                agedAuditDTO.setPartInOutTime((Date) (null == values[indexCount] ? "" : values[indexCount]));
	                indexCount++;
	                agedAuditDTO.setScanTime((Date) (null == values[indexCount] ? "" : values[indexCount]));
	                indexCount++;
	                agedAuditDTO.setLppd((Date)(null == values[indexCount] ? "" : values[indexCount]));
		            indexCount++;
	                agedAuditDtos.add(agedAuditDTO);
			}

		}
		

		LOGGER.debug("*** getAgedAuditSearch EXIT");
		return agedAuditDtos;
	}
	
	public int getAgedAuditSearchCount(PartsInOutAuditSearchDTO partsInOutAudit){
		LOGGER.debug("***getAgedAuditSearchCount Entry");
		StringBuffer queryStringBuf = new StringBuffer();
		if(partsInOutAudit.getTransactionType().equalsIgnoreCase("1")){
		queryStringBuf.append("SELECT COUNT(*)");
		queryStringBuf.append("FROM DBO.PARTINOUT_STAGING_AUDIT P INNER JOIN  DBO.RAN R ON SUBSTRING(P.RAN,1,7)=R.RAN AND P.PART_NO=R.PART_NO WHERE P.RAN!='*' AND P.TRANSACTION_TYPE='IN'");
		queryStringBuf.append("AND R.LPPD IS NOT NULL AND P.SCAN_TIME>R.LPPD AND P.DEVICE_ID!='' AND P.DEVICE_ID IS NOT NULL");
		}
		
		else{
			queryStringBuf.append("SELECT COUNT(*) ");
			queryStringBuf.append("FROM DBO.PARTINOUT_STAGING_AUDIT P INNER JOIN  DBO.RAN R ON SUBSTRING(P.RAN,1,7)=R.RAN AND P.PART_NO=R.PART_NO WHERE P.RAN!='*' AND P.TRANSACTION_TYPE='OUT'");
			queryStringBuf.append("AND P.REASON_CODE='9' AND P.DEVICE_ID!='' AND P.DEVICE_ID IS NOT NULL");
		}
		queryStringBuf.append(WMSBeanUtil.createQueryParamForAgedAudit(partsInOutAudit));
		
		/*SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    if (partsInOutAudit.getFromDate() != null) {
			queryStringBuf.append(" and P.SCAN_TIME >= '"+ dateFormatter.format(partsInOutAudit.getFromDate()) + "'");
			LOGGER.debug("*** getAgedAuditSearch from date----->"+ dateFormatter.format(partsInOutAudit.getFromDate()));
		}
		if(partsInOutAudit.getToDate() != null)
		{
			queryStringBuf.append(" and P.SCAN_TIME < dateadd(dd,1,'"+ dateFormatter.format(partsInOutAudit.getToDate()) + "')");
			LOGGER.debug("*** getAgedAuditSearch to date----->"+ dateFormatter.format(partsInOutAudit.getToDate()));
		}
		if (null != partsInOutAudit.getPlant() && !partsInOutAudit.getPlant().equals("")) {
	            queryStringBuf.append(" AND SUBSTRING(P.LOCATION, 1, 1) = '" + partsInOutAudit.getPlant() + "'");
	    }
	    if (null != partsInOutAudit.getShop() && !partsInOutAudit.getShop().equals("")) {
	            queryStringBuf.append(" AND SUBSTRING(P.LOCATION, 2, 1) = '" + partsInOutAudit.getShop() + "'");
	    }
	    if (null != partsInOutAudit.getLine() && !partsInOutAudit.getLine().equals("")) {
	            queryStringBuf.append(" AND SUBSTRING(P.LOCATION, 3, 1) = '" + partsInOutAudit.getLine() + "'");
	    }
	    if (null !=partsInOutAudit.getSection() && !partsInOutAudit.getSection().equals("")) {
	            queryStringBuf.append(" AND SUBSTRING(P.LOCATION, 4, 1) = '" + partsInOutAudit.getSection() + "'");
	    }
        if (null != partsInOutAudit.getLocation() && !partsInOutAudit.getLocation().equals("")) {
            queryStringBuf.append(" AND  P.LOCATION IN (:locationNos)");
        }
        if (null != partsInOutAudit.getPartNumber() && !partsInOutAudit.getPartNumber().equals("")) {
            queryStringBuf.append(" AND  P.PART_NO IN (:partNos)");
        }
        if (null != partsInOutAudit.getRan() && !partsInOutAudit.getRan().equals("")) {
            queryStringBuf.append(" AND  P.RAN IN (:rans)");
        }*/
		
		Query query1 = entityManager.createNativeQuery(queryStringBuf.toString());
		if (null != partsInOutAudit.getPartNumber() && !partsInOutAudit.getPartNumber().equalsIgnoreCase("")) {
			query1.setParameter("partNos", partsInOutAudit.getPartList());
        }
		if (null != partsInOutAudit.getLocation() && !partsInOutAudit.getLocation().equalsIgnoreCase("")) {
			query1.setParameter("locationNos", partsInOutAudit.getLocationList());
        }
		if (null != partsInOutAudit.getRan() && !partsInOutAudit.getRan().equalsIgnoreCase("")) {
			query1.setParameter("rans", partsInOutAudit.getRanList());
        }
		
		LOGGER.debug("Aged Audit Count Query " + queryStringBuf.toString());
		
		 int noOfRecords = (Integer) query1.getSingleResult();
		
		LOGGER.debug("*** getAgedAuditSearchCount EXIT");
		return noOfRecords;
	}
}
