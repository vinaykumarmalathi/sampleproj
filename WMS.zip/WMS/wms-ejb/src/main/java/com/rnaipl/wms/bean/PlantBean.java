package com.rnaipl.wms.bean;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.PlantDTO;
import com.rnaipl.wms.entities.Plant;
import com.rnaipl.wms.util.WMSBeanConstants;

/**
 * 
 * @author TechM
 * 
 */
@Stateless
@LocalBean
public class PlantBean implements com.rnaipl.wms.bean.Plant {

	private static final Logger LOGGER = Logger.getLogger(PlantBean.class);

    @PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
    private EntityManager entityManager;

    /**
     * This method fetch the value from the database
     * 
     * @return - list of PlantDTO
     */
    private List<PlantDTO> getTempPlantsList() {
        // TODO Auto-generated method stub
        List<PlantDTO> plants = new ArrayList<PlantDTO>();

        PlantDTO plant = new PlantDTO();
        plant.setPlantId("plant001");
        plant.setPlantName("Body Plant");
        plants.add(plant);

        plant = new PlantDTO();
        plant.setPlantId("plant002");
        plant.setPlantName("T&D Plant");
        plants.add(plant);

        plant = new PlantDTO();
        plant.setPlantId("plant003");
        plant.setPlantName("Metal Plant");
        plants.add(plant);

        plant = new PlantDTO();
        plant.setPlantId("plant004");
        plant.setPlantName("Container Plant");
        plants.add(plant);

        plant = new PlantDTO();
        plant.setPlantId("plant005");
        plant.setPlantName("Warehouse Plant");
        plants.add(plant);

        return plants;
    }

    public List<PlantDTO> getAllPlants() {
        LOGGER.debug("getAllPlants() method starts ");
        List<PlantDTO> plantsDTOs = new ArrayList<PlantDTO>();
        Query query = entityManager.createQuery("select p from Plant p ORDER BY p.plantName");
        List<Plant> plants = query.getResultList();
        for (Plant plant : plants) {
            PlantDTO plantDTO = new PlantDTO();
            plantDTO.setPlantId(plant.getPlantId());
            plantDTO.setPlantName(plant.getPlantName());
            plantsDTOs.add(plantDTO);
        }
        LOGGER.debug("getAllPlants() method Ends ");
        return plantsDTOs;
    }

}
