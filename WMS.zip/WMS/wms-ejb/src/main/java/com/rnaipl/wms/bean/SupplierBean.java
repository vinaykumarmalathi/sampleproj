package com.rnaipl.wms.bean;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.SupplierDTO;
import com.rnaipl.wms.util.WMSBeanConstants;

/**
 * 
 * @author TechM
 * 
 */
@Stateless
@LocalBean
public class SupplierBean implements com.rnaipl.wms.bean.Supplier {

	private static final Logger LOGGER = Logger.getLogger(SupplierBean.class);

	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;

	public List<SupplierDTO> getSuppliersList() {
		LOGGER.debug("getAllLines() method starts ");
		List<SupplierDTO> suppliers = new ArrayList<SupplierDTO>();
		Query query = entityManager.createQuery("select p from supplier p ORDER BY p.supplierName");
		List<com.rnaipl.wms.entities.Supplier> sections = query.getResultList();

		for (com.rnaipl.wms.entities.Supplier section : sections) {
			SupplierDTO supplier = new SupplierDTO();
			supplier.setSupplierId(section.getSupplierId());
			supplier.setSupplierName(section.getSupplierName());
			suppliers.add(supplier);
		}

		return suppliers;

	}

}
