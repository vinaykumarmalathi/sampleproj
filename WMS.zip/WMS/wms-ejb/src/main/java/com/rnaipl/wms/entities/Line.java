package com.rnaipl.wms.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the LINE database table.
 * 
 */
@Entity
@Table(name="LINE")
@NamedQuery(name="Line.findAll", query="SELECT l FROM Line l")
public class Line implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LINE_ID")
	private String lineId;

	@Column(name="LINE_NAME")
	private String lineName;

	public Line() {
	}

	public String getLineId() {
		return this.lineId;
	}

	public void setLineId(String lineId) {
		this.lineId = lineId;
	}

	public String getLineName() {
		return this.lineName;
	}

	public void setLineName(String lineName) {
		this.lineName = lineName;
	}

}