package com.rnaipl.wms.bean;

import java.util.List;

import com.rnaipl.wms.dto.MasterScreenDetailsDTO;

public interface MasterScreenDetails {
	
	public List<MasterScreenDetailsDTO> getMasterScreenDetails(MasterScreenDetailsDTO location);
	
	public int getMasterListCount(MasterScreenDetailsDTO pickinglistDTO);
}
