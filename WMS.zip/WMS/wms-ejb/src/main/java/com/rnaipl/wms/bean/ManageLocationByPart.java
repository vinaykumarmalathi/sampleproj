package com.rnaipl.wms.bean;

import java.util.List;

import com.rnaipl.wms.dto.LocationByPartDTO;

public interface ManageLocationByPart {
	
	public List<LocationByPartDTO> getLocationsByPartNo(String partNo);
	
	public String deleteLocations(List<LocationByPartDTO> locationList);
	
	public String saveLocations(List<LocationByPartDTO> locationList);
	
	public String addLocation(LocationByPartDTO locationDto);
}
