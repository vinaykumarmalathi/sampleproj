package com.rnaipl.wms.bean;

import java.util.List;

import com.rnaipl.wms.dto.LineDTO;
import com.rnaipl.wms.dto.PlantDTO;

/**
 * 
 * @author TechM
 *
 */
public interface Line {
	
	/**
	 * It will retrive all the plant details information from database
	 * @return - list of PlantDTO object
	 */
	public List<LineDTO> getAllLines();
	public List<LineDTO> getLineByPlantId(String PlantId);
	public List<LineDTO> getTempPlantsList();
}
