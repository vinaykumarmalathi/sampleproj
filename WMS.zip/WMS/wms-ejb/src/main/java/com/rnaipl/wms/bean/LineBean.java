package com.rnaipl.wms.bean;


import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.LineDTO;
import com.rnaipl.wms.dto.PlantDTO;
import com.rnaipl.wms.util.WMSBeanConstants;

/**
 * 
 * @author TechM
 * 
 */
@Stateless
@LocalBean
public class LineBean implements com.rnaipl.wms.bean.Line {

	private static final Logger LOGGER = Logger.getLogger(LineBean.class);

    @PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
    private EntityManager entityManager;

    /**
     * This method fetch the value from the database
     * 
     * @return - list of PlantDTO
     */
    public List<LineDTO> getTempPlantsList() {
        // TODO Auto-generated method stub
        List<LineDTO> lines = new ArrayList<LineDTO>();

        LineDTO line = new LineDTO();
        line.setLineId("plant001");
        line.setLineName("Body Plant");
        lines.add(line);

        line = new LineDTO();
        line.setLineId("plant002");
        line.setLineName("T&D Plant");
        lines.add(line);

        line = new LineDTO();
        line.setLineId("plant003");
        line.setLineName("Metal Plant");
        lines.add(line);

        line = new LineDTO();
        line.setLineId("plant004");
        line.setLineName("Container Plant");
        lines.add(line);

        line = new LineDTO();
        line.setLineId("plant005");
        line.setLineName("Warehouse Plant");
        lines.add(line);

        return lines;
    }

    public List<LineDTO> getAllLines() {
        // TODO Auto-generated method stub
        LOGGER.debug("getAllLines() method starts ");
        List<LineDTO> LineDTOs = new ArrayList<LineDTO>();
        Query query = entityManager.createQuery("select p from Line p ORDER BY p.lineName");        
        List<com.rnaipl.wms.entities.Line> lines = query.getResultList();
        for (com.rnaipl.wms.entities.Line line : lines) {
            LineDTO LineDTO = new LineDTO();
            LineDTO.setLineId(line.getLineId());
            LineDTO.setLineName(line.getLineName());
            LineDTOs.add(LineDTO);
        }
        LOGGER.debug("getAllPlants() method Ends ");
        return LineDTOs;
    }
    
    public List<LineDTO> getLineByPlantId(String plantId) {
        // TODO Auto-generated method stub
        LOGGER.debug("getAllLines() method starts ");
        List<LineDTO> LineDTOs = new ArrayList<LineDTO>();
        com.rnaipl.wms.entities.Plant plants = entityManager.find(com.rnaipl.wms.entities.Plant.class,plantId);
        if(plants!=null){
        List<com.rnaipl.wms.entities.Line> lines = plants.getLines();
        for (com.rnaipl.wms.entities.Line line : lines) {
            LineDTO LineDTO = new LineDTO();
            LineDTO.setLineId(line.getLineId());
            LineDTO.setLineName(line.getLineName());
            LineDTOs.add(LineDTO);
        }
       }
        else{
        	return null;
        }
        LOGGER.debug("getAllPlants() method Ends ");
        return LineDTOs;
    }

}
