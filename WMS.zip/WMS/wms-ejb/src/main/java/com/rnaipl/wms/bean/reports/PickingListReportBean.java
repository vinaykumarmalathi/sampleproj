package com.rnaipl.wms.bean.reports;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.PickListAndroidDTO;
import com.rnaipl.wms.dto.PickingListDetailDTO;
import com.rnaipl.wms.dto.PickingListHdrDTO;
import com.rnaipl.wms.dto.PickingListRanDTO;
import com.rnaipl.wms.dto.PickinglistDetailsDTO;
import com.rnaipl.wms.dto.reports.LineAllocationDTO;
import com.rnaipl.wms.dto.reports.PickinglistDTO;
import com.rnaipl.wms.dto.reports.PickinglistResultsDTO;
import com.rnaipl.wms.entities.PartinOutStagingAudit;
import com.rnaipl.wms.entities.Shop;
import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSConstants;


@Stateless
@LocalBean
public class PickingListReportBean implements IPickingList {

	private static final Logger LOGGER = Logger.getLogger(PickingListReportBean.class);
	
	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	public List<PickinglistResultsDTO> getPickingList(PickinglistDTO pickinglistDTO) {
		LOGGER.debug("Entering getPickingList bean");
		List<PickinglistResultsDTO> pickinglistResultsDTOList = new ArrayList<PickinglistResultsDTO>();
		Map<String, Object> map = new LinkedHashMap<String, Object>();
		String status = "";
		String querySql = "SELECT PICKING_LIST, LINE, ZONE, SHOP, NO_OPEN_BOX, STATUS, ALLOCATION, Convert(varchar(19),CREATION_TIME,120), CLOSE_TIME, "
				+ "DEVICE, NO_OPEN_PART FROM dbo.TBL_LNFD_MASTER WHERE 1=1";
		querySql = querySql + createWhereClause(pickinglistDTO, map);
	//	LOGGER.debug("Query " + querySql.toString());
		Query query = entityManager.createNativeQuery(querySql);
		if (map != null && !map.isEmpty()) {
			for (String param : map.keySet()) {
				query.setParameter(param, map.get(param));
			}
		}
		
		if(pickinglistDTO.getIsFullDownload()!=1){
			query.setFirstResult(pickinglistDTO.getStartIndex());
			query.setMaxResults(pickinglistDTO.getEndIndex());
		}
		
		List<Object[]> objectsArrayList = query.getResultList();
		if (objectsArrayList != null && objectsArrayList.size() > 0) {
			for (Object[] objectsArray : objectsArrayList) {
				PickinglistResultsDTO pickinglistResultsDTO = new PickinglistResultsDTO();
				
				pickinglistResultsDTO.setPickListnumber(null == objectsArray[0] ?"":objectsArray[0].toString());
				pickinglistResultsDTO.setLine(null == objectsArray[1] ?"":objectsArray[1].toString());
				pickinglistResultsDTO.setZone(null == objectsArray[2] ?"":objectsArray[2].toString());
				pickinglistResultsDTO.setShop(null == objectsArray[3] ?"":objectsArray[3].toString());
				pickinglistResultsDTO.setTotalNoOfBox( (Integer) (null == objectsArray[4] ?0:objectsArray[4]) );
				
				if(objectsArray[5].toString().equals("C")){
					status = "Closed";
				}else if(objectsArray[5].toString().equals("O")){
					status = "Open";
				}else if(objectsArray[5].toString().equals("P")){
					status = "Partial";	
				}else{
					status = "";
				}
				
				pickinglistResultsDTO.setStatus(null == objectsArray[5] ?"":status);
				pickinglistResultsDTO.setAllocation(null == objectsArray[6] ?"":objectsArray[6].toString());
				pickinglistResultsDTO.setCreationTime(null == objectsArray[7] ?"":objectsArray[7].toString());
				pickinglistResultsDTO.setClosureTime(null == objectsArray[8] ?"":objectsArray[8].toString());
				pickinglistResultsDTO.setDeviceId(null == objectsArray[9] ?"":objectsArray[9].toString());
				pickinglistResultsDTO.setTotalNoOfParts( (Integer) (null == objectsArray[10] ?0:objectsArray[10]) );
				
				pickinglistResultsDTOList.add(pickinglistResultsDTO);
			}
		}
		LOGGER.debug("Exiting getPickingList bean");
		return pickinglistResultsDTOList;
	}

	@SuppressWarnings("unchecked")
	public int getClosurePickingListDetail(String deviceTranId, String partNumber,String userId) {
		LOGGER.debug("Entering getClosurePickingListDetail bean");
		
		String querySql = "UPDATE D SET STATUS = 'C',LAST_UPDATED_BY='"+userId+"',LAST_UPDATED_ON=getdate(),CLOSED_BY='WEB' "
				+ "FROM TBL_LNFD_DETAILS D JOIN TBL_LNFD_STK_MASTER M ON D.LNFD_ID = M.LNFD_ID WHERE "
				+ "D.PICKING_LIST = :deviceTranId AND M.PART_NO in (:partNumber) ";
		
		List<String> partno = Arrays.asList(partNumber.split(",")); 
		LOGGER.debug("**Closure Pick List Query :"+querySql);
		Query query = entityManager.createNativeQuery(querySql);
		query.setParameter("deviceTranId", deviceTranId);
		query.setParameter("partNumber", partno);		
		LOGGER.debug("partno in update dtl query : "+partno);
		int i = query.executeUpdate();	
		LOGGER.debug("Closure update value : "+i);		
		if(i > 0){			
			String querySqlHdr = "UPDATE Hdr SET Hdr.NO_OPEN_BOX=abs(NO_BOX-NO_OF_BOXES_OUT),Hdr.NO_OPEN_PART=abs(NO_PART-PART_NO_OUT) FROM  TBL_LNFD_MASTER Hdr "
					+ "inner join ( SELECT D.PICKING_LIST,count(M.PART_NO) AS PART_NO_OUT ,SUM(NO_BOX) AS NO_OF_BOXES_OUT FROM TBL_LNFD_DETAILS D  "
					+ "join TBL_LNFD_STK_MASTER M ON M.LNFD_ID=D.LNFD_ID WHERE D.PICKING_LIST =:deviceTranId AND M.PART_NO in (:partNumber) "
					+ "GROUP BY D.PICKING_LIST ) OUT_RES ON  hdr.PICKING_LIST =OUT_RES.PICKING_LIST "
					+ "WHERE Hdr.PICKING_LIST = :deviceTranId ";
			
			Query queryHdr = entityManager.createNativeQuery(querySqlHdr);
			queryHdr.setParameter("deviceTranId", deviceTranId);
			queryHdr.setParameter("partNumber", partno);
			LOGGER.debug("partno in update master query : "+partno);
			LOGGER.debug("**MAster Pick List update Query :"+querySqlHdr);
			int hdrUpdate = queryHdr.executeUpdate();	
			LOGGER.debug("hdrUpdate value : "+hdrUpdate);
			getStatus(deviceTranId,partNumber,i,userId);	
		}			
		return i;
	}
	
	private void getStatus(String deviceTranId, String partNumber, int i,String userId) {
		int j = 0;
		String querySql = "select distinct status from TBL_LNFD_DETAILS D join TBL_LNFD_STK_MASTER M on D.LNFD_ID = M.LNFD_ID "
				+ " where PICKING_LIST=:deviceTranId ";
		Query query = entityManager.createNativeQuery(querySql);
		query.setParameter("deviceTranId", deviceTranId);
		List<String> stsArrayList = query.getResultList();
		LOGGER.debug("stsArrayList in getStatus() : " + stsArrayList);
		if (stsArrayList != null && stsArrayList.size() > 0) {
			if (stsArrayList.size() == 2 || stsArrayList.size() == 3) {
				LOGGER.debug("STATUS : PARTIAL ");
				querySql = "UPDATE M SET M.STATUS = 'P' FROM TBL_LNFD_MASTER M JOIN TBL_LNFD_DETAILS D ON M.PICKING_LIST = D.PICKING_LIST WHERE "
						+ "M.PICKING_LIST = :deviceTranId ";				
			} else if (stsArrayList.size() == 1) {
				for (String objects : stsArrayList) {
					LOGGER.debug("Next in getStatus() : " + objects.trim());
					if (objects.trim().equalsIgnoreCase("C")) {
						LOGGER.debug("STATUS : CLOSED ");
						querySql = "UPDATE M SET M.STATUS = 'C',DEVICE='"+userId+"',CLOSE_TIME=getdate() FROM TBL_LNFD_MASTER M JOIN TBL_LNFD_DETAILS D ON M.PICKING_LIST = D.PICKING_LIST WHERE "
								+ "M.PICKING_LIST = :deviceTranId ";
					} else if (objects.trim().equalsIgnoreCase("O")) {
						LOGGER.debug("STATUS : OPEN ");
						querySql = "UPDATE M SET M.STATUS = 'O' FROM TBL_LNFD_MASTER M JOIN TBL_LNFD_DETAILS D ON M.PICKING_LIST = D.PICKING_LIST WHERE "
								+ "M.PICKING_LIST = :deviceTranId ";
					} else if (objects.trim().equalsIgnoreCase("P")) {
						LOGGER.debug("STATUS : PARTIAL ");
						querySql = "UPDATE M SET M.STATUS = 'P' FROM TBL_LNFD_MASTER M JOIN TBL_LNFD_DETAILS D ON M.PICKING_LIST = D.PICKING_LIST WHERE "
								+ "M.PICKING_LIST = :deviceTranId ";
					}
				}
			}
			query = entityManager.createNativeQuery(querySql);
			query.setParameter("deviceTranId", deviceTranId);
			j = query.executeUpdate();
		}
		LOGGER.debug("Final update value : "+j);
	}
	
	@SuppressWarnings("unchecked")
	public PickinglistResultsDTO getPickingListDetail(String deviceTranId) {
		LOGGER.debug("Entering getPickingListDetail bean");
		PickinglistResultsDTO pickinglistResultsDTO = new PickinglistResultsDTO();
		String status = "";	
		
		Query querySP = entityManager.createNativeQuery(" EXEC USP_LINEFEEDING_GET_FIFO '', '','','','"+deviceTranId+"','' , 1 ");
		String returnMsg = (String) querySP.getSingleResult();
		LOGGER.debug("returnMsg in getPickListDtlsAndroid : "+returnMsg);
		
		if(returnMsg!=null && !returnMsg.toString().trim().equalsIgnoreCase("") && returnMsg.trim().equalsIgnoreCase("CALCULATED")){
		
		String querySql = " select D.PICKING_LIST, M.PART_TYPE, M.PART_NO, D.LOCATION, D.NO_BOX, P.SNIP, D.QTY, D.WIP, D.REMAINING_ACTUAL, " 
		+" M.EOP_MARK, D.LAST_UPDATED_BY, D.STATUS, M.MODEL, M.ALLOCATION, M.SUPPLIER_METHOD, D.LINE_STK , M.LINE_LOC, D.NO_OPEN_BOX , NO_OPEN_QTY "
		+" FROM TBL_LNFD_DETAILS D, TBL_LNFD_STK_MASTER M ,PART P " 
		+" WHERE 1=1 AND D.LNFD_ID = M.LNFD_ID and M.PART_NO=P.PART_NO "
		+" AND  D.PICKING_LIST = :deviceTranId ";
		
		LOGGER.debug("**Pick List Query :"+querySql);
		Query query = entityManager.createNativeQuery(querySql);
		query.setParameter("deviceTranId", deviceTranId);
		
		LOGGER.debug("**Pick List Id :"+deviceTranId);
		List<Object[]> objectArrayList = query.getResultList();
		
		LOGGER.debug("**Pick List Detail Siza :"+objectArrayList.size());
		if (objectArrayList != null && objectArrayList.size() > 0) {
		
			List<PickinglistDetailsDTO> pickinglistDetailsDTOLsit = new ArrayList<PickinglistDetailsDTO>();
			for (Object[] objectArray : objectArrayList) {
				
				pickinglistResultsDTO.setPickListnumber(null==objectArray[0]?"":objectArray[0].toString());
				
				PickinglistDetailsDTO pickinglistDetailsDTO = new PickinglistDetailsDTO();
				
				pickinglistDetailsDTO.setPartType(null==objectArray[1]?"":objectArray[1].toString());
				pickinglistDetailsDTO.setPartNumber(null==objectArray[2]?"":objectArray[2].toString());
				pickinglistDetailsDTO.setLocation(null==objectArray[3]?"":objectArray[3].toString());
				pickinglistDetailsDTO.setNoOfBoxes((Integer) (null==objectArray[4]?0:objectArray[4]) );
				pickinglistDetailsDTO.setSnp((Integer) (null==objectArray[5]?0:objectArray[5]) );
				pickinglistDetailsDTO.setQuantity((Integer) (null==objectArray[6]?0:objectArray[6]) );
				pickinglistDetailsDTO.setWip((Integer) (null==objectArray[7]?0:objectArray[7]) );
				pickinglistDetailsDTO.setRemainingActualQty((Integer) (null==objectArray[8]?0:objectArray[8]) );
				pickinglistDetailsDTO.setEopMark(null==objectArray[9]?"":objectArray[9].toString());
				pickinglistDetailsDTO.setDevice(null==objectArray[10]?"":objectArray[10].toString());
				//pickinglistDetailsDTO.setWhOut(null==objectArray[11]?"":objectArray[11].toString());
				if(objectArray[11].toString().equals("C")){
					status = "Closed";
				}else if(objectArray[11].toString().equals("O")){
					status = "Open";
				}else if(objectArray[11].toString().equals("P")){
					status = "Partial";	
				}else{
					status = "";
				}
				pickinglistDetailsDTO.setStatus(null==objectArray[11]?"":status);
				pickinglistDetailsDTO.setModel(null==objectArray[12]?"":objectArray[12].toString());
				pickinglistDetailsDTO.setAllocation(null==objectArray[13]?"":objectArray[13].toString());
				pickinglistDetailsDTO.setSupplierMethod(null==objectArray[14]?"":objectArray[14].toString());
				pickinglistDetailsDTO.setLineStk(null==objectArray[15]?"":objectArray[15].toString());
				pickinglistDetailsDTO.setLineLoc(null==objectArray[16]?"":objectArray[16].toString());
				pickinglistDetailsDTO.setNoOfOpenBoxes((Integer) (null==objectArray[17]?0:objectArray[17]) );
				pickinglistDetailsDTO.setNoOfOpenQty((Integer) (null==objectArray[18]?0:objectArray[18]) );			
				pickinglistDetailsDTOLsit.add(pickinglistDetailsDTO);
			}			
			pickinglistResultsDTO.setDetailsDTOList(pickinglistDetailsDTOLsit);
		}
	}
		LOGGER.debug("Existing getPickingListDetail bean");
		return pickinglistResultsDTO;
	}
	
	@SuppressWarnings("unchecked")
	public List<LineAllocationDTO> getLineAllocation(String plant,String shop) {
		LOGGER.debug("Entering getPickingListDetail bean");
		String querySql = "select distinct line,cast(allocation as decimal(18,0)) allocation from TBL_LNFD_MASTER(nolock) where shop in ('T','K') order by line,allocation";
		LOGGER.debug("**Pick List Query :"+querySql);
		Query query = entityManager.createNativeQuery(querySql);
		/*query.setParameter("shop", shop);*/
		List<Object[]> objectArrayList = query.getResultList();
		List<LineAllocationDTO> lineAllocationList=null;
		if (objectArrayList != null && objectArrayList.size() > 0) {
			lineAllocationList = new ArrayList<LineAllocationDTO>();
			for (Object[] objectArray : objectArrayList) {
				LineAllocationDTO lineAllocation = new LineAllocationDTO();
				lineAllocation.setLine(null==objectArray[0] ? "" : objectArray[0].toString());
				lineAllocation.setAllocation(null==objectArray[1] ? "" : objectArray[1].toString());
				lineAllocationList.add(lineAllocation);
			}
		}
		LOGGER.debug("Existing getPickingListDetail bean");
		return lineAllocationList;
	}

	private String createWhereClause(PickinglistDTO pickinglistDTO, Map<String, Object> map) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String querySql = "";
		String status="",
		chooseZone="";
		
		/*if (checkNull(pickinglistDTO.getPickListnumber())) {*/
		if (pickinglistDTO.getPickListnumber()!=null && !pickinglistDTO.getPickListnumber().toString().trim().equalsIgnoreCase("")
				&& pickinglistDTO.getPickListnumber().length() > 0) {
			map.put("Pick_List_ID", pickinglistDTO.getPickListnumber());
			querySql = querySql + " AND PICKING_LIST=:Pick_List_ID";
		}		
		if (checkNull(pickinglistDTO.getLine())) {
			map.put("Line", pickinglistDTO.getLine());
			querySql = querySql + " AND LINE=:Line";
		}		
		if (checkNull(pickinglistDTO.getShop())) {
			if (pickinglistDTO.getShop().charAt(0) != 'K' )	{
				querySql = querySql + " AND SHOP = '"+pickinglistDTO.getShop().charAt(0)+"'";
			} else {
				querySql = querySql + " AND SHOP IN ('T','K')";
			}
		}
		/*if (checkNull(pickinglistDTO.getAllocation())) {*/
		if (pickinglistDTO.getAllocation()!=0 && pickinglistDTO.getAllocation()>0){
			LOGGER.debug("allocation : "+pickinglistDTO.getAllocation());
			map.put("allocation", pickinglistDTO.getAllocation());
			querySql = querySql + " AND ALLOCATION=:allocation";
		}
		
		if (checkNull(pickinglistDTO.getZone())) {
			/*map.put("Zone", pickinglistDTO.getZone());
			if(pickinglistDTO.getZone().toString().equalsIgnoreCase("Pre Final")){
				chooseZone = "PRE FINAL";
			}else if(pickinglistDTO.getZone().toString().equalsIgnoreCase("C/T")){
				chooseZone = "CHASIS";
			}else if(pickinglistDTO.getZone().toString().equalsIgnoreCase("U/F")){
				chooseZone = "UF";
			}else if(pickinglistDTO.getZone().toString().equalsIgnoreCase("Trim B")){
				chooseZone = "TRIM-B";
			}else if(pickinglistDTO.getZone().toString().equalsIgnoreCase("Trim A")){
				chooseZone = "TRIM-A";
			}
			map.put("Zone", chooseZone);*/
			querySql = querySql + " AND ZONE= '"+pickinglistDTO.getZone().trim()+"'";
		}		
		
		if (checkNull(pickinglistDTO.getStatus())) {
			if(!pickinglistDTO.getStatus().toString().trim().equalsIgnoreCase("")){
			if(pickinglistDTO.getStatus().toString().equalsIgnoreCase("Closed")){
				status = "C";
			}else if(pickinglistDTO.getStatus().equalsIgnoreCase("Open")){
				status = "O";
			}else if(pickinglistDTO.getStatus().toString().equalsIgnoreCase("Partial")){
				status = "P";	
			}
			map.put("status", status);			
			querySql = querySql + " AND STATUS=:status";
		    }
		}

		if (checkNull(pickinglistDTO.getBeginDate())) {
			LOGGER.debug("pickinglistDTO.getBeginDate() : "+dateFormat.format(pickinglistDTO.getBeginDate()));
			map.put("FromDate", dateFormat.format(pickinglistDTO.getBeginDate()));
			querySql = querySql + " AND Convert(varchar(19),CREATION_TIME,120)>=:FromDate";
		}
		
		if (checkNull(pickinglistDTO.getEndDate())) {
			LOGGER.debug("pickinglistDTO.getEndDate() : "+dateFormat.format(pickinglistDTO.getEndDate()));
			map.put("ToDate", dateFormat.format(pickinglistDTO.getEndDate()));
			querySql = querySql + " AND Convert(varchar(19),CREATION_TIME,120)<=:ToDate";
		}
		LOGGER.debug("querySql : " + querySql);
		return querySql;
	}

	private boolean checkNull(Object object) {
		return object != null;
	}

	/*
	 * Zone list
	 */
	public List<PickinglistDTO> getZoneList() {
		LOGGER.debug("Entering Zone bean");
		List<PickinglistDTO> zoneDTOList = new ArrayList<PickinglistDTO>();
		String querySql = "select Distinct zone from [dbo].[TBL_LNFD_STK_MASTER] WHERE 1=1";
		Query query = entityManager.createNativeQuery(querySql);
		List<String> objectsArrayList = query.getResultList();
		if (objectsArrayList != null && objectsArrayList.size() > 0) {
			for (String objects : objectsArrayList) {
				PickinglistDTO zoneDTO = new PickinglistDTO();
				zoneDTO.setZone(objects.trim());
				zoneDTOList.add(zoneDTO);
			}
		}
		LOGGER.debug("Exiting zone bean");
		return zoneDTOList;
	}
	
	// ADDED FOR UAT REQ TO MERGE T&K SHOP DROP DOWN -START
	public List<PickinglistDTO> getShopByPlantId(String plantId) {
		// TODO Auto-generated method stub
		LOGGER.debug("getShopByPlantId() method starts ");
		// List<ShopDTO> shopDTOs = new ArrayList<ShopDTO>();
		List<PickinglistDTO> shopDTOs = new ArrayList<PickinglistDTO>();
		com.rnaipl.wms.entities.Plant plants = entityManager.find(com.rnaipl.wms.entities.Plant.class, plantId);
		if (plants != null) {
			List<Shop> shops = plants.getShops();
			String temp = "";
			for (Shop shop : shops) {
				PickinglistDTO pickinglistDTO = new PickinglistDTO();
				if (shop.getShopId().equalsIgnoreCase("T") || shop.getShopId().equalsIgnoreCase("K")) {
					temp = temp + shop.getShopId() + " - " + shop.getShopName() + " & ";
				} else {
					pickinglistDTO.setShopId(shop.getShopId());
					pickinglistDTO.setShopName(shop.getShopName());
					pickinglistDTO.setShopList(shop.getShopId() + " - " + shop.getShopName());
					shopDTOs.add(pickinglistDTO);
				}
			}
			if (temp != "") {
				int index = temp.lastIndexOf('&');
				PickinglistDTO pickinglistDTO = new PickinglistDTO();
				pickinglistDTO.setShopId("T','K");
				pickinglistDTO.setShopList(temp.substring(0, (index - 1)));
				shopDTOs.add(pickinglistDTO);
			}
		} else {
			return null;
		}
		LOGGER.debug("getShopByPlantId() method Ends ");
		return shopDTOs;
	}
		// ADDED FOR UAT REQ TO MERGE T&K SHOP DROP DOWN -END 


   //Added by Meena - To get the image path from DB - Start
	public String getImageLogoPath() {
		String logoPath = "";
		try {
			Query query = entityManager.createNativeQuery(
					"SELECT VALUE FROM COMMON_PARAMETER WHERE name = '" + WMSConstants.DOWNLOAD_LOGO + "'");
			logoPath = (String) query.getSingleResult();
		} catch (Exception e) {
			LOGGER.error("TagSheetBean--> getTagSheetPath", e);
		}
		return logoPath;
	}
   //Added by Meena - To get the image path from DB - End 

	public List<PickinglistDTO> getAllocationByZone(String zone) {
		LOGGER.debug("getAllocatioByZone() method starts ");
		List<PickinglistDTO> allocationDTO = new ArrayList<PickinglistDTO>();
		/*Query query = entityManager
				.createNativeQuery("select Distinct allocation from [dbo].[TBL_LNFD_STK_MASTER] WHERE ZONE = '" + zone
						+ "' order by allocation");*/
		Query query = entityManager
				.createNativeQuery("select Distinct cast(allocation as int) from [dbo].[TBL_LNFD_STK_MASTER] order by cast(allocation as int) ");
		/*List<String> object = query.getResultList();*/
		List<Integer> object = query.getResultList();
		if (!object.isEmpty()) {
			PickinglistDTO pickinglistDTO;
			for (Integer objects : object) {
				pickinglistDTO = new PickinglistDTO();
				pickinglistDTO.setAllocation(objects);
				allocationDTO.add(pickinglistDTO);
			}
		}
		LOGGER.debug("Size :" + allocationDTO.size());
		LOGGER.debug("getAllocatioByZone() method Ends ");
		return allocationDTO;
	}

	public int getPickingListCount(PickinglistDTO pickinglistDTO) {
		LOGGER.debug("Entering getPickingListCount bean");
		List<PickinglistResultsDTO> pickinglistResultsDTOList = new ArrayList<PickinglistResultsDTO>();
		Map<String, Object> map = new LinkedHashMap<String, Object>();
		String querySql = "SELECT COUNT(*) FROM dbo.TBL_LNFD_MASTER WHERE 1=1";
		querySql = querySql + createWhereClause(pickinglistDTO, map);
		LOGGER.debug("Count Query : " + querySql.toString());
		Query query = entityManager.createNativeQuery(querySql);
		if (map != null && !map.isEmpty()) {
			for (String param : map.keySet()) {
				query.setParameter(param, map.get(param));
			}
		}
		int noOfRecords = (Integer) query.getSingleResult();
		LOGGER.debug("recordCount :  " + noOfRecords);
		return noOfRecords;
	}
	
	//For Handy webservice
	public PickListAndroidDTO getPickListDtlsAndroid(String plant, String line, String shop, String allocation,
			String pickingList,String deviceID) {
		String returnMsg = "";
		PickListAndroidDTO pickinglistResultsDTOList = new PickListAndroidDTO(); 
		try {
			LOGGER.debug("deviceID in get method : " +deviceID);
			if(deviceID!=null && deviceID.trim().length()>0){
				try{
					Query query = entityManager.createNativeQuery(" SELECT t.isProcessing FROM TBL_LNFD_HANDY_PROCESSING_DTLS t where t.device_ID='"+deviceID+"' ");
					Boolean processFlag = (Boolean) query.getSingleResult();
					LOGGER.debug("processFlag" +processFlag);	
					if(processFlag==false){
						Query querySP = entityManager.createNativeQuery(" EXEC USP_LINEFEEDING_GET_FIFO '"+plant+"', '"+line+"','"+shop+"','"+allocation+"','"+pickingList+"','"+deviceID+"', 0  ");
						returnMsg = (String) querySP.getSingleResult();
						LOGGER.debug("returnMsg in getPickListDtlsAndroid : "+returnMsg);
						if(returnMsg!=null && !returnMsg.toString().trim().equalsIgnoreCase("") && returnMsg.trim().equalsIgnoreCase("CALCULATED")){
							pickinglistResultsDTOList = getPickingRanDtls(line, allocation,pickingList);
						}
					}else if(processFlag==true){
						pickinglistResultsDTOList.setError("Already in Processing Stage");
					}
				}catch(NoResultException ex){	
					Query querySP = entityManager.createNativeQuery(" EXEC USP_LINEFEEDING_GET_FIFO '"+plant+"', '"+line+"','"+shop+"','"+allocation+"','"+pickingList+"','"+deviceID+"', 0  ");
					returnMsg = (String) querySP.getSingleResult();
					LOGGER.debug("returnMsg in getPickListDtlsAndroid : "+returnMsg);
					if(returnMsg!=null && !returnMsg.toString().trim().equalsIgnoreCase("") && returnMsg.trim().equalsIgnoreCase("CALCULATED")){
						pickinglistResultsDTOList = getPickingRanDtls(line, allocation,pickingList);
					}
				}
			}else{
				Query querySP = entityManager.createNativeQuery(" EXEC USP_LINEFEEDING_GET_FIFO '"+plant+"', '"+line+"','"+shop+"','"+allocation+"','"+pickingList+"','"+deviceID+"', 0  ");
				returnMsg = (String) querySP.getSingleResult();
				LOGGER.debug("returnMsg in getPickListDtlsAndroid : "+returnMsg);
				if(returnMsg!=null && !returnMsg.toString().trim().equalsIgnoreCase("") && returnMsg.trim().equalsIgnoreCase("CALCULATED")){
					pickinglistResultsDTOList = getPickingRanDtls(line, allocation,pickingList);
				}
			}
		} catch (Exception e) {
			LOGGER.error("Error in getPickListDtlsAndroid", e);
		}
		return pickinglistResultsDTOList;
	}	
	
	public PickListAndroidDTO getPickingRanDtls(String line, String allocation,String pickingList){
		List<Object[]> pickListHdr= new ArrayList<Object[]>();
		List<Object[]> pickListDtls= new ArrayList<Object[]>();
		List<Object[]> pickListRan= new ArrayList<Object[]>();	
		
		//Hdr details - start //
		StringBuffer queryBuffer = new StringBuffer();
		queryBuffer.append("  Select PICKING_LIST,LINE,ZONE,SHOP,ALLOCATION,NO_OPEN_BOX AS NO_BOXES, NO_OPEN_PART AS NO_PARTS,"
				+ "[STATUS],CREATION_TIME  from TBL_LNFD_MASTER(nolock) Hdr WHERE LINE='"+line+"' and ALLOCATION='"+allocation+"' "
						+ "and SHOP in ('T','K') AND STATUS IN ('O','P')  ");
		if(pickingList!=null && !pickingList.trim().equalsIgnoreCase("") && !pickingList.trim().equalsIgnoreCase("ALL")){
			queryBuffer.append(" and PICKING_LIST = '"+pickingList+"' ");
		}
		Query query = entityManager.createNativeQuery(queryBuffer.toString());
		pickListHdr =  query.getResultList();
		LOGGER.debug("pickListHdr size : " + pickListHdr.size());
		
		PickListAndroidDTO pickinglistResultsDTOList = new PickListAndroidDTO();
		List<PickingListHdrDTO> PickingListHdrDTOList = new ArrayList<PickingListHdrDTO>(); 
		if (pickListHdr != null && pickListHdr.size() > 0) {
			for (Object[] objectsArray : pickListHdr) {
				PickingListHdrDTO pickingListHdrDto = new PickingListHdrDTO();
				
				pickingListHdrDto.setPickListnumber(null == objectsArray[0] ?"":objectsArray[0].toString());
				pickingListHdrDto.setLine(null == objectsArray[1] ?"":objectsArray[1].toString());
				pickingListHdrDto.setZone(null == objectsArray[2] ?"":objectsArray[2].toString());
				pickingListHdrDto.setShop(null == objectsArray[3] ?"":objectsArray[3].toString());
				pickingListHdrDto.setAllocation(null == objectsArray[4] ?"":objectsArray[4].toString());				
				pickingListHdrDto.setTotalNoOfBox( (Integer) (null == objectsArray[5] ?0:objectsArray[5]) );
				pickingListHdrDto.setTotalNoOfParts( (Integer) (null == objectsArray[6] ?0:objectsArray[6]) );
				pickingListHdrDto.setStatus(null == objectsArray[7] ?"":objectsArray[7].toString());				
				pickingListHdrDto.setCreationTime(null == objectsArray[8] ?"":objectsArray[8].toString());				
				PickingListHdrDTOList.add(pickingListHdrDto);
			}
		}
		pickinglistResultsDTOList.setPickList(PickingListHdrDTOList);
		//Hdr details - end
		
		//Pick list detail - start //
		StringBuffer queryBuffer1 = new StringBuffer();
		queryBuffer1.append(" Select dtl.PICKING_LIST,M.PART_NO,dtl.NO_OPEN_BOX,NO_OPEN_QTY,dtl.STATUS,P.SNIP "
				+ " from TBL_LNFD_DETAILS dtl(nolock) inner join TBL_LNFD_MASTER(nolock) hdr ON hdr.PICKING_LIST = dtl.PICKING_LIST "
				+ " inner join TBL_LNFD_STK_MASTER M ON M.LNFD_ID=dtl.LNFD_ID "
				+ " inner join [dbo].PART P	ON P.PART_NO = M.PART_NO "
				+ " WHERE hdr.LINE='"+line+"' and hdr.ALLOCATION='"+allocation+"' and hdr.SHOP in ('T','K')	AND dtl.STATUS IN ('O','P') "
						+ " and hdr.status in ('O','P') ");
		if(pickingList!=null && !pickingList.trim().equalsIgnoreCase("") && !pickingList.trim().equalsIgnoreCase("ALL")){
			queryBuffer1.append(" and dtl.PICKING_LIST = '"+pickingList+"' ");
		}
		queryBuffer1.append(" ORDER BY dtl.PICKING_LIST ");
		Query query1 = entityManager.createNativeQuery(queryBuffer1.toString());
		pickListDtls =  query1.getResultList();
		
		LOGGER.debug("pickListDtls size : " + pickListDtls.size());
		
		List<PickingListDetailDTO> PickingListDetailDTOList = new ArrayList<PickingListDetailDTO>(); 
		if (pickListDtls != null && pickListDtls.size() > 0) {
			for (Object[] objectsArray : pickListDtls) {
				PickingListDetailDTO pickingListDtlDto = new PickingListDetailDTO();
				
				pickingListDtlDto.setPickListnumber(null == objectsArray[0] ?"":objectsArray[0].toString());
				pickingListDtlDto.setPartNo(null == objectsArray[1] ?"":objectsArray[1].toString());
				pickingListDtlDto.setTotalNoOpenBox((Integer) (null == objectsArray[2] ? 0 :objectsArray[2]) );
				pickingListDtlDto.setTotalNoOpenQty((Integer) (null == objectsArray[3] ? 0 :objectsArray[3]) );
				pickingListDtlDto.setStatus(null == objectsArray[4] ?"":objectsArray[4].toString());				
				pickingListDtlDto.setSnip((Integer) (null == objectsArray[5] ?0:objectsArray[5]) );				
				PickingListDetailDTOList.add(pickingListDtlDto);
			}
		}		
		//pick list details - end //
		pickinglistResultsDTOList.setPartList(PickingListDetailDTOList);
		
		//Pick list ran details - start //
		StringBuffer queryBuffer2 = new StringBuffer();
		queryBuffer2.append(" SELECT R.PICKING_LIST,R.PART_NO,R.LOCATION,R.RAN,R.QTY,R.NO_BOX,PART_ORDER,RAN_ORDER,R.AGEINGDAYS "
				+ " FROM TBL_LNFD_RAN_DETAILS(nolock) R	INNER JOIN TBL_LNFD_MASTER(nolock) hdr ON  hdr.PICKING_LIST=R.PICKING_LIST "
				+ " WHERE hdr.LINE='"+line+"' and hdr.ALLOCATION='"+allocation+"' and hdr.SHOP in ('T','K') and hdr.status in ('O','P') ");
		if(pickingList!=null && !pickingList.trim().equalsIgnoreCase("") && !pickingList.trim().equalsIgnoreCase("ALL")){
			queryBuffer2.append(" and hdr.PICKING_LIST = '"+pickingList+"' ");
		}
		Query query2 = entityManager.createNativeQuery(queryBuffer2.toString());							
		pickListRan =  query2.getResultList();
		
		LOGGER.debug("pickListRan size : " + pickListRan.size());
		
		List<PickingListRanDTO> PickingListRanDTOList = new ArrayList<PickingListRanDTO>(); 
		if (pickListRan != null && pickListRan.size() > 0) {
			for (Object[] objectsArray : pickListRan) {
				PickingListRanDTO pickingListRanDto = new PickingListRanDTO();
				
				pickingListRanDto.setPickListnumber(null == objectsArray[0] ?"":objectsArray[0].toString());
				pickingListRanDto.setPartNo(null == objectsArray[1] ?"":objectsArray[1].toString());
				pickingListRanDto.setLocation(null == objectsArray[2] ?"":objectsArray[2].toString());
				pickingListRanDto.setRanNo(null == objectsArray[3] ?"":objectsArray[3].toString());
				pickingListRanDto.setQty((Integer) (null == objectsArray[4] ? 0 :objectsArray[4]) );
				pickingListRanDto.setTotalNoOpenBox((Integer) (null == objectsArray[5] ? 0 :objectsArray[5]) );
				pickingListRanDto.setPartOrder((Integer) (null == objectsArray[6] ? 0 :objectsArray[6]) );
				pickingListRanDto.setRanOrder((Integer) (null == objectsArray[7] ? 0 :objectsArray[7]) );
				pickingListRanDto.setAgeingDays((Integer) (null == objectsArray[8] ? 0 :objectsArray[8]) );
				PickingListRanDTOList.add(pickingListRanDto);
			}
		}		
		//Pick list ran details - end //
		pickinglistResultsDTOList.setRanList(PickingListRanDTOList);		
		return pickinglistResultsDTOList;	
	}
}
