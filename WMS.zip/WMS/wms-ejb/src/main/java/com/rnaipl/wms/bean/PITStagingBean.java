package com.rnaipl.wms.bean;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.PITCumulativeReportDTO;
import com.rnaipl.wms.dto.PITStagingDTO;
import com.rnaipl.wms.dto.PITTransactionReportDTO;
import com.rnaipl.wms.entities.PITStagingEntity;
import com.rnaipl.wms.util.ApplicationUtility;
import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSBeanUtil;
import com.rnaipl.wms.util.WMSConstants;

/*AJ00482484 -- PIT Automation -- START */

@Stateless
@LocalBean
public class PITStagingBean implements PITStaging{
	
	private static final Logger LOGGER = Logger.getLogger(PITStagingBean.class);
	
	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
    private EntityManager entityManager;

	
	public int insertPitStaging(List<PITStagingDTO> pitStagingDto) {
		LOGGER.debug("**In Insert PIT Staging ->Pit Details Size == " + pitStagingDto.size());
		
		for(PITStagingDTO pitStaging : pitStagingDto){
			PITStagingEntity pitStagingEntity = new PITStagingEntity();
			
			pitStagingEntity.setTransactionId(pitStaging.getTransactionId());
			pitStagingEntity.setPartNumber(pitStaging.getPartNumber());
			pitStagingEntity.setLocation(pitStaging.getLocation());
			
			if((pitStaging.getRan()==null || pitStaging.getRan().trim().equals("")))
			{
				pitStagingEntity.setRan(WMSConstants.DEFAULT_RAN);
			}
			else{
				pitStagingEntity.setRan(pitStaging.getRan());	
			}
			
			pitStagingEntity.setSnp(pitStaging.getSnp());
			pitStagingEntity.setNumberOfBoxes(pitStaging.getNumberOfBoxes());
			pitStagingEntity.setOpenQuantity(pitStaging.getOpenQuantity());
			pitStagingEntity.setTotalQuantity(pitStaging.getTotalQuantity());
			pitStagingEntity.setDateTime(ApplicationUtility.convertStringToSqlTimeStamp(pitStaging.getDateTime(), WMSConstants.TIMESTAMP_FORMAT));
			pitStagingEntity.setDeviceId(pitStaging.getDeviceId());
			pitStagingEntity.setTransactionType(pitStaging.getTransactionType().toUpperCase());
			pitStagingEntity.setIsUpdated(pitStaging.getIsUpdated());
			pitStagingEntity.setCommentsFlag(pitStaging.getCommentsFlag());
			
			if((pitStaging.getComments()==null || pitStaging.getComments().trim().equals(""))){
				pitStagingEntity.setComments("NO COMMENTS");
			}else{
				pitStagingEntity.setComments(pitStaging.getComments());
			}
			
			LOGGER.debug("Transaction Id = "+pitStaging.getTransactionId());
			LOGGER.debug("Part Number = "+pitStaging.getPartNumber());
			LOGGER.debug("Location = "+pitStaging.getLocation());
			LOGGER.debug("RAN = "+pitStaging.getRan());
			LOGGER.debug("SNP = "+pitStaging.getSnp());
			LOGGER.debug("No Of Boxes = "+pitStaging.getNumberOfBoxes());
			LOGGER.debug("Open Quantity = "+pitStaging.getOpenQuantity());
			LOGGER.debug("Total Quantity = "+pitStaging.getTotalQuantity());
			LOGGER.debug("Date Time = "+pitStaging.getDateTime());
			LOGGER.debug("Device Id = "+pitStaging.getDeviceId());
			LOGGER.debug("Transaction Type = "+pitStaging.getTransactionType());
			LOGGER.debug("Is updated = "+pitStaging.getIsUpdated());
			LOGGER.debug("Comments Flag = "+pitStaging.getCommentsFlag());
			LOGGER.debug("Comments = "+pitStaging.getComments());
			LOGGER.debug("-------------------------------------------------------------------");
			
			entityManager.persist(pitStagingEntity);
		}
		
		return 1;
	}

	
	public int getTransactionReportCount(PITTransactionReportDTO pitTransactionReportDto) {
		LOGGER.debug("In PITStaging Bean -- getTransactionReportCount() method");
		StringBuffer queryStringBuf = new StringBuffer();
		
		if(pitTransactionReportDto.getScanned().equalsIgnoreCase("YES")){
			queryStringBuf.append(getPitScannedQuery(pitTransactionReportDto));
		}else if(pitTransactionReportDto.getScanned().equalsIgnoreCase("NO")){
			queryStringBuf.append(getPitNotScannedQuery(pitTransactionReportDto));
		}else{
			queryStringBuf.append(getPitAllQuery(pitTransactionReportDto));
		}
		
		Query query = entityManager.createNativeQuery(queryStringBuf.toString());
		List<Object[]> queryDatas = query.getResultList();
		LOGGER.debug("getTransactionReportCount() == PIT Transaction Report Data size ==  " + queryDatas.size());
		
		int noOfRecords = queryDatas.size();
        LOGGER.debug("PIT Transaction Report Count :  " + noOfRecords);
		return noOfRecords;
	}
	
	
	public List<PITTransactionReportDTO> getPitTransactionReportList(PITTransactionReportDTO pitTransactionReportDto) {
		LOGGER.debug("In PITStaging Bean -- getPitTransactionReportList() method");
		List<PITTransactionReportDTO> pitTransactionReportList  = new ArrayList<PITTransactionReportDTO>();
		
		StringBuffer queryStringBuf = new StringBuffer();
		
		if(pitTransactionReportDto.getScanned().equalsIgnoreCase("YES")){
			queryStringBuf.append(getPitScannedQuery(pitTransactionReportDto));
		}else if(pitTransactionReportDto.getScanned().equalsIgnoreCase("NO")){
			queryStringBuf.append(getPitNotScannedQuery(pitTransactionReportDto));
		}else{
			queryStringBuf.append(getPitAllQuery(pitTransactionReportDto));
		}
		
		Query query = entityManager.createNativeQuery(queryStringBuf.toString());
		
		if(pitTransactionReportDto.getIsFullDownload()!=1){
			query.setFirstResult(pitTransactionReportDto.getStartIndex());
			query.setMaxResults(pitTransactionReportDto.getEndIndex());
		}
		
		List<Object[]> queryDatas = query.getResultList();
		LOGGER.debug("getPitTransactionReportList() ==PIT Transaction Report Data size ==  " + queryDatas.size());
		
		if(null != queryDatas && queryDatas.size() > 0){
			for(int i = 0; i<queryDatas.size(); i++){
				PITTransactionReportDTO resultDto = new PITTransactionReportDTO();
				Object[] data = queryDatas.get(i);
				
				int index = 0;
				resultDto.setTransactionId((null == data[index] ? "" : data[index].toString()));
				
				index++;
				resultDto.setPartNumber((null == data[index] ? "" : data[index].toString()));
				
				index++;
				resultDto.setLocation((null == data[index] ? "" : data[index].toString()));
				
				index++;
				resultDto.setRan((null == data[index] ? "" : data[index].toString()));
				
				index++;
				resultDto.setSnp((Integer)data[index]);
				
				index++;
				resultDto.setNoOfBoxes((Integer)data[index]);
				
				index++;
				if(null == data[index]){
					resultDto.setOpenQuantity("");
				}else{
					int openQty = (Integer)data[index];
					resultDto.setOpenQuantity(Integer.toString(openQty));
				}
				
				
				index++;
				if(null == data[index]){
					resultDto.setTotalQuantity("");
				}else{
					int totalQty = (Integer)data[index];
					resultDto.setTotalQuantity(Integer.toString(totalQty));
				}
				
				index++;
				resultDto.setDateTime((Timestamp) data[index]);
				
				index++;
				resultDto.setDeviceId((null == data[index] ? "" : data[index].toString()));
				
				index++;
				resultDto.setTransactionType((null == data[index] ? "" : data[index].toString()));
				
				index++;
				resultDto.setIsUpdated((null == data[index] ? "" : data[index].toString()));
				
				index++;
				if(null == data[index]){
					resultDto.setCommentsFlag(-1);
				}else{
					resultDto.setCommentsFlag((Integer)data[index]);
				}
				
				
				index++;
				resultDto.setComments((null == data[index] ? "" : (data[index].toString().trim().equalsIgnoreCase("NO COMMENTS") || data[index].toString().trim().equalsIgnoreCase("empty")) ? "" : data[index].toString()));
				
				index++;
				resultDto.setWmsStockQuantity((null == data[index] ? "" : (data[index].toString().trim().equalsIgnoreCase("NO COMMENTS") || data[index].toString().trim().equalsIgnoreCase("empty")) ? "" : data[index].toString()));
				//int wmsStkQty = (Integer)data[index];
				//resultDto.setWmsStockQuantity(wmsStkQty == -1 ? "" : Integer.toString(wmsStkQty));
				
				index++;
				resultDto.setStockDifference((null == data[index] ? "" : (data[index].toString().trim().equalsIgnoreCase("NO COMMENTS") || data[index].toString().trim().equalsIgnoreCase("empty")) ? "" : data[index].toString()));
				/*if(null == data[index]){
					resultDto.setStockDifference("");
				}else{
					int stkDiff = (Integer)data[index];
					resultDto.setStockDifference(stkDiff == -1 ? "" : Integer.toString(stkDiff));
				}*/
				
				index++;
				resultDto.setRecount((null == data[index] ? "" : data[index].toString().trim().equalsIgnoreCase("empty") ? "" : data[index].toString()));
				
				index++;
				resultDto.setUpdatedDateTime((Timestamp) data[index]);
				
				pitTransactionReportList.add(resultDto);
			}
		}
		
		return pitTransactionReportList;
	}
	
	public String getPitScannedQuery(PITTransactionReportDTO pitTransactionReportDto){
		StringBuffer query = new StringBuffer();
		
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		query.append("SELECT TRANSACTION_ID, PART_NO, LOCATION, RAN, SNP, NO_OF_BOXES, OPEN_QUANTITY, ");
		query.append(" TOTAL_QUANTITY, DATE_TIME, DEVICE_ID, TRANSACTION_TYPE, ISUPDATED, COMMENTS_FLAG, ");
		query.append(" COMMENTS, WMS_STOCK_QUANTITY, STOCK_DIFFERENCE, RECOUNT, UPDATED_DATETIME FROM DBO.PIT_HISTORY");
		query.append(" WHERE 1=1 ");
		
		if(null != pitTransactionReportDto.getRanList() && pitTransactionReportDto.getRanList().size() > 0){
			String ranString = queryStr(pitTransactionReportDto.getRanList());
			LOGGER.debug("PIT Table Search Input Rans == "+ranString);
			query.append(" AND RAN IN ("); query.append(ranString);  query.append(")");
		}
		
		if(null != pitTransactionReportDto.getPartList() && pitTransactionReportDto.getPartList().size() > 0){
			String partString = queryStr(pitTransactionReportDto.getPartList());
			LOGGER.debug("PIT Table Search Input Parts == "+partString);
			query.append(" AND PART_NO IN ("); query.append(partString);  query.append(")");
		}
		
		if(null != pitTransactionReportDto.getLocationList() && pitTransactionReportDto.getLocationList().size() > 0){
			String locationString = queryStr(pitTransactionReportDto.getLocationList());
			LOGGER.debug("PIT Table Search Input Locations == "+locationString);
			query.append(" AND LOCATION IN ("); query.append(locationString);  query.append(")");
		}
		
		if(null != pitTransactionReportDto.getRecount() && pitTransactionReportDto.getRecount().equalsIgnoreCase("YES")){
			query.append(" AND RECOUNT = '");query.append("YES"); query.append("'");
		}
		
		if(null != pitTransactionReportDto.getRecount() && pitTransactionReportDto.getRecount().equalsIgnoreCase("NO")){
			query.append(" AND RECOUNT = '");query.append("NO"); query.append("'");
		}
		
		if(null != pitTransactionReportDto.getDeviceId() && pitTransactionReportDto.getDeviceId().length() > 0){
			query.append(" AND DEVICE_ID = '");query.append(pitTransactionReportDto.getDeviceId()); query.append("'");
		}
		
		if(null != pitTransactionReportDto.getPlant() && pitTransactionReportDto.getPlant().length() > 0){
			query.append(" AND SUBSTRING(LOCATION, 1, 1) = '");query.append(pitTransactionReportDto.getPlant()); query.append("'");
		}
		
		if(null != pitTransactionReportDto.getShop() && pitTransactionReportDto.getShop().length() > 0){
			query.append(" AND SUBSTRING(LOCATION, 2, 1) = '");query.append(pitTransactionReportDto.getShop()); query.append("'");
		}
		
		if (null != pitTransactionReportDto.getFromDate() || null != pitTransactionReportDto.getToDate()) {
			
			Map<String,Date> shiftTimes  = WMSBeanUtil.getShiftTime("",pitTransactionReportDto.getFromDate(),pitTransactionReportDto.getToDate());
			
			pitTransactionReportDto.setFromDate(shiftTimes.get("fromDate"));
			pitTransactionReportDto.setToDate(shiftTimes.get("toDate"));
			
			LOGGER.debug("PIT Transaction Report From Date -> "+ dateFormatter.format(pitTransactionReportDto.getFromDate()));
			LOGGER.debug("PIT Transaction Report To Date -> "+ dateFormatter.format(pitTransactionReportDto.getToDate()));
			
			query.append(" AND UPDATED_DATETIME >= '"+ dateFormatter.format(pitTransactionReportDto.getFromDate()) + "'");
			query.append(" AND UPDATED_DATETIME < '"+ dateFormatter.format(pitTransactionReportDto.getToDate()) + "'");
		}
		
		LOGGER.debug("Query Generated for PIT Scanned Transaction Report == "+query.toString());
		
		return query.toString();
	}
	
	public String getPitNotScannedQuery(PITTransactionReportDTO pitTransactionReportDto){
		StringBuffer query = new StringBuffer();
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		query.append(" SELECT TRANSACTION_ID, PART_NO, LOCATION, RAN, SNP, NO_OF_BOXES, OPEN_QUANTITY, TOTAL_QUANTITY, ");
		query.append(" DATE_TIME, DEVICE_ID, TRANSACTION_TYPE, ISUPDATED, COMMENTS_FLAG, COMMENTS, WMS_STOCK_QUANTITY, ");
		query.append("STOCK_DIFFERENCE, RECOUNT, UPDATED_DATETIME FROM (");
		
		query.append(" SELECT ");
		query.append("  CASE ");
		query.append(" WHEN PIT.TRANSACTION_ID IS NOT NULL THEN NULL ");
		query.append(" WHEN PIT.TRANSACTION_ID = 'EMPTY' THEN '' ");
		query.append(" ELSE NULL ");
		query.append(" END AS TRANSACTION_ID, ");
		
		query.append(" PIT.PART_NO, PIT.LOCATION, PIT.RAN, ");
		
		query.append(" CASE ");
		query.append(" WHEN PIT.SNP IS NOT NULL THEN NULL ");
		query.append(" WHEN PIT.SNP = -1234567890 THEN 0 ");
		query.append(" ELSE NULL ");
		query.append(" END AS SNP, ");
		
		query.append(" CASE ");
		query.append(" WHEN PIT.NO_OF_BOXES IS NOT NULL THEN NULL ");
		query.append(" WHEN PIT.NO_OF_BOXES = -1234567890 THEN 0 ");
		query.append(" ELSE NULL ");
		query.append(" END AS NO_OF_BOXES, ");
		
		query.append(" CASE ");
		query.append(" WHEN PIT.OPEN_QUANTITY IS NOT NULL THEN NULL ");
		query.append(" WHEN PIT.OPEN_QUANTITY = -1234567890 THEN 0 ");
		query.append(" ELSE NULL ");
		query.append(" END AS OPEN_QUANTITY, ");
		
		query.append(" CASE ");
		query.append(" WHEN PIT.TOTAL_QUANTITY IS NULL THEN NULL ");
		query.append(" WHEN PIT.TOTAL_QUANTITY > 0 THEN NULL ");
		query.append(" WHEN PIT.TOTAL_QUANTITY < 0 THEN NULL ");
		query.append(" WHEN PIT.TOTAL_QUANTITY = 0 THEN NULL ");
		query.append(" ELSE 0 ");
		query.append(" END AS TOTAL_QUANTITY, ");
		
		query.append(" CASE ");
		query.append(" WHEN PIT.DATE_TIME IS NOT NULL THEN NULL ");
		query.append(" WHEN PIT.DATE_TIME = '1900-01-01 00:00:00.000' THEN '1900-01-01 00:00:00.000' ");
		query.append(" END AS DATE_TIME, ");
		
		query.append(" CASE ");
		query.append(" WHEN PIT.DEVICE_ID IS NOT NULL THEN NULL ");
		query.append(" WHEN PIT.DEVICE_ID = 'EMPTY' THEN '' ");
		query.append(" ELSE NULL ");
		query.append(" END AS DEVICE_ID, ");
		
		query.append(" CASE ");
		query.append(" WHEN PIT.TRANSACTION_TYPE IS NOT NULL THEN NULL ");
		query.append(" WHEN PIT.TRANSACTION_TYPE = 'EMPTY' THEN '' ");
		query.append(" ELSE NULL ");
		query.append(" END AS TRANSACTION_TYPE, ");
		
		query.append(" CASE ");
		query.append(" WHEN PIT.ISUPDATED IS NOT NULL THEN NULL ");
		query.append(" WHEN PIT.ISUPDATED = 'EMPTY' THEN '' ");
		query.append(" ELSE NULL ");
		query.append(" END AS ISUPDATED, ");
		
		query.append(" CASE ");
		query.append(" WHEN PIT.COMMENTS_FLAG IS NOT NULL THEN NULL ");
		query.append(" WHEN PIT.COMMENTS_FLAG = -1234567890 THEN 0 ");
		query.append(" ELSE NULL ");
		query.append(" END AS  COMMENTS_FLAG, ");
		
		query.append(" CASE ");
		query.append(" WHEN PIT.PART_NO IS NULL THEN NULL ");
		query.append(" WHEN (0 - CONVERT (INT, PIT.WMS_STOCK_QUANTITY) = 0) THEN '' ");
		query.append(" ELSE 'RECOUNT REQUIRED' ");
		query.append(" END AS COMMENTS, ");
		
		query.append(" PIT.WMS_STOCK_QUANTITY, ");
		
		query.append(" CONVERT(VARCHAR(10), CASE ");
		query.append(" WHEN PIT.PART_NO IS NULL THEN NULL ");
		query.append(" ELSE 0 - CONVERT (INT, PIT.WMS_STOCK_QUANTITY) ");
		query.append(" END) AS STOCK_DIFFERENCE, ");
		
		query.append(" CASE ");
		query.append(" WHEN PIT.PART_NO IS NULL THEN NULL ");
		query.append(" WHEN (0 - CONVERT (INT, PIT.WMS_STOCK_QUANTITY) = 0) THEN 'NO' ");
		query.append(" ELSE 'YES' ");
		query.append(" END AS RECOUNT, ");
		
		query.append(" PIT.UPDATED_DATETIME ");
		query.append(" FROM dbo.PIT PIT, ( ");
		
		query.append(" SELECT LOCATION_ID, PART_NO, RAN FROM DBO.PART_LOCATION PL WHERE NOT EXISTS ( ");
		query.append(" SELECT * FROM DBO.PIT_HISTORY PH WHERE 1=1 ");
		query.append(" AND PH.RAN = PL.RAN ");
		query.append(" AND PH.LOCATION = PL.LOCATION_ID ");
		query.append(" AND PH.PART_NO = PL.PART_NO ");
		
		if (null != pitTransactionReportDto.getFromDate() || null != pitTransactionReportDto.getToDate()) {
			
			Map<String,Date> shiftTimes  = WMSBeanUtil.getShiftTime("",pitTransactionReportDto.getFromDate(),pitTransactionReportDto.getToDate());
			
			pitTransactionReportDto.setFromDate(shiftTimes.get("fromDate"));
			pitTransactionReportDto.setToDate(shiftTimes.get("toDate"));
			
			LOGGER.debug("PIT Transaction Report From Date -> "+ dateFormatter.format(pitTransactionReportDto.getFromDate()));
			LOGGER.debug("PIT Transaction Report To Date -> "+ dateFormatter.format(pitTransactionReportDto.getToDate()));
			
			query.append(" AND PH.UPDATED_DATETIME >= '"+ dateFormatter.format(pitTransactionReportDto.getFromDate()) + "'");
			query.append(" AND PH.UPDATED_DATETIME < '"+ dateFormatter.format(pitTransactionReportDto.getToDate()) + "'");
		}
		
		if(null != pitTransactionReportDto.getDeviceId() && pitTransactionReportDto.getDeviceId().length() > 0){
			query.append(" AND PH.DEVICE_ID = '");query.append(pitTransactionReportDto.getDeviceId()); query.append("'");
		}
		
		query.append(")");
		
		query.append(") PL_TABLE WHERE 1=1  ");
		query.append(" AND PIT.RAN = PL_TABLE.RAN  ");
		query.append(" AND PIT.PART_NO = PL_TABLE.PART_NO ");
		query.append(" AND PIT.LOCATION = PL_TABLE.LOCATION_ID ");
		
		if(null != pitTransactionReportDto.getRanList() && pitTransactionReportDto.getRanList().size() > 0){
			String ranString = queryStr(pitTransactionReportDto.getRanList());
			LOGGER.debug("PIT Table Search Input Rans == "+ranString);
			query.append(" AND PIT.RAN IN ("); query.append(ranString);  query.append(")");
		}
		
		if(null != pitTransactionReportDto.getPartList() && pitTransactionReportDto.getPartList().size() > 0){
			String partString = queryStr(pitTransactionReportDto.getPartList());
			LOGGER.debug("PIT Table Search Input Parts == "+partString);
			query.append(" AND PIT.PART_NO IN ("); query.append(partString);  query.append(")");
		}
		
		if(null != pitTransactionReportDto.getLocationList() && pitTransactionReportDto.getLocationList().size() > 0){
			String locationString = queryStr(pitTransactionReportDto.getLocationList());
			LOGGER.debug("PIT Table Search Input Locations == "+locationString);
			query.append(" AND PIT.LOCATION IN ("); query.append(locationString);  query.append(")");
		}
		
		if(null != pitTransactionReportDto.getPlant() && pitTransactionReportDto.getPlant().length() > 0){
			query.append(" AND SUBSTRING(PIT.LOCATION, 1, 1) = '");query.append(pitTransactionReportDto.getPlant()); query.append("'");
		}
		
		if(null != pitTransactionReportDto.getShop() && pitTransactionReportDto.getShop().length() > 0){
			query.append(" AND SUBSTRING(PIT.LOCATION, 2, 1) = '");query.append(pitTransactionReportDto.getShop()); query.append("'");
		}
		
		query.append(" AND NOT (");
		query.append(" CASE ");
		query.append(" WHEN PIT.WMS_STOCK_QUANTITY IS NULL THEN 0 ");
		query.append(" WHEN PIT.WMS_STOCK_QUANTITY = 'EMPTY' THEN 0 ");
		query.append(" ELSE CONVERT(INT, PIT.WMS_STOCK_QUANTITY) ");
		query.append(" END = 0 ");
		query.append(" AND SUBSTRING(PIT.LOCATION, 4, 1) = 'F' ");
		query.append(")");
		
		query.append(" UNION ALL ");
		
		query.append(" SELECT PIT.TRANSACTION_ID, PIT.PART_NO, PIT.LOCATION, PIT.RAN, PIT.SNP, PIT.NO_OF_BOXES, PIT.OPEN_QUANTITY, ");
		query.append(" PIT.TOTAL_QUANTITY,  PIT.DATE_TIME, PIT.DEVICE_ID, PIT.TRANSACTION_TYPE, PIT.ISUPDATED, PIT.COMMENTS_FLAG,  ");
		query.append(" PIT.COMMENTS, PIT.WMS_STOCK_QUANTITY,  PIT.STOCK_DIFFERENCE, PIT.RECOUNT, PIT.UPDATED_DATETIME  ");
		query.append(" FROM dbo.PIT PIT WHERE RAN IS NULL AND PART_NO IS NULL AND WMS_STOCK_QUANTITY IS NULL ");
		
		if(null != pitTransactionReportDto.getRanList() && pitTransactionReportDto.getRanList().size() > 0){
			String ranString = queryStr(pitTransactionReportDto.getRanList());
			LOGGER.debug("PIT Table Search Input Rans == "+ranString);
			query.append(" AND PIT.RAN IN ("); query.append(ranString);  query.append(")");
		}
		
		if(null != pitTransactionReportDto.getPartList() && pitTransactionReportDto.getPartList().size() > 0){
			String partString = queryStr(pitTransactionReportDto.getPartList());
			LOGGER.debug("PIT Table Search Input Parts == "+partString);
			query.append(" AND PIT.PART_NO IN ("); query.append(partString);  query.append(")");
		}
		
		if(null != pitTransactionReportDto.getLocationList() && pitTransactionReportDto.getLocationList().size() > 0){
			String locationString = queryStr(pitTransactionReportDto.getLocationList());
			LOGGER.debug("PIT Table Search Input Locations == "+locationString);
			query.append(" AND PIT.LOCATION IN ("); query.append(locationString);  query.append(")");
		}
		
		if(null != pitTransactionReportDto.getPlant() && pitTransactionReportDto.getPlant().length() > 0){
			query.append(" AND SUBSTRING(PIT.LOCATION, 1, 1) = '");query.append(pitTransactionReportDto.getPlant()); query.append("'");
		}
		
		if(null != pitTransactionReportDto.getShop() && pitTransactionReportDto.getShop().length() > 0){
			query.append(" AND SUBSTRING(PIT.LOCATION, 2, 1) = '");query.append(pitTransactionReportDto.getShop()); query.append("'");
		}
		
		if(null != pitTransactionReportDto.getDeviceId() && pitTransactionReportDto.getDeviceId().length() > 0){
			query.append(" AND PIT.DEVICE_ID = '");query.append(pitTransactionReportDto.getDeviceId()); query.append("'");
		}
		
		query.append(" AND NOT (");
		query.append(" CASE ");
		query.append(" WHEN PIT.WMS_STOCK_QUANTITY IS NULL THEN 0 ");
		query.append(" WHEN PIT.WMS_STOCK_QUANTITY = 'EMPTY' THEN 0 ");
		query.append(" ELSE CONVERT(INT, PIT.WMS_STOCK_QUANTITY) ");
		query.append(" END = 0 ");
		query.append(" AND SUBSTRING(PIT.LOCATION, 4, 1) = 'F' ");
		query.append(" )");
		
		
		query.append(") ALL_TABLE WHERE 1=1 ");
		if(null != pitTransactionReportDto.getRecount() && pitTransactionReportDto.getRecount().equalsIgnoreCase("YES")){
			query.append(" AND RECOUNT = '");query.append("YES"); query.append("'");
		}
		
		if(null != pitTransactionReportDto.getRecount() && pitTransactionReportDto.getRecount().equalsIgnoreCase("NO")){
			query.append(" AND RECOUNT = '");query.append("NO"); query.append("'");
		}
		
		if(null != pitTransactionReportDto.getDeviceId() && pitTransactionReportDto.getDeviceId().length() > 0){
			query.append(" AND DEVICE_ID = '");query.append(pitTransactionReportDto.getDeviceId()); query.append("'");
		}
		
		LOGGER.debug("Query Generated for PIT Not Scanned Transaction Report == "+query.toString());
		return query.toString();
	}
	
	public String getPitAllQuery(PITTransactionReportDTO pitTransactionReportDto){
		StringBuffer query = new StringBuffer();
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		query.append("SELECT TRANSACTION_ID, PART_NO, LOCATION, RAN, SNP, NO_OF_BOXES, OPEN_QUANTITY, TOTAL_QUANTITY, ");
		query.append(" DATE_TIME, DEVICE_ID, TRANSACTION_TYPE, ISUPDATED, COMMENTS_FLAG, COMMENTS, WMS_STOCK_QUANTITY, ");
		query.append("STOCK_DIFFERENCE, RECOUNT, UPDATED_DATETIME FROM (");
		
		query.append("SELECT PH.TRANSACTION_ID, PH.PART_NO, PH.LOCATION, PH.RAN, PH.SNP, PH.NO_OF_BOXES, PH.OPEN_QUANTITY, PH.TOTAL_QUANTITY, ");
		query.append(" PH.DATE_TIME, PH.DEVICE_ID, PH.TRANSACTION_TYPE, PH.ISUPDATED, PH.COMMENTS_FLAG, PH.COMMENTS, PH.WMS_STOCK_QUANTITY, ");
		query.append(" PH.STOCK_DIFFERENCE, PH.RECOUNT, PH.UPDATED_DATETIME  FROM DBO.PIT_HISTORY PH WHERE 1=1");
		
		if(null != pitTransactionReportDto.getRanList() && pitTransactionReportDto.getRanList().size() > 0){
			String ranString = queryStr(pitTransactionReportDto.getRanList());
			LOGGER.debug("PIT Table Search Input Rans == "+ranString);
			query.append(" AND PH.RAN IN ("); query.append(ranString);  query.append(")");
		}
		
		if(null != pitTransactionReportDto.getPartList() && pitTransactionReportDto.getPartList().size() > 0){
			String partString = queryStr(pitTransactionReportDto.getPartList());
			LOGGER.debug("PIT Table Search Input Parts == "+partString);
			query.append(" AND PH.PART_NO IN ("); query.append(partString);  query.append(")");
		}
		
		if(null != pitTransactionReportDto.getLocationList() && pitTransactionReportDto.getLocationList().size() > 0){
			String locationString = queryStr(pitTransactionReportDto.getLocationList());
			LOGGER.debug("PIT Table Search Input Locations == "+locationString);
			query.append(" AND PH.LOCATION IN ("); query.append(locationString);  query.append(")");
		}
		
		if(null != pitTransactionReportDto.getPlant() && pitTransactionReportDto.getPlant().length() > 0){
			query.append(" AND SUBSTRING(PH.LOCATION, 1, 1) = '");query.append(pitTransactionReportDto.getPlant()); query.append("'");
		}
		
		if(null != pitTransactionReportDto.getShop() && pitTransactionReportDto.getShop().length() > 0){
			query.append(" AND SUBSTRING(PH.LOCATION, 2, 1) = '");query.append(pitTransactionReportDto.getShop()); query.append("'");
		}
		
		if(null != pitTransactionReportDto.getDeviceId() && pitTransactionReportDto.getDeviceId().length() > 0){
			query.append(" AND PH.DEVICE_ID = '");query.append(pitTransactionReportDto.getDeviceId()); query.append("'");
		}
		
		if (null != pitTransactionReportDto.getFromDate() || null != pitTransactionReportDto.getToDate()) {
			
			Map<String,Date> shiftTimes  = WMSBeanUtil.getShiftTime("",pitTransactionReportDto.getFromDate(),pitTransactionReportDto.getToDate());
			
			pitTransactionReportDto.setFromDate(shiftTimes.get("fromDate"));
			pitTransactionReportDto.setToDate(shiftTimes.get("toDate"));
			
			LOGGER.debug("PIT Transaction Report From Date -> "+ dateFormatter.format(pitTransactionReportDto.getFromDate()));
			LOGGER.debug("PIT Transaction Report To Date -> "+ dateFormatter.format(pitTransactionReportDto.getToDate()));
			
			query.append(" AND PH.UPDATED_DATETIME >= '"+ dateFormatter.format(pitTransactionReportDto.getFromDate()) + "'");
			query.append(" AND PH.UPDATED_DATETIME < '"+ dateFormatter.format(pitTransactionReportDto.getToDate()) + "'");
		}
		
		query.append(" UNION ALL ");
		
		query.append(" SELECT ");
		query.append(" CASE ");
		query.append(" WHEN P.TRANSACTION_ID IS NOT NULL THEN NULL");
		query.append(" WHEN P.TRANSACTION_ID = 'EMPTY' THEN '' ");
		query.append(" ELSE NULL ");
		query.append(" END AS TRANSACTION_ID, ");
		
		query.append(" P.PART_NO, P.LOCATION, P.RAN, ");
		
		query.append(" CASE ");
		query.append(" WHEN P.SNP IS NOT NULL THEN NULL ");
		query.append(" WHEN P.SNP = -1234567890 THEN 0 ");
		query.append(" ELSE NULL ");
		query.append(" END AS SNP, ");
		
		query.append(" CASE  ");
		query.append(" WHEN P.NO_OF_BOXES IS NOT NULL THEN NULL ");
		query.append(" WHEN P.NO_OF_BOXES = -1234567890 THEN 0 ");
		query.append(" ELSE NULL ");
		query.append(" END AS NO_OF_BOXES, ");
		
		query.append(" CASE ");
		query.append(" WHEN P.OPEN_QUANTITY IS NOT NULL THEN NULL ");
		query.append(" WHEN P.OPEN_QUANTITY = -1234567890 THEN 0 ");
		query.append(" ELSE NULL ");
		query.append(" END AS OPEN_QUANTITY, ");
		
		query.append(" CASE ");
		query.append(" WHEN P.TOTAL_QUANTITY IS NULL THEN NULL ");
		query.append(" WHEN P.TOTAL_QUANTITY > 0 THEN NULL ");
		query.append(" WHEN P.TOTAL_QUANTITY < 0 THEN NULL ");
		query.append(" WHEN P.TOTAL_QUANTITY = 0 THEN NULL ");
		query.append(" ELSE 0 ");
		query.append(" END AS TOTAL_QUANTITY, ");
		
		query.append(" CASE ");
		query.append(" WHEN P.DATE_TIME IS NOT NULL THEN NULL ");
		query.append(" WHEN P.DATE_TIME = '1900-01-01 00:00:00.000' THEN '1900-01-01 00:00:00.000'");
		query.append(" ELSE NULL ");
		query.append(" END AS DATE_TIME, ");
		
		query.append(" CASE ");
		query.append(" WHEN P.DEVICE_ID IS NOT NULL THEN NULL ");
		query.append(" WHEN P.DEVICE_ID = 'EMPTY' THEN '' ");
		query.append(" ELSE NULL ");
		query.append(" END AS DEVICE_ID, ");
		
		query.append(" CASE ");
		query.append(" WHEN P.TRANSACTION_TYPE IS NOT NULL THEN NULL ");
		query.append(" WHEN P.TRANSACTION_TYPE = 'EMPTY' THEN '' ");
		query.append(" ELSE NULL ");
		query.append(" END AS TRANSACTION_TYPE, ");
		
		query.append(" CASE ");
		query.append(" WHEN P.ISUPDATED IS NOT NULL THEN NULL ");
		query.append(" WHEN P.ISUPDATED = 'EMPTY' THEN '' ");
		query.append(" ELSE NULL ");
		query.append(" END AS ISUPDATED, ");
		
		query.append(" CASE ");
		query.append(" WHEN P.COMMENTS_FLAG IS NOT NULL THEN NULL ");
		query.append(" WHEN P.COMMENTS_FLAG = -1234567890 THEN 0 ");
		query.append(" ELSE NULL ");
		query.append(" END AS  COMMENTS_FLAG, ");
		
		query.append("  CASE ");
		query.append(" WHEN P.PART_NO IS NULL THEN NULL ");
		query.append(" WHEN (0 - CONVERT (INT, P.WMS_STOCK_QUANTITY) = 0) THEN '' ");
		query.append(" ELSE 'RECOUNT REQUIRED' ");
		query.append(" END AS COMMENTS, ");
		
		query.append(" P.WMS_STOCK_QUANTITY, ");
		
		query.append(" CONVERT(VARCHAR(10), CASE  ");
		query.append(" WHEN P.PART_NO IS NULL THEN NULL ");
		query.append(" ELSE 0 - CONVERT (INT, P.WMS_STOCK_QUANTITY) ");
		query.append(" END) AS STOCK_DIFFERENCE, ");
		
		query.append(" CASE ");
		query.append(" WHEN P.PART_NO IS NULL THEN NULL ");
		query.append(" WHEN (0 - CONVERT (INT, P.WMS_STOCK_QUANTITY) = 0) THEN 'NO' ");
		query.append(" ELSE 'YES' ");
		query.append(" END AS RECOUNT, ");
		
		query.append("  P.UPDATED_DATETIME FROM DBO.PIT P  ");
		query.append(" WHERE NOT EXISTS (");
		
		query.append(" SELECT * FROM DBO.PIT_HISTORY PH WHERE PH.RAN = P.RAN ");
		query.append(" AND PH.PART_NO = P.PART_NO AND PH.LOCATION = P.LOCATION  ");
		
		if (null != pitTransactionReportDto.getFromDate() || null != pitTransactionReportDto.getToDate()) {
			
			Map<String,Date> shiftTimes  = WMSBeanUtil.getShiftTime("",pitTransactionReportDto.getFromDate(),pitTransactionReportDto.getToDate());
			
			pitTransactionReportDto.setFromDate(shiftTimes.get("fromDate"));
			pitTransactionReportDto.setToDate(shiftTimes.get("toDate"));
			
			LOGGER.debug("PIT Transaction Report From Date -> "+ dateFormatter.format(pitTransactionReportDto.getFromDate()));
			LOGGER.debug("PIT Transaction Report To Date -> "+ dateFormatter.format(pitTransactionReportDto.getToDate()));
			
			query.append(" AND PH.UPDATED_DATETIME >= '"+ dateFormatter.format(pitTransactionReportDto.getFromDate()) + "'");
			query.append(" AND PH.UPDATED_DATETIME < '"+ dateFormatter.format(pitTransactionReportDto.getToDate()) + "'");
		}
		
		if(null != pitTransactionReportDto.getDeviceId() && pitTransactionReportDto.getDeviceId().length() > 0){
			query.append(" AND PH.DEVICE_ID = '");query.append(pitTransactionReportDto.getDeviceId()); query.append("'");
		}
		
		query.append(")");
		
		if(null != pitTransactionReportDto.getRanList() && pitTransactionReportDto.getRanList().size() > 0){
			String ranString = queryStr(pitTransactionReportDto.getRanList());
			LOGGER.debug("PIT Table Search Input Rans == "+ranString);
			query.append(" AND P.RAN IN ("); query.append(ranString);  query.append(")");
		}
		
		if(null != pitTransactionReportDto.getPartList() && pitTransactionReportDto.getPartList().size() > 0){
			String partString = queryStr(pitTransactionReportDto.getPartList());
			LOGGER.debug("PIT Table Search Input Parts == "+partString);
			query.append(" AND P.PART_NO IN ("); query.append(partString);  query.append(")");
		}
		
		if(null != pitTransactionReportDto.getLocationList() && pitTransactionReportDto.getLocationList().size() > 0){
			String locationString = queryStr(pitTransactionReportDto.getLocationList());
			LOGGER.debug("PIT Table Search Input Locations == "+locationString);
			query.append(" AND P.LOCATION IN ("); query.append(locationString);  query.append(")");
		}
		
		if(null != pitTransactionReportDto.getPlant() && pitTransactionReportDto.getPlant().length() > 0){
			query.append(" AND SUBSTRING(P.LOCATION, 1, 1) = '");query.append(pitTransactionReportDto.getPlant()); query.append("'");
		}
		
		if(null != pitTransactionReportDto.getShop() && pitTransactionReportDto.getShop().length() > 0){
			query.append(" AND SUBSTRING(P.LOCATION, 2, 1) = '");query.append(pitTransactionReportDto.getShop()); query.append("'");
		}
		
		query.append(" AND NOT( ");
		query.append(" CASE ");
		query.append(" WHEN P.WMS_STOCK_QUANTITY IS NULL THEN 0 ");
		query.append(" WHEN P.WMS_STOCK_QUANTITY = 'EMPTY' THEN 0 ");
		query.append(" ELSE CONVERT(INT, P.WMS_STOCK_QUANTITY) ");
		query.append(" END = 0 ");
		query.append(" AND SUBSTRING(P.LOCATION, 4, 1) = 'F' ");
		query.append(" )");
		
		query.append(") ALL_TABLE WHERE 1=1 ");
		
		if(null != pitTransactionReportDto.getRecount() && pitTransactionReportDto.getRecount().equalsIgnoreCase("YES")){
			query.append(" AND RECOUNT = '");query.append("YES"); query.append("'");
		}
		
		if(null != pitTransactionReportDto.getRecount() && pitTransactionReportDto.getRecount().equalsIgnoreCase("NO")){
			query.append(" AND RECOUNT = '");query.append("NO"); query.append("'");
		}
		
		if(null != pitTransactionReportDto.getDeviceId() && pitTransactionReportDto.getDeviceId().length() > 0){
			query.append(" AND DEVICE_ID = '");query.append(pitTransactionReportDto.getDeviceId()); query.append("'");
		}
		
		LOGGER.debug("Query Generated for PIT ALL Scanned and Not Scanned Transaction Report == "+query.toString());
		return query.toString();
	}
	
	
	
	
	public int getCumulativeReportCount(PITCumulativeReportDTO pitCumulativeReportDto) {
		LOGGER.debug("In PITStaging Bean -- getCumulativeReportCount() method");
		StringBuffer queryStringBuf = new StringBuffer();
		
		if(pitCumulativeReportDto.getScanned().equalsIgnoreCase("YES")){
			queryStringBuf.append(getPitScannedQueryCumulative(pitCumulativeReportDto));
		}else if(pitCumulativeReportDto.getScanned().equalsIgnoreCase("NO")){
			queryStringBuf.append(getPitNotScannedQueryCumulative(pitCumulativeReportDto));
		}else{
			queryStringBuf.append(getPitScannedAllQueryCumulative(pitCumulativeReportDto));
		}
		 
		
		Query query = entityManager.createNativeQuery(queryStringBuf.toString());
		List<Object[]> queryDatas = query.getResultList();
		LOGGER.debug("getCumulativeReportCount() == PIT Cumulative Report Data size ==  " + queryDatas.size());
		
		int noOfRecords = queryDatas.size();
        LOGGER.debug("PIT Cumulative Report Count :  " + noOfRecords);
		return noOfRecords;
	}
	
	
	
	public List<PITCumulativeReportDTO> getPitCumulativeReportList(PITCumulativeReportDTO pitCumulativeReportDto) {

		LOGGER.debug("In PITStaging Bean -- getPitCumulativeReportList() method");
		List<PITCumulativeReportDTO> pitCumulativeReportList  = new ArrayList<PITCumulativeReportDTO>();
		
		StringBuffer queryStringBuf = new StringBuffer();
		
		if(pitCumulativeReportDto.getScanned().equalsIgnoreCase("YES")){
			queryStringBuf.append(getPitScannedQueryCumulative(pitCumulativeReportDto));
		}else if(pitCumulativeReportDto.getScanned().equalsIgnoreCase("NO")){
			queryStringBuf.append(getPitNotScannedQueryCumulative(pitCumulativeReportDto));
		}else{
			queryStringBuf.append(getPitScannedAllQueryCumulative(pitCumulativeReportDto));
		}
		
		Query query = entityManager.createNativeQuery(queryStringBuf.toString());
		
		if(pitCumulativeReportDto.getIsFullDownload()!=1){
			query.setFirstResult(pitCumulativeReportDto.getStartIndex());
			query.setMaxResults(pitCumulativeReportDto.getEndIndex());
		}
		
		List<Object[]> queryDatas = query.getResultList();
		LOGGER.debug("getPitTransactionReportList() ==PIT Transaction Report Data size ==  " + queryDatas.size());
		
		if(null != queryDatas && queryDatas.size() > 0){
			for(int i = 0; i<queryDatas.size(); i++){
				PITCumulativeReportDTO resultDto = new PITCumulativeReportDTO();
				Object[] data = queryDatas.get(i);
				
				int index = 0;
				resultDto.setLocation((null == data[index] ? "" : data[index].toString()));
				
				index++;
				resultDto.setPartNumber((null == data[index] ? "" : data[index].toString()));
				
				index++;
				resultDto.setSnp((Integer)data[index]);
				
				index++;
				if(null == data[index]){
					resultDto.setTotalQuantity("");
				}else{
					int totalQty = (Integer)data[index];
					resultDto.setTotalQuantity(Integer.toString(totalQty));
				}
				
				index++;
				resultDto.setWmsStockQuantity((null == data[index] ? "" : (data[index].toString().trim().equalsIgnoreCase("NO COMMENTS") || data[index].toString().trim().equalsIgnoreCase("empty")) ? "" : data[index].toString()));
				
				index++;
				resultDto.setStockDifference((null == data[index] ? "" : (data[index].toString().trim().equalsIgnoreCase("NO COMMENTS") || data[index].toString().trim().equalsIgnoreCase("empty")) ? "" : data[index].toString()));
				
				index++;
				resultDto.setRecount((null == data[index] ? "" : data[index].toString().trim().equalsIgnoreCase("empty") ? "" : data[index].toString()));
				
				index++;
				resultDto.setDeviceId((null == data[index] ? "" : data[index].toString()));
				
				pitCumulativeReportList.add(resultDto);
			}
		}
		
		return pitCumulativeReportList;
	}

	private Object getPitScannedQueryCumulative(PITCumulativeReportDTO pitCumulativeReportDto) {
		
		StringBuffer query = new StringBuffer();
		
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		query.append("SELECT PH.LOCATION, PH.PART_NO, PH.SNP, PH.TOTAL_QUANTITY, PH.WMS_STOCK_QUANTITY, ");
		query.append(" PH.STOCK_DIFFERENCE, PH.RECOUNT, PH.DEVICE_ID FROM DBO.PIT_HISTORY  PH, (");
		
		query.append(" SELECT TOP 100 PERCENT  PART_NO, LOCATION, MAX(UPDATED_DATETIME) AS UPDATED_DATETIME ");
		query.append(" FROM DBO.PIT_HISTORY WHERE 1=1 ");
		
		if(null != pitCumulativeReportDto.getRanList() && pitCumulativeReportDto.getRanList().size() > 0){
			String ranString = queryStr(pitCumulativeReportDto.getRanList());
			LOGGER.debug("PIT Table Search Input Rans == "+ranString);
			query.append(" AND RAN IN ("); query.append(ranString);  query.append(")");
		}
		
		if(null != pitCumulativeReportDto.getPartList() && pitCumulativeReportDto.getPartList().size() > 0){
			String partString = queryStr(pitCumulativeReportDto.getPartList());
			LOGGER.debug("PIT Table Search Input Parts == "+partString);
			query.append(" AND PART_NO IN ("); query.append(partString);  query.append(")");
		}
		
		if(null != pitCumulativeReportDto.getLocationList() && pitCumulativeReportDto.getLocationList().size() > 0){
			String locationString = queryStr(pitCumulativeReportDto.getLocationList());
			LOGGER.debug("PIT Table Search Input Locations == "+locationString);
			query.append(" AND LOCATION IN ("); query.append(locationString);  query.append(")");
		}
		
		if(null != pitCumulativeReportDto.getRecount() && pitCumulativeReportDto.getRecount().equalsIgnoreCase("YES")){
			query.append(" AND RECOUNT = '");query.append("YES"); query.append("'");
		}
		
		if(null != pitCumulativeReportDto.getRecount() && pitCumulativeReportDto.getRecount().equalsIgnoreCase("NO")){
			query.append(" AND RECOUNT = '");query.append("NO"); query.append("'");
		}
		
		if(null != pitCumulativeReportDto.getPlant() && pitCumulativeReportDto.getPlant().length() > 0){
			query.append(" AND SUBSTRING(LOCATION, 1, 1) = '");query.append(pitCumulativeReportDto.getPlant()); query.append("'");
		}
		
		if(null != pitCumulativeReportDto.getShop() && pitCumulativeReportDto.getShop().length() > 0){
			query.append(" AND SUBSTRING(LOCATION, 2, 1) = '");query.append(pitCumulativeReportDto.getShop()); query.append("'");
		}
		
		if (null != pitCumulativeReportDto.getFromDate() || null != pitCumulativeReportDto.getToDate()) {
			
			Map<String,Date> shiftTimes  = WMSBeanUtil.getShiftTime("",pitCumulativeReportDto.getFromDate(),pitCumulativeReportDto.getToDate());
			
			pitCumulativeReportDto.setFromDate(shiftTimes.get("fromDate"));
			pitCumulativeReportDto.setToDate(shiftTimes.get("toDate"));
			
			LOGGER.debug("PIT Transaction Report From Date -> "+ dateFormatter.format(pitCumulativeReportDto.getFromDate()));
			LOGGER.debug("PIT Transaction Report To Date -> "+ dateFormatter.format(pitCumulativeReportDto.getToDate()));
			
			query.append(" AND UPDATED_DATETIME >= '"+ dateFormatter.format(pitCumulativeReportDto.getFromDate()) + "'");
			query.append(" AND UPDATED_DATETIME < '"+ dateFormatter.format(pitCumulativeReportDto.getToDate()) + "'");
		}
		
		if(null != pitCumulativeReportDto.getDeviceId() && pitCumulativeReportDto.getDeviceId().length() > 0){
			query.append(" AND DEVICE_ID = '");query.append(pitCumulativeReportDto.getDeviceId()); query.append("'");
		}
		
		query.append(" GROUP BY  PART_NO, LOCATION, SNP, DEVICE_ID ");
		query.append(" ORDER BY MAX(UPDATED_DATETIME) ");
		
		query.append(") PH_TABLE WHERE 1=1 ");
		
		//query.append(" AND PH.RAN = PH_TABLE.RAN ");
		query.append(" AND PH.LOCATION = PH_TABLE.LOCATION ");
		query.append(" AND PH.PART_NO = PH_TABLE.PART_NO ");
		query.append(" AND PH.UPDATED_DATETIME = PH_TABLE.UPDATED_DATETIME");
		
		LOGGER.debug("Query Generated for PIT Scanned Cumulative Report == "+query.toString());
		
		return query.toString();
	}
	
	private Object getPitScannedAllQueryCumulative(PITCumulativeReportDTO pitCumulativeReportDto) {
		
		StringBuffer query = new StringBuffer();
		
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		
		query.append("SELECT PH.LOCATION, PH.PART_NO, PH.SNP, PH.TOTAL_QUANTITY, PH.WMS_STOCK_QUANTITY, ");
		query.append(" PH.STOCK_DIFFERENCE, PH.RECOUNT, PH.DEVICE_ID ");
		query.append(" FROM DBO.PIT_HISTORY  PH, ( ");
		
		query.append(" SELECT TOP 100 PERCENT  PART_NO, LOCATION, MAX(UPDATED_DATETIME) AS UPDATED_DATETIME ");
		query.append(" FROM DBO.PIT_HISTORY WHERE 1=1 ");
		
		
		if(null != pitCumulativeReportDto.getRanList() && pitCumulativeReportDto.getRanList().size() > 0){
			String ranString = queryStr(pitCumulativeReportDto.getRanList());
			LOGGER.debug("PIT Table Search Input Rans == "+ranString);
			query.append(" AND RAN IN ("); query.append(ranString);  query.append(")");
		}
		
		if(null != pitCumulativeReportDto.getPartList() && pitCumulativeReportDto.getPartList().size() > 0){
			String partString = queryStr(pitCumulativeReportDto.getPartList());
			LOGGER.debug("PIT Table Search Input Parts == "+partString);
			query.append(" AND PART_NO IN ("); query.append(partString);  query.append(")");
		}
		
		if(null != pitCumulativeReportDto.getLocationList() && pitCumulativeReportDto.getLocationList().size() > 0){
			String locationString = queryStr(pitCumulativeReportDto.getLocationList());
			LOGGER.debug("PIT Table Search Input Locations == "+locationString);
			query.append(" AND LOCATION IN ("); query.append(locationString);  query.append(")");
		}
		
		if(null != pitCumulativeReportDto.getPlant() && pitCumulativeReportDto.getPlant().length() > 0){
			query.append(" AND SUBSTRING(LOCATION, 1, 1) = '");query.append(pitCumulativeReportDto.getPlant()); query.append("'");
		}
		
		if(null != pitCumulativeReportDto.getShop() && pitCumulativeReportDto.getShop().length() > 0){
			query.append(" AND SUBSTRING(LOCATION, 2, 1) = '");query.append(pitCumulativeReportDto.getShop()); query.append("'");
		}
		
		if(null != pitCumulativeReportDto.getRecount() && pitCumulativeReportDto.getRecount().equalsIgnoreCase("YES")){
			query.append(" AND RECOUNT = '");query.append("YES"); query.append("'");
		}
		
		if(null != pitCumulativeReportDto.getRecount() && pitCumulativeReportDto.getRecount().equalsIgnoreCase("NO")){
			query.append(" AND RECOUNT = '");query.append("NO"); query.append("'");
		}
		
		if(null != pitCumulativeReportDto.getDeviceId() && pitCumulativeReportDto.getDeviceId().length() > 0){
			query.append(" AND DEVICE_ID = '");query.append(pitCumulativeReportDto.getDeviceId()); query.append("'");
		}
		
		if (null != pitCumulativeReportDto.getFromDate() || null != pitCumulativeReportDto.getToDate()) {
			
			Map<String,Date> shiftTimes  = WMSBeanUtil.getShiftTime("",pitCumulativeReportDto.getFromDate(),pitCumulativeReportDto.getToDate());
			
			pitCumulativeReportDto.setFromDate(shiftTimes.get("fromDate"));
			pitCumulativeReportDto.setToDate(shiftTimes.get("toDate"));
			
			LOGGER.debug("PIT Transaction Report From Date -> "+ dateFormatter.format(pitCumulativeReportDto.getFromDate()));
			LOGGER.debug("PIT Transaction Report To Date -> "+ dateFormatter.format(pitCumulativeReportDto.getToDate()));
			
			query.append(" AND UPDATED_DATETIME >= '"+ dateFormatter.format(pitCumulativeReportDto.getFromDate()) + "'");
			query.append(" AND UPDATED_DATETIME < '"+ dateFormatter.format(pitCumulativeReportDto.getToDate()) + "'");
		}
		
		query.append(" GROUP BY  PART_NO, LOCATION, SNP, DEVICE_ID ");
		query.append(" ORDER BY MAX(UPDATED_DATETIME) ");
		
		query.append(" )  PH_TABLE WHERE 1=1 ");
		
		//query.append(" AND PH.RAN = PH_TABLE.RAN  ");
		query.append(" AND PH.LOCATION = PH_TABLE.LOCATION  ");
		query.append(" AND PH.PART_NO = PH_TABLE.PART_NO ");
		query.append(" AND PH.UPDATED_DATETIME = PH_TABLE.UPDATED_DATETIME ");
		
		query.append("UNION ALL ");
		
		query.append(" SELECT LOCATION, PART_NO, SNP, TOTAL_QUANTITY, WMS_STOCK_QUANTITY, STOCK_DIFFERENCE, ");
		query.append(" RECOUNT, DEVICE_ID FROM ( ");
		
		query.append(" SELECT TOP 100 PERCENT LOCATION, PART_NO, ");
		query.append(" CASE ");
		query.append(" WHEN  SNP IS NOT NULL THEN NULL ");
		query.append(" WHEN  SNP  = -1234567890 THEN 0 ");
		query.append(" ELSE NULL  ");
		query.append(" END ");
		query.append(" AS SNP, ");
		
		query.append(" SUM( ");
		query.append(" CASE ");
		query.append(" WHEN TOTAL_QUANTITY IS NULL THEN NULL ");
		query.append(" WHEN TOTAL_QUANTITY > 0 THEN NULL ");
		query.append(" WHEN TOTAL_QUANTITY < 0 THEN NULL ");
		query.append(" WHEN TOTAL_QUANTITY = 0 THEN NULL ");
		query.append(" ELSE 0 ");
		query.append(" END ");
		query.append(") AS TOTAL_QUANTITY, ");
		
		
		query.append(" CONVERT(VARCHAR(10), SUM( ");
		query.append(" CASE ");
		query.append(" WHEN WMS_STOCK_QUANTITY IS NULL THEN 0 ");
		query.append(" WHEN WMS_STOCK_QUANTITY = 'EMPTY' THEN 0 ");
		query.append(" ELSE CONVERT(INT, WMS_STOCK_QUANTITY) ");
		query.append(" END ");
		query.append(" )) AS WMS_STOCK_QUANTITY, ");
		
		query.append(" CONVERT(VARCHAR(10), SUM(CASE ");
		query.append(" WHEN TOTAL_QUANTITY IS NULL THEN 0 ");
		query.append(" WHEN TOTAL_QUANTITY > 0 THEN 0 ");
		query.append(" WHEN TOTAL_QUANTITY < 0 THEN 0 ");
		query.append(" WHEN TOTAL_QUANTITY = 0 THEN 0 ");
		query.append(" ELSE NULL ");
		query.append(" END) - ");
		query.append(" SUM(CASE ");
		query.append(" WHEN WMS_STOCK_QUANTITY IS NULL THEN 0 ");
		query.append(" WHEN WMS_STOCK_QUANTITY = 'EMPTY' THEN 0 ");
		query.append(" ELSE CONVERT(INT, WMS_STOCK_QUANTITY) ");
		query.append(" END)) AS STOCK_DIFFERENCE, ");
		
		query.append(" CASE ");
		query.append(" SUM(CASE ");
		query.append(" WHEN TOTAL_QUANTITY IS NULL THEN 0 ");
		query.append(" WHEN TOTAL_QUANTITY > 0 THEN 0 ");
		query.append(" WHEN TOTAL_QUANTITY < 0 THEN 0 ");
		query.append(" WHEN TOTAL_QUANTITY = 0 THEN 0 ");
		query.append(" ELSE NULL ");
		query.append(" END) - ");
		query.append(" SUM(CASE ");
		query.append(" WHEN WMS_STOCK_QUANTITY IS NULL THEN 0 ");
		query.append(" WHEN WMS_STOCK_QUANTITY = 'EMPTY' THEN 0 ");
		query.append(" ELSE CONVERT(INT, WMS_STOCK_QUANTITY) ");
		query.append(" END) ");
		query.append(" WHEN 0 THEN 'NO' ");
		query.append("ELSE 'YES' ");
		query.append(" END AS RECOUNT, ");
		
		query.append(" CASE ");
		query.append(" WHEN DEVICE_ID IS NOT NULL THEN NULL ");
		query.append(" WHEN DEVICE_ID = 'EMPTY' THEN '' ");
		query.append(" ELSE NULL ");
		query.append(" END AS DEVICE_ID ");
		
		query.append(" FROM DBO.PIT PL WHERE NOT EXISTS ( ");
		query.append(" SELECT * FROM DBO.PIT_HISTORY PH WHERE 1=1  AND PH.RAN = PL.RAN ");
		query.append(" AND PH.LOCATION = PL.LOCATION ");
		query.append(" AND PH.PART_NO = PL.PART_NO ");
		if (null != pitCumulativeReportDto.getFromDate() || null != pitCumulativeReportDto.getToDate()) {
			
			Map<String,Date> shiftTimes  = WMSBeanUtil.getShiftTime("",pitCumulativeReportDto.getFromDate(),pitCumulativeReportDto.getToDate());
			
			pitCumulativeReportDto.setFromDate(shiftTimes.get("fromDate"));
			pitCumulativeReportDto.setToDate(shiftTimes.get("toDate"));
			
			LOGGER.debug("PIT Transaction Report From Date -> "+ dateFormatter.format(pitCumulativeReportDto.getFromDate()));
			LOGGER.debug("PIT Transaction Report To Date -> "+ dateFormatter.format(pitCumulativeReportDto.getToDate()));
			
			query.append(" AND PH.UPDATED_DATETIME >= '"+ dateFormatter.format(pitCumulativeReportDto.getFromDate()) + "'");
			query.append(" AND PH.UPDATED_DATETIME < '"+ dateFormatter.format(pitCumulativeReportDto.getToDate()) + "'");
		}
		
		if(null != pitCumulativeReportDto.getPlant() && pitCumulativeReportDto.getPlant().length() > 0){
			query.append(" AND SUBSTRING(PH.LOCATION, 1, 1) = '");query.append(pitCumulativeReportDto.getPlant()); query.append("'");
		}
		
		if(null != pitCumulativeReportDto.getShop() && pitCumulativeReportDto.getShop().length() > 0){
			query.append(" AND SUBSTRING(PH.LOCATION, 2, 1) = '");query.append(pitCumulativeReportDto.getShop()); query.append("'");
		}
		
		query.append(" ) ");
		
		if(null != pitCumulativeReportDto.getRanList() && pitCumulativeReportDto.getRanList().size() > 0){
			String ranString = queryStr(pitCumulativeReportDto.getRanList());
			LOGGER.debug("PIT Table Search Input Rans == "+ranString);
			query.append(" AND PL.RAN IN ("); query.append(ranString);  query.append(")");
		}
		
		if(null != pitCumulativeReportDto.getPartList() && pitCumulativeReportDto.getPartList().size() > 0){
			String partString = queryStr(pitCumulativeReportDto.getPartList());
			LOGGER.debug("PIT Table Search Input Parts == "+partString);
			query.append(" AND PL.PART_NO IN ("); query.append(partString);  query.append(")");
		}
		
		if(null != pitCumulativeReportDto.getLocationList() && pitCumulativeReportDto.getLocationList().size() > 0){
			String locationString = queryStr(pitCumulativeReportDto.getLocationList());
			LOGGER.debug("PIT Table Search Input Locations == "+locationString);
			query.append(" AND PL.LOCATION IN ("); query.append(locationString);  query.append(")");
		}
		
		if(null != pitCumulativeReportDto.getPlant() && pitCumulativeReportDto.getPlant().length() > 0){
			query.append(" AND SUBSTRING(PL.LOCATION, 1, 1) = '");query.append(pitCumulativeReportDto.getPlant()); query.append("'");
		}
		
		if(null != pitCumulativeReportDto.getShop() && pitCumulativeReportDto.getShop().length() > 0){
			query.append(" AND SUBSTRING(PL.LOCATION, 2, 1) = '");query.append(pitCumulativeReportDto.getShop()); query.append("'");
		}
		
		query.append(" AND NOT( CASE");
		query.append(" WHEN PL.WMS_STOCK_QUANTITY IS NULL THEN 0 ");
		query.append(" WHEN PL.WMS_STOCK_QUANTITY = 'EMPTY' THEN 0 ");
		query.append(" ELSE CONVERT(INT, PL.WMS_STOCK_QUANTITY) ");
		query.append(" END = 0 ");
		query.append(" AND SUBSTRING(PL.LOCATION, 4, 1) = 'F' ");
		query.append(" )");
		
		query.append(" GROUP BY LOCATION, PART_NO, SNP, DEVICE_ID ");
		query.append(" ORDER BY LOCATION ");
		
		query.append(" ) PIT_TABLE WHERE 1=1 ");
		if(null != pitCumulativeReportDto.getRecount() && pitCumulativeReportDto.getRecount().equalsIgnoreCase("YES")){
			query.append(" AND PIT_TABLE.RECOUNT = '");query.append("YES"); query.append("'");
		}
		
		if(null != pitCumulativeReportDto.getRecount() && pitCumulativeReportDto.getRecount().equalsIgnoreCase("NO")){
			query.append(" AND PIT_TABLE.RECOUNT = '");query.append("NO"); query.append("'");
		}
		
		if(null != pitCumulativeReportDto.getDeviceId() && pitCumulativeReportDto.getDeviceId().length() > 0){
			query.append(" AND PIT_TABLE.DEVICE_ID = '");query.append(pitCumulativeReportDto.getDeviceId()); query.append("'");
		}
		
		LOGGER.debug("Query Generated for PIT Scanned and Not Scanned Cumulative Report == "+query.toString());
		
		return query.toString();
		
	}

	private Object getPitNotScannedQueryCumulative(PITCumulativeReportDTO pitCumulativeReportDto) {
		
		StringBuffer query = new StringBuffer();
		
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		query.append(" SELECT LOCATION, PART_NO, SNP, TOTAL_QUANTITY, WMS_STOCK_QUANTITY, STOCK_DIFFERENCE, ");
		query.append(" RECOUNT, DEVICE_ID FROM ( ");
		
		query.append(" SELECT TOP 100 PERCENT LOCATION, PART_NO, ");
		query.append(" CASE ");
		query.append(" WHEN  SNP IS NOT NULL THEN NULL ");
		query.append(" WHEN  SNP  = -1234567890 THEN 0 ");
		query.append(" ELSE NULL  ");
		query.append(" END ");
		query.append(" AS SNP, ");
		
		query.append(" SUM( ");
		query.append(" CASE ");
		query.append(" WHEN TOTAL_QUANTITY IS NULL THEN NULL ");
		query.append(" WHEN TOTAL_QUANTITY > 0 THEN NULL ");
		query.append(" WHEN TOTAL_QUANTITY < 0 THEN NULL ");
		query.append(" WHEN TOTAL_QUANTITY = 0 THEN NULL ");
		query.append(" ELSE 0 ");
		query.append(" END ");
		query.append(" ) AS TOTAL_QUANTITY, ");
		
		query.append(" CONVERT(VARCHAR(10), SUM( ");
		query.append(" CASE ");
		query.append(" WHEN WMS_STOCK_QUANTITY IS NULL THEN 0 ");
		query.append(" WHEN WMS_STOCK_QUANTITY = 'EMPTY' THEN 0 ");
		query.append(" ELSE CONVERT(INT, WMS_STOCK_QUANTITY) ");
		query.append(" END ");
		query.append(" )) AS WMS_STOCK_QUANTITY, ");
		
		query.append(" CONVERT(VARCHAR(10), SUM(CASE ");
		query.append(" WHEN TOTAL_QUANTITY IS NULL THEN 0 ");
		query.append(" WHEN TOTAL_QUANTITY > 0 THEN 0 ");
		query.append(" WHEN TOTAL_QUANTITY < 0 THEN 0 ");
		query.append(" WHEN TOTAL_QUANTITY = 0 THEN 0 ");
		query.append(" ELSE NULL ");
		query.append(" END) - ");
		query.append(" SUM(CASE ");
		query.append(" WHEN WMS_STOCK_QUANTITY IS NULL THEN 0 ");
		query.append(" WHEN WMS_STOCK_QUANTITY = 'EMPTY' THEN 0 ");
		query.append(" ELSE CONVERT(INT, WMS_STOCK_QUANTITY) ");
		query.append(" END)) AS STOCK_DIFFERENCE, ");
		
		query.append(" CASE ");
		query.append(" SUM(CASE ");
		query.append(" WHEN  TOTAL_QUANTITY IS NULL THEN 0 ");
		query.append(" WHEN TOTAL_QUANTITY > 0 THEN 0 ");
		query.append(" WHEN TOTAL_QUANTITY < 0 THEN 0 ");
		query.append(" WHEN TOTAL_QUANTITY = 0 THEN 0 ");
		query.append(" ELSE NULL ");
		query.append(" END) - ");
		query.append(" SUM(CASE ");
		query.append(" WHEN WMS_STOCK_QUANTITY IS NULL THEN 0 ");
		query.append(" WHEN WMS_STOCK_QUANTITY = 'EMPTY' THEN 0 ");
		query.append(" ELSE CONVERT(INT, WMS_STOCK_QUANTITY) ");
		query.append(" END) ");
		query.append(" WHEN 0 THEN 'NO' ");
		query.append("ELSE 'YES' ");
		query.append(" END AS RECOUNT, ");
		
		query.append(" CASE ");
		query.append(" WHEN DEVICE_ID IS NOT NULL THEN NULL ");
		query.append(" WHEN DEVICE_ID = 'EMPTY' THEN '' ");
		query.append(" ELSE NULL ");
		query.append(" END AS DEVICE_ID ");
		
		query.append(" FROM DBO.PIT PL WHERE NOT EXISTS ( ");
		query.append(" SELECT * FROM DBO.PIT_HISTORY PH WHERE 1=1  AND PH.RAN = PL.RAN ");
		query.append(" AND PH.LOCATION = PL.LOCATION ");
		query.append(" AND PH.PART_NO = PL.PART_NO ");
		if (null != pitCumulativeReportDto.getFromDate() || null != pitCumulativeReportDto.getToDate()) {
			
			Map<String,Date> shiftTimes  = WMSBeanUtil.getShiftTime("",pitCumulativeReportDto.getFromDate(),pitCumulativeReportDto.getToDate());
			
			pitCumulativeReportDto.setFromDate(shiftTimes.get("fromDate"));
			pitCumulativeReportDto.setToDate(shiftTimes.get("toDate"));
			
			LOGGER.debug("PIT Transaction Report From Date -> "+ dateFormatter.format(pitCumulativeReportDto.getFromDate()));
			LOGGER.debug("PIT Transaction Report To Date -> "+ dateFormatter.format(pitCumulativeReportDto.getToDate()));
			
			query.append(" AND PH.UPDATED_DATETIME >= '"+ dateFormatter.format(pitCumulativeReportDto.getFromDate()) + "'");
			query.append(" AND PH.UPDATED_DATETIME < '"+ dateFormatter.format(pitCumulativeReportDto.getToDate()) + "'");
		}
		
		if(null != pitCumulativeReportDto.getPlant() && pitCumulativeReportDto.getPlant().length() > 0){
			query.append(" AND SUBSTRING(PH.LOCATION, 1, 1) = '");query.append(pitCumulativeReportDto.getPlant()); query.append("'");
		}
		
		if(null != pitCumulativeReportDto.getShop() && pitCumulativeReportDto.getShop().length() > 0){
			query.append(" AND SUBSTRING(PH.LOCATION, 2, 1) = '");query.append(pitCumulativeReportDto.getShop()); query.append("'");
		}
		
		query.append(" ) ");
		
		if(null != pitCumulativeReportDto.getRanList() && pitCumulativeReportDto.getRanList().size() > 0){
			String ranString = queryStr(pitCumulativeReportDto.getRanList());
			LOGGER.debug("PIT Table Search Input Rans == "+ranString);
			query.append(" AND PL.RAN IN ("); query.append(ranString);  query.append(")");
		}
		
		if(null != pitCumulativeReportDto.getPartList() && pitCumulativeReportDto.getPartList().size() > 0){
			String partString = queryStr(pitCumulativeReportDto.getPartList());
			LOGGER.debug("PIT Table Search Input Parts == "+partString);
			query.append(" AND PL.PART_NO IN ("); query.append(partString);  query.append(")");
		}
		
		if(null != pitCumulativeReportDto.getLocationList() && pitCumulativeReportDto.getLocationList().size() > 0){
			String locationString = queryStr(pitCumulativeReportDto.getLocationList());
			LOGGER.debug("PIT Table Search Input Locations == "+locationString);
			query.append(" AND PL.LOCATION IN ("); query.append(locationString);  query.append(")");
		}
		
		if(null != pitCumulativeReportDto.getPlant() && pitCumulativeReportDto.getPlant().length() > 0){
			query.append(" AND SUBSTRING(PL.LOCATION, 1, 1) = '");query.append(pitCumulativeReportDto.getPlant()); query.append("'");
		}
		
		if(null != pitCumulativeReportDto.getShop() && pitCumulativeReportDto.getShop().length() > 0){
			query.append(" AND SUBSTRING(PL.LOCATION, 2, 1) = '");query.append(pitCumulativeReportDto.getShop()); query.append("'");
		}
		
		query.append(" AND NOT( CASE");
		query.append(" WHEN PL.WMS_STOCK_QUANTITY IS NULL THEN 0 ");
		query.append(" WHEN PL.WMS_STOCK_QUANTITY = 'EMPTY' THEN 0 ");
		query.append(" ELSE CONVERT(INT, PL.WMS_STOCK_QUANTITY) ");
		query.append(" END = 0 ");
		query.append(" AND SUBSTRING(PL.LOCATION, 4, 1) = 'F' ");
		query.append(" )");
		
		query.append(" GROUP BY LOCATION, PART_NO, SNP, DEVICE_ID ");
		query.append(" ORDER BY LOCATION ");
		
		query.append(" ) PIT_TABLE WHERE 1=1 ");
		if(null != pitCumulativeReportDto.getRecount() && pitCumulativeReportDto.getRecount().equalsIgnoreCase("YES")){
			query.append(" AND PIT_TABLE.RECOUNT = '");query.append("YES"); query.append("'");
		}
		
		if(null != pitCumulativeReportDto.getRecount() && pitCumulativeReportDto.getRecount().equalsIgnoreCase("NO")){
			query.append(" AND PIT_TABLE.RECOUNT = '");query.append("NO"); query.append("'");
		}
		
		if(null != pitCumulativeReportDto.getDeviceId() && pitCumulativeReportDto.getDeviceId().length() > 0){
			query.append(" AND PIT_TABLE.DEVICE_ID = '");query.append(pitCumulativeReportDto.getDeviceId()); query.append("'");
		}
		
		LOGGER.debug("Query Generated for PIT Not Scanned Cumulative Report == "+query.toString());
		
		return query.toString();
	}

	private String queryStr(List<String> queryStr){
		String result = "";
		for(String str : queryStr){
			result = result + "'"+str+"',";
		}
		result = result.substring(0, result.length()-1);
		return result;
	}

}
/*AJ00482484 -- PIT Automation -- END */
