package com.rnaipl.wms.bean;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.LocationByPartDTO;
import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSConstants;
import com.rnaipl.wms.entities.PartLocation;
import com.rnaipl.wms.entities.Location;
import com.rnaipl.wms.entitiesPK.PartLocationPK;

@Stateless
@LocalBean
public class ManageLocationByPartBean implements
		com.rnaipl.wms.bean.ManageLocationByPart {
	private static final Logger LOGGER = Logger
			.getLogger(ManageLocationByPartBean.class);

	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;

	public List<LocationByPartDTO> getLocationsByPartNo(String partNo) {
		List<LocationByPartDTO> result = new ArrayList<LocationByPartDTO>();
		LocationByPartDTO dto = null;
		Query query = entityManager
				.createQuery("select p from PartLocation p where p.part.partNo = :partNo");
		query.setParameter("partNo", partNo);
		List<PartLocation> locationList = query.getResultList();
		if (!locationList.isEmpty() && locationList.size() > 0) {
			for (PartLocation entity : locationList) {
				dto = new LocationByPartDTO();
				dto.setLocationId(entity.getLocation().getLocationId());
				dto.setCurrentQty(entity.getCurrentQty());
				dto.setTotalCapacity(entity.getTotalCapacity());
				dto.setRan(entity.getId().getRan());
				result.add(dto);
			}
		}
		return result;
	}

//	public String deleteLocations(List<LocationByPartDTO> locationList) {
//		String result = "1";
//		List<String> locationIds = new ArrayList<String>();
//		for (LocationByPartDTO locatiosDTO : locationList) {
//			locationIds.add(locatiosDTO.getLocationId());
//			PartLocationPK partLocId = new PartLocationPK();
//			partLocId.setLocationId(locatiosDTO.getLocationId());
//			partLocId.setPartNo(locatiosDTO.getPartNo());
//			PartLocation partLoc = entityManager.find(PartLocation.class,
//					partLocId);
//			if (null != partLoc) {
//				entityManager.remove(partLoc);
//				// if location is removed successfully return "0"
//				result = "0";
//			}
//		}
//		return result;
//	}
	
	public String deleteLocations(List<LocationByPartDTO> locationList) {
		List<String> locationIds = new ArrayList<String>();
		String partNo = "";
		String userId="";
		int updateRes = 0;
		List<String> ranList = new ArrayList<String>();
		for (LocationByPartDTO locatiosDTO : locationList) {
			locationIds.add(locatiosDTO.getLocationId());
			ranList.add(locatiosDTO.getRan());
			partNo = locatiosDTO.getPartNo();
			userId=locatiosDTO.getUserId();
		}
		Query query = entityManager
				.createQuery("DELETE FROM PartLocation p WHERE p.id.partNo = :partNo AND p.id.locationId IN (:locationsList) AND p.id.ran IN (:ranList)");
		query.setParameter("partNo", partNo);
		query.setParameter("locationsList", locationIds);
		query.setParameter("ranList", ranList);
		int res = query.executeUpdate();
		
		// updation in PART_LOCATION_HISTORY when delete happens in PART_LOCATION-start
		if(res>0){
			Query updateQuery = entityManager
					.createNativeQuery("UPDATE [dbo].[PART_LOCATION_HISTORY] SET LAST_UPDATED_BY='"+userId+"' WHERE PART_NO = :partNo AND LOCATION_ID IN (:locationsList) AND RAN IN (:ranList) ");
			updateQuery.setParameter("partNo", partNo);
			updateQuery.setParameter("locationsList", locationIds);
			updateQuery.setParameter("ranList", ranList);		
			updateRes = updateQuery.executeUpdate();
			LOGGER.debug("update PART_LOCATION_HISTORY result : " +updateRes);
		}	
		//updation in PART_LOCATION_HISTORY when delete happens in PART_LOCATION-end
		LOGGER.debug("IN delete location --deleted records:"+res);
		return res+"";
	}

	public String addLocation(LocationByPartDTO locationDto) {
		Location locEntity = new Location();
		locEntity.setLocationId(locationDto.getLocationId());
		Location locExists = entityManager.find(Location.class,
				locationDto.getLocationId());
		LOGGER.debug("In insertlocation  locExists:"+locExists);
		if (null == locExists) {
			return "1";
		}
		PartLocationPK partLocId = new PartLocationPK();
		partLocId.setLocationId(locationDto.getLocationId());
		partLocId.setPartNo(locationDto.getPartNo());
		partLocId.setRan((null == locationDto.getRan() || "".equals(locationDto.getRan().trim())) ? WMSConstants.DEFAULT_RAN : locationDto.getRan());
		
		PartLocation partLoc = entityManager.find(PartLocation.class,
				partLocId);
		LOGGER.debug("IN insertlocation partLocId:"+partLocId);
		if (null != partLoc) {
			return "2";
		}
		
		LOGGER.debug("**Loc Exist getParts " + locExists.getParts());
		if(locExists.getParts()!=null)
		{
			LOGGER.debug("**lOCATION PARTS SIZE " + locExists.getParts().size());
		}
		
		if(locationDto.getLocationId().substring(3,4).equalsIgnoreCase("W")){
			LOGGER.debug("** Location is W ");
			 if(locExists.getParts() != null ){
				 
				 LOGGER.debug("** locationExist part is not null ");
				  
				 if(locExists.getParts().size()>0){
					 return "3";	 
				 }
			 }
			/* else if(locExists.getParts().size()>0){
				 LOGGER.debug("** locationExist part size is greater than 0 ");
				 return "3";
			 }*/
		}
		LOGGER.debug("** mapping check ends ");
		/*PartLocationPK pkId = new PartLocationPK();
		pkId.setLocationId(locationDto.getLocationId());
		pkId.setPartNo(locationDto.getPartNo());*/
		com.rnaipl.wms.entities.PartLocation partLocation = new com.rnaipl.wms.entities.PartLocation();
		partLocation.setCurrentQty(locationDto.getCurrentQty());
		partLocation.setTotalCapacity(locationDto.getTotalCapacity());
		//partLocation.setRan(locationDto.getRan()); 

		partLocation.setId(partLocId);
		entityManager.persist(partLocation);

		// insert PartLocation EXIT
		LOGGER.debug("IN insertLocation -- DATA inserted Successfully !!");
		return "0";
	}

	public String saveLocations(List<LocationByPartDTO> locationList) {
		String result = "1";
		for (LocationByPartDTO locatiosDTO : locationList) {
			PartLocationPK partLocId = new PartLocationPK();
			partLocId.setLocationId(locatiosDTO.getLocationId());
			partLocId.setPartNo(locatiosDTO.getPartNo());
			partLocId.setRan(locatiosDTO.getRan());
			PartLocation partLoc = entityManager.find(PartLocation.class,
					partLocId);
			if (null != partLoc) {
				partLoc.setTotalCapacity(locatiosDTO.getTotalCapacity());
				partLoc.setCurrentQty(locatiosDTO.getCurrentQty());
				//partLoc.setRan(locatiosDTO.getRan());
				LOGGER.debug("Total Cap :" + partLoc.getTotalCapacity()+" currentQty:"+locatiosDTO.getCurrentQty()+" ran:"+locatiosDTO.getRan());
				entityManager.merge(partLoc);
				// if location is updated successfully return "0"
				result = "0";
			}
		}
		return result;
	}
}
