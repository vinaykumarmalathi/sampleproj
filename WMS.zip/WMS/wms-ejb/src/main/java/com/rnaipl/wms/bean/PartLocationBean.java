package com.rnaipl.wms.bean;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.PartLocationCorrectionDTO;
import com.rnaipl.wms.dto.PartLocationDTO;
import com.rnaipl.wms.entities.PartinoutStaging;
import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSBeanUtil;


/**
 * 
 * @author TechM
 * 
 */
@Stateless
@LocalBean
public class PartLocationBean implements PartLocation {

    private static final Logger LOGGER = Logger.getLogger(PartLocationBean.class);

    @PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
    private EntityManager entityManager;

  
    
    /**
     * @param partLocCorrDTOs
     */
   
    
    public List<PartLocationDTO> getPartLocations(PartLocationDTO partLoc) {
        LOGGER.debug("getPartLocations() method starts ");
        LOGGER.debug("** Part Number " + partLoc.getPartNo());
        LOGGER.debug("** Plant " + partLoc.getPlant());
        LOGGER.debug("** Shop " + partLoc.getShop());
        LOGGER.debug("** line " + partLoc.getLine());
        LOGGER.debug("** section " + partLoc.getSection());
        LOGGER.debug("** Start Index " + partLoc.getStartIndex());
        LOGGER.debug("** End Index " + partLoc.getEndIndex());

        List<PartLocationDTO> partLocationDTOs = new ArrayList<PartLocationDTO>();
        StringBuffer queryStringBuf = new StringBuffer();
        queryStringBuf.append("select PART_NO,LOCATION_ID,CURRENT_QTY,LOCATION_TYPE from ( ");
        queryStringBuf.append("SELECT PARTQTY.PART_NO,PARTQTY.LOCATION_ID,PARTQTY.CURRENT_QTY,LOC.LOCATION_TYPE FROM  ");
        queryStringBuf.append("DBO.LOCATION LOC,(SELECT PL.LOCATION_ID AS LOCATION_ID,PL.PART_NO PART_NO,SUM(CURRENT_QTY) AS CURRENT_QTY  ");
        queryStringBuf.append("FROM DBO.PART_LOCATION PL,DBO.LOCATION L  WHERE PL.LOCATION_ID=L.LOCATION_ID ");
        if (null != partLoc.getRan() && !partLoc.getRan().equals("")) {
            queryStringBuf.append(" AND  PL.RAN IN (:rans)");
        }
        queryStringBuf.append(" GROUP BY PL.PART_NO,PL.LOCATION_ID ) PARTQTY  ");
        queryStringBuf.append(" WHERE LOC.LOCATION_ID=PARTQTY.LOCATION_ID  ");
        queryStringBuf.append(" AND   NOT (CURRENT_QTY=0 AND SUBSTRING(LOC.LOCATION_ID,4,1)='F')");
        
        if (null != partLoc.getPlant() && !partLoc.getPlant().equals("")) {
            queryStringBuf.append(" AND  LOC.PLANT = '" + partLoc.getPlant() + "'");
        }
        if (null != partLoc.getShop() && !partLoc.getShop().equals("")) {
            queryStringBuf.append(" AND  LOC.SHOP = '" + partLoc.getShop() + "'");
        }
        if (null != partLoc.getLine() && !partLoc.getLine().equals("")) {
            queryStringBuf.append(" AND  LOC.LINE = '" + partLoc.getLine() + "'");
        }
        if (null != partLoc.getSection() && !partLoc.getSection().equals("")) {
            queryStringBuf.append(" AND  LOC.SECTION= '" + partLoc.getSection() + "'");
        }
        if (null != partLoc.getLocationId() && !partLoc.getLocationId().equals("")) {
            queryStringBuf.append(" AND  LOC.LOCATION_ID IN (:locationIds)"); 	
        }
        if (null != partLoc.getPartNo() && !partLoc.getPartNo().equals("")) {
            queryStringBuf.append(" AND  PARTQTY.PART_NO IN (:partNos)");
        }
        queryStringBuf.append(" Union ");
        
        queryStringBuf.append(" Select  distinct  RES.PART_NO,RES.LOCATION_ID,RES.CURRENT_QTY ,RES.LOCATION_TYPE from ( ");
        
        queryStringBuf.append(" Select  PART_NO,concat(Line,Shop,Zone) AS LOCATION_ID,SUM(Stock) AS CURRENT_QTY,'LS' AS LOCATION_TYPE ");
        queryStringBuf.append(" from TBL_LNFD_STK_MASTER M where 1=1 ");
        if (null != partLoc.getShop() && !partLoc.getShop().equals("")) {
            queryStringBuf.append(" AND  M.SHOP = ('"+partLoc.getShop()+"') ");
        }
        if (null != partLoc.getLine() && !partLoc.getLine().equals("")) {
            queryStringBuf.append(" and M.LINE='" + partLoc.getLine() + "'");
        }
        queryStringBuf.append(" Group by concat(Line,Shop,Zone),PART_NO ) RES  ");
        queryStringBuf.append(" inner join  PART_LOCATION PL on  1=1  ");
        queryStringBuf.append(" and PL.PART_NO=RES.PART_NO  ");
        if (null != partLoc.getLocationId() && !partLoc.getLocationId().equals("")) {
            queryStringBuf.append(" and PL.LOCATION_ID in (:locationIdsLS) ");
        }
        if (null != partLoc.getPartNo() && !partLoc.getPartNo().equals("")) {
            queryStringBuf.append(" AND RES.PART_NO IN (:partNosLS) ");
        }
        
        queryStringBuf.append(" ) RES1  order by RES1.PART_NO,RES1.LOCATION_ID ");
        
        System.out.println(">>>>>>>>>>>>>"+queryStringBuf.toString());
        LOGGER.debug("Query :  " + queryStringBuf.toString());
        Query query = entityManager.createNativeQuery(queryStringBuf.toString());

        if (null != partLoc.getPartNo() && !partLoc.getPartNo().equalsIgnoreCase("")) {
            query.setParameter("partNos", partLoc.getPartList());
            query.setParameter("partNosLS", partLoc.getPartList());
        }
        if (null != partLoc.getLocationId() && !partLoc.getLocationId().equalsIgnoreCase("")) {
            query.setParameter("locationIds", partLoc.getLocationList());
            query.setParameter("locationIdsLS", partLoc.getLocationList());
        }
        if (null != partLoc.getRan() && !partLoc.getRan().equalsIgnoreCase("")) {
            query.setParameter("rans", partLoc.getRanList());
        }

        query.setFirstResult(partLoc.getStartIndex());
        query.setMaxResults(partLoc.getEndIndex());
        LOGGER.debug("*Stock Location start index " +partLoc.getStartIndex() );
        LOGGER.debug("*Stock Location end index " +partLoc.getEndIndex() );
        
        List<Object[]> partLocations = query.getResultList();
        
       LOGGER.debug("partLocations size " + partLocations.size());

        if (null != partLocations && partLocations.size() > 0) {
            for (Iterator<Object[]> i = partLocations.iterator(); i.hasNext();) {
            	int indexCount=0;
                Object[] values = (Object[]) i.next();
                PartLocationDTO partLocationDto = new PartLocationDTO();
                partLocationDto.setPartNo((null == values[indexCount] ? "" : values[indexCount].toString()));
                indexCount++;
                partLocationDto.setLocationId((null == values[indexCount] ? "" : values[indexCount].toString()));
                indexCount++;
               // partLocationDto.setTotalCapactity((Integer) (null == values[2] ? 0 : values[2]));
                partLocationDto.setCurrentQty((Integer) (null == values[indexCount] ? 0 : values[indexCount]));
                indexCount++;
                partLocationDto.setLocationType((null == values[indexCount] ? "" : values[indexCount].toString()));
                indexCount++;
                partLocationDTOs.add(partLocationDto);
            }

        }

        LOGGER.debug("getAllPartLocations() method Ends " + partLocationDTOs.size());
        return partLocationDTOs;
    }

    public int getPartLocationCount(PartLocationDTO partLoc) {
        LOGGER.debug("getPartLocationCount() method starts ");
        LOGGER.debug("** Part Number " + partLoc.getPartNo());
        LOGGER.debug("** Plant " + partLoc.getPlant());
        LOGGER.debug("** Shop " + partLoc.getShop());
        LOGGER.debug("** line " + partLoc.getLine());
        LOGGER.debug("** section " + partLoc.getSection());

        StringBuffer queryStringBuf1 = new StringBuffer();
        queryStringBuf1.append("Select Count(*) FROM ");
        queryStringBuf1.append("DBO.LOCATION LOC,(SELECT PL.LOCATION_ID AS LOCATION_ID,PL.PART_NO PART_NO,SUM(CURRENT_QTY) AS CURRENT_QTY  ");
        queryStringBuf1.append("FROM DBO.PART_LOCATION PL,DBO.LOCATION L  WHERE PL.LOCATION_ID=L.LOCATION_ID ");
        if (null != partLoc.getRan() && !partLoc.getRan().equals("")) {
        	queryStringBuf1.append(" AND  PL.RAN IN (:rans)");
        }
        queryStringBuf1.append(" GROUP BY PL.PART_NO,PL.LOCATION_ID ) PARTQTY  ");
        queryStringBuf1.append(" WHERE LOC.LOCATION_ID=PARTQTY.LOCATION_ID  ");
        queryStringBuf1.append(" AND   NOT (CURRENT_QTY=0 AND SUBSTRING(LOC.LOCATION_ID,4,1)='F')"); 
        
        if (null != partLoc.getPlant() && !partLoc.getPlant().equals("")) {
        	queryStringBuf1.append(" AND  LOC.PLANT = '" + partLoc.getPlant() + "'");
        }
        if (null != partLoc.getShop() && !partLoc.getShop().equals("")) {
        	queryStringBuf1.append(" AND  LOC.SHOP = '" + partLoc.getShop() + "'");
        }
        if (null != partLoc.getLine() && !partLoc.getLine().equals("")) {
        	queryStringBuf1.append(" AND  LOC.LINE = '" + partLoc.getLine() + "'");
        }
        if (null != partLoc.getSection() && !partLoc.getSection().equals("")) {
        	queryStringBuf1.append(" AND  LOC.SECTION= '" + partLoc.getSection() + "'");
        }
        if (null != partLoc.getLocationId() && !partLoc.getLocationId().equals("")) {
        	queryStringBuf1.append(" AND  LOC.LOCATION_ID IN (:locationIds)");
        }
        if (null != partLoc.getPartNo() && !partLoc.getPartNo().equals("")) {
        	queryStringBuf1.append(" AND  PARTQTY.PART_NO IN (:partNos)");
        }
       
        LOGGER.debug("Query Count :  " + queryStringBuf1.toString());

        Query query1 = entityManager.createNativeQuery(queryStringBuf1.toString());

   
        if (null != partLoc.getPartNo() && !partLoc.getPartNo().equalsIgnoreCase("")) {
        	query1.setParameter("partNos", partLoc.getPartList());
        }
        if (null != partLoc.getLocationId() && !partLoc.getLocationId().equalsIgnoreCase("")) {
        	query1.setParameter("locationIds", partLoc.getLocationList());
        }
        if (null != partLoc.getRan() && !partLoc.getRan().equalsIgnoreCase("")) {
        	query1.setParameter("rans", partLoc.getRanList());
        }
        
        int noOfRecords = (Integer) query1.getSingleResult();
        LOGGER.debug("recordCount :  " + noOfRecords);

        return noOfRecords;
    }
    
    public List<PartLocationDTO> downloadPartLocations(PartLocationDTO partLoc){
    	 List<PartLocationDTO> partLocationDTOs = new ArrayList<PartLocationDTO>();
         StringBuffer queryStringBuf = new StringBuffer();
     
         queryStringBuf.append(" SELECT PL.PART_NO,PL.LOCATION_ID,PL.RAN,PL.CURRENT_QTY,PL.TOTAL_CAPACITY FROM DBO.PART_LOCATION PL, DBO.LOCATION L  ");
         queryStringBuf.append(" WHERE L.LOCATION_ID=PL.LOCATION_ID  ");
         queryStringBuf.append(" AND  NOT (CURRENT_QTY=0 AND SUBSTRING(PL.LOCATION_ID,4,1)='F') "); 
         
         
         if (null != partLoc.getPlant() && !partLoc.getPlant().equals("")) {
             queryStringBuf.append(" AND  L.PLANT = '" + partLoc.getPlant() + "'");
         }
         if (null != partLoc.getShop() && !partLoc.getShop().equals("")) {
             queryStringBuf.append(" AND  L.SHOP = '" + partLoc.getShop() + "'");
         }
         if (null != partLoc.getLine() && !partLoc.getLine().equals("")) {
             queryStringBuf.append(" AND  L.LINE = '" + partLoc.getLine() + "'");
         }
         if (null != partLoc.getSection() && !partLoc.getSection().equals("")) {
             queryStringBuf.append(" AND  L.SECTION= '" + partLoc.getSection() + "'");
         }
         if (null != partLoc.getLocationId() && !partLoc.getLocationId().equals("")) {
             queryStringBuf.append(" AND  L.LOCATION_ID IN (:locationIds)");
         }
         if (null != partLoc.getPartNo() && !partLoc.getPartNo().equals("")) {
             queryStringBuf.append(" AND  PL.PART_NO IN (:partNos)");
         }
         if (null != partLoc.getRan() && !partLoc.getRan().equals("")) {
             queryStringBuf.append(" AND  PL.RAN IN (:rans)");
         }
        
         queryStringBuf.append(" UNION ");
         queryStringBuf.append(" Select  distinct  RES.PART_NO,RES.LOCATION_ID,'' AS RAN,RES.CURRENT_QTY ,0 AS TOTAL_CAPACITY  ");
         queryStringBuf.append("from (  ");
         queryStringBuf.append("Select  ");
         queryStringBuf.append("PART_NO,");
         queryStringBuf.append("concat(Line,Shop,Zone) AS LOCATION_ID,");
         queryStringBuf.append("SUM(Stock) AS CURRENT_QTY,");
         queryStringBuf.append("'LS' AS LOCATION_TYPE ");
         queryStringBuf.append("from TBL_LNFD_STK_MASTER M ");
         queryStringBuf.append("where 1=1   ");
         if (null != partLoc.getShop() && !partLoc.getShop().equals("")) {
             queryStringBuf.append("AND M.SHOP = ('" + partLoc.getShop() + "')   ");
         }
         if (null != partLoc.getLine() && !partLoc.getLine().equals("")) {
             queryStringBuf.append("and M.LINE='"+partLoc.getLine()+"' ");
         }
         queryStringBuf.append("Group by concat(Line,Shop,Zone),PART_NO ) RES   inner join  PART_LOCATION PL on  1=1   ");
         queryStringBuf.append("and PL.PART_NO=RES.PART_NO ");
         if (null != partLoc.getLocationId() && !partLoc.getLocationId().equals("")) {
             queryStringBuf.append(" and PL.LOCATION_ID in (:locationIdsLS) ");
         }
         if (null != partLoc.getPartNo() && !partLoc.getPartNo().equals("")) {
             queryStringBuf.append(" AND RES.PART_NO IN (:partNosLS) ");
         }
         
         
         
         LOGGER.debug("Query :  " + queryStringBuf.toString());
         System.out.println("<<<<<<>>>>>>"+queryStringBuf.toString());
         Query query = entityManager.createNativeQuery(queryStringBuf.toString());

         if (null != partLoc.getPartNo() && !partLoc.getPartNo().equalsIgnoreCase("")) {
             query.setParameter("partNos", partLoc.getPartList());
             query.setParameter("partNosLS", partLoc.getPartList());
         }
         if (null != partLoc.getLocationId() && !partLoc.getLocationId().equalsIgnoreCase("")) {
             query.setParameter("locationIds", partLoc.getLocationList());
             query.setParameter("locationIdsLS", partLoc.getLocationList());
         }
         if (null != partLoc.getRan() && !partLoc.getRan().equalsIgnoreCase("")) {
             query.setParameter("rans", partLoc.getRanList());
         }

   

         List<Object[]> partLocations = query.getResultList();
         LOGGER.debug("partLocations size " + partLocations.size());

         if (null != partLocations && partLocations.size() > 0) {
             for (Iterator<Object[]> i = partLocations.iterator(); i.hasNext();) {
             	int indexCount=0;
                 Object[] values = (Object[]) i.next();
                 PartLocationDTO partLocationDto = new PartLocationDTO();
                 partLocationDto.setPartNo((null == values[indexCount] ? "" : values[indexCount].toString()));
                 indexCount++;
                 partLocationDto.setLocationId((null == values[indexCount] ? "" : values[indexCount].toString()));
                 indexCount++;
                 partLocationDto.setRan((null == values[indexCount] ? "" : values[indexCount].toString()));
                 indexCount++;
                 partLocationDto.setCurrentQty((Integer) (null == values[indexCount] ? 0 : values[indexCount]));
                 indexCount++;    
                 partLocationDto.setTotalCapactity((Integer) (null == values[indexCount] ? 0 : values[indexCount]));
                 indexCount++; 
                 partLocationDTOs.add(partLocationDto);
             }

         }

         LOGGER.debug("getAllPartLocations() method Ends " + partLocationDTOs.size());
         return partLocationDTOs;
    	
    }
    
}
