package com.rnaipl.wms.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the COMMON_PARAMETER database table.
 * 
 */
@Entity
@Table(name="COMMON_PARAMETER")
@NamedQuery(name="CommonParameter.findAll", query="SELECT c FROM CommonParameter c")
public class CommonParameter implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID")
	private String id;

	@Column(name="NAME")
	private String name;

	@Column(name="[VALUE]")
	private String value;

	public CommonParameter() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}