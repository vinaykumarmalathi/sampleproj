package com.rnaipl.wms.bean;

import java.util.List;

import com.rnaipl.wms.dto.PartsInOutAuditErrorDTO;
import com.rnaipl.wms.dto.PartsInOutAuditSearchDTO;

public interface PartsInOutAuditSearch {
	
		
	public List<PartsInOutAuditSearchDTO> getPartsAuditSearch(PartsInOutAuditSearchDTO PartsInOutAuditSearchDTO) throws Exception;
	
	public int getPartInOutAuditSearchCount(PartsInOutAuditSearchDTO PartsInOutAuditSearchDTO);
	
}
