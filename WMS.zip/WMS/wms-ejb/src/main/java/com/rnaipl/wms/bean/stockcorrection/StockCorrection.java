package com.rnaipl.wms.bean.stockcorrection;

import java.util.List;

import com.rnaipl.wms.dto.PartLocationCorrectionDTO;
import com.rnaipl.wms.dto.PartLocationDTO;
import com.rnaipl.wms.dto.StockCorrectionDTO;
import com.rnaipl.wms.dto.StockCorrectionReasonDTO;


/**
 * 
 * @author TechM
 * 
 */
public interface StockCorrection {
    
    /**
     * It will retrive all the PartLocation details information from database
     * 
     * @return - list of PartLocationDTO object
     */
    List<PartLocationDTO> getStockCorrectionPartLocations(PartLocationDTO partLoc);

    int getStockCorrectionPartLocationCount(PartLocationDTO partLoc);
    
	public void updatePartLocation(List<PartLocationCorrectionDTO> partLocCorrDTOs);
	
	public void moveAllRanToDifferentLoc(PartLocationCorrectionDTO partLocationCorrectionDTO); 

	public List<StockCorrectionReasonDTO> getAllStockCorrectionReason();
 
}
