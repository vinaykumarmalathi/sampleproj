package com.rnaipl.wms.bean.common;


public interface CommonParameter {

	public String  getParamValueById(String id);
	
}
