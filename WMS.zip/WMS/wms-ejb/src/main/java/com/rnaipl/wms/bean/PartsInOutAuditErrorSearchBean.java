package com.rnaipl.wms.bean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.PartsInOutAuditErrorDTO;
import com.rnaipl.wms.entities.PartinoutStagingError;
import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSBeanUtil;

@Stateless
@LocalBean
public class PartsInOutAuditErrorSearchBean implements PartsAuditErrorSearch {

	private static final Logger LOGGER = Logger
			.getLogger(PartsInOutAuditErrorSearchBean.class);

	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;


	public List<PartsInOutAuditErrorDTO> getPartsAuditErrorSearch(
			PartsInOutAuditErrorDTO partsInOutAuditErrorDTO)  {
		// TODO Auto-generated method stub
				LOGGER.debug("*** getPartsAuditSearch -- Location* ENTRY"
						+ partsInOutAuditErrorDTO.getLocation());
				List<PartsInOutAuditErrorDTO> partInOutAuditDtos = new ArrayList<PartsInOutAuditErrorDTO>();

				StringBuffer queryStringBuf = new StringBuffer();
				queryStringBuf.append("select p from PartinoutStagingError p");
				queryStringBuf.append(" WHERE 1=1");
				queryStringBuf.append(WMSBeanUtil.createQueryParamForPartInOutError(partsInOutAuditErrorDTO));
				queryStringBuf.append(" ORDER BY p.partInOutTime DESC");
				

				Query query = entityManager
						.createQuery(queryStringBuf.toString());
				LOGGER.debug("**Part Inout Error Query " + queryStringBuf.toString());
				if (null != partsInOutAuditErrorDTO.getPartNumber() && !partsInOutAuditErrorDTO.getPartNumber().equalsIgnoreCase("")) {
					query.setParameter("partNos", partsInOutAuditErrorDTO.getPartList());
		        }
				if (null != partsInOutAuditErrorDTO.getLocation() && !partsInOutAuditErrorDTO.getLocation().equalsIgnoreCase("")) {
					query.setParameter("locationNos", partsInOutAuditErrorDTO.getLocationList());
		        }
				 if (null != partsInOutAuditErrorDTO.getRan() && !partsInOutAuditErrorDTO.getRan().equalsIgnoreCase("")) {
					 query.setParameter("rans", partsInOutAuditErrorDTO.getRanList());
			    }
				query.setFirstResult(partsInOutAuditErrorDTO.getStartIndex());
				query.setMaxResults(partsInOutAuditErrorDTO.getEndIndex());
				
				List<PartinoutStagingError> queryDatas = query.getResultList();
				

				if (null != queryDatas && queryDatas.size() > 0) {
					for (PartinoutStagingError values : queryDatas) {				
						PartsInOutAuditErrorDTO partinoutStagingError = setPartsInOutData(values);						
						partInOutAuditDtos.add(partinoutStagingError);
					}

				}

				LOGGER.debug("*** getPartsAuditSearch -- Location* EXIT");
				return partInOutAuditDtos;
	}

	public int getPartInOutAuditErrorSearchCount(
			PartsInOutAuditErrorDTO partsInOutAuditError) {
		StringBuffer queryStringBuf = new StringBuffer();
		queryStringBuf.append("select count(p) from PartinoutStagingError p");
		queryStringBuf.append(" WHERE 1=1");
		queryStringBuf.append(WMSBeanUtil.createQueryParamForPartInOutError(partsInOutAuditError));
		
		LOGGER.debug("Query Count :  " + queryStringBuf.toString());
        Query query1 = entityManager.createQuery(queryStringBuf.toString());
		
        if (null != partsInOutAuditError.getPartNumber() && !partsInOutAuditError.getPartNumber().equalsIgnoreCase("")) {
        	query1.setParameter("partNos", partsInOutAuditError.getPartList());
        }
        if (null != partsInOutAuditError.getLocation() && !partsInOutAuditError.getLocation().equalsIgnoreCase("")) {
        	query1.setParameter("locationNos", partsInOutAuditError.getLocationList());
        }
        if (null != partsInOutAuditError.getRan() && !partsInOutAuditError.getRan().equalsIgnoreCase("")) {
        	query1.setParameter("rans", partsInOutAuditError.getRanList());
        }
        Long noOfRecords = (Long) query1.getSingleResult();
        LOGGER.debug("recordCount :  " + noOfRecords);

        return noOfRecords.intValue();
	}
	


	private PartsInOutAuditErrorDTO setPartsInOutData(PartinoutStagingError partsAuditData) {

		PartsInOutAuditErrorDTO partInOutAuditErrorDto = new PartsInOutAuditErrorDTO();
		LOGGER.debug("****Part No" + partsAuditData.getPartNo());
		LOGGER.debug("****Location Type" + partsAuditData.getLocation());
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
		try {
			partInOutAuditErrorDto.setPartNumber((null == partsAuditData.getPartNo() ? ""
					: partsAuditData.getPartNo().toString()));
			partInOutAuditErrorDto.setLocation((null == partsAuditData.getLocation() ? ""
					: partsAuditData.getLocation().toString()));
			partInOutAuditErrorDto.setTransactionType((null == partsAuditData.getTransactionType() ? ""
					: partsAuditData.getTransactionType().toString()));
			partInOutAuditErrorDto.setCount(partsAuditData.getCount());
			partInOutAuditErrorDto.setRan((null == partsAuditData.getRan() ? "" : partsAuditData.getRan()
					.toString()));
			partInOutAuditErrorDto.setUserId((null == partsAuditData.getUserId() ? ""
					: partsAuditData.getUserId().toString()));
			partInOutAuditErrorDto.setDeviceId((null == partsAuditData.getDeviceId() ? ""
					: partsAuditData.getDeviceId().toString()));

			partInOutAuditErrorDto.setPartInOutTime(null == partsAuditData.getPartInOutTime() ? null
					: partsAuditData.getPartInOutTime());

			partInOutAuditErrorDto.setReasonCode((null == partsAuditData.getReasonCode() ? ""
					: partsAuditData.getReasonCode().getReasonCode()));
			partInOutAuditErrorDto.setComments((null == partsAuditData.getComments() ? ""
					: partsAuditData.getComments().toString()));
			partInOutAuditErrorDto.setReason((null == partsAuditData.getReasonCode() ? ""
					: partsAuditData.getReasonCode().getReason().toString()));
			partInOutAuditErrorDto.setErrorMessage(setErrorMessage(partsAuditData.getErrorCode()));
			partInOutAuditErrorDto.setSuggestedLocation((null == partsAuditData.getSuggestedLocation() ? ""
					: partsAuditData.getSuggestedLocation().toString()));
			partInOutAuditErrorDto.setSuggestedRan((null == partsAuditData.getSuggestedRan() ? ""
					: partsAuditData.getSuggestedRan().toString()));
			partInOutAuditErrorDto.setLocationDestination((null == partsAuditData.getLocationDestination() ? ""
					: partsAuditData.getLocationDestination().toString()));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return partInOutAuditErrorDto;

	}

	private String setErrorMessage(int errorCode) {
		if(errorCode == 1) {
			return "PART NOT EXIST";
		} else if (errorCode == 2) {
			return "LOCATION NOT EXIST";
		} else if (errorCode == 3) {
			return "PART-LOCATION COMBINATION NOT EXIST";
		}else if (errorCode == 4) {
			return "DUPLICATE RECORD";
		}
		
		return "";
	} 
	
}
