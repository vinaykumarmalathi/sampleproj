package com.rnaipl.wms.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the LOCATION_TYPE database table.
 * 
 */
@Entity
@Table(name="LOCATION_TYPE")
@NamedQuery(name="LocationType.findAll", query="SELECT l FROM LocationType l")
public class LocationType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LOCATIONTYPE_ID")
	private String locationtypeId;

	@Column(name="LOCATION_TYPE")
	private String locationType;

	/*//bi-directional many-to-one association to Location
	@OneToMany(mappedBy="locationTypeBean")
	private List<Location> locations;*/

	public LocationType() {
	}

	public String getLocationtypeId() {
		return this.locationtypeId;
	}

	public void setLocationtypeId(String locationtypeId) {
		this.locationtypeId = locationtypeId;
	}

	public String getLocationType() {
		return this.locationType;
	}

	public void setLocationType(String locationType) {
		this.locationType = locationType;
	}



}