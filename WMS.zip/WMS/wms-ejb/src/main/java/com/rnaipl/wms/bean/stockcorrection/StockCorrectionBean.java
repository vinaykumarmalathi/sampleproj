package com.rnaipl.wms.bean.stockcorrection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.PartLocationCorrectionDTO;
import com.rnaipl.wms.dto.PartLocationDTO;
import com.rnaipl.wms.dto.StockCorrectionReasonDTO;
import com.rnaipl.wms.entities.PartinoutStaging;
import com.rnaipl.wms.entities.StockCorrectionReasons;
import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSBeanUtil;


/**
 * 
 * @author TechM
 * 
 */
@Stateless
@LocalBean
public class StockCorrectionBean implements StockCorrection {

    private static final Logger LOGGER = Logger.getLogger(StockCorrectionBean.class);

    @PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
    private EntityManager entityManager;


	
	public List<PartLocationDTO> getStockCorrectionPartLocations(PartLocationDTO partLoc) {
        LOGGER.debug("getPartLocations() method starts ");
        LOGGER.debug("** Part Number " + partLoc.getPartNo());
        LOGGER.debug("** Plant " + partLoc.getPlant());
        LOGGER.debug("** Shop " + partLoc.getShop());
        LOGGER.debug("** line " + partLoc.getLine());
        LOGGER.debug("** section " + partLoc.getSection());
        LOGGER.debug("** Start Index " + partLoc.getStartIndex());
        LOGGER.debug("** End Index " + partLoc.getEndIndex());

        List<PartLocationDTO> partLocationDTOs = new ArrayList<PartLocationDTO>();
        StringBuffer queryStringBuf = new StringBuffer();
        queryStringBuf.append("Select PL.PART_NO as Part_NO , PL.LOCATION_ID as Location_Id,PL.RAN, PL.TOTAL_CAPACITY,PL.CURRENT_QTY , LT.LOCATIONTYPE_ID, LT.LOCATION_TYPE ");
        queryStringBuf.append(" from [dbo].[PART_LOCATION] PL , [dbo].[LOCATION] L , [dbo].[LOCATION_TYPE] LT ");
        queryStringBuf.append(" WHERE PL.LOCATION_ID = L.LOCATION_ID and  L.LOCATION_TYPE = LT.LOCATIONTYPE_ID ");

        if (null != partLoc.getPlant() && !partLoc.getPlant().equals("")) {
            queryStringBuf.append(" AND  L.PLANT = '" + partLoc.getPlant() + "'");
        }
        if (null != partLoc.getShop() && !partLoc.getShop().equals("")) {
            queryStringBuf.append(" AND  L.SHOP = '" + partLoc.getShop() + "'");
        }
        if (null != partLoc.getLine() && !partLoc.getLine().equals("")) {
            queryStringBuf.append(" AND  L.LINE = '" + partLoc.getLine() + "'");
        }
        if (null != partLoc.getSection() && !partLoc.getSection().equals("")) {
            queryStringBuf.append(" AND  L.SECTION= '" + partLoc.getSection() + "'");
        }
        if (null != partLoc.getPartNo() && !partLoc.getPartNo().equals("")) {
            queryStringBuf.append(" AND  PL.PART_NO IN (:partNos)");
        }
       /* if (null != partLoc.getLocationId() && !partLoc.getLocationId().equals("")) {
            queryStringBuf.append(" AND  PL.LOCATION_ID IN (:locationIds)");
        }*/
        if (null != partLoc.getRan() && !partLoc.getRan().equals("")) {
        	queryStringBuf.append(" AND  PL.RAN IN (:rans)");
        }
        queryStringBuf.append(" ORDER BY PL.PART_NO, PL.LOCATION_ID");
        
        LOGGER.debug("Query :  " + queryStringBuf.toString());
        Query query = entityManager.createNativeQuery(queryStringBuf.toString());

        if (null != partLoc.getPartNo() && !partLoc.getPartNo().equalsIgnoreCase("")) {
            query.setParameter("partNos", partLoc.getPartList());
        }
     /*   if (null != partLoc.getLocationId() && !partLoc.getLocationId().equalsIgnoreCase("")) {
            query.setParameter("locationIds", partLoc.getLocationList());
        }*/
        if (null != partLoc.getRan() && !partLoc.getRan().equalsIgnoreCase("")) {
            query.setParameter("rans", partLoc.getRanList());
        }
        query.setFirstResult(partLoc.getStartIndex());
        query.setMaxResults(partLoc.getEndIndex());

        List<Object[]> partLocations = query.getResultList();
        LOGGER.debug("partLocations size " + partLocations.size());

        if (null != partLocations && partLocations.size() > 0) {
            for (Iterator<Object[]> i = partLocations.iterator(); i.hasNext();) {
            	int indexCount=0;
                Object[] values = (Object[]) i.next();
                PartLocationDTO partLocationDto = new PartLocationDTO();
                partLocationDto.setPartNo((null == values[indexCount] ? "" : values[indexCount].toString()));
                indexCount++;
                partLocationDto.setLocationId((null == values[indexCount] ? "" : values[indexCount].toString()));
                indexCount++;
                partLocationDto.setRan((null == values[indexCount] ? "" : values[indexCount].toString()));
                indexCount++;
                partLocationDto.setTotalCapactity((Integer) (null == values[indexCount] ? 0 : values[indexCount]));
                indexCount++;
                partLocationDto.setCurrentQty((Integer) (null == values[indexCount] ? 0 : values[indexCount]));
                indexCount++;
                partLocationDto.setLocationType((null == values[indexCount] ? "" : values[indexCount].toString()));
                indexCount++;
                partLocationDTOs.add(partLocationDto);
            }

        }

        LOGGER.debug("getAllPartLocations() method Ends " + partLocationDTOs.size());
        return partLocationDTOs;
    }
  
	
	public int getStockCorrectionPartLocationCount(PartLocationDTO partLoc) {
        LOGGER.debug("getPartLocationCount() method starts ");
        LOGGER.debug("** Part Number " + partLoc.getPartNo());
        LOGGER.debug("** Plant " + partLoc.getPlant());
        LOGGER.debug("** Shop " + partLoc.getShop());
        LOGGER.debug("** line " + partLoc.getLine());
        LOGGER.debug("** section " + partLoc.getSection());

        StringBuffer queryStringBuf1 = new StringBuffer();
        queryStringBuf1.append("Select Count(*) ");
        queryStringBuf1.append(" from [dbo].[PART_LOCATION] PL , [dbo].[LOCATION] L , [dbo].[LOCATION_TYPE] LT ");
        queryStringBuf1.append(" WHERE PL.LOCATION_ID = L.LOCATION_ID and  L.LOCATION_TYPE = LT.LOCATIONTYPE_ID ");

        if (null != partLoc.getPlant() && !partLoc.getPlant().equals("")) {
            queryStringBuf1.append(" AND  L.PLANT = '" + partLoc.getPlant() + "'");
        }
        if (null != partLoc.getShop() && !partLoc.getShop().equals("")) {
            queryStringBuf1.append(" AND  L.SHOP = '" + partLoc.getShop() + "'");
        }
        if (null != partLoc.getLine() && !partLoc.getLine().equals("")) {
            queryStringBuf1.append(" AND  L.LINE = '" + partLoc.getLine() + "'");
        }
        if (null != partLoc.getSection() && !partLoc.getSection().equals("")) {
            queryStringBuf1.append(" AND  L.SECTION= '" + partLoc.getSection() + "'");
        }
        if (null != partLoc.getPartNo() && !partLoc.getPartNo().equals("")) {
            queryStringBuf1.append(" AND  PL.PART_NO IN (:partNos)");
        }
        if (null != partLoc.getRan() && !partLoc.getRan().equals("")) {
        	queryStringBuf1.append(" AND  PL.RAN IN (:rans)");
        }

        LOGGER.debug("Query Count :  " + queryStringBuf1.toString());

        Query query1 = entityManager.createNativeQuery(queryStringBuf1.toString());

        if (null != partLoc.getPartNo() && !partLoc.getPartNo().equalsIgnoreCase("")) {
            query1.setParameter("partNos", partLoc.getPartList());
        }
        if (null != partLoc.getRan() && !partLoc.getRan().equalsIgnoreCase("")) {
        	query1.setParameter("rans", partLoc.getRanList());
        }
        int noOfRecords = (Integer) query1.getSingleResult();
        LOGGER.debug("recordCount :  " + noOfRecords);

        return noOfRecords;
    }
	
	 public void updatePartLocation(List<PartLocationCorrectionDTO> partLocCorrDTOs) {
	        LOGGER.debug("updatePartLocation 1 - Starts "+partLocCorrDTOs.size());
	        for (PartLocationCorrectionDTO partLocCorrDTO : partLocCorrDTOs) {
	            LOGGER.debug("Part No [ " + partLocCorrDTO.getPartNo() + " ] Source Location [ " + partLocCorrDTO.getSourceLocation() + " ] Corrected Location [ " + partLocCorrDTO.getCorrectedLocation()
	                    + " ] Corrected Quantity [ " + partLocCorrDTO.getCorrectQty() +" ] Source Quantity [ " + partLocCorrDTO.getSourceQty() +" ]");
	            LOGGER.debug("RAN***" + partLocCorrDTO.getRan());
	          if (partLocCorrDTO.getCorrectedLocation() != null && partLocCorrDTO.getCorrectQty() != 0) {
	        	    LOGGER.debug("***Location and Quantity both are NOT null ");  
	                insertPartsInOutStaging(partLocCorrDTO);
	           }
	          else if (partLocCorrDTO.getCorrectedLocation() == null && partLocCorrDTO.getCorrectQty() != 0) {
	        	  LOGGER.debug("***Location is null ");
	        	  partLocCorrDTO.setCorrectedLocation(partLocCorrDTO.getSourceLocation());
	        	  insertPartsInOutStagingBasedOnQuantity(partLocCorrDTO);
	          } else if(partLocCorrDTO.getCorrectedLocation() != null && partLocCorrDTO.getCorrectQty() == 0){
	        	  LOGGER.debug("***Quantity is null ");
	        	  partLocCorrDTO.setCorrectQty(partLocCorrDTO.getSourceQty());
	        	  insertPartsInOutStaging(partLocCorrDTO);
	          }
	        }
	        LOGGER.debug("updatePartLocation 1 - Ends");
	    }
	 
		
	 public void moveAllRanToDifferentLoc(PartLocationCorrectionDTO partLocationCorrectionDTO) {
			
		 LOGGER.debug("**In bulkLocationMovement starts part no " +partLocationCorrectionDTO.getPartNo());
		 LOGGER.debug("**In bulkLocationMovement starts source loc" +partLocationCorrectionDTO.getSourceLocation());
		 LOGGER.debug("**In bulkLocationMovement starts dest loc " +partLocationCorrectionDTO.getCorrectedLocation());
		 LOGGER.debug("**In bulkLocationMovement starts COMMENTS " +partLocationCorrectionDTO.getComments());
		 
		 StringBuffer queryStringBuf = new StringBuffer("DBO.USP_WMS_PARTS_LOCATION_BULK_MOVEMENT");
		 
		// entityManager.creat
		 
		 Query query = entityManager.createNativeQuery("EXEC DBO.USP_WMS_PARTS_LOCATION_BULK_MOVEMENT :PART_NO,:SOURCE_LOCATION,:DESTINATION_LOCATION, :COMMENTS ");		 
		 query.setParameter("PART_NO", partLocationCorrectionDTO.getPartNo());		 
		 query.setParameter("SOURCE_LOCATION", partLocationCorrectionDTO.getSourceLocation());
		 query.setParameter("DESTINATION_LOCATION", partLocationCorrectionDTO.getCorrectedLocation());
		 query.setParameter("COMMENTS", partLocationCorrectionDTO.getComments());
		 query.executeUpdate();
		 
		 LOGGER.debug("**In bulkLocationMovement ends");
			
		}
		
	 
		public List<StockCorrectionReasonDTO> getAllStockCorrectionReason() {
			// TODO Auto-generated method stub
			Query query=entityManager.createQuery("select s from StockCorrectionReasons s");
			List<StockCorrectionReasonDTO> stockCorrectionDTOs = new ArrayList<StockCorrectionReasonDTO>(); 
			List<StockCorrectionReasons> stockCorrectionReasonList= query.getResultList();
			LOGGER.debug("**Stock Correction Reason List Size " + stockCorrectionReasonList.size());
			if(stockCorrectionReasonList!=null){
				for(StockCorrectionReasons stockCorrectionReason:stockCorrectionReasonList){
					StockCorrectionReasonDTO stockCorrectionDTO = new StockCorrectionReasonDTO();
					stockCorrectionDTO.setReasonId(stockCorrectionReason.getReasonId());
					stockCorrectionDTO.setReasonName(stockCorrectionReason.getReasonName());					
					stockCorrectionDTOs.add(stockCorrectionDTO);
				}
			}
					
			return stockCorrectionDTOs;
		}
		
		
	    
	    /**
	     * @param partLocCorrDTO
	     */
	    private void insertPartsInOutStaging(PartLocationCorrectionDTO partLocCorrDTO){
	    	LOGGER.debug("*** insertPartsInOutStaging Start *");
	    	PartinoutStaging partInOutBean = WMSBeanUtil.conversionFromPartLocCorrDTOToBean(partLocCorrDTO, WMSBeanConstants.TRANSACTION_TYPE_MOVE);
	    	//PartinoutStaging partInBean = WMSBeanUtil.conversionFromPartLocCorrDTOToBean(partLocCorrDTO, WMSBeanConstants.TRANSACTION_TYPE_IN);
	    	entityManager.persist(partInOutBean);
	    	//entityManager.persist(partInBean);

	    	//executePartsInOutUpdationProcedure();
			LOGGER.debug("*** insertPartsInOutStaging exit *");
	    }
	    
	    /**
	     * @param partLocCorrDTO
	     */
	    private void insertPartsInOutStagingBasedOnQuantity(PartLocationCorrectionDTO partLocCorrDTO){
	    	LOGGER.debug("*** insertPartsInOutStagingBasedOnQuantity Start *");
	    	PartinoutStaging partBean = new PartinoutStaging();
	  	  if(partLocCorrDTO.getCorrectQty() < 0)
	  	  {
	  		
	  		partLocCorrDTO.setCorrectQty(-1*partLocCorrDTO.getCorrectQty());
	  		  partBean = WMSBeanUtil.conversionFromPartLocCorrDTOToBean(partLocCorrDTO, WMSBeanConstants.TRANSACTION_TYPE_OUT);
	  	  }
	  	  else
	  	  {
	  		
	  		  partBean = WMSBeanUtil.conversionFromPartLocCorrDTOToBean(partLocCorrDTO, WMSBeanConstants.TRANSACTION_TYPE_IN);
	  	  }
	    	entityManager.persist(partBean);
	    	//executePartsInOutUpdationProcedure();
			LOGGER.debug("*** insertPartsInOutStagingBasedOnQuantity exit *");
	    }


	

	   /* private void executePartsInOutUpdationProcedure(){
	    		String queryStringBuf = "EXEC USP_WMS_PARTS_IN_OUT_UPDATE ";
				Query query = entityManager
						.createNativeQuery(queryStringBuf.toString());
				query.executeUpdate();
	    	
	    }*/



    
    
    
}
