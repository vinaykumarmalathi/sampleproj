package com.rnaipl.wms.bean;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSConstants;

@Stateless
@LocalBean
public class PickingListPathBean implements PickingList{
	private static final Logger LOGGER = Logger.getLogger(PickingListPathBean.class);

	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;
	public String getPickingListPath(){
		String pickingListPath="";
		try{
			Query query = entityManager.createNativeQuery("SELECT VALUE FROM COMMON_PARAMETER WHERE ID = '2'");
			pickingListPath = (String) query.getSingleResult();
			if(pickingListPath.equals("null") || pickingListPath==null || pickingListPath.equals("")){
				pickingListPath = WMSConstants.PICKINGLISTSHEET;
			}
		}
		catch(Exception e){
			LOGGER.error("PickingListBean--> getPickingListPath",e);
			pickingListPath = WMSConstants.PICKINGLISTSHEET;
		}
		return pickingListPath;
	}
}