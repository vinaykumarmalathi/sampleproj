package com.rnaipl.wms.bean;

import java.util.List;

import com.rnaipl.wms.dto.MenuDTO;
import com.rnaipl.wms.dto.UserDTO;

public interface UserMenu {

    /**
     * get all the user menus by giving user input
     * 
     * @param user
     * @return
     */
	public List<MenuDTO> getUserMenus(UserDTO user);
	public List<String> rolesPrivilege();
}
