package com.rnaipl.wms.bean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.rnaipl.wms.dto.PartsInOutAuditSearchDTO;
import com.rnaipl.wms.entities.PartinOutStagingAudit;
import com.rnaipl.wms.util.WMSBeanConstants;
import com.rnaipl.wms.util.WMSBeanUtil;

@Stateless
@LocalBean
public class PartsInOutAuditSearchBean implements PartsInOutAuditSearch {

	private static final Logger LOGGER = Logger
			.getLogger(PartsInOutAuditSearchBean.class);

	@PersistenceContext(unitName = WMSBeanConstants.DATA_SOURCE_NAME)
	private EntityManager entityManager;
	
	public List<PartsInOutAuditSearchDTO> getPartsAuditSearch(
			PartsInOutAuditSearchDTO partsInOutAudit) throws Exception { 
		
		// TODO Auto-generated method stub
		LOGGER.debug("*** getPartsAuditSearch -- Location* ENTRY"
				+ partsInOutAudit.getLocation());
		List<PartsInOutAuditSearchDTO> partInOutAuditDtos = new ArrayList<PartsInOutAuditSearchDTO>();

		StringBuffer queryStringBuf = new StringBuffer();
		queryStringBuf.append("select p from PartinOutStagingAudit p");
		queryStringBuf.append(" WHERE 1=1 ");
		queryStringBuf.append(WMSBeanUtil.createQueryParamForAuditSearch(partsInOutAudit));
		queryStringBuf.append(" ORDER BY p.partInOutTime DESC");

		Query query = entityManager
				.createQuery(queryStringBuf.toString());
		
		if (null != partsInOutAudit.getPartNumber() && !partsInOutAudit.getPartNumber().equalsIgnoreCase("")) {
			query.setParameter("partNos", partsInOutAudit.getPartList());
        }
		if (null != partsInOutAudit.getLocation() && !partsInOutAudit.getLocation().equalsIgnoreCase("")) {
			query.setParameter("locationNos", partsInOutAudit.getLocationList());
        }
		if (null != partsInOutAudit.getRan() && !partsInOutAudit.getRan().equalsIgnoreCase("")) {
			query.setParameter("rans", partsInOutAudit.getRanList());
        }
		LOGGER.debug("Audit Data Query " + queryStringBuf.toString());
		
		if(partsInOutAudit.getIsFullDownload()!=1){
			query.setFirstResult(partsInOutAudit.getStartIndex());
			query.setMaxResults(partsInOutAudit.getEndIndex());
		}
		
		List<PartinOutStagingAudit> queryDatas = query.getResultList();
		LOGGER.debug("Audit Data size " + queryDatas.size());

		if (null != queryDatas && queryDatas.size() > 0) {
			for (PartinOutStagingAudit values : queryDatas) {
				
				
				PartsInOutAuditSearchDTO partInOutAuditSearchDto = setPartsInOutData(values);
				partInOutAuditDtos.add(partInOutAuditSearchDto);
			}

		}

		LOGGER.debug("*** getPartsAuditSearch -- Location* EXIT");
		return partInOutAuditDtos;

	}

	public int getPartInOutAuditSearchCount(PartsInOutAuditSearchDTO partsInOutAudit){
		StringBuffer queryStringBuf = new StringBuffer();
		queryStringBuf.append("select count(p) from PartinOutStagingAudit p");
		queryStringBuf.append(" WHERE 1=1");
		queryStringBuf.append(WMSBeanUtil.createQueryParamForAuditSearch(partsInOutAudit));
		
		LOGGER.debug("Query Count :  " + queryStringBuf.toString());
        Query query1 = entityManager.createQuery(queryStringBuf.toString());
        
        if (null != partsInOutAudit.getPartNumber() && !partsInOutAudit.getPartNumber().equalsIgnoreCase("")) {
        	query1.setParameter("partNos", partsInOutAudit.getPartList());
        }
        if (null != partsInOutAudit.getLocation() && !partsInOutAudit.getLocation().equalsIgnoreCase("")) {
        	query1.setParameter("locationNos", partsInOutAudit.getLocationList());
        }
    	if (null != partsInOutAudit.getRan() && !partsInOutAudit.getRan().equalsIgnoreCase("")) {
    		query1.setParameter("rans", partsInOutAudit.getRanList());
        }
        Long noOfRecords = (Long) query1.getSingleResult();
        LOGGER.debug("recordCount :  " + noOfRecords);

        return noOfRecords.intValue();
		
	}
	
   
 	private PartsInOutAuditSearchDTO setPartsInOutData(PartinOutStagingAudit partsAuditData) throws Exception{

		PartsInOutAuditSearchDTO partInOutAuditSearchDto = new PartsInOutAuditSearchDTO();
		String shiftName ="";
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
		try {
			partInOutAuditSearchDto.setPartNumber((null == partsAuditData.getPartNo() ? ""
					: partsAuditData.getPartNo().toString()));
			partInOutAuditSearchDto.setLocation((null == partsAuditData.getLocation() ? ""
					: partsAuditData.getLocation().toString()));
			partInOutAuditSearchDto.setTransactionType((null == partsAuditData.getTransactionType() ? ""
					: partsAuditData.getTransactionType().toString()));
			partInOutAuditSearchDto.setCount(partsAuditData.getCount());
			partInOutAuditSearchDto.setRan((null == partsAuditData.getRan() ? "" : partsAuditData.getRan()
					.toString()));
			partInOutAuditSearchDto.setUserId((null == partsAuditData.getUserId() ? ""
					: partsAuditData.getUserId().toString()));
			partInOutAuditSearchDto.setDeviceId((null == partsAuditData.getDeviceId() ? ""
					: partsAuditData.getDeviceId().toString()));

			partInOutAuditSearchDto.setPartInOutTime(null == partsAuditData.getPartInOutTime() ? null
					: partsAuditData.getPartInOutTime());

			partInOutAuditSearchDto.setReasonCode((null == partsAuditData.getReasonCode() ? ""
					: partsAuditData.getReasonCode().getReasonCode()));
			partInOutAuditSearchDto.setComments((null == partsAuditData.getComments() ? ""
					: partsAuditData.getComments().toString()));
			partInOutAuditSearchDto.setReason((null == partsAuditData.getReasonCode() ? ""
					: partsAuditData.getReasonCode().getReason().toString()));
			
			shiftName = WMSBeanUtil.getShift(partsAuditData.getScanTime().getHours(),
					partsAuditData.getScanTime().getMinutes(),partsAuditData.getScanTime().getSeconds());			
			partInOutAuditSearchDto.setShift(shiftName);
			
			partInOutAuditSearchDto.setScanTime(null == partsAuditData.getScanTime() ? null
					: partsAuditData.getScanTime());
			partInOutAuditSearchDto.setSnp(partsAuditData.getSnp());
			partInOutAuditSearchDto.setNoOfBoxes(partsAuditData.getNoOfBoxes());
			partInOutAuditSearchDto.setSuggestedLocation((null == partsAuditData.getSuggestedLocation() ? ""
					:partsAuditData.getSuggestedLocation().toString()));
			partInOutAuditSearchDto.setSuggestedRan((null == partsAuditData.getSuggestedRan() ? ""
					:partsAuditData.getSuggestedRan().toString()));	
			partInOutAuditSearchDto.setLocationDestination((null == partsAuditData.getLocationDestination() ? ""
					:partsAuditData.getLocationDestination().toString()));	
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error(e);
			throw e;
		}
		return partInOutAuditSearchDto;

	}
	
	
	
}
