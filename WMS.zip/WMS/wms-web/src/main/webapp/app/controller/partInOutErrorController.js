wmsApp.controller('partInOutErrorController', 
		[ '$scope','$window','$filter', '$location', 'partInOutErrorService','locationService','uiGridTreeViewConstants', '$http','commonService','localStorageService','partNumberService','ranService',
        function($scope,$window,$filter, $location, partInOutErrorService,locationService,uiGridTreeViewConstants, $http,commonService,localStorageService,partNumberService,ranService) {
			$scope.selectedErrorCode='';
			$scope.searchDataEror="Click search to fetch records.";
			$scope.beginDate=new Date();
		    $scope.endDate=new Date();
		    $scope.fromMaxDate=new Date();
               $scope.shiftDropdown=false;
			   $scope.todayDate = new Date();
			   $scope.transactionList = ["In", "Out"];	
			   $scope.shiftList = ["A", "B" ,"C"];				  
			   
			   $scope.options = [
			                     { label: 'Invalid Part', value: 1 },
			                     { label: 'Invalid Location', value: 2 },
			                     { label: 'Invalid mapping', value: 3 }
			                   ];			   
			    $scope.beginDatePickerOpen = false;
			    $scope.endDatePickerOpen = false;

			    $scope.openBeginDatePicker = function ($event) {			    	
				    $event.preventDefault();
				    $event.stopPropagation();
				    $scope.beginDatePickerOpen = !$scope.beginDatePickerOpen;				   
				    };

				    $scope.openEndDatePicker = function ($event) {
				    $event.preventDefault();
				    $event.stopPropagation();
				    $scope.endDatePickerOpen = !$scope.endDatePickerOpen;			  
				    };
				 
			 
			 
			
			// --------- Part Number List ---------
			$scope.partNumber='';
			$scope.searchClicked=false;
			$scope.tags=[];	 
			/*ON ADD NEW PART TAG*/
			$scope.transactionList= ["In", "Out"];
			$scope.tagAdded = function(tag) {				
				  $scope.partArray = [];
				     for (var j=0; j < $scope.tags.length; j++) {
				    	 $scope.partArray.push($scope.tags[j].text);
				      }
				     $scope.partNumber=$scope.partArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			/*ON REMOVE ADDED PART TAG*/
			    
		    $scope.tagRemoved = function(tag) {			   
		    	 $scope.partArray = [];
			     for (var j=0; j < $scope.tags.length; j++) {

			    	 $scope.partArray.push($scope.tags[j].text);
			      }
			     $scope.partNumber=$scope.partArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
			
		    /*AUTOCOMPLE PART ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadParts = function(query) {		    	
		    	var partInputObj = {"partNumber": query};			    	
		    	return partNumberService.partNumberList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    });			    				         
		    };
			    
			  
		    /*ON ADD NEW LOCATION TAG*/
		    
			$scope.location="";
			$scope.locationIdData=[];	 
		    $scope.locationAdded = function(tag) {					
		    $scope.locationArray = [];
			    for (var j=0; j < $scope.locationIdData.length; j++) {
			    	$scope.locationArray.push($scope.locationIdData[j].text);
			    }
			    $scope.location=$scope.locationArray.join(',');
			    $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    /*ON REMOVE ADDED LOCATION TAG*/
		    
		    $scope.locationRemoved = function(tag) {			   
		    	 $scope.locationArray = [];
			     for (var j=0; j < $scope.locationIdData.length; j++) {
			    	 $scope.locationArray.push($scope.locationIdData[j].text);
			     }
			     $scope.location=$scope.locationArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
				    
		    /*AUTOCOMPLE LOCATION ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadLocation = function(query) {
		    	
		    	var locationInputObj = {"locationId": query};			    	
		    	return locationService.locationList(locationInputObj).then(function(response){	
		    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    	});			    				         
		    };
		    
		    /* RAN Auto Completion - Start */
		    $scope.ranData=[];	
		    
		    $scope.ranAdded = function(tag) {			
				console.log("tagAdded:",tag);
				  $scope.ranArray = [];
				     for (var j=0; j < $scope.ranData.length; j++) {
				    	 $scope.ranArray.push($scope.ranData[j].text);
				      }
				     $scope.part.ran=$scope.ranArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			};
		    
		    $scope.ranRemoved = function(tag) {			   
		    	 $scope.ranArray = [];
			     for (var j=0; j < $scope.ranData.length; j++) {

			    	 $scope.ranArray.push($scope.ranData[j].text);
			      }
			     $scope.part.ran=$scope.ranArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    $scope.loadRan = function(query) {
		    	var partInputObj = {"ranId": query};
		    	return ranService.ranList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){	
		        			 console.log(response.data.object);
		        			  return response.data.object;                           
		        		 }
		        	 }		    		
			    });	
		    };
		    
		/*   $scope.pasteRanTags = function(event){
				  event.preventDefault();
				  console.log("In Paste RAN tags starts *");
				  console.log("Text Data" , event);
				  
				  //For IE
				 if ($window.clipboardData && $window.clipboardData.getData) {
					  $scope.tagsCopies = $window.clipboardData.getData('Text').split(/[,\n\t\s]+/);
					  console.log("IE");
					  console.log("$scope.tagsCopies",$scope.tagsCopies);
				  }
				  // Other Browsers
				  else if (event.originalEvent.clipboardData && event.originalEvent.clipboardData.getData) { 
					  $scope.tagsCopies = event.originalEvent.clipboardData.getData('text/plain').split(/[,\n\t\s]+/);
					  console.log("Other Browser");
					  console.log("$scope.tagsCopies",$scope.tagsCopies);
				  }
				  console.log("In Paste RAN tags ends");
			    
			     
			}; */
		    /*RAN Auto Completion - End */
		    
		 // --------- Location drop down list -------

			  if($window.sessionStorage.getItem('locationDPCollection') == null || $window.sessionStorage.getItem('locationDPCollection')=='undefined' || $window.sessionStorage.getItem('locationDPCollection')==undefined){
				  commonService.getAllPlants()
				  .success(function(response){					 
					  $scope.locations = response.objectList;				
					  $window.sessionStorage.setItem('locationDPCollection',JSON.stringify($scope.locations));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.locations = JSON.parse(sessionStorage.locationDPCollection);
			  }
			  
			  // --------- Section drop down list ---------

			  if($window.sessionStorage.getItem('sectionDPCollection') == null || $window.sessionStorage.getItem('sectionDPCollection')=='undefined' || $window.sessionStorage.getItem('sectionDPCollection')==undefined){
				  commonService.getAllSections()
				  .success(function(response){					 
					  $scope.sections = response.objectList;	
					  $window.sessionStorage.setItem('sectionDPCollection',JSON.stringify($scope.sections));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.sections = JSON.parse(sessionStorage.sectionDPCollection);
			  }
			  
			// --------- Shops drop down list ---------
			  
			  $scope.loadShopLine = function(){
			    	 $scope.part.line = '';
			    	 $scope.part.shop = '';
			    	 commonService.getLineList($scope.part.plant)
					  .success(function(response){
						  $scope.lines = response.objectList;				
					  })
					  .error(function(response){
					  });
			    	 commonService.getShopList($scope.part.plant)
					  .success(function(response){
						  $scope.shops = response.objectList;				
					  })
					  .error(function(response){
					  });

			    }
			   
			 /* if($window.sessionStorage.getItem('shopDPCollection') == null || $window.sessionStorage.getItem('shopDPCollection')=='undefined' || $window.sessionStorage.getItem('shopDPCollection')==undefined){
				  commonService.getAllShop()
				  .success(function(response){						  
					  $scope.shops = response.objectList;				
					  $window.sessionStorage.setItem('shopDPCollection',JSON.stringify($scope.shops));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.shops = JSON.parse(sessionStorage.shopDPCollection);
			  }*/
			 // --------- Line drop down list ---------

			  /*if($window.sessionStorage.getItem('linesDPCollection') == null || $window.sessionStorage.getItem('linesDPCollection')=='undefined' || $window.sessionStorage.getItem('linesDPCollection')==undefined){
				  commonService.getAllLines()
				  .success(function(response){					 
					  $scope.lines = response.objectList;
					  $window.sessionStorage.setItem('linesDPCollection',JSON.stringify($scope.lines));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.lines = JSON.parse(sessionStorage.linesDPCollection);
			  }*/
			    			    		  
		    $scope.part = {				
		    	  partNumber : $scope.partNumber,
		    	  location : $scope.location, 
                  fromDate : $scope.beginDate,
                  toDate : $scope.endDate,
                  startIndex : 0,
                  endIndex : 0
              };
			
			
			
			 var paginationOptions = {
				 	startIndex : 0,
				 	endIndex : 0,
				    pageNumber: 1,
				    pageSize: 100,
				    sort: null
				  };
			 
		
			 //Grid
			 $scope.gridOptions = {
			 enablePaginationControls:false,
			 enableGridMenu: true,
             enableFiltering: true,            
             enableColumnResize: true,
             paginationPageSizes: [100,250,500,750,1000],
     	     paginationPageSize: 100,         
             useExternalPagination: true,
             autoResize:true,
             enableSorting: true,
             enableColumnMenus: false,
             enablePinning: true,  
             enableColumnResizing: true,
             showFooter:true,
             
             columnDefs: [                       
						    { field: 'partNumber', displayName: 'Part Number', width:150, pinnedLeft:true },
					       	{ field: 'location', displayName: 'Location', width:150, pinnedLeft:true },
					       	{ field: 'ran', displayName: 'RAN', width:100},
					       	{ field: 'locationDestination', displayName: 'Location Moved', width:150},
					       	{ field: 'transactionType', displayName: 'Txn', width:50},
					       	{ field: 'count', displayName: 'Count', width:80},
					       	{ field: 'ran', displayName: 'RAN',visible: false,width:50},
					       	{ field: 'userId', displayName: 'User', width:100},
					       	{ field: 'deviceId', displayName: 'Device', width:100},
					       	{ field: 'partInOutTime', displayName: 'In Out Time', width:200},
					       	{ field: 'reason', displayName: 'Reason',width:100},
					       	{ field: 'comments', displayName: 'Comments',width:150},
					       	{ field: 'errorMessage', displayName: 'Error Message', width:300},
					       	{ field: 'suggestedLocation', displayName: 'Suggested Location', width:150},
					       	{ field: 'suggestedRan', displayName: 'Suggested Ran', width:150}
                        ],
                        exporterCsvFilename: 'partInOutErrorReport.csv',
                        exporterMenuVisibleData: false,
                        exporterPdfDefaultStyle: {fontSize: 9},
                        exporterPdfTableStyle: {margin: [70, 5, 0, 5]},
                        exporterPdfTableHeaderStyle: {fontSize: 10, bold: true, italics: true, color: 'red'},
                        exporterPdfHeader: { text: "Part In Out Error Report", style: 'headerStyle' },
                        exporterPdfFooter: function ( currentPage, pageCount ) {
                          return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
                        },
                        exporterPdfCustomFormatter: function ( docDefinition ) {
                        	 docDefinition.styles.headerStyle = { fontSize: 20, bold: true, alignment: 'center', margin: [0, 0, 20, 0] }; 
                             docDefinition.styles.footerStyle = { fontSize: 10, bold: true, alignment: 'center',  margin: [5, 0, 20, 0] }; 
                          return docDefinition;
                        },
                        exporterPdfOrientation: 'landscape',
                        exporterPdfPageSize: 'LETTER',
                        exporterPdfMaxGridWidth: 500,
                        exporterPdfFilename: 'partInOutErrorReport.pdf',
                        exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
                       
                        onRegisterApi: function( gridApi ) {
                        	 $scope.gridApi = gridApi;
                        	 //Pagination
                        	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                        		 $scope.blockUI();
             		          paginationOptions.pageNumber = newPage;
             		          paginationOptions.pageSize = pageSize;
             		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
             		        paginationOptions.endIndex   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
             		        $scope.load();
             		        });
                        
                	    }
		    };
 // Clear the filter
	 $scope.clearFilters = function() {
		 $scope.gridApi.core.clearAllFilters();
     };
// Reset the values
	    $scope.resetParts = function(){	
	    	$scope.shops = "";
	    	$scope.lines = "";
	    	$scope.beginDate=new Date();
		    $scope.endDate=new Date();    	   
	    	$scope.gridOptions.data = [];
	    	$scope.clearFilters();	  
	    	$scope.part = {};
	    	$scope.tags=[];
	    	$scope.ranData=[];
	    	$scope.locationIdData=[];	
	    	$scope.gridOptions.totalItems=0;
	    	$scope.location="";
	    	$scope.partNumber="";
	    	$scope.gridOptions.enablePaginationControls=false;	    
	    	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    $scope.shiftDropdown=false;
	    };	    
     $scope.partLocationData = function(){
    	 
    		 $scope.blockUI();
    		 if($scope.selectedErrorCode!=""){
    			 $scope.part.errorCode= $scope.selectedErrorCode.value;
    		 }else{
    			 $scope.part.errorCode='';
    		 }
    		 
    		 partInOutErrorService.errorReport($scope.part).then(function(response){
    			 $scope.gridOptions.data = [];
    			 if(response.data.objectList!== undefined && response.data.objectList!=null){
    				 
    				 if(response.data.statusType === 'success' ){
    					 $scope.gridOptions.enablePaginationControls=true;
    					 response.data.objectList.forEach(function(row){	    	    	          	          
    						 row.partInOutTime =$filter('date')(row.partInOutTime, 'MMM d, yyyy HH:mm:ss a');
    						 $scope.gridOptions.data = response.data.objectList;	 
    					 });
    					 
    					 
    				 } else {
    					 $scope.gridOptions.enablePaginationControls=false;
    					 $scope.alerts = [];
    					 $scope.alerts.push({
    						 type : response.data.statusType,
    						 msg : response.data.statusMessage,
    						 error : response.data.exceptionStackTrace,
    						 errorClsName : response.data.exceptionClassName,
    						 errorMsg : response.data.exceptionMessage
    					 });
    				 }
    				 $.unblockUI();
    			 } else {
    				 $scope.searchDataEror=response.data.statusMessage;	    		
    				 $.unblockUI();
    			 }
    		 });
     };
     
	 		/* Load data in grid */
		    $scope.load = function () {
		    	$scope.part.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

		    	if(paginationOptions.endIndex === 0){
		    		$scope.part.endIndex = $scope.gridOptions.paginationPageSize;
		    	}
		    	$scope.part.startIndex = paginationOptions.startIndex;
		    	$scope.part.endIndex = paginationOptions.pageSize;
		    	$scope.part.partNumber=$scope.partNumber;
		    	$scope.part.location=$scope.location;		
		    	
		    	$scope.part.fromDate=$scope.fromDate;
		    	$scope.part.toDate=$scope.toDate;
		    	 if($scope.selectedErrorCode!=""){
		    		 $scope.part.errorCode= $scope.selectedErrorCode.value;
		    	 }else{
		    		 $scope.part.errorCode='';
		    	 }
		    	
		    	partInOutErrorService.errorReportCount($scope.part).then(function(response){
		    		$scope.gridOptions.totalItems = response.data.object;		    		
		    		$scope.recordCount = response.data.object;		    		
		    		$scope.partLocationData();
		    		
		    	});
		    	
		    };
		    
		    // --------- search button ---------
            $scope.searchParts = function() {
            	
            	if($scope.validateFilter() == true){
            		$scope.fromDate = $filter('date')($scope.beginDate, 'yyyy-MM-dd');
            		$scope.toDate = $filter('date')($scope.endDate, 'yyyy-MM-dd');
            		$scope.alerts = [];
            		$scope.gridOptions.data = [];
            		$scope.part.partNumber=$scope.partNumber;
            		$scope.part.location=$scope.location;
            		
            		paginationOptions.startIndex= 0;
            		paginationOptions.endIndex= 0;
            		paginationOptions.pageNumber= 1;
            		paginationOptions.pageSize= 100; 
            		$scope.gridOptions.paginationCurrentPage=1;
            		$scope.gridOptions.paginationPageSize=100;
            		
            		$scope.searchClicked=true;
            		$scope.clearFilters();                	
            		$scope.load();
            		
            		$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
            	}else{
            		$scope.alerts = [];
	       			$scope.alerts.push({
	       				 type : 'danger',
	       				 msg : 'Plant/Shop or Part or RAN or Location is/are mandatory'
	       			});
            	}
            };
		    
		 
			//Close the alert msg
            $scope.closeAlert = function(index) {
		        $scope.alerts.splice(index, 1);
		    };
		    
		   
		    $scope.selectEndDate = function(endDate) {		    
		    	$scope.fromMaxDate=$filter('date')(endDate, 'yyyy-MM-dd');
		    	$scope.part.shift='';
		    	if($filter('date')(endDate, 'yyyy-MM-dd')== $filter('date')($scope.beginDate, 'yyyy-MM-dd')){
		    		$scope.shiftDropdown=false;
		    	}else{
		    		$scope.shiftDropdown=true;
		    	}		    	
		    };
		    
		    $scope.selectStartDate = function(startDate) {		    	
		    	$scope.part.shift='';
		    	if($filter('date')(startDate, 'yyyy-MM-dd')== $filter('date')($scope.endDate, 'yyyy-MM-dd')){
		    		$scope.shiftDropdown=false;
		    	}else{
		    		$scope.shiftDropdown=true;
		    	}		    	
		    };
		    
		    $scope.validateFilter = function(){
		    	 if($scope.part.plant !== "" && $scope.part.plant !== null && $scope.part.plant !== undefined && $scope.part.shop !== "" && $scope.part.shop !== null && $scope.part.shop !== undefined)
				 {
					 return true;
				 }
		    	 else if($scope.ranData.length>0 || $scope.tags.length>0 || $scope.locationIdData.length>0){
		    		 return true;
		    	 }
		    	 
		    	 else{
					 return false;
				 }
		     };
		
} ]);