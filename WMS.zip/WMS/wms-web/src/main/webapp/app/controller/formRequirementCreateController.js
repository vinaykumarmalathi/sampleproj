wmsApp.controller('formRequirementCreateController',
		[ '$scope','$window','$filter', '$location','$q', 'formRequirementCreateService', '$http',
	        function($scope,$window,$filter, $location,$q, formRequirementCreateService, $http) {

			
					 //Grid
					 $scope.gridOptions = {
					 enablePaginationControls:false,
					 enableGridMenu: true,
		             enableFiltering: true,            
		             enableColumnResize: true,
		             paginationPageSizes: [100,250,500,750,1000],
		     	     paginationPageSize: 100,         
		             useExternalPagination: true,
		             autoResize:true,
		             enableSorting: true,
		             enableColumnMenus: false,
		             enablePinning: true,            
		             columnDefs: [
		                          { field: 'cycleCountDate', displayName: 'Cycle Count Date', width:150 },
		                          { field: 'a or b', displayName: 'A/B', width:100 },
		                          { field: 'partNumber', displayName: 'Part Number', width:180 },
		                          { field: 'partName', displayName: 'Part Name', width:220 },
					       	      { field: 'supplierName', displayName: 'Supplier Name', width:220},
		                          { field: 'shop', displayName: 'Shop', width:180},
		                          { field: 'class', displayName: 'Class', width:180},
		                          { field: 'systemStock', displayName: 'System Stock', width:180},
		                          { field: 'physicalStock', displayName: 'Physical Stock', width:100 },
		                          { field: 'qtyAdjusted', displayName: 'Qty Adjusted', width:100 },
		                          { field: 'unitPrice', displayName: 'Unit Price', width:100 },
		                          { field: 'costImpact', displayName: 'Cost Impact', width:100 },
		                          { field: 'reasonCode', displayName: 'Reason Code', width:100 },
		                          { field: 'counterMeasure', displayName: 'Counter Measure', width:100 },
		                          { field: 'action', displayName: 'Action', width:100 }
		                          
		                        ],
		                        exporterMenuVisibleData: false,
				    };
					
					 $scope.attachmentGridOptions = {
							 enablePaginationControls:false,
							 enableGridMenu: true,
				             enableFiltering: true,            
				             enableColumnResize: true,
				             paginationPageSizes: [100,250,500,750,1000],
				     	     paginationPageSize: 100,         
				             useExternalPagination: true,
				             autoResize:true,
				             enableSorting: true,
				             enableColumnMenus: false,
				             enablePinning: true,            
				             columnDefs: [
				                          { field: 'documentID', displayName: 'Document ID', width:150 },
				                          { field: 'documentName', displayName: 'Document Name', width:100 },
				                          { field: 'documentLink', displayName: 'Document Link', width:180 },
				                          { field: 'delete', displayName: 'Delete', width:220 }
				                          
				                        ],
				                        exporterMenuVisibleData: false,
						    };
							
					 
					// Clear the filter
					$scope.clearFilters = function() {
						$scope.gridApi.core.clearAllFilters();
				    };
			
		}]);