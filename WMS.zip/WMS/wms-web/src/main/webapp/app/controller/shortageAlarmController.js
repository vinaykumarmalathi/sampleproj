wmsApp.controller('shortageAlarmController', 
		[ '$scope','$window','$filter', '$location','$q', 'auditTrialService','locationService','uiGridTreeViewConstants', '$http','commonService','localStorageService','partNumberService','ranService','shortageAlarmService','PartNumberInterService','lineFeedingDetailsService','manageLocationByPartNoService',
        function($scope,$window,$filter, $location,$q, auditTrialService,locationService,uiGridTreeViewConstants, $http,commonService,localStorageService,partNumberService,ranService,shortageAlarmService,PartNumberInterService,lineFeedingDetailsService,manageLocationByPartNoService) {
			$scope.searchDataError="Click search to fetch records.";
			$scope.beginDate=new Date();
		    $scope.endDate=new Date();
		    $scope.currentTime=new Date();
			$scope.maximumDate = new Date();
		    var numberOfDaysToAdd = 0;
		   // $scope.maximumDate.setDate($scope.maximumDate.getDate() + numberOfDaysToAdd); 
		    $scope.fromMaxDate=new Date();
		    $scope.allPartsFlg=false;
		    $scope.lastCalDate = '';
			$scope.todayDate = new Date();
			$scope.beginDatePickerOpen = false;
			$scope.endDatePickerOpen = false;

			    $scope.openBeginDatePicker = function ($event) {			    	
			    $event.preventDefault();
			    $event.stopPropagation();
			    $scope.beginDatePickerOpen = !$scope.beginDatePickerOpen;
			    };

			    $scope.openEndDatePicker = function ($event) {
			    $event.preventDefault();
			    $event.stopPropagation();
			    $scope.endDatePickerOpen = !$scope.endDatePickerOpen;			  
			    };
			    
			$scope.loginUser= $window.sessionStorage.getItem('loggedUserId');
			console.log("$scope.loginUser : " +$scope.loginUser);
				// To enable/disable all parts cats coverage button access to the specified logged in user    
			    $scope.loadAllPartsButtonEnable = function(user) {	
				    return shortageAlarmService.getUserForAllPartsCoverage($scope.loginUser).then(function(response){			    		
			        		 if(response.data.object!=null && response.data.object.userId!=null){				        		
			        			  if($scope.loginUser==response.data.object.userId){
			        				  $scope.allPartsFlg=true;
			        			  }                 
			        		 }else{
			        			 $scope.allPartsFlg=false;
			        		 }	
				    });	
				 };	
				 
				 $scope.loadAllPartsButtonEnable($scope.loginUser);
				 
				 //To get the max of gross date from db
				 $scope.getMaxDate = function() {
					 numberOfDaysToAdd = 0;
					 $scope.maximumDate = new Date();
					 return shortageAlarmService.getMaxDate().then(function(response){		
						 if(response.data.object!=null){
							 numberOfDaysToAdd = response.data.object;
							 $scope.maximumDate.setDate($scope.maximumDate.getDate() + numberOfDaysToAdd);
						//	 $scope.endDate.setDate($scope.maximumDate.getDate());
						 }
					 });
				 }
				 $scope.getMaxDate();
				 
				 //DTO variables
			     $scope.shortageAlmData = {
						 plant : '',
						 shop : '',
						 line:'',
						 zone : '',
						 partType : '',
						 wip : null,					 
						 partNumber : $scope.partNumberList,
						 supCode : $scope.supplierList,
						 depotCode :$scope.depotList,
						 pcCode:$scope.pcList,
						 calLogic:'W',	
		                 shortageTypeR:true,
		                 shortageTypeG:true,
		                 shortageTypeY:true,
						 fromDate : '',
		                 toDate : '',	 	
						 startIndex: 0,
						 endIndex: 0,
						 isFullDownload : false,
						 userId :  $scope.loginUser,
				    };
			   

			// --------- Part Number List ---------
			$scope.partNumberList='';
			$scope.tags=[];	 
			/*ON ADD NEW PART TAG*/
						
			$scope.tagAdded = function(tag) {
				
				  $scope.partArray = [];
				  
				     for (var j=0; j < $scope.tags.length; j++) {
				    	 
				    	 $scope.partArray.push($scope.tags[j].text);
				    	 console.log("Part Array",$scope.partArray);
				      }
				     $scope.partNumberList=$scope.partArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			/*ON REMOVE ADDED PART TAG*/
			    
		    $scope.tagRemoved = function(tag) {			   
		    	 $scope.partArray = [];
			     for (var j=0; j < $scope.tags.length; j++) {

			    	 $scope.partArray.push($scope.tags[j].text);
			      }
			     $scope.partNumberList=$scope.partArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    $scope.addingTag = function(tag) {
		    	console.log("Tag.text",tag.text);
		    	  tag.text = tag.text.replace(/ /g, ',');
		    	  console.log("Tag.text 2",tag.text);
		    	  return tag;
		    	};
		    	
			
		    /*AUTOCOMPLE PART ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadParts = function(query) {
		    	var partInputObj = {"partNumber": query};			    	
		    	return shortageAlarmService.partNumberList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		console.log("empty part number");
		        	 }			    		
			    });			    				         
		    };
		    
		 // --------- SUPPLIER CODE LIST ---------		
		    $scope.supplierList='';
		    $scope.supplierTags=[];	 
			/*ON ADD NEW Supplier TAG*/
			
			$scope.supplierTagsAdded = function(tag) {				
				  $scope.supplierArray = [];
				     for (var j=0; j < $scope.supplierTags.length; j++) {
				    	 $scope.supplierArray.push($scope.supplierTags[j].text);
				      }
				     $scope.supplierList=$scope.supplierArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			/*ON REMOVE ADDED Supplier TAG*/
			    
		    $scope.supplierTagsRemoved = function(tag) {			   
		    	 $scope.supplierArray = [];
			     for (var j=0; j < $scope.supplierTags.length; j++) {
			    	 $scope.supplierArray.push($scope.supplierTags[j].text);
			      }
			     $scope.supplierList=$scope.supplierArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
			
		   /* AUTOCOMPLE SUPPLIER ON ENTER MIN 3 CHAR DATA */
		    
		    $scope.loadSupplier = function(query) {		    	
		    	var partInputObj = {"partNumber": query};			    	
		    	return shortageAlarmService.supplierList(partInputObj).then(function(response){			    		
		    		if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		console.log("empty");
		        	 }			    		
			    });			    				         
		    };
		    
		    // --------- DEPO CODE LIST ---------			
		    $scope.depoCodeTags=[];	 
		    $scope.depotList='';
			/*ON ADD NEW depocode TAG*/
			
			$scope.depoCodeTagsAdded = function(tag) {				
				  $scope.depoCodeArray = [];
				     for (var j=0; j < $scope.depoCodeTags.length; j++) {
				    	 $scope.depoCodeArray.push($scope.depoCodeTags[j].text);
				      }
				     $scope.depotList=$scope.depoCodeArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			/*ON REMOVE ADDED depocode TAG*/
			    
		    $scope.depoCodeTagsRemoved = function(tag) {			   
		    	 $scope.depoCodeArray = [];
			     for (var j=0; j < $scope.depoCodeTags.length; j++) {
			    	 $scope.depoCodeArray.push($scope.depoCodeTags[j].text);
			      }
			     $scope.depotList=$scope.depoCodeArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
           /* AUTOCOMPLE DEPO CODE ON ENTER MIN 3 CHAR DATA */
		    
		    $scope.loadDepoCode = function(query) {		    	
		    	var partInputObj = {"partNumber": query};			    	
		    	return shortageAlarmService.depoCodeList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		console.log("empty");
		        	 }			    		
			    });			    				         
		    };
		    
		    
		 // --------- PC CODE LIST ---------			
		    $scope.pcCodeTags=[];	 
		    $scope.pcList='';
			/*ON ADD NEW pccode TAG*/
			
			$scope.pcCodeTagsAdded = function(tag) {				
				  $scope.pcCodeArray = [];
				     for (var j=0; j < $scope.pcCodeTags.length; j++) {
				    	 $scope.pcCodeArray.push($scope.pcCodeTags[j].text);
				      }
				     $scope.pcList=$scope.pcCodeArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			/*ON REMOVE ADDED depocode TAG*/
			    
		    $scope.pcCodeTagsRemoved = function(tag) {			   
		    	 $scope.pcCodeArray = [];
			     for (var j=0; j < $scope.pcCodeTags.length; j++) {
			    	 $scope.pcCodeArray.push($scope.pcCodeTags[j].text);
			      }
			     $scope.pcList=$scope.pcCodeArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
           /* AUTOCOMPLE DEPO CODE ON ENTER MIN 3 CHAR DATA */
		    
		    $scope.loadPcCode = function(query) {		    	
		    	var partInputObj = {"partNumber": query};			    	
		    	return shortageAlarmService.pcCodeList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		console.log("empty");
		        	 }			    		
			    });			    				         
		    };
		  
		    
		    /*ON ADD NEW LOCATION TAG*/
		    
			$scope.location="";
			$scope.locationIdData=[];	 
		    $scope.locationAdded = function(tag) {					
		    $scope.locationArray = [];
			    for (var j=0; j < $scope.locationIdData.length; j++) {
			    	$scope.locationArray.push($scope.locationIdData[j].text);
			    }
			    $scope.location=$scope.locationArray.join(',');
			    $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    /*ON REMOVE ADDED LOCATION TAG*/
		    
		    $scope.locationRemoved = function(tag) {			   
		    	 $scope.locationArray = [];
			     for (var j=0; j < $scope.locationIdData.length; j++) {
			    	 $scope.locationArray.push($scope.locationIdData[j].text);
			     }
			     $scope.location=$scope.locationArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		 // --------- Location drop down list -------

			  if($window.sessionStorage.getItem('locationDPCollection') == null || $window.sessionStorage.getItem('locationDPCollection')=='undefined' || $window.sessionStorage.getItem('locationDPCollection')==undefined){
				  commonService.getAllPlants()
				  .success(function(response){					 
					  $scope.locations = response.objectList;				
					  $window.sessionStorage.setItem('locationDPCollection',JSON.stringify($scope.locations));
					 
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.locations = JSON.parse(sessionStorage.locationDPCollection);
			  }
			  
			   $scope.getAllZones = function(){
				  shortageAlarmService.getAllZones()
				  .success(function(response){
					  $scope.zones = response.objectList;				
				  })
				  .error(function(response){
				  });
			  };
			  
			  $scope.getWips = function(){
				  shortageAlarmService.getWips()
				  .success(function(response){
					  $scope.wips = response.objectList;				
				  })
				  .error(function(response){
				  });
			  };
			  
			// --------- Shops drop down list ---------
			  
			    $scope.loadShopLine = function(){
			    	$scope.getWips();
			    	$scope.getAllZones();
			    	$scope.getLstCalTime();			    	
					$scope.shortageAlmData.shop = "";
					$scope.shortageAlmData.line = "";
					$scope.shops="";
					$scope.lines="";
			 	    shortageAlarmService.getShopByPlantId($scope.shortageAlmData.plant).success(function(response) {
					 			$scope.shops = response.objectList;
					 		}).error(function(response) {
					 		});
			    }
			    
			    //To load the lines based on the shop
			    $scope.loadLinesByShop = function(){
			    	$scope.shortageAlmData.line = ""; 
			    	$scope.lines="";
			    	 if($scope.shortageAlmData.shop!=null && $scope.shortageAlmData.shop!=''){
			    	        shortageAlarmService.getlinesByShopId($scope.shortageAlmData.shop.charAt(0)).success(function(response) {
					 			$scope.lines = response.objectList;
					 		}).error(function(response) {
					 		});
			          }
			    }
			
			 var paginationOptions = {
				 	startIndex : 0,
				 	endIndex : 0,
				    pageNumber: 1,
				    pageSize: 100,
				    sort: null
				  };
			 
			
			 //Grid
			 $scope.gridOptions = {
			 enablePaginationControls:false,
			 enableGridMenu: true,
             enableFiltering: true,            
             enableColumnResize: true,
             paginationPageSizes: [100,250,500,750,1000],
     	     paginationPageSize: 100,         
             useExternalPagination: true,
             autoResize:true,
             enableSorting: true,
             enableColumnMenus: false,
             enablePinning: true,            
             columnDefs: [

	       	      { field: 'partType', displayName: 'Part Type', width:20, pinnedLeft:true},   
            	  { field: 'partNumber', displayName: 'Part Number', width:90, pinnedLeft:true },   
	       	      { field: 'pcCode', displayName: 'PC', width:30,pinnedLeft:true},
	       	      { field: 'partName', displayName: 'Part Name', width:100},
	       	      { field: 'supName', displayName: 'Sup Name', width:100},
	       	      { field: 'depotCode', displayName: 'Depo Code', width:30},
	       	      { field: 'zone', displayName: 'LS Zone', width:60},
	       	      { field: 'snep', displayName: 'SNEP', width:50},
	       	      { field: 'snip', displayName: 'SNIP', width:50},
	       	      { field: 'trimWip', displayName: 'TCF WIP', width:50},
	       	      { field: 'pbsWip', displayName: 'PBS WIP', width:50},
	       	      { field: 'pa2Wip', displayName: 'PA2 WIP', width:50},
	       	      { field: 'pa1Wip', displayName: 'PA1 WIP', width:50},
	       	      { field: 'metalWip', displayName: 'Metal WIP', width:50},	
	       	      { field: 'totWip', displayName: 'Total WIP', width:50},	  
	       	      { field: 'tcf',displayName: 'TCF ClsStk',width:70,
	       	    cellTemplate: '<div class="ui-grid-cell-contents"><span ng-if="row.entity.tcfClr ==null" font: bold;">{{row.entity.tcf}}</span><span ng-if="row.entity.tcfClr==\'G\'" style="background-color:green;color:white;font: bold;">{{row.entity.tcf}}</span><span ng-if="row.entity.tcfClr==\'Y\'" style="background-color:yellow;color:black;font: bold;">{{row.entity.tcf}}</span><span ng-if="row.entity.tcfClr==\'R\'" style="background-color:red;color:white;font: bold;">{{row.entity.tcf}}</span></div>'
	       	      },
			      { field: 'pbs', displayName: 'PBS ClsStk', width:70,
	       	    cellTemplate: '<div class="ui-grid-cell-contents"><span ng-if="row.entity.pbsClr ==null" font: bold;">{{row.entity.pbs}}</span><span ng-if="row.entity.pbsClr==\'G\'" style="background-color:green;color:white;font: bold;">{{row.entity.pbs}}</span><span ng-if="row.entity.pbsClr==\'Y\'" style="background-color:yellow;color:black;font: bold;">{{row.entity.pbs}}</span><span ng-if="row.entity.pbsClr==\'R\'" style="background-color:red;color:white;font: bold;">{{row.entity.pbs}}</span></div>'  
			      },
			      { field: 'pa2', displayName: 'PA2 ClsStk', width:70,
			    cellTemplate: '<div class="ui-grid-cell-contents"><span ng-if="row.entity.pa2Clr ==null" font: bold;">{{row.entity.pa2}}</span><span ng-if="row.entity.pa2Clr==\'G\'" style="background-color:green;color:white;font: bold;">{{row.entity.pa2}}</span><span ng-if="row.entity.pa2Clr==\'Y\'" style="background-color:yellow;color:black;font: bold;">{{row.entity.pa2}}</span><span ng-if="row.entity.pa2Clr==\'R\'" style="background-color:red;color:white;font: bold;">{{row.entity.pa2}}</span></div>'  
			      },
			      { field: 'pa1', displayName: 'PA1 ClsStk', width:70,
			    cellTemplate: '<div class="ui-grid-cell-contents"><span ng-if="row.entity.pa1Clr ==null" font: bold;">{{row.entity.pa1}}</span><span ng-if="row.entity.pa1Clr==\'G\'" style="background-color:green;color:white;font: bold;">{{row.entity.pa1}}</span><span ng-if="row.entity.pa1Clr==\'Y\'" style="background-color:yellow;color:black;font: bold;">{{row.entity.pa1}}</span><span ng-if="row.entity.pa1Clr==\'R\'" style="background-color:red;color:white;font: bold;">{{row.entity.pa1}}</span></div>'  
			      },
			      { field: 'metal', displayName: 'Metal ClsStk', width:70,
			    cellTemplate: '<div class="ui-grid-cell-contents"><span ng-if="row.entity.metalClr ==null" font: bold;">{{row.entity.metal}}</span><span ng-if="row.entity.metalClr==\'G\'" style="background-color:green;color:white;font: bold;">{{row.entity.metal}}</span><span ng-if="row.entity.metalClr==\'Y\'" style="background-color:yellow;color:black;font: bold;">{{row.entity.metal}}</span><span ng-if="row.entity.metalClr==\'R\'" style="background-color:red;color:white;font: bold;">{{row.entity.metal}}</span></div>'  
			      },
			      /*{ field: 'grossDate', displayName: 'Gross Date', width:80},*/
			      { field: 'grossDate', displayName: 'Gross Date', width:80, cellFilter: 'date:\'MMM d, yyyy \''},
			      { field: 'grossQty', displayName: 'Qty', width:70},
			      { field: 'lastWhOut', displayName: 'Last WH Out', width:80, cellFilter: 'date:\'MMM d, yyyy HH:mm:ss a\''},
			      { field: 'lastWhOutQty', displayName: 'Last WH Out Qty', width:70},
	       	      { field: 'catsStk', displayName: 'Cats Stock', width:70},
	       	      { field: 'wmsStock', 
	       	    	  displayName: 'WMS Stock', 
	       	    	  width:70,
	       	    	  cellTemplate: '<div class="details-link" data-toggle="modal" data-target="#manageLocationModal" ng-click="grid.appScope.openModel(row.entity.partNumber)">{{row.entity.wmsStock}}</div>'
	       	      }, 
	       	      { field: 'lsStock', displayName: 'LS Stock', width:70},
	       	      { field: 'eopMark', displayName: 'EOP Mark', width:20},
	       	      { field: 'eopFlagQty', displayName: 'EOP Flag Qty', width:70},
	       	      { field: 'holdQty', displayName: 'Hold Stock', width:70},
	       	      { field: 'undeliveredQty', displayName: 'Undelivered Qty', width:70},
	       	      { field: 'pendingRanQty', displayName: 'Pending Qty', width:70}
                        ],
                        exporterPdfAlign:'left',
                        exporterCsvFilename: 'ShortageAlarmReport.csv',
                        exporterMenuVisibleData: false,
                        exporterPdfDefaultStyle: {fontSize: 9},
                        exporterPdfTableStyle: {margin: [70, 5, 0, 5]},
                        exporterPdfTableHeaderStyle: {fontSize: 10, bold: true, italics: true, color: 'red'},
                        exporterPdfHeader: { text: "Shortage Alarm Report", style: 'headerStyle' },
                        exporterPdfFooter: function ( currentPage, pageCount ) {
                          return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
                        },
                        exporterPdfCustomFormatter: function ( docDefinition ) {
                        	 docDefinition.styles.headerStyle = { fontSize: 20, bold: true, alignment: 'center', margin: [0, 0, 20, 0] }; 
                             docDefinition.styles.footerStyle = { fontSize: 10, bold: true, alignment: 'center',  margin: [5, 0, 20, 0] }; 
                          return docDefinition;
                        },
                        exporterPdfOrientation: 'landscape',
                        exporterPdfPageSize: 'LETTER',
                        exporterPdfMaxGridWidth: 500,
                        exporterPdfFilename: 'ShortageAlarmReport.pdf',
                        exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
                       
                        onRegisterApi: function( gridApi ) {
                        	 $scope.gridApi = gridApi;
                        	 //Pagination
                        	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                        		 $scope.blockUI();
             		          paginationOptions.pageNumber = newPage;
             		          paginationOptions.pageSize = pageSize;
             		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
             		        /*paginationOptions.endIndex   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);*/
             		        paginationOptions.endIndex   = paginationOptions.pageSize;
             		        $scope.load();
             		        });
                        
                	    }
			 };
			 
			 $scope.gridOptions.exporterFieldCallback = function ( grid, row, col, value ){
				 if ( col.name === 'partInOutTime' || col.name === 'scanTime'){
					    value =  $filter('date')(value, 'dd/MM/yyyy HH:mm:ss');
					}				      
				  return value;
			 };
			 
			 $scope.openModel = function(partNumber){
			    	PartNumberInterService.partNumber = partNumber;
			    }; 
			 					
 // Clear the filter
	 $scope.clearFilters = function() {
		 $scope.gridApi.core.clearAllFilters();
     };
// Reset the values
	    $scope.resetForm = function(){
	    	$scope.lastWmsCalDate = "";
   		    $scope.lastCatsCalDate = "";
	    	$scope.shops = "";
	    	$scope.lines = "";	    	
	    	$scope.shortageAlmData.plant="";
	    	$scope.shortageAlmData.shop="";
	    	$scope.shortageAlmData.line="";
	    	$scope.shortageAlmData.zone="";
	    	$scope.shortageAlmData.partType="";
	    	$scope.shortageAlmData.wip=null;
	    	$scope.shortageAlmData.calLogic="W";
	    	$scope.shortageAlmData.shortageTypeR=true;
	    	$scope.shortageAlmData.shortageTypeG=true;
	    	$scope.shortageAlmData.shortageTypeY=true;
	    	$scope.beginDate=new Date();
		    $scope.endDate=new Date(); 
		    $scope.getMaxDate();
	    	$scope.gridOptions.data = [];
	    	$scope.clearFilters();	
	    	$scope.partNumberList="";	
	    	$scope.supplierList="";
	    	$scope.depotList="";
	    	$scope.pcList="";
	    	$scope.shortageAlmData.startIndex = 0;
	    	$scope.shortageAlmData.endIndex = 0;
	    	$scope.tags=[];
	    	$scope.supplierTags=[];
	    	$scope.depoCodeTags=[];
	    	$scope.pcCodeTags=[];
	    	$scope.locationIdData=[];	
	    	$scope.searchDataError = "Click search to fetch records";
	    	$scope.gridOptions.totalItems=0;
	    	$scope.gridOptions.enablePaginationControls=false;	    
	    	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"});
	    };	 
	    
	 // Get the list of shortage records
     $scope.getShortageAlmList = function(){
    	 shortageAlarmService.getShortageAlmList($scope.shortageAlmData).then(function(response){
	    		$scope.gridOptions.data = [];
	    		if(response.data.objectList !== undefined && response.data.objectList !== null){	    			
	    			if(response.data.statusType === 'success' ){
	    				$scope.gridOptions.enablePaginationControls=true;
	    				var i=0;
	    				 response.data.objectList.forEach(function(row){
	    					 if(response.data.objectList[i].grossDate==null){
	    						 response.data.objectList[i].grossDate = "-";
	    					 }
	    	    	           $scope.gridOptions.data = response.data.objectList;
	    	    	           i= i+1;
	    	    	          });
	    			} else {
	    				$scope.gridOptions.enablePaginationControls=false;
	    				$scope.alerts = [];
			            $scope.alerts.push({
			                type : response.data.statusType,
			                msg : response.data.statusMessage,
			                error : response.data.exceptionStackTrace,
			                errorClsName : response.data.exceptionClassName,
			                errorMsg : response.data.exceptionMessage
			            });
	    			}
	    			$.unblockUI();
	    		} else {
	    			$scope.searchDataError=response.data.statusMessage;	  
	    			$.unblockUI();
	    		}
	    		$.unblockUI();
	    	});
     };
	 	
            $scope.load = function () {
            $scope.shortageAlmData.endIndex = paginationOptions.pageSize;
	    	if(paginationOptions.endIndex === 0){
	    		$scope.shortageAlmData.endIndex = $scope.gridOptions.paginationPageSize;
	    	}
	    	$scope.shortageAlmData.startIndex = paginationOptions.startIndex;
	     	$scope.shortageAlmData.endIndex = paginationOptions.pageSize;
	    	$scope.shortageAlmData.partNumber = $scope.partNumberList;
	    	$scope.shortageAlmData.supCode = $scope.supplierList;
	    	$scope.shortageAlmData.depotCode = $scope.depotList;
	    	$scope.shortageAlmData.pcCode = $scope.pcList;
	    	
	    	if($scope.shortageAlmData.plant=="G"){
	    	//$scope.blockUI();
		    	shortageAlarmService.getShortageAlmListCount($scope.shortageAlmData).then(function(response){
		    		$scope.gridOptions.totalItems = response.data.object;		    		
		    		$scope.recordCount = response.data.object;		    		
		    		if($scope.recordCount==0){
		    			$scope.searchDataError="No Records Found!!!";
		    			$.unblockUI();
		    			$scope.gridOptions.enablePaginationControls=false;	
		    			$scope.alerts = [];
		    			
		    		}else{
		    			$scope.getShortageAlmList();
		    		}
		    	});
	    	}else{
	    		$scope.recordCount=0;
	    		if($scope.recordCount==0){
	    			$scope.searchDataError="No Records Found!!!";
	    			$.unblockUI();
	    			$scope.gridOptions.enablePaginationControls=false;	
	    			$scope.alerts = [];
	    		}
	    	}
	    };
	    
		    // --------- search button ---------
	    $scope.searchShortageData = function() {
	    	//$scope.blockUI();
        	if( $scope.validateFilter() == true){
        		if($scope.validateWip()== true)	{
        			$scope.blockUI();
        		$scope.shortageAlmData.fromDate = $filter('date')($scope.beginDate, 'yyyy-MM-dd');
        		$scope.shortageAlmData.toDate = $filter('date')($scope.endDate, 'yyyy-MM-dd');
        		$scope.alerts = [];
        		$scope.gridOptions.data = [];
        		paginationOptions.startIndex= 0;
        		paginationOptions.endIndex= 0;
        		paginationOptions.pageNumber= 1;
        		paginationOptions.pageSize= 100; 
        		$scope.gridOptions.paginationCurrentPage=1;
        		$scope.gridOptions.paginationPageSize=100;
        		$scope.shortageAlmData.startIndex=0;
    			$scope.shortageAlmData.endIndex=0;
    			$scope.shortageAlmData.isFullDownload=false;
        		$scope.searchClicked=true;
        		$scope.clearFilters();     
        		$scope.getLstCalTime();//Added as per biz siva requirement to get the latest time of batch job
        		$scope.load();
        		
        		$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
        		} else {
        			$scope.alerts = [];
           			$scope.alerts.push({
           				 type : 'danger',
           				 msg : 'Select atleast any one of the Color!!!'
           			});
           			$.unblockUI();
           			$scope.gridOptions.enablePaginationControls=false;
					$scope.gridOptions.data = [];
					return;
        		}
        	}else{
        		$scope.alerts = [];
       			$scope.alerts.push({
       				 type : 'danger',
       				 msg : 'Plant is mandatory'
       			});
       			$.unblockUI();
       			$scope.gridOptions.enablePaginationControls=false;
				$scope.gridOptions.data = [];
				return;
        	}
        	
        };
		    
        //Download button function for Missing and all parts cats coverage
        $scope.downloadSAReport = function (flag) {
        	$scope.shortageAlmData.flag=flag;
        	$scope.blockUI();
        	return shortageAlarmService.getDownloadNameFmDB($scope.shortageAlmData).then(function(response){
        		if(response.data.object != null && response.data.object.downloadName!=null){
        			shortageAlarmService.downloadFile(response.data.object.downloadName);
        		}
        	});
        }
        
       //Full Download function for Screen data
       $scope.downloadSANormalReport =function(){
        if( $scope.validateFilter() == true){
        	if($scope.shortageAlmData.plant=="G"){
        	if($scope.validateWip()== true)	{
    	$scope.blockUI();
 	    $scope.shortageAlmData.fromDate=$filter('date')($scope.beginDate, 'yyyy-MM-dd');;
    	$scope.shortageAlmData.toDate=$filter('date')($scope.endDate, 'yyyy-MM-dd');
    	$scope.shortageAlmData.isFullDownload=true;
    	$scope.shortageAlmData.partNumber = $scope.partNumberList;
    	$scope.shortageAlmData.supCode = $scope.supplierList;
    	$scope.shortageAlmData.depotCode = $scope.depotList;
    	$scope.shortageAlmData.pcCode = $scope.pcList;
    	shortageAlarmService.getShortageAlmListCount($scope.shortageAlmData).then(function(response){
    		$scope.recordCount = response.data.object;		    		
    		if($scope.recordCount==0){
    			$.unblockUI();
    			$scope.alerts = [];
       			$scope.alerts.push({
       				 type : 'danger',
       				 msg : 'No Records Found to download!!!'
       			});	
    		}else{
    			return shortageAlarmService.getShortageAlmDownload($scope.shortageAlmData);
    		}
    	 });
         } else {
        		$.unblockUI();
    			$scope.alerts = [];
       			$scope.alerts.push({
       				 type : 'danger',
       				 msg : 'Select atleast any one of the Color!!!'
       			});
    	  }        	
          }else{
        		$.unblockUI();
        		$scope.alerts = [];
    			$scope.searchDataError="No Records Found!!!";    			
    			$scope.gridOptions.enablePaginationControls=false;	
    	}
        }else{
        	$.unblockUI();
    		$scope.alerts = [];
   			$scope.alerts.push({
   				 type : 'danger',
   				 msg : 'Plant is mandatory'
   			});
    	}
    };
    
           	//Close the alert msg
            $scope.closeAlert = function(index) {
		        $scope.alerts.splice(index, 1);
		    };
		    
		    $scope.selectEndDate = function(endDate) {		    	
		    	$scope.fromMaxDate=$filter('date')(endDate, 'yyyy-MM-dd');
		    	// $scope.duplicateRAN.shift='';
		    	if($filter('date')(endDate, 'yyyy-MM-dd')== $filter('date')($scope.beginDate, 'yyyy-MM-dd')){
		    		$scope.shiftDropdown=false;
		    	}else{
		    		$scope.shiftDropdown=true;
		    	}		    	
		    };
		    
		    $scope.selectStartDate = function(startDate) {		    	
		    	// $scope.duplicateRAN.shift='';
		    	if($filter('date')(startDate, 'yyyy-MM-dd')== $filter('date')($scope.endDate, 'yyyy-MM-dd')){
		    		$scope.shiftDropdown=false;
		    	}else{
		    		$scope.shiftDropdown=true;
		    	}		    	
		    };
		    
		    //validation
		    $scope.validateFilter = function(){
		    	 if($scope.shortageAlmData.plant !== "" && $scope.shortageAlmData.plant !== null && $scope.shortageAlmData.plant !== undefined)
				 {
					 return true;
				 }else{
					 return false;
				 }
		     };
		     
		     //validate wip
		     $scope.validateWip = function(){
		    	 if($scope.shortageAlmData.shortageTypeR == false && $scope.shortageAlmData.shortageTypeY == false && $scope.shortageAlmData.shortageTypeG == false){
	 					return false;
					} else{
						return true;
					}  
				 
		     };
		     
		     //validate wip with color
		     $scope.wipClr = function(){
		    	 if($scope.shortageAlmData.wip == null)
				 {
		    		 $scope.shortageAlmData.shortageTypeR = true;
		    		 $scope.shortageAlmData.shortageTypeY = true;
		    		 $scope.shortageAlmData.shortageTypeG = true;
				 }
		     };
		     
		     //validate wip with color
		     $scope.getLstCalTime = function(){
		    if($scope.shortageAlmData.plant == "G")	{
		    	 return shortageAlarmService.getlstCalTime($scope.shortageAlmData.plant).then(function(response){
		    	   if(response.data.object != null){
		    			 if(response.data.object.lastWmsCalStr!=null){
		    				 $scope.lastWmsCalDate = response.data.object.lastWmsCalStr;
		    			 }
		    			 if(response.data.object.lastCatsCalStr!=null){
			        		 $scope.lastCatsCalDate = response.data.object.lastCatsCalStr;
		    			 }
		        	}
		        });
		      }else{
		    		 $scope.lastWmsCalDate = "";
		    		 $scope.lastCatsCalDate = "";
		    	 }
		     };
		     
		     
		 //Pop-up locations functionality
		     
		     $('#manageLocationModal').on('show.bs.modal', function () {
	            	$scope.clearFilters();
	            	$scope.partNo = PartNumberInterService.partNumber;
	            	$scope.partHeaderName = $scope.partNo;
	            	console.log("$scope.partNo:",$scope.partNo);
	            	$scope.searchLocations();     
	            	$scope.closeAlert();
			    });


	//FIND locations for the part number as input.
				    $scope.searchLocations = function(){
				    	if($scope.partNo!='' && $scope.partNo!=undefined){
				    		$scope.popupGridOptions.data = [];
				    		manageLocationByPartNoService.getLocationsByPartNumber($scope.partNo).then(function(response){	
					    	//	$scope.popupGridOptions.data = [];
					    		if(response.data!== undefined && response.data.objectList!== undefined && response.data.objectList!=null){	
					    			if(response.data.statusType === 'success' && response.data.objectList.length>0){
					    				$scope.popupGridOptions.data = response.data.objectList;
					    				//-------------------------end load
					    			} else {
					    				$scope.searchDataEror=response.data.statusMessage;
					    			}
					    			$.unblockUI();
					    		} else {
					    			$scope.searchDataEror=response.data.statusMessage;					    			
						            $.unblockUI();
					    		}
					    	});
				    	}else{
				    		$scope.popupGridOptions.data =[];
		    				$scope.alerts = [];
				            $scope.alerts.push({
				                type : "danger",
				                msg : "Please enter part number."
				            });
				    	}
				    };


	//Close the alert msg
		            $scope.closeAlert = function(index) {
				        $scope.alerts.splice(index, 1);
				    };

	/*GRID DEFAULT OPTIONS*/
				//gridMenuShowHideColumns:false;
				$scope.popupGridOptions = {		
						 enablePaginationControls:false,
						 enableGridMenu: true,
			             enableFiltering: true,            
			             enableColumnResize: true,
			             paginationPageSizes: [100,250,500],
			     	     paginationPageSize: 100,         
			             useExternalPagination: true,
			             autoResize:true,
			             enableSorting: true,
			             enableColumnMenus :true,
			             enablePinning: true, 
			             showGridFooter: false,
			             showColumnFooter: false,
			             columnDefs: [
			                         {
					                	 field: 'locationId', displayName: 'Location Id',
					                	 enableCellEdit: false,
					                	 editableCellTemplate: '<div><form name="inputForm"><input type="text" ng-class="\'colt\' + col.uid" ui-grid-editor ng-model="MODEL_COL_FIELD"></form></div>',
					                 }				                 
					                 ,{
					                	 field: 'currentQty', displayName: 'Current Quantity',
					                	 enableCellEdit: false,
					                 }
					                 /*,
					                 
					                 {
					                	 field: 'ran', displayName: 'RAN',
					                	 enableCellEdit: false,
					                 },

					                 {
					                	 field: 'totalCapacity',
					                	 displayName: 'Total Capacity',
					                	 enableCellEdit: false,
					                	 cellTemplate:'<div><label ng-show="row.isSelected" style="border:1px solid #F00;"><input type="text" ng-show="row.isSelected" ng-model="row.entity.totalCapacity"></input></label></div><div ng-show="!row.isSelected">{{row.entity.totalCapacity}}</div>',
					                		 
					                 }*/
					             ],
					             onRegisterApi: function( gridApi ) {
		                        	 $scope.gridApi = gridApi;
		                	    }
					           
					    };
} ]);