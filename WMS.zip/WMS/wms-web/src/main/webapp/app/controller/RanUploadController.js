wmsApp.controller('RanUploadController',['$scope','$location','$http','RanUploadService','$q','$filter','$window','commonService',function($scope,$location,$http,RanUploadService,$q,$filter,$window,commonService){
	
	 $scope.validUpload = false;
	 $scope.plant = "";
	 
	 // uploadRan
	 $scope.uploadRAN = function(){
		 if($scope.plant != "" && $scope.plant !== null){
	         var file = $scope.fileToUpload;
	         var fileName = file.name;
	         console.log(fileName);
	         $scope.fileName = fileName;
	         if($scope.plant == 'G')	{
	        	 var url = 'rest/RanUpload/uploadRanRecordPV';
	         } else {
	        	 var url = 'rest/RanUpload/uploadRanRecordPT';
	         } 
	         
	         if($scope.validUpload){
	         $scope.blockUI();
	         RanUploadService.uploadRAN(file,url).success(function(msg){					 
			     $scope.alerts = [];
	             $scope.alerts.push({
	                 type : msg.statusType,
	                 msg : msg.statusMessage
	             }); $.unblockUI();
	         }).error(function(response){
	        	  $scope.alerts = [];
	              $scope.alerts.push({
	                 type : msg.statusType,
	                 msg : msg.statusMessage
	             });$.unblockUI();
	         });
	       }
		 } else {
    	   $scope.alerts = [];
           $scope.alerts.push({
              type : "danger",
              msg : "Please select the plant..!"
          });$.unblockUI();
       }
	 };
	 
	 
	// --------- Plant drop down list -------
		if ($window.sessionStorage.getItem('locationDPCollection') == null || $window.sessionStorage.getItem('locationDPCollection') == 'undefined' || $window.sessionStorage.getItem('locationDPCollection') == undefined) {
			//$scope.ranUploadMethod();
			commonService.getAllPlants().success(function(response) {
				$scope.locations = response.objectList;
				$window.sessionStorage.setItem('locationDPCollection', JSON.stringify($scope.locations));
			}).error(function(response) {
			});
		} else {
			//$scope.ranUploadMethod();
			$scope.locations = JSON.parse(sessionStorage.locationDPCollection);
		}
		
	  
	 var searchString = "RanUpload";
	 var handleFileSelect = function( event ){
		 $scope.alerts = [];
			$scope.data = [];
		    var target = event.srcElement || event.target;
		    if (target && target.files && target.files.length === 1) {
		     $scope.blockUI();
		      var fileObject = target.files[0];
		      var fileType = " ";
		      fileType = fileObject.name;
		      if (!String.prototype.startsWith) {
		    	    String.prototype.startsWith = function(searchString, position){
		    	      position = position || 0;
		    	      return this.substr(position, searchString.length) === searchString;
		    	  };
		    	}
		      if(fileType.startsWith("RanUpload")){
		    	  var fileExtension = [];
		    	  var fileExtension = fileObject.name.split(".");
		      if(fileExtension[1].toLowerCase() == "xlsx" || fileExtension[1].toLowerCase() == "xls"){
		    	  $.unblockUI();
		    	  $scope.validUpload = true;
		    	  $scope.closeAlert();
		      }}else{
		    	  $scope.alerts = [];
	                 $scope.alerts.push({
	                     type : "danger",
	                     msg : "Invalid file!"
	                });
	                 $scope.validUpload = false;
	                 $scope.$apply();
	              $.unblockUI();
		      }
		    }			    
		  };
		 
		 
		  var fileChooser = document.querySelectorAll('.file-chooser');
		  
		  if ( fileChooser.length !== 1 ){
		    console.log('Found > 1 or < 1 file choosers within the menu item, error, cannot continue');
		  } else {
		    fileChooser[0].addEventListener('change', handleFileSelect, false);
		  }
		  

	$scope.closeAlert = function(index) {
	        $scope.alerts.splice(index, 1);
	    };

	    
	    // RanUploadData
	    
		 $scope.status="";
		 RanUploadService.getAllRANUploadDetails().then(function(response){
			 if(response.data!== undefined && response.data.objectList!== undefined && response.data.objectList!=null){	
				 console.log(response.data.objectList);
	    			if(response.data.statusType === 'success' && response.data.objectList.length>0){	
	    				for (var i = 0; i <response.data.objectList.length; i++){
	    				if(response.data.objectList[i].status == 0){
	    					response.data.objectList[i].status = "In Progress";
	    				}
	    				if(response.data.objectList[i].status == 1){
	    					response.data.objectList[i].status = "Complete";
	    				}
	    				if(response.data.objectList[i].status == 2){
	    					response.data.objectList[i].status = "Error";
	    				}
	    			}
	    				$scope.gridOptions.data = response.data.objectList;
	    			} else {
	    				$scope.searchDataEror=response.data.statusMessage;				    				
	    			}	    			
			 	}
			 	else {
	    			$scope.searchDataEror=response.data.statusMessage;		
	    		}
	    	});

	 var rowHighLight = '<div ng-class="{ rowColor:(row.entity.status==\'Error\' || row.entity.procedureError==\'Yes\') }"><div ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name" class="ui-grid-cell" ng-class="{ \'ui-grid-row-header-cell\': col.isRowHeader }" ui-grid-cell></div></div>';
	 $scope.gridOptions = {
				 enableGridMenu: true,
	             enableFiltering: true,            
	             enableColumnResize: true,
	             autoResize:true,
	             enableSorting: true,
	             enableColumnMenus: false,
	             enablePinning: true,
	             rowTemplate: rowHighLight,
	             columnDefs: [
	                          { field: 'runId', displayName: 'Run ID' },
	                          { field: 'plant', displayName: 'Plant' },
	                          { field: 'startTime', displayName: 'Start Time',cellFilter: 'date:\'MMM d, yyyy HH:mm:ss a\''},                          
	                          { field: 'endTime', displayName: 'End Time',cellFilter: 'date:\'MMM d, yyyy HH:mm:ss a\''},
	                          { field: 'status', displayName: 'Status'},
	                          { field: 'totalNoOfRecordUploaded', displayName: 'Total No of Records Uploads'},
	                          //{ field: 'fileName', displayName: 'fileName',visible:false},
	                          {field: 'error', displayName:'Error',cellTemplate:'<div class="dataCenter"><button ng-disabled = "row.entity.status == \'Complete\' && row.entity.error > 0? false : true" ng-class="{inactiveLink: (row.entity.status != \'Complete\' || row.entity.error == 0),  rowColor:(row.entity.status==\'Error\' || row.entity.procedureError==\'Yes\')}" class="disable" ng-csv=\'grid.appScope.downloadRANErrorRecords(row.entity.runId)\' filename="WMSRanDownload.csv" field-separator="," decimal-separator="." lazy-load="true"  csv-header=\'grid.appScope.getDownloadRanReportHeader()\' csv-column-order=\'grid.appScope.csvColumnOrder\'>{{row.entity.error}}</button></div>'},
	                          { field: 'procedureError', displayName: 'Procedure Error'},
	                          { field: 'procedureErrorMsg', displayName: 'Procedure Error Message'}
	                        
                        ],   
		    };
	 
	
	// download
	var downloadRANErroData = {};
	 $scope.downloadRANErrorRecords = function(downloadRanErrorId){
		 $scope.runId = downloadRanErrorId;
		 console.log($scope.runId);
     	return  RanUploadService.downloadErrorRecords($scope.runId).then(function(response){
     		console.log(response.objectList);
    		return response.objectList;
     	});
     };
     
     $scope.getDownloadRanReportHeader = function () {
     	return ["Ran","Part Number","MFG Date","Error Reason"];
    };
    
    $scope.csvColumnOrder=['ran','partNumber','mfgDate','errorReason'];
    
    $scope.refresh = function(){
    	$scope.blockUI();
    	//$window.location.reload();
    	$scope.plant="";
    	 RanUploadService.getAllRANUploadDetails().then(function(response){
    		 if(response.data!== undefined && response.data.objectList!== undefined && response.data.objectList!=null){	
    			 console.log(response.data.objectList);
        			if(response.data.statusType === 'success' && response.data.objectList.length>0){	
        				for (var i = 0; i <response.data.objectList.length; i++){
        				if(response.data.objectList[i].status == 0){
        					response.data.objectList[i].status = "In Progress";
        				}
        				if(response.data.objectList[i].status == 1){
        					response.data.objectList[i].status = "Complete";
        				}
        				if(response.data.objectList[i].status == 2){
        					response.data.objectList[i].status = "Error";
        				}
        			}
        				$scope.gridOptions.data = response.data.objectList;
        			} else {
        				$scope.searchDataEror=response.data.statusMessage;				    				
        			}	
        		$.unblockUI();
    		 }
    		else {
        			$scope.searchDataEror=response.data.statusMessage;	
        			$.unblockUI();
        		}
        	});
    };

}]);