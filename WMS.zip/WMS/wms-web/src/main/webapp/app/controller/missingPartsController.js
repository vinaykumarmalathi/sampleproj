wmsApp.controller('missingPartsController',
		['$scope','$window','$filter', '$location','$q', 'missingPartsService','locationService','uiGridTreeViewConstants', '$http','commonService','localStorageService','partNumberService',
	        function($scope,$window,$filter, $location,$q, missingPartsService,locationService,uiGridTreeViewConstants, $http,commonService,localStorageService, partNumberService) {
			
			$scope.searchDataEror="Click search to fetch records.";
			
			$scope.beginDate=new Date();
		    $scope.endDate=new Date();
		    
		    $scope.fromMaxDate=new Date();
		    
		    $scope.todayDate = new Date();
		    
		    $scope.beginDatePickerOpen = false;
		    $scope.endDatePickerOpen = false;
		    
		    $scope.openBeginDatePicker = function ($event) {			    	
	    		$event.preventDefault();
	    		$event.stopPropagation();
	    		$scope.beginDatePickerOpen = !$scope.beginDatePickerOpen;
		    };

		    $scope.openEndDatePicker = function ($event) {
		    	$event.preventDefault();
		    	$event.stopPropagation();
		    	$scope.endDatePickerOpen = !$scope.endDatePickerOpen;			  
		    };
		    
		 // --------- Part Number List ---------
			$scope.partNumber='';
			$scope.searchClicked=false;
			$scope.tags=[];	 
			/*ON ADD NEW PART TAG*/
			$scope.transactionList= ["In", "Out", "Move"];
			$scope.tagAdded = function(tag) {
				
				  $scope.partArray = [];
				  
				     for (var j=0; j < $scope.tags.length; j++) {
				    	 
				    	 $scope.partArray.push($scope.tags[j].text);
				    	 console.log("Part Array",$scope.partArray);
				      }
				     $scope.partNumber=$scope.partArray.join(',');
				     console.log("Part Number",$scope.partNumber);
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			/*ON REMOVE ADDED PART TAG*/
			    
		    $scope.tagRemoved = function(tag) {			   
		    	 $scope.partArray = [];
			     for (var j=0; j < $scope.tags.length; j++) {

			    	 $scope.partArray.push($scope.tags[j].text);
			      }
			     $scope.partNumber=$scope.partArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    $scope.addingTag = function(tag) {
		    	console.log("Tag.text",tag.text);
		    	  tag.text = tag.text.replace(/ /g, ',');
		    	  console.log("Tag.text 2",tag.text);
		    	  return tag;
		    	};
		    	
			
		    /*AUTOCOMPLE PART ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadParts = function(query) {		    	
		    	var partInputObj = {"partNumber": query};			    	
		    	return partNumberService.partNumberList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    });			    				         
		    };
			
			$scope.missingParts = {
					  partNumber : $scope.partNumber,
	                  fromDate : $scope.beginDate,
	                  toDate : $scope.endDate,
	                  startIndex : 0,
	                  endIndex : 0
	              };
			
			var paginationOptions = {
				 	startIndex : 0,
				 	endIndex : 0,
				    pageNumber: 1,
				    pageSize: 100,
				    sort: null
				  };
			
			//Grid
			 $scope.gridOptions = {
			 enablePaginationControls:false,
			 enableGridMenu: true,
            enableFiltering: true,            
            enableColumnResize: true,
            paginationPageSizes: [100,250,500,750,1000],
    	     paginationPageSize: 100,         
            useExternalPagination: true,
            autoResize:true,
            enableSorting: true,
            enableColumnMenus: false,
            enablePinning: true,            
            columnDefs: [
                         { field: 'partNumber', displayName: 'Part Number', width:200 },
                         { field: 'liveReceiptUpdatedTime', displayName: 'Live Receipt Date', width:220,cellFilter: 'date:\'MMM d, yyyy HH:mm:ss a\'' },
                         
                       ],
                       exporterPdfAlign:'left',
                       exporterCsvFilename: 'MissingParts.csv',
                       exporterMenuVisibleData: false,
                       exporterPdfDefaultStyle: {fontSize: 9},
                       exporterPdfTableStyle: {margin: [70, 5, 0, 5]},
                       exporterPdfTableHeaderStyle: {fontSize: 10, bold: true, italics: true, color: 'red'},
                       exporterPdfHeader: { text: "Missing Parts", style: 'headerStyle' },
                       exporterPdfFooter: function ( currentPage, pageCount ) {
                         return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
                       },
                       exporterPdfCustomFormatter: function ( docDefinition ) {
                       	 docDefinition.styles.headerStyle = { fontSize: 20, bold: true, alignment: 'center', margin: [0, 0, 20, 0] }; 
                            docDefinition.styles.footerStyle = { fontSize: 10, bold: true, alignment: 'center',  margin: [5, 0, 20, 0] }; 
                         return docDefinition;
                       },
                       exporterPdfOrientation: 'landscape',
                       exporterPdfPageSize: 'LETTER',
                       exporterPdfMaxGridWidth: 500,
                       exporterPdfFilename: 'MissingParts.pdf',
                       exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
                      
                       onRegisterApi: function( gridApi ) {
                       	 $scope.gridApi = gridApi;
                       	 //Pagination
                       	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                       		 $scope.blockUI();
            		          paginationOptions.pageNumber = newPage;
            		          paginationOptions.pageSize = pageSize;
            		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
            		        paginationOptions.endIndex   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
            		       $scope.load();
            		        });
                       
               	    }
		    };
			
			// Clear the filter
			$scope.clearFilters = function() {
				$scope.gridApi.core.clearAllFilters();
		    };
		    
		 // --------- search button ---------
           // $scope.searchMissingParts = function() {
            	
        		$scope.blockUI();
        		
        		$scope.alerts = [];
        		$scope.gridOptions.data = [];
        		
        		$scope.missingParts.isFullDownload=0;
        		paginationOptions.startIndex= 0;
        		paginationOptions.endIndex= 0;
        		paginationOptions.pageNumber= 1;
        		paginationOptions.pageSize= 100; 
        		$scope.gridOptions.paginationCurrentPage=1;
        		$scope.gridOptions.paginationPageSize=100;
        		$scope.searchClicked=true;
        		//$scope.clearFilters();                	
        		
        		$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
            	
            //};
            
            /* Load data in grid */
			  var load = function () {
			    	$scope.missingParts.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

			    	if(paginationOptions.endIndex === 0){
			    		$scope.missingParts.endIndex = $scope.gridOptions.paginationPageSize;
			    	}
			    	$scope.missingParts.startIndex = paginationOptions.startIndex;
			    	$scope.missingParts.endIndex = paginationOptions.pageSize;
			    	
			    	
			    	missingPartsService.getMissingPartsListCount($scope.missingParts).then(function(response){
			    		$scope.gridOptions.totalItems = response.data.object;		    		
			    		$scope.recordCount = response.data.object;	
			    		$scope.missingPartsData();
			    	});
			    	
			    };
			    
			    load();
			    
			    $scope.missingPartsData = function(){    	    	 
			    	missingPartsService.getMissingPartsList($scope.missingParts).then(function(response){
				    		$scope.gridOptions.data = [];
				    		console.log(response.data.objectList.length);
				    		if(response.data.objectList !== undefined && response.data.objectList !== null){
				    			if(response.data.statusType === 'success' ){
				    				$scope.gridOptions.enablePaginationControls=true;
				    				 response.data.objectList.forEach(function(row){	    	    	         	          
				    	    	           $scope.gridOptions.data = response.data.objectList;	 
				    	    	          });
				    				 
				    				 	
				    			} else {
				    				$scope.gridOptions.enablePaginationControls=false;
				    				$scope.alerts = [];
						            $scope.alerts.push({
						                type : response.data.statusType,
						                msg : response.data.statusMessage,
						                error : response.data.exceptionStackTrace,
						                errorClsName : response.data.exceptionClassName,
						                errorMsg : response.data.exceptionMessage
						            });
				    			}
				    			$.unblockUI();
				    		} else {
				    			$scope.searchDataEror=response.data.statusMessage;	    			
					            $.unblockUI();
				    		}
				    	});
			     };
			     
			     $scope.downloadMissingParts =function(){
		            	$scope.alerts = [];
		            	$scope.blockUI();
		            	
				    	var validateFlag = true;
				    	if( validateFlag == true){	
			            	$scope.missingParts.isFullDownload=1;
			            	return missingPartsService.missingPartsDownload($scope.missingParts).then(function(response){
			            		
			            			if(response.objectList != null){
				            			for (var i = 0; i < response.objectList.length; i++) {
				            				response.objectList[i].partNumber = '="'+response.objectList[i].partNumber+'"';
				            				response.objectList[i].liveReceiptUpdatedTime =$filter('date')(response.objectList[i].liveReceiptUpdatedTime, 'dd/MM/yyyy HH:mm:ss');
				            			}
				            			$.unblockUI();
				            			return response.objectList;
				            		}else{
				            			$.unblockUI();
				            			$scope.alerts = [];
				    	       			$scope.alerts.push({
				    	       				 type : 'danger',
				    	       				msg : response.statusMessage
				    	       			});
				            		}
			            	});
				    	}
				    	else{
				    		$.unblockUI();
		            		$scope.alerts = [];
			       			$scope.alerts.push({
			       				 type : 'danger',
			       				 msg : 'Date Fields Should not be Empty. Please select the Date Range.'
			       			});
			       			//Throwing null pointer error intentionally as a temporary fix to stop downloading.
			       			var temp=null;
			       			console.log("Temp length",temp.length);	       			
		            	}
		            };
		            
		            $scope.getMissingPartsHeader = function () {
		            	return ["Part Number", "Live Receipt Date"];
		           };
		           
		           $scope.csvColumnOrder=['partNumber', 'liveReceiptUpdatedTime'];
		           
		           
		           /* Load data in grid */
				   $scope.load = function () {
				    	$scope.missingParts.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

				    	if(paginationOptions.endIndex === 0){
				    		$scope.missingParts.endIndex = $scope.gridOptions.paginationPageSize;
				    	}
				    	$scope.missingParts.startIndex = paginationOptions.startIndex;
				    	$scope.missingParts.endIndex = paginationOptions.pageSize;
				    	
				    	
				    	missingPartsService.getMissingPartsListCount($scope.missingParts).then(function(response){
				    		$scope.gridOptions.totalItems = response.data.object;		    		
				    		$scope.recordCount = response.data.object;	
				    		$scope.missingPartsData();
				    	});
				    	
				    };
		           
		        // --------- search button ---------
		            $scope.searchMissingParts = function() {
		            	
	            		$scope.blockUI();
	            		$scope.fromDate = $filter('date')($scope.beginDate, 'yyyy-MM-dd');
	            		$scope.toDate = $filter('date')($scope.endDate, 'yyyy-MM-dd');
	            		
	            		$scope.alerts = [];
	            		$scope.gridOptions.data = [];
	            		
	            		$scope.missingParts.partNumber=$scope.partNumber;
	            		$scope.missingParts.fromDate = $filter('date')($scope.beginDate, 'yyyy-MM-dd');
	            		$scope.missingParts.toDate = $filter('date')($scope.endDate, 'yyyy-MM-dd');
	            		
	            		$scope.missingParts.isFullDownload=0;
	            		paginationOptions.startIndex= 0;
	            		paginationOptions.endIndex= 0;
	            		paginationOptions.pageNumber= 1;
	            		paginationOptions.pageSize= 100; 
	            		$scope.gridOptions.paginationCurrentPage=1;
	            		$scope.gridOptions.paginationPageSize=100;
	            		$scope.searchClicked=true;
	            		$scope.clearFilters();                	
	            		$scope.load();
	            		$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
		            	
		            };
		            
		         // Reset the values
				    $scope.resetMissingParts = function(){	
				    	
				    	$scope.beginDate=new Date();
					    $scope.endDate=new Date(); 
					    
				    	$scope.gridOptions.data = [];
				    	$scope.clearFilters();	  
				    	$scope.missingParts = {};
				    	$scope.partNumber="";	    	
				    	$scope.missingParts.startIndex = 0;
				    	$scope.missingParts.endIndex = 0;
				    	$scope.tags=[];
				    	$scope.ranData=[];
				    	
				    	$scope.gridOptions.totalItems=0;
				    	
				    	$scope.gridOptions.enablePaginationControls=false;	    
				    	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
					   
				    };
		}
]);