wmsApp.controller('headerMenuController', [ '$scope','userMenuService','$window',
                        function($scope,userMenuService,$window) {
	var userId = $window.sessionStorage.getItem('loggedUserId');
 	userMenuService.getUserMenus(userId).then(function(response){
		 if(response.data.objectList!== undefined && response.data.objectList!=null){	
    			if(response.data.statusType === 'success' && response.data.objectList.length>0){
    				$scope.userMenu = response.data.objectList;
    				console.log("userMenu ",$scope.userMenu);
    				$scope.userMenuValid = [];
    				$scope.userMenuValid.push('#/home');
	    				$scope.userMenu.forEach(function(parent){
	    					if(parent.checked == true){
	    						$scope.userMenuValid.push(parent.path);
	    						if(parent.childMenu.length > 0){
	    							parent.childMenu.forEach(function(child){
	    								if(child.checked == true){
	    									$scope.userMenuValid.push(child.path);
	    									if(child.childMenu.length > 0){
	    										child.childMenu.forEach(function(subChild){
	    											if(subChild.checked == true){
	    												$scope.userMenuValid.push(subChild.path);
	    											}
	    										});
	    									}
	    								}
	    							});
	    						}
	    						//console.log("test ",$scope.userMenuValid);
	    						$window.sessionStorage.setItem('userMenu',$scope.userMenuValid);
	    					}
	    				});
	    			}
		 }
	});
}]);