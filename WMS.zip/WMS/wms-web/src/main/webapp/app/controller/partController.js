wmsApp.controller('partController', [ '$scope', '$location', '$routeParams','$window', 'partFactory', 
        function($scope,$location,$routeParams,$window,partFactory) {
	
	partFactory.listAllParts.query().$promise.then(function(partCollection){
				
		console.log(partCollection);
		//if (partCollection.statusType === 'success') {
			$scope.parts=partCollection.objectList;
      //  } else {
            $scope.alerts = [];
            $scope.alerts.push({
                type : partCollection.statusType,
                msg : partCollection.statusMessage,
                error : partCollection.exceptionStackTrace,
                errorClsName : partCollection.exceptionClassName,
                errorMsg : partCollection.exceptionMessage
            });
       // }
            //console.log($scope.parts);
		//console.log($scope.alerts);
	});
	

    $scope.closeAlert = function(index) {
        $scope.alerts.splice(index, 1);
    };

	
} ]);