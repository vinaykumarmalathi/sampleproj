wmsApp.controller('ranMasterController', 
		[ '$scope','$window','$filter', '$location','$q', 'ranMasterService','locationService','uiGridTreeViewConstants', '$http','commonService','localStorageService','partNumberService','ranService','commonService','localStorageService',
        function($scope,$window,$filter, $location,$q, ranMasterService,locationService,uiGridTreeViewConstants, $http,commonService,localStorageService,partNumberService,ranService,commonService,localStorageService) {
			$scope.searchDataEror="Click search to fetch records.";
			$scope.datePickerOpen = false;

		    $scope.openDatePicker = function ($event) {			    	
		    $event.preventDefault();
		    $event.stopPropagation();
		    $scope.datePickerOpen = !$scope.datePickerOpen;
		    };
		    
		    $scope.enableRanFlg = false;
		    
		    //$scope.downloadAuditData =[];
			
			$scope.partNumber='';
			$scope.searchClicked=false;
			$scope.tags=[];	 
			/*ON ADD NEW PART TAG*/
			$scope.lppdList= ["All", "Available","Not Available"];
			
			
			if($window.sessionStorage.getItem('locationDPCollection') == null || $window.sessionStorage.getItem('locationDPCollection')=='undefined' || $window.sessionStorage.getItem('locationDPCollection')==undefined){
				  commonService.getAllPlants()
				  .success(function(response){					 
					  $scope.locations = response.objectList;				
					  $window.sessionStorage.setItem('locationDPCollection',JSON.stringify($scope.locations));
					 
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.locations = JSON.parse(sessionStorage.locationDPCollection);
			  }
			
			//document.getElementById('sel_location').value = "G";
			
			$scope.tagAdded = function(tag) {
				
				  $scope.partArray = [];
				  
				     for (var j=0; j < $scope.tags.length; j++) {
				    	 
				    	 $scope.partArray.push($scope.tags[j].text);
				    	 console.log("Part Array",$scope.partArray);
				      }
				     $scope.partNumber=$scope.partArray.join(',');
				     console.log("Part Number",$scope.partNumber);
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			/*ON REMOVE ADDED PART TAG*/
			    
		    $scope.tagRemoved = function(tag) {			   
		    	 $scope.partArray = [];
			     for (var j=0; j < $scope.tags.length; j++) {

			    	 $scope.partArray.push($scope.tags[j].text);
			      }
			     $scope.partNumber=$scope.partArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    $scope.addingTag = function(tag) {
		    	console.log("Tag.text",tag.text);
		    	  tag.text = tag.text.replace(/ /g, ',');
		    	  console.log("Tag.text 2",tag.text);
		    	  return tag;
		    	};
		    	
			
		    /*AUTOCOMPLE PART ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadParts = function(query) {		    	
		    	var partInputObj = {"partNumber": query};			    	
		    	return partNumberService.partNumberList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    });			    				         
		    };
			    
			  
		   
		    
		    /* RAN Auto Completion - Start */
		    $scope.ranData=[];	
		    
		    $scope.ranAdded = function(tag) {			
				console.log("tagAdded:",tag);
				  $scope.ranArray = [];
				     for (var j=0; j < $scope.ranData.length; j++) {
				    	 $scope.ranArray.push($scope.ranData[j].text);
				      }
				     $scope.ranMaster.ranId=$scope.ranArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			};
		    
		    $scope.ranRemoved = function(tag) {			   
		    	 $scope.ranArray = [];
			     for (var j=0; j < $scope.ranData.length; j++) {

			    	 $scope.ranArray.push($scope.ranData[j].text);
			      }
			     $scope.ranMaster.ranId=$scope.ranArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    /*$scope.loadRan = function(query) {
		    	var partInputObj = {"ranId": query};
		    	return ranService.ranList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){	
		        			 console.log(response.data.object);
		        			  return response.data.object;                           
		        		 }
		        	 }		    		
			    });	
		    };*/
		    
		    
		    $scope.loadRan = function(query,colName){
		    	var partInputObj = {"ranId": query};
		    	$scope.ranMaster.input=partInputObj;
				return ranMasterService.getRanListByPlant($scope.ranMaster).then(function(response){
					console.log(response.data.object);
					if(response.data.statusType == "success"){
						if(response.data.object != 'null' && response.data.object != null){
							return response.data.object;
						}
					}
				});
			};
		    

		    /*RAN Auto Completion - End */
		    
		    $scope.enableRAN = function (){
		    	if($scope.ranMaster.plant!=null && $scope.ranMaster.plant!=''){
		    		$scope.enableRanFlg = true;
		    	}else{
		    		$scope.enableRanFlg = false;
		    	}
		    }
		  			    		  
		    $scope.ranMaster = {
		          plant : '',
		    	  partNo : $scope.partNumber,
                  ran : $scope.auditRAN,
                  updatedDate : $scope.updatedDateTime,
                  startIndex : 0,
                  endIndex : 0,
                  input : ''
              };

		     var paginationOptions = {
				 	startIndex : 0,
				 	endIndex : 0,
				    pageNumber: 1,
				    pageSize: 100,
				    sort: null
				  };
			 
			 //Grid
			 $scope.gridOptions = {
			 enablePaginationControls:false,
			 enableGridMenu: true,
             enableFiltering: true,            
             enableColumnResize: true,
             paginationPageSizes: [100,250,500,750,1000],
     	     paginationPageSize: 100,         
             useExternalPagination: true,
             autoResize:true,
             enableSorting: true,
             enableColumnMenus: false,
             enablePinning: true,            
             columnDefs: [
                          { field: 'ranId', displayName: 'RAN', width:100 },
                          { field: 'partNo', displayName: 'Part Number', width:150, pinnedLeft:true },
                          /*{ field: 'mfgDate', displayName: 'Mfg Date', width:100 },*/
                          { field: 'mfgDate', displayName: 'Shipping Date', width:100 },
			       	      { field: 'lppd', displayName: 'LPPD', width:130,cellFilter: 'date:\'MMM d, yyyy \''},
			       	      { field: 'updatedDateTime', displayName: 'Updated Date ', width:180,cellFilter: 'date:\'MMM d, yyyy \''}
                        ],
                        exporterPdfAlign:'left',
                        exporterCsvFilename: 'RANMaster.csv',
                        exporterMenuVisibleData: false,
                        exporterPdfDefaultStyle: {fontSize: 9},
                        exporterPdfTableStyle: {margin: [70, 5, 0, 5]},
                        exporterPdfTableHeaderStyle: {fontSize: 10, bold: true, italics: true, color: 'red'},
                        exporterPdfHeader: { text: "RAN Master", style: 'headerStyle' },
                        exporterPdfFooter: function ( currentPage, pageCount ) {
                          return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
                        },
                        exporterPdfCustomFormatter: function ( docDefinition ) {
                        	 docDefinition.styles.headerStyle = { fontSize: 20, bold: true, alignment: 'center', margin: [0, 0, 20, 0] }; 
                             docDefinition.styles.footerStyle = { fontSize: 10, bold: true, alignment: 'center',  margin: [5, 0, 20, 0] }; 
                          return docDefinition;
                        },
                        exporterPdfOrientation: 'landscape',
                        exporterPdfPageSize: 'LETTER',
                        exporterPdfMaxGridWidth: 500,
                        exporterPdfFilename: 'RANMaster.pdf',
                        exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
                       
                        onRegisterApi: function( gridApi ) {
                        	 $scope.gridApi = gridApi;
                        	 //Pagination
                        	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                        		 $scope.blockUI();
             		          paginationOptions.pageNumber = newPage;
             		          paginationOptions.pageSize = pageSize;
             		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
             		        paginationOptions.endIndex   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
             		       $scope.load();
             		        });
                        
                	    }
		    };
			 
		/*	 $scope.gridOptions.exporterFieldCallback = function ( grid, row, col, value ){
				 
				 if ( col.name === 'partInOutTime' || col.name === 'scanTime'){					 	
					    value =  $filter('date')(value, 'dd/MM/yyyy HH:mm:ss');					   
					}				      
				  return value;
				 
			 };*/ 
 // Clear the filter
	 $scope.clearFilters = function() {
		 $scope.gridApi.core.clearAllFilters();
     };
// Reset the values
	    $scope.resetRANList = function(){
	    	    	  
	    	$scope.gridOptions.data = [];
	    	$scope.clearFilters();	  
	    	$scope.ranMaster = {};
	    	$scope.ranMaster.plant='';
	    	$scope.partNumber="";	    	
	    	$scope.ranMaster.startIndex = 0;
	    	$scope.ranMaster.endIndex = 0;
	    	$scope.tags=[];
	    	$scope.ranData=[];
	    	$scope.gridOptions.totalItems=0;
	    	$scope.partNumber="";
	    	//$scope.ranMaster.lppdAvailable=true;
	    	$scope.updatedDateTime = "";
	    	$scope.gridOptions.enablePaginationControls=false;	   
	    	$scope.enableRAN();
	    	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
	    	
		    
	    };	    
   $scope.ranMasterData = function(){ 
    	 ranMasterService.getRanList($scope.ranMaster).then(function(response){
	    		$scope.gridOptions.data = [];
	    		console.log(response.data.objectList.length);
	    		if(response.data.objectList !== undefined && response.data.objectList !== null){
	    			if(response.data.statusType === 'success' ){
	    				$scope.gridOptions.enablePaginationControls=true;
	    				 response.data.objectList.forEach(function(row){	    	    	         	          
	    	    	           $scope.gridOptions.data = response.data.objectList;	 
	    	    	          });
	    				 
	    				 	
	    			} else {
	    				$scope.gridOptions.enablePaginationControls=false;
	    				$scope.alerts = [];
			            $scope.alerts.push({
			                type : response.data.statusType,
			                msg : response.data.statusMessage,
			                error : response.data.exceptionStackTrace,
			                errorClsName : response.data.exceptionClassName,
			                errorMsg : response.data.exceptionMessage
			            });
	    			}
	    			$.unblockUI();
	    		} else {
	    			$scope.searchDataEror=response.data.statusMessage;	    			
		            $.unblockUI();
	    		}
	    	});
     };
     
	 		/* Load data in grid */
		   $scope.load = function () {
		    	$scope.ranMaster.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

		    	if(paginationOptions.endIndex === 0){
		    		$scope.ranMaster.endIndex = $scope.gridOptions.paginationPageSize;
		    	}
		    	$scope.ranMaster.startIndex = paginationOptions.startIndex;
		    	$scope.ranMaster.endIndex = paginationOptions.pageSize;
		    	$scope.ranMaster.partNo = $scope.partNumber;
		    	$scope.ranMaster.ran = $scope.ranMaster.ranId;
		    	
		    	ranMasterService.getRanListCount($scope.ranMaster).then(function(response){
                  if(response.data!=null && response.data.statusCode=='N001'){
                	  $scope.searchDataEror = "No Records Found";
                	  $.unblockUI();
                  }else{
                	  $scope.gridOptions.totalItems = response.data.object;		    		
  		    		  $scope.recordCount = response.data.object;	
  		    		  $scope.ranMasterData();
                  }
		    	});
		    	
		    };
		    
		    // --------- search button ---------
            $scope.searchRANList = function() {
            	if( $scope.validateFilter() == true){
            		$scope.blockUI();
            		$scope.alerts = [];
            		$scope.gridOptions.data = [];
            		$scope.ranMaster.partNo=$scope.partNumber;
            		$scope.ranMaster.updatedDate = $filter('date')($scope.updatedDateTime, 'yyyy-MM-dd');
            		$scope.ranMaster.isFullDownload=0;
            		paginationOptions.startIndex= 0;
            		paginationOptions.endIndex= 0;
            		paginationOptions.pageNumber= 1;
            		paginationOptions.pageSize= 100; 
            		$scope.gridOptions.paginationCurrentPage=1;
            		$scope.gridOptions.paginationPageSize=100;
            		$scope.searchClicked=true;
            		$scope.clearFilters();
            		//$.unblockUI();
            		$scope.load();
            		//$scope.agedAuditData();
            		$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
            		
            }else{
        		$scope.alerts = [];
       			$scope.alerts.push({
       				 type : 'danger',
       				 msg : 'Plant is mandatory'
       			});
       			$.unblockUI();
       			$scope.gridOptions.enablePaginationControls=false;
				$scope.gridOptions.data = [];
				return;
        	}
            	
            };
		    
            $scope.downloadRanList =function(){
            	/*if( $scope.validateFilter() == true){*/
            	$scope.ranMaster.partNo=$scope.partNumber;            
            	$scope.ranMaster.isFullDownload=1;
            	return  ranMasterService.getRanListDownload($scope.ranMaster).then(function(response){
            		for (var i = 0; i < response.objectList.length; i++) {
						response.objectList[i].ranId = '="'+response.objectList[i].ranId+'"';	
            			response.objectList[i].partNo = '="'+response.objectList[i].partNo+'"';						
						response.objectList[i].lppd =$filter('date')(response.objectList[i].lppd, 'dd/MM/yyyy');
						response.objectList[i].updatedDateTime =$filter('date')(response.objectList[i].updatedDateTime, 'dd/MM/yyyy');
					}
					return response.objectList;
            	});
            	/*}else{
            		$scope.alerts = [];
           			$scope.alerts.push({
           				 type : 'danger',
           				 msg : 'Plant is mandatory'
           			});
           			$.unblockUI();
           			$scope.gridOptions.enablePaginationControls=false;
    				$scope.gridOptions.data = [];
    				return;
            	}*/
        
            };
         
            $scope.getDownloadRANListHeader = function () {
            	/*return [ "RAN","Part Number","Mfg Date","LPPD","Updated Date "];*/
            	return [ "RAN","Part Number","Shipping Date","LPPD","Updated Date "];
           };
           $scope.csvColumnOrder=['ranId','partNo','mfgDate','lppd','updatedDateTime'];
           
          // $scope.fileName=['test.csv'];
           
         /*  $scope.getFileName = function (){
        	   if($scope.ranMaster.plant!='D'){
            	   return "PV_RAN_MASTER.csv";
               }else{
            	   return "PT_RAN_MASTER.csv";
               }
           }*/
           
           /*if($scope.ranMaster.plant!='D'){
        	   $scope.fileName = "PV_RAN_MASTER.csv";
           }else{
        	   $scope.fileName = "PT_RAN_MASTER.csv";
           }*/
          

			//Close the alert msg
            $scope.closeAlert = function(index) {
		        $scope.alerts.splice(index, 1);
		    };
		    
		   
		    
		   /* $scope.validateFilter = function(){
		    	 return true;
		     };*/
		    
		    $scope.validateFilter = function(){
		    	 if($scope.ranMaster.plant !== "" && $scope.ranMaster.plant !== null && $scope.ranMaster.plant !== undefined)
				 {
					 return true;
				 }else{
					 return false;
				 }
		     };
		
} ]);