wmsApp.controller('FIFOSuggestionOverrideController', 
		[ '$scope','$window','$filter', '$location','$q', 'FIFOSuggestionOverrideService','locationService','uiGridTreeViewConstants', '$http','commonService','localStorageService','partNumberService','ranService',
        function($scope,$window,$filter, $location,$q, FIFOSuggestionOverrideService,locationService,uiGridTreeViewConstants, $http,commonService,localStorageService,partNumberService,ranService) {
			$scope.searchDataEror="Click search to fetch records.";
			$scope.beginDate=new Date();
		    $scope.endDate=new Date();
		    $scope.fromMaxDate=new Date();
               $scope.shiftDropdown=false;
			   $scope.todayDate = new Date();
			   $scope.shiftList = ["A", "B" ,"C"];
			    $scope.beginDatePickerOpen = false;
			    $scope.endDatePickerOpen = false;

			    $scope.openBeginDatePicker = function ($event) {			    	
			    $event.preventDefault();
			    $event.stopPropagation();
			    $scope.beginDatePickerOpen = !$scope.beginDatePickerOpen;
			    };

			    $scope.openEndDatePicker = function ($event) {
			    $event.preventDefault();
			    $event.stopPropagation();
			    $scope.endDatePickerOpen = !$scope.endDatePickerOpen;			  
			    };
			 
			    
			
			// --------- Part Number List ---------
			$scope.partNumber='';
			$scope.searchClicked=false;
			$scope.tags=[];	 
			/*ON ADD NEW PART TAG*/
			$scope.transactionList= ["In", "Out"];
			$scope.tagAdded = function(tag) {
				
				  $scope.partArray = [];
				  
				     for (var j=0; j < $scope.tags.length; j++) {
				    	 
				    	 $scope.partArray.push($scope.tags[j].text);
				    	 console.log("Part Array",$scope.partArray);
				      }
				     $scope.partNumber=$scope.partArray.join(',');
				     console.log("Part Number",$scope.partNumber);
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			/*ON REMOVE ADDED PART TAG*/
			    
		    $scope.tagRemoved = function(tag) {			   
		    	 $scope.partArray = [];
			     for (var j=0; j < $scope.tags.length; j++) {

			    	 $scope.partArray.push($scope.tags[j].text);
			      }
			     $scope.partNumber=$scope.partArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    $scope.addingTag = function(tag) {
		    	console.log("Tag.text",tag.text);
		    	  tag.text = tag.text.replace(/ /g, ',');
		    	  console.log("Tag.text 2",tag.text);
		    	  return tag;
		    	};
		    	
			
		    /*AUTOCOMPLE PART ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadParts = function(query) {		    	
		    	var partInputObj = {"partNumber": query};			    	
		    	return partNumberService.partNumberList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    });			    				         
		    };
			    
			  
		    /*ON ADD NEW LOCATION TAG*/
		    
			$scope.location="";
			$scope.locationIdData=[];	 
		    $scope.locationAdded = function(tag) {					
		    $scope.locationArray = [];
			    for (var j=0; j < $scope.locationIdData.length; j++) {
			    	$scope.locationArray.push($scope.locationIdData[j].text);
			    }
			    $scope.location=$scope.locationArray.join(',');
			    $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    /*ON REMOVE ADDED LOCATION TAG*/
		    
		    $scope.locationRemoved = function(tag) {			   
		    	 $scope.locationArray = [];
			     for (var j=0; j < $scope.locationIdData.length; j++) {
			    	 $scope.locationArray.push($scope.locationIdData[j].text);
			     }
			     $scope.location=$scope.locationArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    /* RAN Auto Completion - Start */
		    $scope.ranData=[];	
		    
		    $scope.ranAdded = function(tag) {			
				console.log("tagAdded:",tag);
				  $scope.ranArray = [];
				     for (var j=0; j < $scope.ranData.length; j++) {
				    	 $scope.ranArray.push($scope.ranData[j].text);
				      }
				     $scope.fifoSuggest.ran=$scope.ranArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			};
		    
		    $scope.ranRemoved = function(tag) {			   
		    	 $scope.ranArray = [];
			     for (var j=0; j < $scope.ranData.length; j++) {

			    	 $scope.ranArray.push($scope.ranData[j].text);
			      }
			     $scope.fifoSuggest.ran=$scope.ranArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    $scope.loadRan = function(query) {
		    	var partInputObj = {"ranId": query};
		    	return ranService.ranList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){	
		        			 console.log(response.data.object);
		        			  return response.data.object;                           
		        		 }
		        	 }		    		
			    });	
		    };

		 // --------- Location drop down list -------

			  if($window.sessionStorage.getItem('locationDPCollection') == null || $window.sessionStorage.getItem('locationDPCollection')=='undefined' || $window.sessionStorage.getItem('locationDPCollection')==undefined){
				  commonService.getAllPlants()
				  .success(function(response){					 
					  $scope.locations = response.objectList;				
					  $window.sessionStorage.setItem('locationDPCollection',JSON.stringify($scope.locations));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.locations = JSON.parse(sessionStorage.locationDPCollection);
			  }
			  
			  // --------- Section drop down list ---------

			  if($window.sessionStorage.getItem('sectionDPCollection') == null || $window.sessionStorage.getItem('sectionDPCollection')=='undefined' || $window.sessionStorage.getItem('sectionDPCollection')==undefined){
				  commonService.getAllSections()
				  .success(function(response){					 
					  $scope.sections = response.objectList;	
					  $window.sessionStorage.setItem('sectionDPCollection',JSON.stringify($scope.sections));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.sections = JSON.parse(sessionStorage.sectionDPCollection);
			  }
			  
			// --------- Shops drop down list ---------
			  
			    $scope.loadShopLine = function(){
			    	 $scope.fifoSuggest.line = '';
			    	 $scope.fifoSuggest.shop = '';
			    	 commonService.getLineList($scope.fifoSuggest.plant)
					  .success(function(response){
						  $scope.lines = response.objectList;				
					  })
					  .error(function(response){
					  });
			    	 commonService.getShopList($scope.fifoSuggest.plant)
					  .success(function(response){
						  $scope.shops = response.objectList;				
					  })
					  .error(function(response){
					  });

			    };
		
		    /*AUTOCOMPLE LOCATION ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadLocation = function(query) {
		    	
		    	var locationInputObj = {"locationId": query};			    	
		    	return locationService.locationList(locationInputObj).then(function(response){	
		    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    	});			    				         
		    };
			    			    		  
		    $scope.fifoSuggest = {				
		    	  partNumber : $scope.partNumber,
		    	  location : $scope.location, 
                  fromDate : $scope.beginDate,
                  toDate : $scope.endDate,
                  startIndex : 0,
                  endIndex : 0
              };
			
			
			
			 var paginationOptions = {
				 	startIndex : 0,
				 	endIndex : 0,
				    pageNumber: 1,
				    pageSize: 100,
				    sort: null
				  };
			 
		
			 //Grid
			 $scope.gridOptions = {
			 enablePaginationControls:false,
			 enableGridMenu: true,
             enableFiltering: true,            
             enableColumnResize: true,
             paginationPageSizes: [100,250,500,750,1000],
     	     paginationPageSize: 100,         
             useExternalPagination: true,
             autoResize:true,
             enableSorting: true,
             enableColumnMenus: false,
             enablePinning: true,            
             columnDefs: [
                          { field: 'partNumber', displayName: 'Part Number', width:150},                          
			       	      { field: 'suggestedRan', displayName: 'Suggested RAN', width:150},
			       	      { field: 'suggestedLocation', displayName: 'Suggested Location', width:150 },
			       	      { field: 'suggestedRanLppd', displayName: 'Suggested RAN LPPD', width:150,cellFilter: 'date:\'MMM d, yyyy \''},
			       	      { field: 'actualRan', displayName: 'Actual RAN', width:100},
			       	      { field: 'actualLocation', displayName: 'Actual Location', width:100},
			       	      { field: 'actualRanLppd', displayName: 'Actual RAN LPPD',width:150,cellFilter: 'date:\'MMM d, yyyy \''},
			       	      { field: 'duration', displayName: 'Duration', width:100},
			       	      { field: 'reason', displayName: 'Reason', width:100},
			       	      { field: 'snp', displayName: 'SNP', width:100},
			       	      { field: 'quantity', displayName: 'Quantity', width:100},
			       	      { field: 'scanTime',type: 'date', displayName: 'Scan Time', width:200,cellFilter: 'date:\'MMM d, yyyy HH:mm:ss a\'' },
			       	      { field: 'partInOutTime',type: 'date', displayName: 'In Out Time', width:200,cellFilter: 'date:\'MMM d, yyyy HH:mm:ss a\'' },
			       	      { field: 'deviceId', displayName: 'Device', width:100},
                        ],
                        exporterPdfAlign:'left',
                        exporterCsvFilename: 'FIFOSuggestionDetailsReport.csv',
                        exporterMenuVisibleData: false,
                        exporterPdfDefaultStyle: {fontSize: 9},
                        exporterPdfTableStyle: {margin: [70, 5, 0, 5]},
                        exporterPdfTableHeaderStyle: {fontSize: 10, bold: true, italics: true, color: 'red'},
                        exporterPdfHeader: { text: "FIFO Suggestion Report", style: 'headerStyle' },
                        exporterPdfFooter: function ( currentPage, pageCount ) {
                          return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
                        },
                        exporterPdfCustomFormatter: function ( docDefinition ) {
                        	 docDefinition.styles.headerStyle = { fontSize: 20, bold: true, alignment: 'center', margin: [0, 0, 20, 0] }; 
                             docDefinition.styles.footerStyle = { fontSize: 10, bold: true, alignment: 'center',  margin: [5, 0, 20, 0] }; 
                          return docDefinition;
                        },
                        exporterPdfOrientation: 'landscape',
                        exporterPdfPageSize: 'LETTER',
                        exporterPdfMaxGridWidth: 500,
                        exporterPdfFilename: 'FIFOSuggestionDetailsReport.pdf',
                        exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
                       
                        onRegisterApi: function( gridApi ) {
                        	 $scope.gridApi = gridApi;
                        	 //Pagination
                        	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                        		 $scope.blockUI();
             		          paginationOptions.pageNumber = newPage;
             		          paginationOptions.pageSize = pageSize;
             		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
             		        paginationOptions.endIndex   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
             		        $scope.load();
             		        });
                        
                	    }
		    };
			 
			 $scope.gridOptions.exporterFieldCallback = function ( grid, row, col, value ){
				 
				 if ( col.name === 'partInOutTime' || col.name === 'scanTime'){					 	
					    value =  $filter('date')(value, 'dd/MM/yyyy HH:mm:ss');					   
					}				      
				  return value;
				 
			 };
 // Clear the filter
	 $scope.clearFilters = function() {
		 $scope.gridApi.core.clearAllFilters();
     };
// Reset the values
	    $scope.resetfifoSuggest = function(){
	    	$scope.shops = "";
	    	$scope.lines = "";
	    	$scope.beginDate=new Date();
		    $scope.endDate=new Date();    	  
	    	$scope.gridOptions.data = [];
	    	$scope.clearFilters();	  
	    	$scope.fifoSuggest = {};
	    	$scope.partNumber="";	    	
	    	$scope.fifoSuggest.startIndex = 0;
	    	$scope.fifoSuggest.endIndex = 0;
	    	$scope.tags=[];
	    	$scope.ranData=[];
	    	$scope.locationIdData=[];	
	    	$scope.gridOptions.totalItems=0;
	    	$scope.location="";
	    	$scope.partNumber="";
	    	$scope.gridOptions.enablePaginationControls=false;	    
	    	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
	    	
		    $scope.shiftDropdown=false;
		    $scope.fifoSuggest.deviceId="";
	    };	    
	    
     $scope.fifoSuggestGridData = function(){    	    	 
    	 FIFOSuggestionOverrideService.fifoSuggestionReport($scope.fifoSuggest).then(function(response){
	    		$scope.gridOptions.data = [];
	    		if(response.data.objectList !== undefined && response.data.objectList !== null){
	    			if(response.data.statusType === 'success' ){
	    				$scope.gridOptions.enablePaginationControls=true;
	    				 response.data.objectList.forEach(function(row){	    	    	         	          
	    	    	           $scope.gridOptions.data = response.data.objectList;	 
	    	    	          });
	    				 
	    				 	
	    			} else {
	    				$scope.gridOptions.enablePaginationControls=false;
	    				$scope.alerts = [];
			            $scope.alerts.push({
			                type : response.data.statusType,
			                msg : response.data.statusMessage,
			                error : response.data.exceptionStackTrace,
			                errorClsName : response.data.exceptionClassName,
			                errorMsg : response.data.exceptionMessage
			            });
	    			}
	    			$.unblockUI();
	    		} else {
	    			$scope.searchDataEror=response.data.statusMessage;	    			
		            $.unblockUI();
	    		}
	    	});
     };
     
	 		/* Load data in grid */
		    $scope.load = function () {
		    	$scope.fifoSuggest.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

		    	if(paginationOptions.endIndex === 0){
		    		$scope.fifoSuggest.endIndex = $scope.gridOptions.paginationPageSize;
		    	}
		    	$scope.fifoSuggest.startIndex = paginationOptions.startIndex;
		    	$scope.fifoSuggest.endIndex = paginationOptions.pageSize;
		    	$scope.fifoSuggest.partNumber = $scope.partNumber;
		    	$scope.fifoSuggest.location = $scope.location;		
		    	
		    	$scope.fifoSuggest.fromDate = $scope.fromDate;
		    	$scope.fifoSuggest.toDate = $scope.toDate;
		    	
		    	FIFOSuggestionOverrideService.fifoSuggestionCount($scope.fifoSuggest).then(function(response){
		    		$scope.gridOptions.totalItems = response.object;		    		
		    		$scope.recordCount = response.object;		    		
		    		$scope.fifoSuggestGridData();
		    	});
		    	
		    };
		    
		    // --------- search button ---------
            $scope.searchfifoSuggest = function() {
            	if( $scope.validateFilter() == true){
            		$scope.blockUI();
            		$scope.fromDate = $filter('date')($scope.beginDate, 'yyyy-MM-dd');
            		$scope.toDate = $filter('date')($scope.endDate, 'yyyy-MM-dd');
            		$scope.alerts = [];
            		$scope.gridOptions.data = [];
            		$scope.fifoSuggest.partNumber=$scope.partNumber;
            		$scope.fifoSuggest.location=$scope.location;
            		paginationOptions.startIndex= 0;
            		paginationOptions.endIndex= 0;
            		paginationOptions.pageNumber= 1;
            		paginationOptions.pageSize= 100; 
            		$scope.gridOptions.paginationCurrentPage=1;
            		$scope.gridOptions.paginationPageSize=100;
            		$scope.searchClicked=true;
            		$scope.clearFilters();                	
            		$scope.load();
            		$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
            	}else{
            		$scope.alerts = [];
	       			$scope.alerts.push({
	       				 type : 'danger',
	       				 msg : 'Plant/Shop or Part or RAN or Location is/are mandatory'
	       			});
            	}
            };
		    
            $scope.downloadfifoSuggest =function(){
            	$scope.blockUI();
            	$scope.fifoSuggest.fromDate=$filter('date')($scope.beginDate, 'yyyy-MM-dd');;
		    	$scope.fifoSuggest.toDate=$filter('date')($scope.endDate, 'yyyy-MM-dd');
		    	$scope.fifoSuggest.partNumber=$scope.partNumber;
            	$scope.fifoSuggest.location=$scope.location;
            	return FIFOSuggestionOverrideService.fifoSuggestionDownload($scope.fifoSuggest).then(function(response){
            		if(response.objectList != null){
            			for (var i = 0; i < response.objectList.length; i++) {
            				response.objectList[i].partNumber = '="'+response.objectList[i].partNumber+'"';
            				response.objectList[i].partInOutTime =$filter('date')(response.objectList[i].partInOutTime, 'dd/MM/yyyy HH:mm:ss');
            				response.objectList[i].scanTime =$filter('date')(response.objectList[i].scanTime, 'dd/MM/yyyy HH:mm:ss');
            				response.objectList[i].suggestedRanLppd = $filter('date')(response.objectList[i].suggestedRanLppd, 'dd/MM/yyyy ');
            				response.objectList[i].actualRanLppd = $filter('date')(response.objectList[i].actualRanLppd, 'dd/MM/yyyy ');
            			}
            			$.unblockUI();
            			return response.objectList;
            		}else{
            			$scope.alerts = [];
    	       			$scope.alerts.push({
    	       				 type : 'danger',
    	       				 msg : 'Data is not available'
    	       			});
            		}
            		$.unblockUI();
            	});
        
            };
         
            $scope.getDownloadfifoSuggestReportHeader = function () {
            	return ["Part Number", "Suggested RAN","Suggested Location","Suggested RAN Lppd","Actual RAN","Actual Location","Actual RAN Lppd","Duration","Reason","SNP","Quantity","Scan Time","In-Out Time","Device"];
           };
           $scope.csvColumnOrder=['partNumber','suggestedRan','suggestedLocation','suggestedRanLppd','actualRan','actualLocation','actualRanLppd','duration','reason','snp','quantity','scanTime','partInOutTime','deviceId'];

			//Close the alert msg
            $scope.closeAlert = function(index) {
		        $scope.alerts.splice(index, 1);
		    };
		    
		    $scope.selectEndDate = function(endDate) {		    	
		    	$scope.fromMaxDate=$filter('date')(endDate, 'yyyy-MM-dd');
		    	 $scope.fifoSuggest.shift='';
		    	if($filter('date')(endDate, 'yyyy-MM-dd')== $filter('date')($scope.beginDate, 'yyyy-MM-dd')){
		    		$scope.shiftDropdown=false;
		    	}else{
		    		$scope.shiftDropdown=true;
		    	}		    	
		    };
		    
		    $scope.selectStartDate = function(startDate) {		    	
		    	 $scope.fifoSuggest.shift='';
		    	if($filter('date')(startDate, 'yyyy-MM-dd')== $filter('date')($scope.endDate, 'yyyy-MM-dd')){
		    		$scope.shiftDropdown=false;
		    	}else{
		    		$scope.shiftDropdown=true;
		    	}		    	
		    };
		    
		    $scope.validateFilter = function(){
		    	 if($scope.fifoSuggest.plant !== "" && $scope.fifoSuggest.plant !== null && $scope.fifoSuggest.plant !== undefined && $scope.fifoSuggest.shop !== "" && $scope.fifoSuggest.shop !== null && $scope.fifoSuggest.shop !== undefined)
				 {
					 return true;
				 }
		    	 else if($scope.ranData.length>0 || $scope.tags.length>0 || $scope.locationIdData.length>0){
		    		 return true;
		    	 }
		    	 else{
					 return false;
				 }
		     };
		
} ]);
