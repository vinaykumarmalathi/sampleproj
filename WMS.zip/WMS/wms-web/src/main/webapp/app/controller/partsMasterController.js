wmsApp.controller('partsMasterController', 			
			[ '$scope','$window','$filter','$location', 'partsMasterService','locationService','uiGridTreeViewConstants', '$http','commonService','partNumberService',
		        function($scope,$window,$filter,$location, partsMasterService,locationService,uiGridTreeViewConstants, $http,commonService,partNumberService) {
					
					
		//INITIAL ON LOAD DATAS....
					
			$scope.searchDataEror="Click search to fetch records.";
					
			$scope.populateClicked=false;
			$scope.addNewButton=true;
			
			 $scope.part = {		
					  partNumber:$scope.partNumber,
					  supplierCode:$scope.searchSupplierCode,
	                  startIndex : 0,
	                  endIndex : 0
	          };
			  
			  $scope.map = {							    	 
					  partNumber : '',
					  partName : '',
					  partType:'',
					  snp:'',
					  category:'',
					  safetyStock:'',
					  supplierCode:'',
					  depoCode:'',
					  rePackingFlag:'',
					  comments : '',
					  locations : ''
	              };
			  
			  

				 var paginationOptions = {
					 	startIndex : 0,
					 	endIndex : 0,
					    pageNumber: 0,
					    pageSize: 100,
					    sort: null
					  };
			  
			
			
			// --------- Part Number List ---------			
			$scope.tags=[];	 
			/*ON ADD NEW PART TAG*/
			
			$scope.tagAdded = function(tag) {				
				  $scope.partArray = [];
				     for (var j=0; j < $scope.tags.length; j++) {
				    	 $scope.partArray.push($scope.tags[j].text);
				      }
				     $scope.partNumber=$scope.partArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			/*ON REMOVE ADDED PART TAG*/
			    
		    $scope.tagRemoved = function(tag) {			   
		    	 $scope.partArray = [];
			     for (var j=0; j < $scope.tags.length; j++) {

			    	 $scope.partArray.push($scope.tags[j].text);
			      }
			     $scope.partNumber=$scope.partArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
			
		    /*AUTOCOMPLE PART ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadParts = function(query) {		    	
		    	var partInputObj = {"partNumber": query};			    	
		    	return partNumberService.partNumberList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    });			    				         
		    };
		    
		    
		 // --------- SUPPLIER CODE LIST ---------			
		    $scope.supplierTags=[];	 
			/*ON ADD NEW Supplier TAG*/
			
			$scope.supplierTagsAdded = function(tag) {				
				  $scope.supplierArray = [];
				     for (var j=0; j < $scope.supplierTags.length; j++) {
				    	 $scope.supplierArray.push($scope.supplierTags[j].text);
				      }
				     $scope.searchSupplierCode=$scope.supplierArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			/*ON REMOVE ADDED Supplier TAG*/
			    
		    $scope.supplierTagsRemoved = function(tag) {			   
		    	 $scope.supplierArray = [];
			     for (var j=0; j < $scope.supplierTags.length; j++) {
			    	 $scope.supplierArray.push($scope.supplierTags[j].text);
			      }
			     $scope.searchSupplierCode=$scope.supplierArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
			
		   /* AUTOCOMPLE SUPPLIER ON ENTER MIN 3 CHAR DATA
		    
		    $scope.loadSupplier = function(query) {		    	
		    	var partInputObj = {"partNumber": query};			    	
		    	return partNumberService.partNumberList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    });			    				         
		    };*/
		    
			
			
			
		    // --------- LOCATION LIST ---------	
		    /*ON ADD NEW LOCATION TAG*/
		    
			$scope.location="";
			$scope.locationIdData=[];	 
		    $scope.locationAdded = function(tag) {					
		    $scope.locationArray = [];
			    for (var j=0; j < $scope.locationIdData.length; j++) {
			    	$scope.locationArray.push($scope.locationIdData[j].text);
			    }
			    $scope.location=$scope.locationArray.join(',');
			    $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    /*ON REMOVE ADDED LOCATION TAG*/
		    
		    $scope.locationRemoved = function(tag) {			   
		    	 $scope.locationArray = [];
			     for (var j=0; j < $scope.locationIdData.length; j++) {
			    	 $scope.locationArray.push($scope.locationIdData[j].text);
			     }
			     $scope.location=$scope.locationArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    		    
		    $scope.locationRemoving = function(tag) {		   
		    	//if(tag.count>0 || tag.count<0){
		    	if(tag.count!=0){
		    	return false;
		    	}		    	 
		    };
				    
		    /*AUTOCOMPLE LOCATION ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadLocation = function(query) {
		    	
		    	var locationInputObj = {"locationId": query};			    	
		    	return locationService.locationList(locationInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){			        					        			 		        			
		        			 var ary = [];							    										    		
		    				   angular.forEach(response.data.object, function(value, key){			    					  
		    					  var obj = {};	
		    					   obj['text'] = value.text;
		    					   obj['count'] = 0;
			    				   ary.push(obj);
		    					   });
		    				   return JSON.parse(JSON.stringify(ary));		        			 
		        		 }
		        	 }		    		
			    	});			    				         
		    };
			    			    
			/*RESET WHOLE SCREEN*/  
			  $scope.resetParts = function(){
				  $('div').removeClass('has-error');
			    	$scope.gridOptions.data = [];
			    	$scope.clearFilters();
			    	$scope.part.startIndex = 0;
			    	$scope.part.endIndex = 0;
			    	$scope.searchSupplierCode="";
			    	$scope.partNumber="";
			    	$scope.gridOptions.enablePaginationControls=false;			
			    	$scope.gridOptions.totalItems=0;
			    	$scope.part.partName = "";
			    	$scope.part.category = "";
			    	$scope.part.partType = "";			    	
			    	$scope.tags=[];
			    	$scope.supplierTags=[];		
			    	$scope.searchDataEror="Click search to fetch records.";
			    	$scope.map.locations = "";
			    	$scope.locationIdData=[];							    	
			    	$scope.location="";	
			    	$scope.map.snp="";
			    	$scope.map.partNumber="";
			    	$scope.map.partName="";
			    	$scope.map.partType="";
			    	$scope.map.category="";
			    	$scope.map.safetyStock="";
			    	$scope.map.supplierCode="";
			    	$scope.map.depoCode="";
			    	$scope.map.rePackingFlag="";
			    	$scope.map.comments="";		
			    	$scope.populateClicked=false;
    				$scope.addNewButton=true;
    				$scope.enableRemark=false;
			    	$scope.closeAlert();
			    	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			  
				 /*GRID DEFAULT  OPTIONS*/
			    
				 gridMenuShowHideColumns:false;
				 $scope.gridOptions = {						
						 enablePaginationControls:false,
						 enableGridMenu: false,
			             enableFiltering: true,            
			             enableColumnResize: true,
			             paginationPageSizes: [100,250,500,750,1000],
			     	     paginationPageSize: 100,         
			             useExternalPagination: true,
			             autoResize:true,
			             enableSorting: true,
			             enableColumnMenus :false,
			             enablePinning: true,            
			             columnDefs:[			                  
				                     {
				                    field: 'text',displayName: 'Part Number', headerCellClass: 'center' ,cellTemplate: '<button type="button" class="btn btn-default btn-md btn-block"  ng-click="grid.appScope.populatePartDetails(row.entity.text)">{{row.entity.text}}</button>'
				                    }				                    
				                ],
			                       
			                        onRegisterApi: function( gridApi ) {
			                        	 $scope.gridApi = gridApi;
			                        	 //Pagination
			                        	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			                        		 $scope.blockUI();
			             		          paginationOptions.pageNumber = newPage;
			             		          paginationOptions.pageSize = pageSize;
			             		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
			             		        paginationOptions.endIndex   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
			             		        $scope.load();
			             		        });
			                        
			                	    }
					    };
			  
			  
				 
				 /* Load data in grid */
				    $scope.load = function () {
				    	$scope.part.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

				    	if(paginationOptions.endIndex === 0){
				    		$scope.part.endIndex = $scope.gridOptions.paginationPageSize;
				    	}
				    	$scope.part.startIndex = paginationOptions.startIndex;
				    	$scope.part.endIndex = paginationOptions.pageSize;	
				    	$scope.part.partNumber=$scope.partNumber;
				    	$scope.part.supplierCode=$scope.searchSupplierCode;
				    	partsMasterService.partsCount($scope.part).then(function(response){
				    		$scope.gridOptions.totalItems = response.data.object;		    		
				    		$scope.recordCount = response.data.object;		    		
				    		$scope.partMasterData();
				    		
				    	});
				    	
				    };
				    
				    
				    $scope.partMasterData = function(){  
				    	$scope.part.partNumber=$scope.partNumber;
				    	$scope.part.supplierCode=$scope.searchSupplierCode;
				    	partsMasterService.parts($scope.part).then(function(response){				    		
					    		$scope.gridOptions.data = [];
					    		if(response.data!== undefined && response.data.objectList!== undefined && response.data.objectList!=null){					    		
					    			if(response.data.statusType === 'success' && response.data.objectList.length>0){
					    				$scope.gridOptions.enablePaginationControls=true;
					    				$scope.gridOptions.data = response.data.objectList;					    				
					    			} else {
					    				$scope.searchDataEror=response.data.statusMessage;
					    				$scope.gridOptions.enablePaginationControls=false;					    				
					    			}
					    			$.unblockUI();
					    		} else {
					    			$scope.searchDataEror=response.data.statusMessage;					    			
						            $.unblockUI();
					    		}
					    	});
				     };
				     
				     
				     
				     // --------- search button ---------
			            $scope.searchParts = function() {			            	
			            	$scope.alerts = [];
			            	$scope.gridOptions.data = [];			            	
			            	paginationOptions.startIndex= 0;
			            	paginationOptions.endIndex= 0;
			            	paginationOptions.pageNumber= 1;
			            	paginationOptions.pageSize= 100; 
			            	$scope.gridOptions.paginationCurrentPage=1;
			            	$scope.gridOptions.paginationPageSize=100;			            				            	
			            	$scope.clearFilters();                	
			            	$scope.load();			 
			            	 $scope.clearPartsMap();
			            	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
			            };	
			            
			            $scope.clearFilters = function() {
			       		 $scope.gridApi.core.clearAllFilters();
			            };
			            
			            /*POPULATE PARTS DETAILS ONCLICK PART NUMABER*/
			             $scope.populatePartDetails = function(partNo)
			             {			            	 
			            	 $scope.partNo = {							    	 
			            			 partNumber : partNo			   	                  
			   	              };			   				
			            	 partsMasterService.populatPartsInfo($scope.partNo).then(function(response){						    								    		
							    		if(response.data.object!== undefined && response.data.object!=null){							    		
							    			if(response.data.statusType === 'success' ){							    				
							    				if(response.data.object.logs!=null && response.data.object.logs!='null' && response.data.object.logs!=''){
							    					response.data.object.logs=response.data.object.logs.toString();
							    					logArray=response.data.object.logs.split('^^');
							    					var remarkArray = [];							    										    		
								    				   angular.forEach(logArray, function(value, key){								    					 
								    					   var splitData=value.split('##');								    				
								    					   var obj = {};	
								    					   splitData[1]=splitData[1].replace("/","-");
								    					   splitData[1]=splitData[1].replace("/","-");
								    					   dateTime=splitData[1].split(' ');
								    					   obj['user'] = splitData[0];
								    					   obj['commentedOn'] = $filter('date')(dateTime[0], 'MMM d, yyyy')+' '+dateTime[1];
								    					   obj['comments'] = splitData[2];
								    					   remarkArray.push(obj);
								    					   });
								    				   $scope.logs=remarkArray.reverse();									    				   
							    					$scope.enableRemark=true;
							    				}else{
							    					$scope.enableRemark=false;
							    				}
							    				
							    				$scope.populateClicked=true;
							    				$scope.addNewButton=false;							    				
							    				var ary = [];							    										    		
							    				   angular.forEach(response.data.object.locationCount, function(value, key){							    					  
							    					   var obj = {};	
							    					   obj['text'] = key;
							    					   obj['count'] = value;
								    				   ary.push(obj);
							    					   });
							    				 var locationListDetails= JSON.parse(JSON.stringify(ary));							    				
							    				$scope.locationIdData=[];
							    				$scope.locationIdData = locationListDetails;							    				
							    				 $scope.locationArray = [];
							    			     for (var j=0; j < $scope.locationIdData.length; j++) {
							    			    	 $scope.locationArray.push($scope.locationIdData[j].text);
							    			     }
							    			     $scope.location=$scope.locationArray.join(',');							    			    
							    				$scope.map.partNumber=response.data.object.partNumber;
							    				$scope.map.partName=response.data.object.partName;							    			
							    				$scope.map.partType=response.data.object.partType;	
							    				$scope.map.snp=response.data.object.snp;
							    				$scope.map.category=response.data.object.category;	
							    				$scope.map.safetyStock=response.data.object.safetyStock;	
							    				$scope.map.supplierCode=response.data.object.supplierCode;	
							    				$scope.map.depoCode=response.data.object.depoCode;	
							    				$scope.map.rePackingFlag=response.data.object.rePackingFlag;
							    				$scope.map.comments=response.data.object.comments;
							    				$scope.map.userId=$window.sessionStorage.getItem('userId');
							    				
							    			} else {							    				
							    				$scope.alerts = [];
							    				 $scope.alerts.push({
										                type : 'danger',
										                msg : response.data.statusMessage								              
										            });
							    			}
							    			$.unblockUI();
							    		} else {							    	
							    			$scope.alerts = [];
								            $scope.alerts.push({
								                type : 'danger',
								                msg : response.data.statusMessage
								            });
								            $.unblockUI();
							    		}
							    	});
			             };
			             
			             /*UPDATE PART DETAILS*/
			             
			             $scope.savePartsMap = function() {
			            	 $('div').removeClass('has-error');
			            	 $scope.submitError='';			            	
			              if(!$scope.map.partNumber){	    	  
			   		    	  $scope.submitError='Please enter part number.';
                              $("#sub_partNo_div").addClass('has-error');
                              $("#sub_partNo").focus();
			   		      }
			           /*   else if($scope.map.partNumber.length<10){
			   		    	  $scope.submitError='Please enter part number minimum of 10 characters.';
			   		    	$("#sub_partNo_div").addClass('has-error');
                            $("#sub_partNo").focus();
			   		      }*/
			              else if(!$scope.map.partName){
			   		    	 $scope.submitError='Please enter part name.';
			   		    	$("#sub_partName_div").addClass('has-error');
                            $("#sub_partName").focus();
			   		      }else if(!$scope.map.comments){
			   		    	$("#sub_remark_div").addClass('has-error');
                            $("#sub_remark").focus();
			   		    	$scope.submitError='Please enter update remarks .';
			   		      }else{				            	 
			            	 $scope.blockUI();
				            	$scope.alerts = [];				            	
				            	$scope.saveClicked=true;
				            	$scope.clearFilters();				            	
				            	$scope.map.locations=$scope.location;
				            	$scope.map.userId=$window.sessionStorage.getItem('userId');				            	
				            	partsMasterService.savePartsMapDetails($scope.map).then(function(response){					            					            							    		
						    			if(response.data.statusType === 'success' ){
						    				$scope.alerts = [];
								            $scope.alerts.push({
								                type : response.data.statusType,
								                msg : response.data.statusMessage
								            });								            
								            $scope.populatePartDetails($scope.map.partNumber);	
								            $.unblockUI();
						    			} else {						    				
						    				$scope.alerts = [];
						    				 $scope.alerts.push({
									                type : 'danger',
									                msg : response.data.statusMessage								              
									            });
								            $.unblockUI();
						    			}						    			
						    	});					            	
				            	$.unblockUI();
			   		        }
			            	 if($scope.submitError!=''){
			            	 $scope.alerts = [];
			            		
					            $scope.alerts.push({
					                type : 'danger',
					                msg : $scope.submitError
					            });
			            	 }
			            	 $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"});
				            };		
				            
				            /*CLEAR PART DETAILS ALONE*/
				            $scope.addNewPartsMap = function(){		
				            	$('div').removeClass('has-error');
						    	$scope.clearFilters();						    	
						    	$scope.map.locations = "";
						    	$scope.locationIdData=[];							    	
						    	$scope.location="";	
						    	$scope.map.snp="";
						    	$scope.map.partNumber="";
						    	$scope.map.partName="";
						    	$scope.map.partType="";
						    	$scope.map.category="";
						    	$scope.map.safetyStock="";
						    	$scope.map.supplierCode="";
						    	$scope.map.depoCode="";
						    	$scope.map.rePackingFlag="";
						    	$scope.map.comments="";		
						    	$scope.populateClicked=false;
			    				$scope.addNewButton=true;
			    				$scope.enableRemark=false;
						    	$scope.closeAlert();
						    	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
						    };						    
						    $scope.closeAlert = function(index) {
						        $scope.alerts.splice(index, 1);
						    };		
						    
					       /*ADD NEW PART DETAILS*/						    
						    $scope.saveNewPartsMap = function() {
						    	$('div').removeClass('has-error');
						    	 $scope.submitError='';			            	
				              if(!$scope.map.partNumber){	    	  
				   		    	  $scope.submitError='Please enter part number.';
	                              $("#sub_partNo_div").addClass('has-error');
	                              $("#sub_partNo").focus();
				   		      }
				            /*  else if($scope.map.partNumber.length<10){
				   		    	  $scope.submitError='Please enter part number minimum of 10 characters.';
				   		    	$("#sub_partNo_div").addClass('has-error');
	                            $("#sub_partNo").focus();
				   		      }*/
				              else if(!$scope.map.partName){
				   		    	 $scope.submitError='Please enter part name.';
				   		    	$("#sub_partName_div").addClass('has-error');
	                            $("#sub_partName").focus();
				   		      }else if(!$scope.map.comments){
				   		    	$("#sub_remark_div").addClass('has-error');
	                            $("#sub_remark").focus();
				   		    	  $scope.submitError='Please enter update remarks .';
				   		       }else{	
						    	$scope.blockUI();
				            	$scope.alerts = [];				            	
				            	$scope.saveClicked=true;
				            	$scope.clearFilters();				            	
				            	$scope.map.locations=$scope.location;
				            	$scope.map.userId=$window.sessionStorage.getItem('userId');
				            	partsMasterService.addPartsMapDetails($scope.map).then(function(response){				            					            								    		
						    			if(response.data.statusType === 'success' ){
						    				$scope.alerts = [];
								            $scope.alerts.push({
								                type : response.data.statusType,
								                msg : response.data.statusMessage
								            });
								            $scope.populatePartDetails($scope.map.partNumber);	
								            $.unblockUI();
						    			} else {						    				
						    				$scope.alerts = [];
						    				 $scope.alerts.push({
									                type : 'danger',
									                msg : response.data.statusMessage								              
									            });	
								            $.unblockUI();
						    			}						    								    	
						    	});	
				            	$.unblockUI();	
				            	 
				   		   } if($scope.submitError!=''){						    	
				    			$scope.alerts = [];
					            $scope.alerts.push({
					                type : 'danger',
					                msg : $scope.submitError
					            });
					            $.unblockUI();
				    		}
				   		$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"});
				            };
				            
				            /*DELETE PART DETAILS*/
				            
				            $scope.yesDelete = function(partNumber) {
				            	$scope.blockUI();
				            	 $scope.deletePart = {							    	 
				            			 partNumber : partNumber,				   					
				   	              };
				            	partsMasterService.deleteMaster($scope.deletePart).then(function(response){				            	
				            						    			
						    			if(response.data.statusType === 'success' ){
						    				$scope.alerts = [];
								            $scope.alerts.push({
								                type : response.data.statusType,
								                msg : response.data.statusMessage
								            });			
								            $scope.searchParts();				            	 
								            $scope.clearPartsMap();
						    				$("#deletePartMapModal").modal('hide');		
								          
								            $.unblockUI();		
						    			} else {						    				
						    				$scope.alerts = [];
								            $scope.alerts.push({
								                type : 'danger',
								                msg : response.data.statusMessage								              
								            });
								            $("#deletePartMapModal").modal('hide');	
								            $.unblockUI();		
						    			}
						    			$.unblockUI();						    		
						    	});					            
				            	   		            	  
						    };			
						    
						    $scope.clearPartsMap = function() {
						    	 $scope.map.locations = "";
							    	$scope.locationIdData=[];							    	
							    	$scope.location="";	
							    	$scope.map.snp="";
							    	$scope.map.partNumber="";
							    	$scope.map.partName="";
							    	$scope.map.partType="";
							    	$scope.map.category="";
							    	$scope.map.safetyStock="";
							    	$scope.map.supplierCode="";
							    	$scope.map.depoCode="";
							    	$scope.map.rePackingFlag="";
							    	$scope.map.comments="";		
							    	$scope.populateClicked=false;
				    				$scope.addNewButton=true;
				    				$scope.enableRemark=false;
				    				$('div').removeClass('has-error');
							    	 $scope.submitError='';	
						    };
						    
} ]);