wmsApp.controller('locationMasterController', 
		[ '$scope','$window','$filter', '$location', '$routeParams', 'locationMasterService','locationService','uiGridTreeViewConstants', '$http','commonService','partNumberService',
        function($scope,$window,$filter, $location, $routeParams, locationMasterService,locationService,uiGridTreeViewConstants, $http,commonService,partNumberService) {		
			$scope.searchDataEror="Click search to fetch records.";
			$scope.populateClicked=false;
			$scope.addNewButton=true;
			$scope.locationIdEnable=false;
			// --------- Part Number List ---------
			
			$scope.partNumber='';		
			$scope.locationMapList= ["Mapped","Not Mapped"];
		    /*ON ADD NEW LOCATION TAG*/
		    
			$scope.location="";
			$scope.locationIdData=[];	 
		    $scope.locationAdded = function(tag) {
		    $scope.locationArray = [];
		    document.getElementById('sub_remarks').value = '';
			    for (var j=0; j < $scope.locationIdData.length; j++) {
			    	$scope.locationArray.push($scope.locationIdData[j].text);
			    }
			    $scope.location=$scope.locationArray.join(',');
			    $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    /*ON REMOVE ADDED LOCATION TAG*/
		    
		    $scope.locationRemoved = function(tag) {			   
		    	 $scope.locationArray = [];
			     for (var j=0; j < $scope.locationIdData.length; j++) {
			    	 $scope.locationArray.push($scope.locationIdData[j].text);
			     }
			     $scope.location=$scope.locationArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
				    
		    /*AUTOCOMPLE LOCATION ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadLocation = function(query) {
		    	
		    	var locationInputObj = {"locationId": query};			    	
		    	return locationService.locationList(locationInputObj).then(function(response){	
		    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }			    		
			    	});			    				         
		    };
			
		    $scope.map = {							    	 
					  plant : '',
					  shop : '',
					  line:'',
					  section:'',
					  level:'',
					  series:'',
					  zone:'',
					  locationId:'',
					  locationSeries1:'',
					  locationSeries2:'',
					  locationType:'',
					  cellId:'',
					  comments:'', /*added by Meena*/					  
					  remarks:'',
					  userId:''
					  
	        };
			    
			    
			    
		    $scope.part = {
				  plant : '',
				  shop : '',
                  line : '',
                  section : '',                 
                  locationId : $scope.location,
                  startIndex : 0,
                  endIndex : 0
              };
		    
		    $scope.deletePart = {							    	 
       			 locationId : '',	
       			 remarks : '',
       			 userId : ''			            			 
	        };
			
			// --------- Shops drop down list ---------
		    
		    $scope.loadShopLine = function(){
		    	 $scope.part.line = '';
		    	 $scope.part.shop = '';
		    	 commonService.getLineList($scope.part.plant)
				  .success(function(response){
					  console.log(response.objectList);
					  $scope.lines = response.objectList;				
				  })
				  .error(function(response){
				  });
		    	 commonService.getShopList($scope.part.plant)
				  .success(function(response){
					  console.log(response.objectList);
					  $scope.shops = response.objectList;				
				  })
				  .error(function(response){
				  });

		    }
			   
			  /*if($window.sessionStorage.getItem('shopDPCollection') == null || $window.sessionStorage.getItem('shopDPCollection')=='undefined' || $window.sessionStorage.getItem('shopDPCollection')==undefined){
				  commonService.getAllShop()
				  .success(function(response){						  
					  $scope.shops = response.objectList;				
					  $window.sessionStorage.setItem('shopDPCollection',JSON.stringify($scope.shops));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.shops = JSON.parse(sessionStorage.shopDPCollection);
			  }*/
			  
			// --------- Location drop down list -------

			  if($window.sessionStorage.getItem('locationDPCollection') == null || $window.sessionStorage.getItem('locationDPCollection')=='undefined' || $window.sessionStorage.getItem('locationDPCollection')==undefined){
				  commonService.getAllPlants()
				  .success(function(response){	
					  $scope.locations = response.objectList;				
					  $window.sessionStorage.setItem('locationDPCollection',JSON.stringify($scope.locations));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.locations = JSON.parse(sessionStorage.locationDPCollection);
			  }
			  
			  // --------- Section drop down list ---------

			  if($window.sessionStorage.getItem('sectionDPCollection') == null || $window.sessionStorage.getItem('sectionDPCollection')=='undefined' || $window.sessionStorage.getItem('sectionDPCollection')==undefined){
				  commonService.getAllSections()
				  .success(function(response){					 
					  $scope.sections = response.objectList;	
					  $window.sessionStorage.setItem('sectionDPCollection',JSON.stringify($scope.sections));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.sections = JSON.parse(sessionStorage.sectionDPCollection);
			  }
			  
			 // --------- Line drop down list ---------

			  /*if($window.sessionStorage.getItem('linesDPCollection') == null || $window.sessionStorage.getItem('linesDPCollection')=='undefined' || $window.sessionStorage.getItem('linesDPCollection')==undefined){
				  commonService.getAllLines()
				  .success(function(response){					 
					  $scope.lines = response.objectList;
					  $window.sessionStorage.setItem('linesDPCollection',JSON.stringify($scope.lines));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.lines = JSON.parse(sessionStorage.linesDPCollection);
			  }
			  */
			
			 var paginationOptions = {
				 	startIndex : 0,
				 	endIndex : 0,
				    pageNumber: 1,
				    pageSize: 100,
				    sort: null
				  };
			 
			 
			 /*GRID DEFAULT  OPTIONS*/
			    
			 gridMenuShowHideColumns:false;
			 $scope.gridOptions = {						
					 enablePaginationControls:false,
					 enableGridMenu: false,
		             enableFiltering: true,            
		             enableColumnResize: true,
		             paginationPageSizes: [100,250,500,750,1000],
		     	     paginationPageSize: 100,         
		             useExternalPagination: true,
		             autoResize:true,
		             enableSorting: true,
		             enableColumnMenus :false,
		             enablePinning: true,            
		             columnDefs:[			                  
			                     {
			                    field: 'text',displayName: 'Location', headerCellClass: 'center' ,cellTemplate: '<button type="button" class="btn btn-default btn-md btn-block"  ng-click="grid.appScope.populateLocationDetails(row.entity.text)">{{row.entity.text}}</button>'
			                    }				                    
			                ],
		                       
		                        onRegisterApi: function( gridApi ) {
		                        	 $scope.gridApi = gridApi;
		                        	 //Pagination
		                        	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
		                        		 $scope.blockUI();
		             		          paginationOptions.pageNumber = newPage;
		             		          paginationOptions.pageSize = pageSize;
		             		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
		             		        paginationOptions.endIndex   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
		             		        $scope.load();
		             		        });
		                        
		                	    }
				    };
			 
			 /* Load data in grid */
			    $scope.load = function () {
			    	$scope.part.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

			    	if(paginationOptions.endIndex === 0){
			    		$scope.part.endIndex = $scope.gridOptions.paginationPageSize;
			    	}
			    	$scope.part.startIndex = paginationOptions.startIndex;
			    	$scope.part.endIndex = paginationOptions.pageSize;				    	
			    	$scope.part.locationId=$scope.location;		
			    	locationMasterService.locationCount($scope.part).then(function(response){
			    		$scope.gridOptions.totalItems = response.data.object;		    		
			    		$scope.recordCount = response.data.object;		    		
			    		$scope.locationMasterData();
			    		
			    	});
			    	
			    };
			    
			    $scope.locationMasterData = function(){  			    	
			    	$scope.part.locationId=$scope.location;	
			    	locationMasterService.location($scope.part).then(function(response){	
			    		console.log("Location searchLine 202",$scope.part);
				    		$scope.gridOptions.data = [];
				    		if(response.data!== undefined && response.data.objectList!== undefined && response.data.objectList!=null){					    		
				    			if(response.data.statusType === 'success' && response.data.objectList.length>0){
				    				$scope.gridOptions.enablePaginationControls=true;
				    				$scope.gridOptions.data = response.data.objectList;					    				
				    			} else {
				    				$scope.searchDataEror=response.data.statusMessage;
				    				$scope.gridOptions.enablePaginationControls=false;					    				
				    			}
				    			$.unblockUI();
				    		} else {
				    			$scope.searchDataEror=response.data.statusMessage;					    			
					            $.unblockUI();
				    		}
				    	});
			     };
			     
			     // --------- search button ---------
		            $scope.searchParts = function() {			            	
		            	$scope.alerts = [];
		            	$scope.gridOptions.data = [];			            	
		            	paginationOptions.startIndex= 0;
		            	paginationOptions.endIndex= 0;
		            	paginationOptions.pageNumber= 1;
		            	paginationOptions.pageSize= 100;
		            	$scope.part.isFullDownload = 0;
		            	$scope.gridOptions.paginationCurrentPage=1;
		            	$scope.gridOptions.paginationPageSize=100;			            				            	
		            	$scope.clearFilters(); 
		            	$scope.addNewParts();
		            	$scope.load();			            
		            	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
		            };	
		            
		            $scope.clearFilters = function() {
		       		 $scope.gridApi.core.clearAllFilters();
		            };
		            
		            
		            /*POPULATE LOCATION DETAILS ONCLICK LOCATION ID*/
		             $scope.populateLocationDetails = function(location)
		             {		
		            	 $scope.populateLoc = {							    	 
		            			 locationId : location			   	                  
		   	              };			   				
		            	 locationMasterService.populateLocationInfo($scope.populateLoc).then(function(response){
		            		        $('div').removeClass('has-error');
						    		if(response.data.object!== undefined && response.data.object!=null){							    		
						    			if(response.data.statusType === 'success' ){	
						    				
						    				
						    				if(response.data.object.comments!=null && response.data.object.comments!='null' && response.data.object.comments!=''){
						    					response.data.object.comments=response.data.object.comments.toString();
						    					logArray=response.data.object.comments.split('^^');
						    					var remarkArray = [];							    										    		
							    				   angular.forEach(logArray, function(value, key){								    					 
							    					   var splitData=value.split('##');								    				
							    					   var obj = {};	
							    					   splitData[1]=splitData[1].replace("/","-");
							    					   splitData[1]=splitData[1].replace("/","-");
							    					   dateTime=splitData[1].split(' ');
							    					   obj['user'] = splitData[0];
							    					   obj['commentedOn'] = $filter('date')(dateTime[0], 'MMM d, yyyy')+' '+dateTime[1];
							    					   obj['comments'] = splitData[2];
							    					   remarkArray.push(obj);
							    					   });
							    				   $scope.logs=remarkArray.reverse();									    				   						    					
							    				   $scope.enableRemark=true;
						    				}else{
						    					$scope.enableRemark=false;
						    				}				    				
						    				$scope.map.plant = response.data.object.plant;
						    				$scope.map.shop = response.data.object.shop;
						    				$scope.map.line = response.data.object.line;
						    				$scope.map.section = response.data.object.section;
						    				$scope.map.level = response.data.object.level;
						    				$scope.map.series = response.data.object.series;
						    				$scope.map.zone = response.data.object.zone;
						    				$scope.map.locationId = response.data.object.locationId;
						    				$scope.map.locationSeries1 = response.data.object.locationSeries1;
						    				$scope.map.locationSeries2 = response.data.object.locationSeries2; 
						    				$scope.map.locationType = response.data.object.locationType;
						    				$scope.map.cellId = response.data.object.cellId;
						    				$scope.populateClicked=true;
						    				$scope.addNewButton=false;	
						    				$scope.locationIdEnable=true;
						    				var ary = [];							    										    		
						    				   angular.forEach(response.data.object.partCount, function(value, key){							    					  
						    					   var obj = {};	
						    					   obj['text'] = key;
						    					   obj['count'] = value;
							    				   ary.push(obj);
						    					   });
						    				 var partNumberListDetails= JSON.parse(JSON.stringify(ary));							    				
						    				$scope.partNumberData=[];
						    				$scope.partNumberData = partNumberListDetails;							    				
						    				 $scope.partNumberArray = [];
						    			     for (var j=0; j < $scope.partNumberData.length; j++) {
						    			    	 $scope.partNumberArray.push($scope.partNumberData[j].text);
						    			     }								    			   
						    			     $scope.partNumber=$scope.partNumberArray.join(',');												    				
						    			} else {							    				
						    				$scope.alerts = [];
								            $scope.alerts.push({
								                type : response.data.statusType,
								                msg : response.data.statusMessage,
								                error : response.data.exceptionStackTrace,
								                errorClsName : response.data.exceptionClassName,
								                errorMsg : response.data.exceptionMessage
								            });
						    			}
						    			$.unblockUI();
						    		} else {							    	
						    			$scope.alerts = [];
							            $scope.alerts.push({
							                type : 'danger',
							                msg : response.data.statusMessage
							            });
							            $.unblockUI();
						    		}
						    	});
		             }
		             
		             
		             
		           /*  UPDATE LOCATION DETAILS
		             
			            /*CLEAR LOCATION DETAILS ALONE*/			           					   
					    $scope.closeAlert = function(index) {
					        $scope.alerts.splice(index, 1);
					    };		
					    
				       /*ADD NEW LOCATION DETAILS*/						    
					    $scope.saveNewLocationMap = function() {
					    	 $('div').removeClass('has-error');
			            	 $scope.submitError='';			            	
			              if(!$scope.map.locationId){	    	  
			   		    	  $scope.submitError='Please enter location Id.';
	                          $("#sub_locationId_div").addClass('has-error');
	                          $("#sub_locationId").focus();
			   		      }
			             else if($scope.map.locationId.length!=10 &&  $scope.map.locationId.length!=8){
			   		    	  $scope.submitError='Please enter location Id of 8 or 10 characters.';
			   		    	$("#sub_locationId_div").addClass('has-error');
	                        $("#sub_locationId").focus();
			   		      }	
			             else if(!$scope.map.comments){
				   		    	$("#sub_remark_div").addClass('has-error');
	                            $("#sub_remark").focus();
				   		    	  $scope.submitError='Please enter update remarks .';
				   		       }
			              else{		
					    	$scope.blockUI();
			            	$scope.alerts = [];				            	
			            	$scope.saveClicked=true;
			            	$scope.clearFilters();				            				            
			            	$scope.map.userId=$window.sessionStorage.getItem('userId');		
			            	locationMasterService.addLocationsMapDetails($scope.map).then(function(response){				            					            								    		
					    			if(response.data.statusType === 'success' ){
					    				$scope.alerts = [];
							            $scope.alerts.push({
							                type : response.data.statusType,
							                msg : response.data.statusMessage
							            });
							            $scope.populatePartDetails($scope.map.partNumber);	
							            $.unblockUI();
					    			} else {						    				
					    				$scope.alerts = [];
					    				  $scope.alerts.push({
								                type : 'danger',
								                msg : response.data.statusMessage
								            });
							            $.unblockUI();
					    			}						    								    	
					    	});	
			            	$.unblockUI();
			   		        }
			            	 if($scope.submitError!=''){
			            	 $scope.alerts = [];
			            		
					            $scope.alerts.push({
					                type : 'danger',
					                msg : $scope.submitError
					            });
			            	 }
			            	 $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"});
			            };
			            
			            /*DELETE LOCATION DETAILS*/
			            
			           /* $scope.yesDelete = function(location) {
			            	$scope.blockUI();
			            	 $scope.deletePart = {							    	 
			            			 locationId : location,	
			            			 
			   	              };
			            	 locationMasterService.deleteMaster($scope.deletePart).then(function(response){				            	
			            						    			
					    			if(response.data.statusType === 'success' ){					    						
							            $("#deleteLocationMapModal").modal('hide');	
							            $scope.addNewParts();
							            $scope.searchParts();
							            $scope.alerts = [];
							            $scope.alerts.push({
							                type : response.data.statusType,
							                msg : response.data.statusMessage
							            });	
							            $.unblockUI();		
					    			} else {						    				
					    				$scope.alerts = [];
					            		
							            $scope.alerts.push({
							                type : 'danger',
							                msg : response.data.statusMessage
							            });
							            $("#deleteLocationMapModal").modal('hide');	
							            $.unblockUI();		
					    			}
					    			$.unblockUI();						    		
					    	});					            			            	   		            	  
					    };	  */
					  
			           /*WHEN CLICK NO BUTTON - TO CLEAR THE GIVEN DATA*/
			           $scope.noDelete = function(){
			        	   $scope.clearValues();
			        	   $scope.map.remarks="";	
			           };
					    
			           /*DELETE LOCATION DETAILS*/
					    $scope.yesDelete = function(map) {
					    	$scope.clearValues(); 		            			 
					    	if(!$scope.map.remarks){
				   		    	$("#sub_remarks_div").addClass('has-error');
	                            $("#sub_remarks").focus();
	                            document.getElementById('remarksError').innerHTML = 'Please enter remarks';
					    	}else {
					    		 document.getElementById('remarksError').innerHTML='';
					    	    var userId = $window.sessionStorage.getItem('loggedUserId');
					    	    $scope.map.userId = userId;
					      	    $scope.blockUI();
					      	     $scope.deletePart.locationId =$scope.map.locationId;
		            			 $scope.deletePart.remarks = $scope.map.remarks;
		            			 $scope.deletePart.userId = $scope.map.userId;	
			            	    locationMasterService.deleteMaster($scope.deletePart).then(function(response){
					    			if(response.data.statusType === 'success' ){
							            $("#deleteLocationMapModal").modal('hide');
							            $scope.clearValues(); 	//added by meena
							            document.getElementById('sub_remarks').value = '';
							           	$scope.map.remarks="";	
							            $scope.addNewParts();
							            $scope.searchParts();
							            $scope.alerts = [];
							            $scope.alerts.push({
							                type : response.data.statusType,
							                msg : response.data.statusMessage
							            });	
							            $.unblockUI();		
					    			} else {						    				
					    				$scope.alerts = [];					            		
							            $scope.alerts.push({
							                type : 'danger',
							                msg : response.data.statusMessage
							            });
							            $("#deleteLocationMapModal").modal('hide');	
							            $scope.map.remarks="";	
							            //$scope.clearValues(); 
							            document.getElementById('sub_remarks').value = '';
							            $.unblockUI();		
					    			}
					    			$.unblockUI();						    		
					    	});		
					    }					    	
					    };		
					    
					    /*CLEAR VALUES FOR DELETE FUNCTIONALITY*/
					    $scope.clearValues = function(){
					    	$scope.alerts = [];	
					    	document.getElementById('remarksError').innerHTML='';
					    	$('div').removeClass('has-error');
					    	$scope.deletePart.locationId="";
					    	$scope.deletePart.remarks="";	
					    	$scope.deletePart.userId="";					    	
					    	document.getElementById('sub_remarks').value = '';
					    };
					    
					    /*RESET WHOLE SCREEN*/  
						  $scope.resetParts = function(){
							  $('div').removeClass('has-error');
							  $scope.locationIdData=[];	
							    $scope.shops = "";
						    	$scope.lines = "";
						    	$scope.location="";
						    	$scope.gridOptions.data = [];
						    	$scope.clearFilters();
						    	$scope.part.startIndex = 0;
						    	$scope.part.endIndex = 0;
						    	$scope.part.plant = '';
								$scope.part.section = '';
								$scope.part.shop ='';
								$scope.part.line = '';
								$scope.part.partNo  = '';
								$scope.part.locationId  = '';	
						    	$scope.closeAlert();
						    	$scope.gridOptions.enablePaginationControls=false;			
						    	$scope.gridOptions.totalItems=0;						    				    						    				    	
						    	$scope.searchDataEror="Click search to fetch records.";						    							    						    	
						    		    		
			    				$scope.addNewParts();
						    	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
						    };
						    /*ADD NEW SCREEN*/  
							  $scope.addNewParts = function(){								  			    						    	  	
					    			  $scope.map.plant = '';
					    			  $scope.map.shop = '';
					    			  $scope.map.line= '';
					    			  $scope.map.section= '';
					    			  $scope.map.level= '';
					    			  $scope.map.series= '';
					    			  $scope.map.zone= '';
					    			  $scope.map.locationId= '';
					    			  $scope.map.locationSeries1= '';
					    			  $scope.map.locationSeries2= '';
					    			  $scope.map.locationType= '';
					    			  $scope.map.cellId= '';
					    			  $scope.map.comments="";
					    			  $scope.locationIdEnable=false;
					    			  $scope.populateClicked=false;
					    				$scope.addNewButton=true;
					    				
					    				$('div').removeClass('has-error');
								    	 $scope.submitError='';							    			 
							  };
							  
						
							/* Download */
							  $scope.downloadLocation = function() {
								  $scope.part.locationId=$scope.location;
								  $scope.part.isFullDownload = 1;
					            	return  locationMasterService.locationDownload($scope.part).then(function(response){
										return response.objectList;
					            	});
					            };
					         
					            $scope.getDownloadLocationListHeader = function () {
					            	return [ "LOCATION"];
					           };
					           
					           $scope.csvColumnOrder=['text'];
} ]);
		 