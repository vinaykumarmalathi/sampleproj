wmsApp.controller('partLocationTrackerController', 
		[ '$scope','$window', '$location', '$routeParams', 'partLocationService','locationService','uiGridTreeViewConstants', '$http','commonService','localStorageService','partNumberService','Location','ranService',
        function($scope,$window, $location, $routeParams, partLocationService,locationService,uiGridTreeViewConstants, $http,commonService,localStorageService,partNumberService,Location,ranService) {		
			$scope.searchDataEror="Click search to fetch records.";
			// --------- Part Number List ---------
			$scope.hideRAN = true;
			$scope.isLocNeed = true;
			$scope.partNumber='';
			$scope.searchClicked=false;
			$scope.tags=[];	 
			$scope.downloadAvail = true;
			
			
			
			
			$scope.findDuplicate= function(arra1) {
				  var i,len=arra1.length,result = [],obj = {};
				  for (i=0; i<len; i++) {
				    obj[arra1[i]]=0;
				  }
				  for (i in obj) {
				    result.push(i);
				  }
				  return result;
		    };
			
			$scope.tagAdded = function(tag) {			
				console.log("tagAdded:",tag);
				  $scope.partArray = [];
				     for (var j=0; j < $scope.tags.length; j++) {
				    	 $scope.partArray.push($scope.tags[j].text);
				      }
				     $scope.partNumber=$scope.partArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			/*ON REMOVE ADDED PART TAG*/
			    
		    $scope.tagRemoved = function(tag) {			   
		    	 $scope.partArray = [];
			     for (var j=0; j < $scope.tags.length; j++) {

			    	 $scope.partArray.push($scope.tags[j].text);
			      }
			     $scope.partNumber=$scope.partArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
			
		    /*AUTOCOMPLE PART ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadParts = function(query) {		    	
		    	var partInputObj = {"partNumber": query};			    	
		    	return partNumberService.partNumberList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    });			    				         
		    };
			    
		    
		    
		    /* RAN Auto Completion - Start */
		    $scope.ranData=[];	
		    
		    $scope.ranAdded = function(tag) {			
				
				  $scope.ranArray = [];
				     for (var j=0; j < $scope.ranData.length; j++) {
				    	 $scope.ranArray.push($scope.ranData[j].text);
				      }
				     $scope.part.ran=$scope.ranArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			};
		    
		    $scope.ranRemoved = function(tag) {			   
		    	 $scope.ranArray = [];
			     for (var j=0; j < $scope.ranData.length; j++) {

			    	 $scope.ranArray.push($scope.ranData[j].text);
			      }
			     $scope.part.ran=$scope.ranArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    $scope.loadRan = function(query) {
		    	var partInputObj = {"ranId": query};
		    	return ranService.ranList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){	
		        			 console.log(response.data.object);
		        			  return response.data.object;                           
		        		 }
		        	 }		    		
			    });	
		    };
		    
		   
		    
		    
		    /*ON ADD NEW LOCATION TAG*/
		    
			$scope.location="";
			$scope.locationIdData=[];	 
		    $scope.locationAdded = function(tag) {					
		    $scope.locationArray = [];
			    for (var j=0; j < $scope.locationIdData.length; j++) {
			    	$scope.locationArray.push($scope.locationIdData[j].text);
			    }
			    $scope.location=$scope.locationArray.join(',');
			    $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    /*ON REMOVE ADDED LOCATION TAG*/
		    
		    $scope.locationRemoved = function(tag) {			   
		    	 $scope.locationArray = [];
			     for (var j=0; j < $scope.locationIdData.length; j++) {
			    	 $scope.locationArray.push($scope.locationIdData[j].text);
			     }
			     $scope.location=$scope.locationArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
				    
		    /*AUTOCOMPLE LOCATION ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadLocation = function(query) {
		    	
		    	var locationInputObj = {"locationId": query};			    	
		    	return locationService.locationList(locationInputObj).then(function(response){	
		    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    	});			    				         
		    };
			    
		    $scope.part = {
				  plant : '',
				  shop : '',
                  line : '',
                  section : '',
                  partNo : $scope.partNumber,
                  locationId : $scope.location,
                  startIndex : 0,
                  endIndex : 0
              };
			
			// --------- Shops drop down list ---------
			   
/*			  if($window.sessionStorage.getItem('shopDPCollection') == null || $window.sessionStorage.getItem('shopDPCollection')=='undefined' || $window.sessionStorage.getItem('shopDPCollection')==undefined){
				  commonService.getAllShop()
				  .success(function(response){						  
					  $scope.shops = response.objectList;				
					  $window.sessionStorage.setItem('shopDPCollection',JSON.stringify($scope.shops));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.shops = JSON.parse(sessionStorage.shopDPCollection);
			  }
			  */
		    
		    $scope.loadShopLine = function(){
		    	 $scope.part.line = '';
		    	 $scope.part.shop = '';
		    	 commonService.getLineList($scope.part.plant)
				  .success(function(response){
					  $scope.lines = response.objectList;				
				  })
				  .error(function(response){
				  });
		    	 commonService.getShopList($scope.part.plant)
				  .success(function(response){
					  $scope.shops = response.objectList;				
				  })
				  .error(function(response){
				  });

		    }
			 // --------- Location drop down list -------

			  if($window.sessionStorage.getItem('locationDPCollection') == null || $window.sessionStorage.getItem('locationDPCollection')=='undefined' || $window.sessionStorage.getItem('locationDPCollection')==undefined){
				  commonService.getAllPlants()
				  .success(function(response){					 
					  $scope.locations = response.objectList;				
					  $window.sessionStorage.setItem('locationDPCollection',JSON.stringify($scope.locations));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.locations = JSON.parse(sessionStorage.locationDPCollection);
			  }
			  
			  // --------- Section drop down list ---------

			  if($window.sessionStorage.getItem('sectionDPCollection') == null || $window.sessionStorage.getItem('sectionDPCollection')=='undefined' || $window.sessionStorage.getItem('sectionDPCollection')==undefined){
				  commonService.getAllSections()
				  .success(function(response){					 
					  $scope.sections = response.objectList;	
					  $window.sessionStorage.setItem('sectionDPCollection',JSON.stringify($scope.sections));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.sections = JSON.parse(sessionStorage.sectionDPCollection);
			  }
			  
			 // --------- Line drop down list ---------

/*			  if($window.sessionStorage.getItem('linesDPCollection') == null || $window.sessionStorage.getItem('linesDPCollection')=='undefined' || $window.sessionStorage.getItem('linesDPCollection')==undefined){
				  commonService.getAllLines()
				  .success(function(response){					 
					  $scope.lines = response.objectList;
					  $window.sessionStorage.setItem('linesDPCollection',JSON.stringify($scope.lines));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.lines = JSON.parse(sessionStorage.linesDPCollection);
			  }*/
			  
			
			 var paginationOptions = {
				 	startIndex : 0,
				 	endIndex : 0,
				    pageNumber: 1,
				    pageSize: 100,
				    sort: null
				  };
			 
			 var partCellWareHouseTemplate = '<div> <a href="" ng-show="row.entity.childRecord" data-toggle="modal" data-target="#locationTrackerModal"  ng-click=grid.appScope.setLocationId(row.entity.wareHouseQty);>{{COL_FIELD}}</a> <span ng-show="!row.entity.childRecord" >{{COL_FIELD}}</span> </div>';
			 var partCellOverFlowTemplate = '<div> <a href="" ng-show="row.entity.childRecord" data-toggle="modal" data-target="#locationTrackerModal"  ng-click=grid.appScope.setLocationId(row.entity.overflowQty);>{{COL_FIELD}}</a> <span ng-show="!row.entity.childRecord" >{{COL_FIELD}}</span> </div>';
			 //added by arun for T&C CR
			 var partCellOthersTemplate = '<div> <a href="" ng-show="row.entity.childRecord" data-toggle="modal" data-target="#locationTrackerModal"  ng-click=grid.appScope.setLocationId(row.entity.otherQty);>{{COL_FIELD}}</a> <span ng-show="!row.entity.childRecord" >{{COL_FIELD}}</span> </div>';
			 //
			 var partCellLineTemplate = '<div> <a style="text-decoration: none;" ng-show="row.entity.childRecord" data-toggle="modal">{{COL_FIELD}}</a> <span ng-show="!row.entity.childRecord" >{{COL_FIELD}}</span> </div>';
			
			 //Grid
			 $scope.gridOptions = {
			 enablePaginationControls:false,
			 enableGridMenu: true,
             enableFiltering: true,
             enableColumnResize: true,
             paginationPageSizes: [100,250,500,750,1000],
     	     paginationPageSize: 100,
             treeRowHeaderAlwaysVisible: true,
             showTreeExpandNoChildren: false,
             useExternalPagination: true,
             autoResize:true,
             enableSorting: true,
             enableColumnMenus: false,
             enablePinning: true,
             headerTemplate: 'app/partials/partLocation-header-template.html',
             category: [{name: 'Part Number', visible: true },
                        {name: 'Quantity at', visible: true},{name: 'Total', visible: true}],
             columnDefs: [
                          { field: 'partNo', displayName: 'Part Number',category:"Part Number", showHeader: false , headerCellClass: $scope.highlightFilteredHeader, enableFiltering: false },
					       	      { field: 'wareHouseQty', displayName: 'Warehouse', category:"Quantity at", cellTemplate: partCellWareHouseTemplate},
					       	      { field: 'overflowQty', displayName: 'OverFlow', category:"Quantity at", cellTemplate: partCellOverFlowTemplate},
					       	      //added by anish for Line Stock
					       	      { field: 'lineQty', displayName: 'Line', category:"Quantity at", cellTemplate: partCellLineTemplate},
					       	      //added by arun for tc CR
					       	      { field: 'otherQty', displayName: 'Others', category:"Quantity at", cellTemplate: partCellOthersTemplate},
					       	      //
					       	      { field: 'totalQty', displayName: 'Total', category:"Total", visible:true}
                        ],
                        exporterCsvFilename: 'LocationMasterReport.csv',
                        exporterMenuVisibleData: false,
                        exporterPdfDefaultStyle: {fontSize: 9},
                        exporterPdfTableStyle: {margin: [70, 5, 0, 5]},
                        exporterPdfTableHeaderStyle: {fontSize: 10, bold: true, italics: true, color: 'red'},
                        exporterPdfHeader: { text: "Part Location Report", style: 'headerStyle' },
                        exporterPdfFooter: function ( currentPage, pageCount ) {
                          return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
                        },
                        exporterPdfCustomFormatter: function ( docDefinition ) {
                        	 docDefinition.styles.headerStyle = { fontSize: 20, bold: true, alignment: 'center', margin: [0, 0, 20, 0] }; 
                             docDefinition.styles.footerStyle = { fontSize: 10, bold: true, alignment: 'center',  margin: [5, 0, 20, 0] }; 
                          return docDefinition;
                        },
                        exporterPdfOrientation: 'landscape',
                        exporterPdfPageSize: 'LETTER',
                        exporterPdfMaxGridWidth: 500,
                        exporterPdfFilename: 'LocationMasterReport.pdf',
                        exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
                       
                        onRegisterApi: function( gridApi ) {
                        	 $scope.gridApi = gridApi;
                        	 //Pagination
                        	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                        		 $scope.blockUI();
             		          paginationOptions.pageNumber = newPage;
             		          paginationOptions.pageSize = pageSize;
             		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
             		        paginationOptions.endIndex   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
             		       $scope.load();
             		        });
                        	 //select row
                        	 gridApi.selection.on.rowSelectionChanged($scope,function(row){
                     	        if(row.isSelected==true){
                     	            var childRows   = row.treeNode.children;
                     	            for (var j = 0, length = childRows.length; j < length; j++) {
                     	                var rowEntity   = childRows[j].row.entity;
                     	                $scope.gridApi.selection.selectRow(rowEntity);
                     	            }
                     	        }

                     	        if(row.isSelected==false){
                     	            var childRows   = row.treeNode.children;
                     	            for (var j = 0, length = childRows.length; j < length; j++) {
                     	                var rowEntity   = childRows[j].row.entity;
                     	                $scope.gridApi.selection.unSelectRow(rowEntity);
                     	            }
                     	        }
                     	 });
                        	
                	    }
		    };
			 // Clear the filter
				 $scope.clearFilters = function() {
					 $scope.gridApi.core.clearAllFilters();
			     };
			// Reset the values
				    $scope.resetParts = function(){
				    	$scope.shops = "";
				    	$scope.lines = "";
				    	$scope.gridOptions.data = [];
				    	$scope.clearFilters();
				    	$scope.part = {};
				    	$scope.partNumber="";	    	
				    	$scope.part.startIndex = 0;
				    	$scope.part.endIndex = 0;
				    	$scope.tags=[];
				    	$scope.ranData=[];
				    	$scope.locationIdData=[];	
				    	$scope.gridOptions.totalItems=0;
				    	$scope.location="";
				    	$scope.partNumber="";
				    	$scope.searchDataEror="Click search to fetch records.";
				    	$scope.gridOptions.enablePaginationControls=false;
				    	$scope.closeAlert();
				    	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
				    };
     
		     $scope.partLocationData = function(){
		    		 $scope.blockUI();
		    		 partLocationService.locationreport($scope.part).then(function(response){
		    			 $scope.gridOptions.data = [];
		    			 if(response.data.objectList[0] !== undefined){
		    				 if(response.data.statusType === 'success' ){
		    					 //Fix for grid row issue - Start
		    					 $scope.modifyDataStructure(response.data.objectList);
		    					 //Fix for grid row issue - End
		    					 $scope.gridOptions.enablePaginationControls=true;
		    					 $scope.response = response.data.objectList;
		    					 if(!$scope.part.download){
		    						 writeoutNode( response.data.objectList, 0, $scope.gridOptions.data );
		    					 }
		    				 } else {
		    					 $scope.gridOptions.enablePaginationControls=false;
		    					 $scope.alerts = [];
		    					 $scope.alerts.push({
		    						 type : response.data.statusType,
		    						 msg : response.data.statusMessage,
		    						 error : response.data.exceptionStackTrace,
		    						 errorClsName : response.data.exceptionClassName,
		    						 errorMsg : response.data.exceptionMessage
		    					 });
		    				 }
		    				 $.unblockUI();
		    			 } else {
		    				 $scope.searchDataEror=response.data.statusMessage;
		    				 $.unblockUI();
		    			 }
		    		 });
		     };
		     
		     //-- Fix for grid row issue - Start
		     
		     $scope.modifyDataStructure = function(partLocationData){

		    	for (var partId=0; partId < partLocationData.length; partId++) {
		    		$scope.listOfColumn = ["wareHouseQty","overflowQty","otherQty","lineQty"];
		    		for (var i=0; i < $scope.listOfColumn.length; i++) {
		    			$scope.minLoad(partLocationData[partId].partLocationTypeQty,$scope.listOfColumn[i]);
		    		}
		    		$scope.removeEmptyRow(partLocationData[partId].partLocationTypeQty);
		    	}

		    	console.log($scope.partLocationTypeQty);
		     };
		     
		     $scope.minLoad = function(partLocationTypeQty,param) {
		    	 
		    	 	for (var i=0; i < partLocationTypeQty.length; i++) {
					 
						 if(partLocationTypeQty[i][param] == null){
							 
							 for (var j = i; j < partLocationTypeQty.length; j++) {
								 if(partLocationTypeQty[j][param] != null){
									 var objval = partLocationTypeQty[j][param];
									 partLocationTypeQty[j][param] = null;
									 partLocationTypeQty[i][param] = objval;
									 break;
								 } 
							 }
						 }
					}
		    	 
		     };
		     
		     $scope.removeEmptyRow = function(partLocationTypeQty) {
		    	 for (var i=0; i < partLocationTypeQty.length; i++) {
		    		 if(partLocationTypeQty[i].wareHouseQty == null && partLocationTypeQty[i].overflowQty == null && partLocationTypeQty[i].otherQty == null && partLocationTypeQty[i].lineQty == null){
		    			 delete partLocationTypeQty[i];
		    		 }
		    	 }
		     };
		     
		     //--Fix for grid row issue - End
		     
	 		/* Load data in grid */
		    $scope.load = function () {
		    	console.log("IN Load function");
		    	$scope.part.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

		    	if(paginationOptions.endIndex === 0){
		    		$scope.part.endIndex = $scope.gridOptions.paginationPageSize;
		    	}
		    	$scope.part.startIndex = paginationOptions.startIndex;
		    	$scope.part.endIndex = paginationOptions.pageSize;
		    	$scope.part.partNo=$scope.partNumber;
		    	$scope.part.locationId=$scope.location;		
		    	
		    	if($scope.validateFilter() == true){
		    		partLocationService.locationreportCount($scope.part).then(function(response){
		    			$scope.gridOptions.totalItems = response.data.object;		    		
		    			$scope.recordCount = response.data.object;
		    			$scope.partLocationData();
		    		});
		    	}else{
		    		 $scope.alerts = [];
					 $scope.alerts.push({
						 type : 'danger',
						 msg : 'Plant/Shop or Part or RAN or Location is/are mandatory'
					 });
		    	}	

		    };

		    // --------- search button ---------
            $scope.searchParts = function() {
            	$scope.alerts = [];
            	$scope.gridOptions.data = [];
            	$scope.part.partNo=$scope.partNumber;
            	$scope.part.locationId=$scope.location;
            	paginationOptions.startIndex= 0;
            	paginationOptions.endIndex= 0;
            	paginationOptions.pageNumber= 1;
            	paginationOptions.pageSize= 100; 
            	$scope.gridOptions.paginationCurrentPage=1;
            	$scope.gridOptions.paginationPageSize=100;
        		$scope.searchClicked=true;
            	$scope.clearFilters();                	
            	$scope.load();
            	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
            };
		    
		    /* Tree view */
            var writeoutNode = function( childArray, currentLevel, dataArray ){
				if (typeof childArray !== 'undefined') {					
				      childArray.forEach(function(childNode) {
				        if (typeof childNode.partLocationTypeQty !== 'undefined') {
				          if (childNode.partLocationTypeQty.length >= 0) {
				            childNode.$$treeLevel = currentLevel;
				          }
				        }
				        dataArray.push(childNode);
				        writeoutNode(childNode.partLocationTypeQty, currentLevel + 1, dataArray);
				      });
				    }
			};
			
            // Download report - Start		  
			$scope.downloadPartLocation =function(){
				$scope.blockUI();	
				$scope.partDownload = {
						plant : $scope.part.plant,
						shop :  $scope.part.shop,
						line :  $scope.part.line,
						section : $scope.part.section,
						ran : $scope.part.ran,
						partNo : $scope.partNumber,
						locationId : $scope.location,
						
				};
				
				return partLocationService.PartLocationDownload($scope.partDownload).then(function(response){
					var responseList = [];
					if(response.objectList != null){
						for (var i = 0; i < response.objectList.length; i++) {
							var obj = {};
							obj["LOCATION_ID"] = response.objectList[i].locationId;
							obj["PART_NO"] = '="'+response.objectList[i].partNo+'"';
							obj["RAN"] = '="'+response.objectList[i].ran+'"';
							obj["CURRENT_QTY"] = response.objectList[i].currentQty;
							obj["TOTAL_CAPACITY"] = response.objectList[i].totalCapactity;
							responseList.push(obj);
						}
						$.unblockUI();
						return responseList;
					}else{
						$scope.alerts = [];
    	       			$scope.alerts.push({
    	       				 type : 'danger',
    	       				 msg : 'Data is not available'
    	       			});
					}
					$.unblockUI();
				});
	        };
	        $scope.getDownloadReportHeader = function () {
	        		return ["LOCATION_ID", "PART_NO","RAN","CURRENT_QTY","TOTAL_CAPACITY"];
            };
            //Download report - End
            
			//Alert msg
		    $scope.closeAlert = function(index) {
		        $scope.alerts.splice(index, 1);
		    };
		    
		    $scope.setLocationId = function(locationId) {		    			    
		    	Location.location=locationId;
		    	$scope.locationId=locationId;
		     };
		     
		     $scope.validateFilter = function(){
		    	
		    	 if($scope.part.plant !== "" && $scope.part.plant !== null && $scope.part.plant !== undefined && $scope.part.shop !== "" && $scope.part.shop !== null && $scope.part.shop !== undefined)
				 {
					 return true;
				 }
		    	 else if($scope.ranData.length>0 || $scope.tags.length>0 || $scope.locationIdData.length>0){
		    		 return true;
		    	 }
		    	 
		    	 else{
					 return false;
				 }
		     };
} ]);