wmsApp.controller('ZonewiseConsumptionController', [ '$scope', '$window', '$filter', '$location', '$q', 'zoneConsumptionService', 'locationService', 'uiGridTreeViewConstants', '$http', 'commonService', 'localStorageService', 'partNumberService', 'ranService', 'shortageAlarmService','lineFeedingDetailsService', 
		function($scope, $window, $filter, $location, $q, zoneConsumptionService, locationService, uiGridTreeViewConstants, $http, commonService, localStorageService, partNumberService, ranService, shortageAlarmService, lineFeedingDetailsService) {
	
	$scope.loginUser= $window.sessionStorage.getItem('loggedUserId');
	$scope.searchDataError="Click search to fetch records.";
	$scope.partNumberList='';
	$scope.beginDatePickerOpen = false;
	$scope.endDatePickerOpen = false;
	$scope.beginDate = new Date();
	$scope.endDate = new Date();
	
	$scope.mininumDate = new Date();
    //var numberOfDaysToAdd = ;
    $scope.mininumDate.setMonth($scope.mininumDate.getMonth() - 6);
    //$scope.mininumDate.setDate($scope.mininumDate.getDate() + numberOfDaysToAdd); 
	
	$scope.openBeginDatePicker = function($event) {
		$event.preventDefault();
		$event.stopPropagation();
		$scope.isBeginDateChanged = true;
		$scope.beginDatePickerOpen = !$scope.beginDatePickerOpen;
	};
	$scope.openEndDatePicker = function($event) {
		$event.preventDefault();
		$event.stopPropagation();
		$scope.endDatePickerOpen = !$scope.endDatePickerOpen;
	};
	
	//search input initiation
	$scope.zoneConsumption = {
			 plant : '',
			 shop : '',
			 line:'',
			 zone : '',				 
			 partNumber : $scope.partNumberList,
			 userId :  $scope.loginUser,
			 startIndex: 0,
			 endIndex: 0,
			 beginDate : $scope.beginDate,
			 endDate : $scope.endDate,
		};
  
	//load plant drop down on page load
	commonService.getAllPlants()
		.success(function(response){					 	
				$scope.locations = response.objectList;				
			})
		.error(function(response){
		  	});
	
	
	// --------- Shops drop down list ---------
	$scope.loadShopLine = function() {
		commonService.getLineList($scope.zoneConsumption.plant).success(function(response) {
			$scope.lines = response.objectList;
		}).error(function(response) {
		});
		
		lineFeedingDetailsService.getShopList($scope.zoneConsumption.plant).success(function(response) {
		 
		$scope.shops = response.objectList;
		}).error(function(response) {
		});
		
		
	}

	//load zone drop down on change event of plant
	$scope.getAllZones = function(){
		  shortageAlarmService.getAllZones()
		  .success(function(response){
			  $scope.zones = response.objectList;				
		  })
		  .error(function(response){
		  });
	  };
	
	  
	// --------- Part Number List ---------
		$scope.partNumberList='';
		$scope.tags=[];	 
		/*ON ADD NEW PART TAG*/
					
		$scope.tagAdded = function(tag) {
			
			  $scope.partArray = [];
			  
			     for (var j=0; j < $scope.tags.length; j++) {
			    	 
			    	 $scope.partArray.push($scope.tags[j].text);
			    	 console.log("Part Array",$scope.partArray);
			      }
			     $scope.partNumberList=$scope.partArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		/*ON REMOVE ADDED PART TAG*/
		    
	    $scope.tagRemoved = function(tag) {			   
	    	 $scope.partArray = [];
		     for (var j=0; j < $scope.tags.length; j++) {

		    	 $scope.partArray.push($scope.tags[j].text);
		      }
		     $scope.partNumberList=$scope.partArray.join(',');
		     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
	    };
	    
	    $scope.addingTag = function(tag) {
	    	console.log("Tag.text",tag.text);
	    	  tag.text = tag.text.replace(/ /g, ',');
	    	  console.log("Tag.text 2",tag.text);
	    	  return tag;
	    	};
	    	
		
	    /*AUTOCOMPLE PART ON ENTER MIN 3 CHAR DATA*/
	    
	    $scope.loadParts = function(query) {
	    	var partInputObj = {"partNumber": query};			    	
	    	return shortageAlarmService.partNumberList(partInputObj).then(function(response){			    		
	    		 if(response.data.statusType=='success'){
	        		 if(response.data.object!='null' && response.data.object!=null){				        		
	        			  return response.data.object;                           
	        		 }
	        	 }else{
	        		console.log("empty part number");
	        	 }			    		
		    });			    				         
	    };
    
    var paginationOptions = {
		 	startIndex : 0,
		 	endIndex : 0,
		    pageNumber: 1,
		    pageSize: 100,
		    sort: null
	};
    
    //Grid
	 $scope.gridOptions = {
			 enablePaginationControls:false,
			 enableGridMenu: true,
			 enableFilering: true,            
			 enableColumnResize: true,
			 paginationPageSizes: [100,250,500,750,1000],
			 paginationPageSize: 100,         
			 useExternalPagination: true,
			 autoResize:true,
			 enableSorting: true,
			 enableColumnMenus: false,
			 enablePinning: true,            
			 columnDefs: [
		  	      { field: 'line', displayName: 'Line', width:40 , pinnedLeft:true},   
		  	      { field: 'shop', displayName: 'Shop', width:40 , pinnedLeft:true },   
		  	      { field: 'zone', displayName: 'Zone', width:70 , pinnedLeft:true},
		  	      { field: 'partNumber', displayName: 'Part Number',width:130},
		  	      { field: 'partName', displayName: 'Part Name', width:100},
		  	      { field: 'source', displayName: 'Source', width:30},
		  	      { field: 'pofZone', displayName: 'POF Zone', width:60},
		  	      { field: 'lastPickListTime', displayName: 'Pick List Time', width:180},
		  	      { field: 'lastPickListSTS', displayName: 'Pick List Status', width:70},
		  	      { field: 'lastPickListQTY', displayName: 'Pick List Qty', width:60},
		  	      { field: 'lastWHoutTIME', displayName: 'WH-Out Time', width:180},
		  	      { field: 'lastWhOUTQTY', displayName: 'WH-Out Qty', width:50},
		  	      { field: 'zoneTactHISRY', displayName: 'Tact',width:180},
		  	     // { field: 'shift', displayName: 'Shift', width:50},	
		  	      { field: 'offLineQTY', displayName: 'Offline Cons',width:70},
		  	     // { field: 'lineInvent', displayName: 'Line Inv', width:50},
		  	      { field: 'lineStock', displayName: 'Line Stk', width:70},
		  	      { field: 'whStock', displayName: 'WH Stk', width:70},
		  	      { field: 'catsStock', displayName: 'Cats Stk', width:70},
		  	      { field: 'mismatch', displayName: 'Mismatch', width:70}, 
               ],
               exporterPdfAlign:'left',
               exporterCsvFilename: 'ZoneConsumption.csv',
               exporterMenuVisibleData: false,
               exporterPdfDefaultStyle: {fontSize: 9},
               exporterPdfTableStyle: {margin: [70, 5, 0, 5]},
               exporterPdfTableHeaderStyle: {fontSize: 10, bold: true, italics: true, color: 'red'},
               exporterPdfHeader: { text: "Zone Consumption Report", style: 'headerStyle' },
               exporterPdfFooter: function ( currentPage, pageCount ) {
                 return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
               },
               exporterPdfCustomFormatter: function ( docDefinition ) {
               	 docDefinition.styles.headerStyle = { fontSize: 20, bold: true, alignment: 'center', margin: [0, 0, 20, 0] }; 
                    docDefinition.styles.footerStyle = { fontSize: 10, bold: true, alignment: 'center',  margin: [5, 0, 20, 0] }; 
                 return docDefinition;
               },
               exporterPdfOrientation: 'landscape',
               exporterPdfPageSize: 'LETTER',
               exporterPdfMaxGridWidth: 500,
               exporterPdfFilename: 'ZoneConsumptionReport.pdf',
               exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
              
               onRegisterApi: function( gridApi ) {
               	 $scope.gridApi = gridApi;
               	 //Pagination
               	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
               		 $scope.blockUI();
    		          paginationOptions.pageNumber = newPage;
    		          paginationOptions.pageSize = pageSize;
    		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
    		        paginationOptions.endIndex   = paginationOptions.pageSize;
    		        $scope.load();
    		        });
               
       	    }
	};
	 
	$scope.clearFilters = function() {
		 $scope.gridApi.core.clearAllFilters();
    };
     
    //Reset the values
    $scope.resetForm = function(){
    	$scope.zoneConsumption.plant = "";
    	$scope.zoneConsumption.shop = "";
    	$scope.zoneConsumption.line = "";
    	$scope.zoneConsumption.zone = "";
    	$scope.beginDate = new Date();
		$scope.endDate = new Date();
    	$scope.gridOptions.data = [];
    	$scope.clearFilters();	
    	$scope.locationIdData=[];
    	$scope.tags=[];
    	$scope.partNumberList="";
    	$scope.searchDataError = "Click search to fetch records";
    	$scope.gridOptions.totalItems=0;
    	$scope.gridOptions.enablePaginationControls=false;	    
    	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"});
    };	
    
    $scope.validatePlantFilter = function(){
   	 if($scope.zoneConsumption.plant !== "" && $scope.zoneConsumption.plant !== null && $scope.zoneConsumption.plant !== undefined)
		 {
			 return true;
		 }else{
			 return false;
		 }
    };
    
    $scope.validateShopFilter = function(){
      	 if($scope.zoneConsumption.shop !== "" && $scope.zoneConsumption.shop !== null && $scope.zoneConsumption.shop !== undefined)
   		 {
   			 return true;
   		 }else{
   			 return false;
   		 }
    };
    
    $scope.searchZoneConsumption = function() {
    	if($scope.validatePlantFilter()==true && $scope.validateShopFilter()==true)	{
    			console.log("inside search");
        		$scope.blockUI();
        		$scope.alerts = [];
        		$scope.gridOptions.data = [];
        		paginationOptions.startIndex= 0;
        		paginationOptions.endIndex= 0;
        		paginationOptions.pageNumber= 1;
        		paginationOptions.pageSize= 100; 
        		$scope.gridOptions.paginationCurrentPage=1;
        		$scope.gridOptions.paginationPageSize=100;        		
        		$scope.zoneConsumption.startIndex=0;
    			$scope.zoneConsumption.endIndex=0;
    			$scope.beginDate = $filter('date')($scope.beginDate, 'yyyy-MM-dd');
    			$scope.endDate = $filter('date')($scope.endDate, 'yyyy-MM-dd');			
        		$scope.load();
        		//$.unblockUI();
    	}else{
    		$scope.alerts = [];
   			$scope.alerts.push({
   				 type : 'danger',
   				 msg : 'Plant & Shop is mandatory'
   			});
   			//$.unblockUI();
   			$scope.gridOptions.enablePaginationControls=false;
			$scope.gridOptions.data = [];
			return;
    	}
    };
    
    $scope.load = function () {
        $scope.zoneConsumption.endIndex = paginationOptions.pageSize;
    	if(paginationOptions.endIndex === 0){
    		$scope.zoneConsumption.endIndex = $scope.gridOptions.paginationPageSize;
    	}
    	$scope.zoneConsumption.startIndex = paginationOptions.startIndex;
     	$scope.zoneConsumption.endIndex = paginationOptions.pageSize;
    	$scope.zoneConsumption.partNumber = $scope.partNumberList;
    	$scope.zoneConsumption.beginDate = $scope.beginDate;
		$scope.zoneConsumption.endDate = $scope.endDate
    	
    	if($scope.zoneConsumption.plant=="G"){
    		zoneConsumptionService.getConsumptionListCount($scope.zoneConsumption).then(function(response){
	    		$scope.gridOptions.totalItems = response.data.object;		    		
	    		$scope.recordCount = response.data.object;		    		
	    		if($scope.recordCount==0){
	    			$scope.searchDataError="No Records Found!!!";
	    			$.unblockUI();
	    			$scope.gridOptions.enablePaginationControls=false;	
	    			$scope.alerts = [];
	    			
	    		}else{
	    			$scope.getConsumptionList();
	    		}
	    	});
    	}else{
    		$scope.recordCount=0;
    		if($scope.recordCount==0){
    			$scope.searchDataError="No Records Found!!!";
    			$.unblockUI();
    			$scope.gridOptions.enablePaginationControls=false;	
    			$scope.alerts = [];
    		}
    	}
    };
    
    $scope.getConsumptionList = function(){
    	$scope.zoneConsumption.partNumber = $scope.partNumberList;
    	zoneConsumptionService.getConsumptionList($scope.zoneConsumption).then(function(response){
	    		$scope.gridOptions.data = [];
	    		if(response.data.objectList !== undefined && response.data.objectList !== null){	    			
	    			if(response.data.statusType === 'success' ){
	    				$scope.gridOptions.enablePaginationControls=true;
	    	    	           $scope.gridOptions.data = response.data.objectList;
	    	    	           $.unblockUI();
	    			} else {
	    				$scope.gridOptions.enablePaginationControls=false;
	    				$scope.alerts = [];
			            $scope.alerts.push({
			                type : response.data.statusType,
			                msg : response.data.statusMessage,
			                error : response.data.exceptionStackTrace,
			                errorClsName : response.data.exceptionClassName,
			                errorMsg : response.data.exceptionMessage
			            });
			            $.unblockUI();
	    			}
	    			
	    		} else {
	    			$scope.searchDataError=response.data.statusMessage;	  
	    			$.unblockUI();
	    		}
	    		//$.unblockUI();
	    	});
    };
    
    $scope.downloadZoneConsumption = function () {
       
    	$scope.zoneConsumption.partNumber = $scope.partNumberList;
    	$scope.blockUI();
    	if($scope.zoneConsumption.plant=="G"){
    		zoneConsumptionService.getConsumptionListCount($scope.zoneConsumption).then(function(response){
	    		$scope.gridOptions.totalItems = response.data.object;		    		
	    		$scope.recordCount = response.data.object;		    		
	    		if($scope.recordCount==0){
	    			$scope.searchDataError="No Records Found to download!!!";
	    			$.unblockUI();
	    			$scope.gridOptions.enablePaginationControls=false;	
	    			$scope.alerts = [];
	    			
	    		}else{
	    			return zoneConsumptionService.getZoneConsumptionDownload($scope.zoneConsumption);
	    		}
	    		$.unblockUI();
	    	});
    	}else{
    		$scope.recordCount=0;
    		if($scope.recordCount==0){
    			$scope.searchDataError="No Records Found to download!!!";
    			$.unblockUI();
    			$scope.gridOptions.enablePaginationControls=false;	
    			$scope.alerts = [];
    		}
    	}
    };
    
	    
	
	
} ]);


wmsApp.factory('zoneConsumptionService', [ 'commonService', '$http', '$q', '$window', function(commonService, $http, $q,$window) {
	var fact = {};
	
	fact.getConsumptionListCount = function(searchParams)
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/zoneconsumption/zonelistCount',
			data : searchParams,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});		
	};
	
	fact.getConsumptionList = function(searchParams)
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/zoneconsumption/zonelist',	
			data : searchParams,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;			
		});		
	};
	
	fact.getZoneConsumptionDownload= function(searchParams)
    {    
    $http({       
     method: 'POST',        
     url: 'rest/zoneconsumption/zoneconsumptionDownload',    
     data : searchParams,
     responseType: 'arraybuffer'    
     }).success(function (data, status, headers) {        
     headers = headers();         
	     var filename = headers['x-filename'];        
	     var contentType = headers['content-type'];         
	     var linkElement = document.createElement('a');  
	     try {
	    	 if(status==200){
	    		 var blob = new Blob([data], { type: contentType }); 
		            var url = window.URL.createObjectURL(blob);     
		            linkElement.setAttribute('href', url);       
		            linkElement.setAttribute("download", filename);			           
		            if ($window.navigator && $window.navigator.msSaveOrOpenBlob) {
		           $window.navigator.msSaveOrOpenBlob(blob, filename);
		         } else{
		           var e = document.createEvent('MouseEvents');
		           e.initEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
		           linkElement.dispatchEvent(e);
		       } 
	    	 }else{
	    		 console.log("error - No records found")
	    	 }			    	 
	    	 $.unblockUI();
	       } catch (ex) {
	    	   $.unblockUI();        
	         }  

	      }).error(function (data) {
	    	  $.unblockUI();
	          console.log("failure : " +data);   
	         });
    };
	
	return fact;
} ]);