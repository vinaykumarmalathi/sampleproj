wmsApp.controller('formRequirementSearchController',
		[ '$scope','$window','$filter',  '$rootScope', '$location','$q','formRequirementSearchService',
	        function($scope,$window,$filter, $rootScope,  $location,$q,formRequirementSearchService) {
			$scope.fromDate=new Date();
		    $scope.toDate=new Date();
		    
		    $scope.beginDatePickerOpen = false;
		    $scope.endDatePickerOpen = false;
		    var summaryList = [];
			$scope.defaultReviewerList= [];
			$scope.additionalReviewerList = [];
			$scope.attachmentListArray = [];
			$scope.approverList = [];
		    
		    	$scope.openBeginDatePicker = function ($event) {			    	
		    		$event.preventDefault();
		    		$event.stopPropagation();
		    		$scope.beginDatePickerOpen = !$scope.beginDatePickerOpen;
			    };

			    $scope.openEndDatePicker = function ($event) {
			    	$event.preventDefault();
			    	$event.stopPropagation();
			    	$scope.endDatePickerOpen = !$scope.endDatePickerOpen;			  
			    };
			    
			    
			    $rootScope.formStatus = '';
					 
			    $scope.searchPageData = {
			    		formID : '',
			    		beginDate: '',
			    		endDate: '',
			    		formStatus :'',
			    		initiatorZID : '',
			    		initiatorName : '',
			    		formValueSymbol:'',
			    		formValue:'',
			    		agingDaysSymbol: '',
			    		agingDays:'',
			    		pendingFormByZID :''
			    };
			    $scope.pageData = {
			    		formID : '',
			    };
			    
					 //Grid
					 $scope.gridOptions = {
					 enablePaginationControls:false,
					 enableGridMenu: true,
		             enableFiltering: true,            
		             enableColumnResize: true,
		             paginationPageSizes: [100,250,500,750,1000],
		     	     paginationPageSize: 100,         
		             useExternalPagination: true,
		             autoResize:true,
		             enableSorting: true,
		             enableColumnMenus: false,
		             enablePinning: true,            
		             columnDefs: [
		            	 {field: 'id', displayName: 'ID', with:180},
		            	 { field: 'formID',
		            		 displayName: 'Form ID', 
		            		 cellTemplate: '<div class="ui-grid-cell-contents"><span ng-if="row.entity.formStatus==\'Saved\'" class="details-link" data-toggle="modal" data-target="#summaryPartMapModal" ng-click="grid.appScope.openModalTable(row.entity.formID,row.entity.formStatus)">{{row.entity.formID}}</span><span ng-if="row.entity.formStatus!=\'Saved\'" class="details-link" data-toggle="modal" data-target="#viewPartMapModal" ng-click="grid.appScope.openModalTable(row.entity.formID,row.entity.formStatus)">{{row.entity.formID}}</span></div>'
		            		  },
                         { field: 'initiatorZID', displayName: 'Initiated By', width:100 },
                         {field: 'initiatorName', displayName: 'Initiator Name', width:100},
                         { field: 'createdOn', displayName: 'Created On', width:180 },
                         { field: 'formStatus', displayName: 'Status', width:220 },
			       	      { field: 'formValue', displayName: 'Form Value', width:220},
			       	      {field: 'formComments', displayName: 'Form Comments', width:220},
                         { field: 'agingDays', displayName: 'Ageing Days', width:180},
                         {field: 'nextReviewer', displayName: 'Next Reviewer', width:180},
                         {field: 'formCategory', displayName: 'Form Category', width:180},
                         {field:'download',type: 'object',displayName: 'Download',headerCellClass: 'center nonEditableField',width:120, cellTemplate:'<div><button title="Download" type="button" style="margin-top: 4px;margin-left: 3px;" class="btn btn-default btn-sm" data-toggle="modal" data-target="#download" ng-click="grid.appScope.download(row.entity.formID)"><span class="glyphicon glyphicon-list-alt"></span></button></div>'},
                         
                        // { field:'viewsummary',type: 'object',displayName: 'View Summary',headerCellClass: 'center nonEditableField', width:80, cellTemplate:'<div><button type="button" class="btn btn-default btn-sm" data-toggle="modal" data-target="#viewSummaryModal" ng-click="grid.appScope.openModel(row.entity.partNumber)"><span class="glyphicon glyphicon-list-alt"></span> View Summary</button></div>'}//
		                          
		                        ],
		                        exporterMenuVisibleData: false,
		                        exporterPdfCustomFormatter: function ( docDefinition ) {
		                        	 docDefinition.styles.headerStyle = { fontSize: 20, bold: true, alignment: 'center', margin: [0, 0, 20, 0] }; 
		                             docDefinition.styles.footerStyle = { fontSize: 10, bold: true, alignment: 'center',  margin: [5, 0, 20, 0] }; 
		                          return docDefinition;
		                        },
		                       
		                        onRegisterApi: function( gridApi ) {
		                        	 $scope.gridApi = gridApi;
		                        	 //Pagination
		                        	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
		                        		 $scope.blockUI();
		             		          paginationOptions.pageNumber = newPage;
		             		          paginationOptions.pageSize = pageSize;
		             		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
		             		        paginationOptions.maxResult   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
		             		        $scope.loadPaginationGrid();
		             		        });
		                        
		                	    }
				    };
					 
			    /*$scope.savedGridOptions = {
						 enablePaginationControls:false,
						 enableGridMenu: true,
			             enableFiltering: true,            
			             enableColumnResize: true,
			             paginationPageSizes: [100,250,500,750,1000],
			     	     paginationPageSize: 100,         
			             useExternalPagination: true,
			             autoResize:true,
			             enableSorting: true,
			             enableColumnMenus: false,
			             enablePinning: true,            
			             columnDefs: [
			            	 {field: 'id', displayName: 'ID', with:180},
			            	 { field: 'formID',
			            		 displayName: 'Form ID', 
			            		 cellTemplate: '<div class="ui-grid-cell-contents"><span class="details-link" data-toggle="modal" data-target="#summaryPartMapModal" ng-click="grid.appScope.openModalTable(row.entity.formID,row.entity.formStatus)">{{row.entity.formID}}</span></div>'
			            		  },
	                         { field: 'initiatorZID', displayName: 'Initiated By', width:100 },
	                         {field: 'initiatorName', displayName: 'Initiator Name', width:100},
	                         { field: 'createdOn', displayName: 'Created On', width:180 },
	                         { field: 'formStatus', displayName: 'Status', width:220 },
				       	      { field: 'formValue', displayName: 'Form Value', width:220},
				       	      {field: 'formComments', displayName: 'Form Comments', width:220},
	                         { field: 'agingDays', displayName: 'Ageing Days', width:180},
	                         {field: 'nextReviewer', displayName: 'Next Reviewer', width:180},
	                         {field: 'formCategory', displayName: 'Form Category', width:180},
	                         {field:'download',type: 'object',displayName: 'Download',headerCellClass: 'center nonEditableField',width:120, cellTemplate:'<div><button title="Download" type="button" style="margin-top: 4px;margin-left: 3px;" class="btn btn-default btn-sm" data-toggle="modal" data-target="#download" ng-click="grid.appScope.download(row.entity.formID)"><span class="glyphicon glyphicon-list-alt"></span></button></div>'},
	                         
	                        // { field:'viewsummary',type: 'object',displayName: 'View Summary',headerCellClass: 'center nonEditableField', width:80, cellTemplate:'<div><button type="button" class="btn btn-default btn-sm" data-toggle="modal" data-target="#viewSummaryModal" ng-click="grid.appScope.openModel(row.entity.partNumber)"><span class="glyphicon glyphicon-list-alt"></span> View Summary</button></div>'}//
			                          
			                        ],
			                        exporterMenuVisibleData: false,
			                        exporterPdfCustomFormatter: function ( docDefinition ) {
			                        	 docDefinition.styles.headerStyle = { fontSize: 20, bold: true, alignment: 'center', margin: [0, 0, 20, 0] }; 
			                             docDefinition.styles.footerStyle = { fontSize: 10, bold: true, alignment: 'center',  margin: [5, 0, 20, 0] }; 
			                          return docDefinition;
			                        },
			                       
			                        onRegisterApi: function( gridApi ) {
			                        	 $scope.gridApi = gridApi;
			                        	 //Pagination
			                        	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			                        		 $scope.blockUI();
			             		          paginationOptions.pageNumber = newPage;
			             		          paginationOptions.pageSize = pageSize;
			             		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
			             		        paginationOptions.maxResult   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
			             		        $scope.loadPaginationGrid();
			             		        });
			                        
			                	    }
					    };
						 */
			    
			    $scope.approvalGridOptions = {
						 enablePaginationControls:false,
						 enableGridMenu: true,
			             enableFiltering: true,            
			             enableColumnResize: true,
			             paginationPageSizes: [100,250,500,750,1000],
			     	     paginationPageSize: 100,         
			             useExternalPagination: true,
			             autoResize:true,
			             enableSorting: true,
			             enableColumnMenus: false,
			             enablePinning: true,            
			             columnDefs: [
			                          { field: 'cycleCountDate', displayName: 'Cycle Count Date', width:150 },
			                          { field: 'aorb', displayName: 'A/B', width:100 },
			                          { field: 'partNumber', displayName: 'Part Number', width:180 },
			                          { field: 'partName', displayName: 'Part Name', width:220 },
						       	      { field: 'supplierName', displayName: 'Supplier Name', width:220},
			                          { field: 'shop', displayName: 'Shop', width:180},
			                          { field: 'class', displayName: 'Class', width:180},
			                          { field: 'systemStock', displayName: 'System Stock', width:180},
			                          { field: 'physicalStock', displayName: 'Physical Stock', width:100 },
			                          { field: 'qtyAdjusted', displayName: 'Qty Adjusted', width:100 },
			                          { field: 'unitPrice', displayName: 'Unit Price', width:100 },
			                          { field: 'costImpact', displayName: 'Cost Impact', width:100 },
			                          { field: 'reasonCode', displayName: 'Reason Code', width:100 },
			                          { field: 'counterMeasure', displayName: 'Counter Measure', width:100 },
			                          
			                        ],
			                        exporterMenuVisibleData: false,
			                        exporterMenuVisibleData: false,
			                        exporterPdfCustomFormatter: function ( docDefinition ) {
			                        	 docDefinition.styles.headerStyle = { fontSize: 20, bold: true, alignment: 'center', margin: [0, 0, 20, 0] }; 
			                             docDefinition.styles.footerStyle = { fontSize: 10, bold: true, alignment: 'center',  margin: [5, 0, 20, 0] }; 
			                          return docDefinition;
			                        },
			                       
			                        onRegisterApi: function( gridApi ) {
			                        	 $scope.gridApi = gridApi;
			                        	 //Pagination
			                        	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			                        		 $scope.blockUI();
			             		          paginationOptions.pageNumber = newPage;
			             		          paginationOptions.pageSize = pageSize;
			             		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
			             		        paginationOptions.maxResult   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
			             		        $scope.loadPaginationGrid();
			             		        });
			                        
			                	    }
					    };
					 
					 $scope.loadPaginationGrid = function () {
					    	if(paginationOptions.endIndex === 0){
					    		paginationOptions.endIndex = $scope.gridOptions.paginationPageSize;
					    	}
					    	
					    	$scope.part.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

					    	if(paginationOptions.endIndex === 0){
					    		$scope.part.endIndex = $scope.gridOptions.paginationPageSize;
					    	}
					    	$scope.part.startIndex = paginationOptions.startIndex;
					    	$scope.part.endIndex = paginationOptions.pageSize;
					    	
					    	formRequirementSearchService.searchListCount().then(function(response){
				    			$scope.gridOptions.totalItems = response.data.object;
				    			$scope.recordCount = response.data.object;
				    			
				    		});
						    // --End
					    };
					 
					    $scope.searchFormData = function() {
					    	$scope.z9SearchGrid = false;
					    	formRequirementSearchService.getSearchPageData($scope.searchPageData).then(function(response){
					    		console.log(response.data);
					    		if(response.data.objectList !== undefined && response.data.objectList !== null){
					    			if(response.data.statusType === 'success' ){
					    				response.data.objectList.forEach(function(row){
					    					$scope.gridOptions.enablePaginationControls=true;
				    						$scope.gridOptions.data = response.data.objectList;
					    				});
					    				 	
					    			} else {
					    				$scope.gridOptions.enablePaginationControls=false;
					    				$scope.alerts = [];
							            $scope.alerts.push({
							                type : response.data.statusType,
							                msg : response.data.statusMessage,
							                error : response.data.exceptionStackTrace,
							                errorClsName : response.data.exceptionClassName,
							                errorMsg : response.data.exceptionMessage
							            });
					    			}
					    			$.unblockUI();
					    		} else {
					    			$scope.searchDataEror=response.data.statusMessage;	    			
						            $.unblockUI();
					    		}
					    	});
					
					    };
					    
					    $scope.summaryGridOptions = {
								 enablePaginationControls:false,
								 enableGridMenu: true,
					             enableFiltering: true,            
					             enableColumnResize: true,
					             enableCellEditOnFocus: true,
					             paginationPageSizes: [100,250,500,750,1000],
					     	     paginationPageSize: 100,         
					             useExternalPagination: true,
					             autoResize:true,
					             enableSorting: true,
					             enableColumnMenus: false,
					             enablePinning: true,            
					             columnDefs: [
					                          { field: 'cycleCountDate', displayName: 'Cycle Count Date', width:150, enableCellEdit:true },
					                          { field: 'aorb', displayName: 'A/B', width:100, enableCellEdit: true },
					                          { field: 'partType', displayName: 'Part Type', width:220, enableCellEdit:true },
					                          { field: 'partNumber', displayName: 'Part Number', width:180, enableCellEdit:true },
					                          //{ field: 'partName', displayName: 'Part Name', width:220, enableCellEdit:false },
								       	      { field: 'supplierCode', displayName: 'Supplier Name', width:220, enableCellEdit:true},
					                          { field: 'shop', displayName: 'Shop', width:180, enableCellEdit:true},
					                          { field: 'partClass', displayName: 'Class', width:180, enableCellEdit: true},
					                          { field: 'systemStock', displayName: 'System Stock', width:180, enableCellEdit: true},
					                          { field: 'physicalStock', displayName: 'Physical Stock', width:100, enableCellEdit:true },
					                          { field: 'adjustedQuantity', displayName: 'Qty Adjusted', width:100,enableCellEdit:true },
					                          { field: 'unitPrice', displayName: 'Unit Price', width:100, enableCellEdit:true },
					                          { field: 'cost', displayName: 'Cost Impact', width:100, enableCellEdit:true },
					                          { field: 'reasonCode', displayName: 'Reason Code', width:100,enableCellEdit:true },
					                          { field: 'counterMeasure', displayName: 'Counter Measure', width:100,enableCellEdit:true },
					                          
					                        ],
					                        exporterMenuVisibleData: false,
							    };
					    
					    

					    $scope.openModalTable=function(formId,formStatus){
					    	$scope.pageData.formID = formId;
							if(formStatus == 'Reviewed' || formStatus == 'Submitted' || formStatus == 'Rejected' || formStatus == 'Approved') {
								formRequirementSearchService.getFormData($scope.pageData).then(function(response){
						    		console.log("other status"+response);
						    		if(response.data.objectList !== undefined && response.data.objectList !== null && response.data.statusMessage !== "No Data Found !!!"){
						    			$scope.viewGridData(response);
						    		}
						    	});
							}else if(formStatus == 'Saved') {
							//if('Saved') {
						    		approvalGridOptions = {};
						    		formRequirementSearchService.getFormData($scope.pageData).then(function(response){
							    		console.log("saved response"+response);
							    		if(response.data.objectList !== undefined && response.data.objectList !== null && response.data.statusMessage !== "No Data Found !!!"){
							    		
							    			$scope.savedGridData(response);
							    		}
						    		});
					    	}
						};
					    
					    $scope.savedGridData = function(response) {
							$scope.gridOptions.data = [];
							if (response.data.objectList !== undefined && response.data.objectList !== null) {
								if (response.data.statusType === 'success') {
									$scope.gridOptions.enablePaginationControls = true;
									var loginUser= $window.localStorage.getItem('username');
				    				var createdBy = response.data.objectList.createdBy;
				    				if(createdBy != loginUser) {
				    					saveOtherStatus();
				    					document.getElementById('reject').disabled = "disabled";
				    					document.getElementById('approve').disabled = "disabled";
				    					document.getElementById('cancel').disabled = "disabled";
				    					return;
				    				}
				    				$scope.gridOptions.enablePaginationControls=true;
				    				var formRequirementDefaultReviewerObject = {};
				    				var formRequirementAdditionalReviewerObject = {};
				    				var formRequirementAttachmentObject = {};
				    				var formRequirementApprovalObject = {};
				    				
				    				angular.forEach(response.data.objectList[1], function(formRequirementCreateFetchObject, formRequirementCreateFetchKey){
						    					var objectArray = {};
						    					console.log(formRequirementCreateFetchObject)
						    					if(formRequirementCreateFetchObject.cycleCountDate!=null) {
						    						objectArray.cycleCountDate = formRequirementCreateFetchObject.cycleCountDate;
						    					}
						    					//objectArray.aorb = formRequirementCreateFetchObject.aorb;
						    					if(formRequirementCreateFetchObject.partType!=null) {
						    						objectArray.partType = formRequirementCreateFetchObject.partType;
						    					}
						    					if(formRequirementCreateFetchObject.partNumber!=null) {
						    						objectArray.partNumber = formRequirementCreateFetchObject.partNumber;
						    					}
						    					//objectArray.partName = formRequirementCreateFetchObject.partName;
						    					if(formRequirementCreateFetchObject.supplierCode!=null) {
						    						objectArray.supplierCode = formRequirementCreateFetchObject.supplierCode;
						    					}
						    					if(formRequirementCreateFetchObject.shop!=null) {
						    						objectArray.shop = formRequirementCreateFetchObject.shop;
						    					}
						    					if(formRequirementCreateFetchObject.partClass!=null) {
						    						objectArray.partClass = formRequirementCreateFetchObject.partClass;
						    					} 
						    					if(formRequirementCreateFetchObject.systemStock!=null) {
						    						objectArray.systemStock = formRequirementCreateFetchObject.systemStock;
						    					}
						    					if(formRequirementCreateFetchObject.physicalStock!=null) {
						    						objectArray.physicalStock = formRequirementCreateFetchObject.physicalStock;
						    					}
						    					if(formRequirementCreateFetchObject.adjustedQuantity!=null) {
						    						objectArray.adjustedQuantity = formRequirementCreateFetchObject.adjustedQuantity;
						    					}
						    					if(formRequirementCreateFetchObject.unitPrice!=null) {
						    						objectArray.unitPrice = formRequirementCreateFetchObject.unitPrice;
						    					}
						    					if(formRequirementCreateFetchObject.cost!=null) {
						    						objectArray.cost = formRequirementCreateFetchObject.cost;
						    					}
						    					if(formRequirementCreateFetchObject.reasonCode!=null) {
						    						objectArray.reasonCode = formRequirementCreateFetchObject.reasonCode;
						    					}
						    					if(formRequirementCreateFetchObject.counterMeasure!=null) {
						    						objectArray.counterMeasure = formRequirementCreateFetchObject.counterMeasure;
						    					}
						    					
						    					summaryList.push(objectArray);
						    					
						    					$scope.summaryGridOptions.data = summaryList;
						    					
						    					if(response.data.statusMessage == "Failure") {
						    						$scope.gridOptions.enablePaginationControls=false;
								    				$scope.alerts = [];
										            $scope.alerts.push({
										                type : response.data.statusType,
										                msg : response.data.statusMessage,
										                error : response.data.exceptionStackTrace,
										                errorClsName : response.data.exceptionClassName,
										                errorMsg : response.data.exceptionMessage
										            });
						    					}
						    					
						    					 $.unblockUI();
						    				});
				    				
				    				angular.forEach(response.data.objectList[2], function(formRequirementReviewerListObject, formRequirementCreateFetchKey){
				    					console.log(formRequirementReviewerListObject.reviewerType)
				    					if(formRequirementReviewerListObject.reviewerType == 'DefaultReviewer') {
				    						var obj = {};
				    						obj.empId = formRequirementReviewerListObject.employeeID;
				    						obj.empName = formRequirementReviewerListObject.reviewerName;
				    						$scope.defaultReviewerList.push(obj);
				    						console.log("default reviewer"+$scope.defaultReviewerList)
				    					}
				    					
				    					if(formRequirementReviewerListObject.reviewerType == 'AdditionalReviewer') {
				    						var obj = {};
				    						obj.empId = formRequirementReviewerListObject.employeeID;
				    						obj.empName = formRequirementReviewerListObject.reviewerName;
				    						$scope.additionalReviewerList.push(obj);
				    						console.log("additional Reviewer"+$scope.additionalReviewerList)
				    					}
				    					if(formRequirementReviewerListObject.reviewerType == 'Approver') {
				    						var obj = {};
				    						obj.empId = formRequirementReviewerListObject.employeeID;
				    						obj.empName = formRequirementReviewerListObject.reviewerName;
				    						$scope.approverList.push(obj);
				    						console.log("approver"+$scope.approverList)
				    					}
				    					if(response.data.statusMessage == "Failure") {
				    						$scope.gridOptions.enablePaginationControls=false;
						    				$scope.alerts = [];
								            $scope.alerts.push({
								                type : response.data.statusType,
								                msg : response.data.statusMessage,
								                error : response.data.exceptionStackTrace,
								                errorClsName : response.data.exceptionClassName,
								                errorMsg : response.data.exceptionMessage
								            });
				    					}
				    					
				    					 $.unblockUI();
				    				});
				    				
				    				angular.forEach(response.data.objectList[3], function(formRequirementDocumentObject, formRequirementCreateFetchKey){
				    					if(formRequirementDocumentObject.documentName!=null) {
				    						var attachmentObjectArray= {};
					    					attachmentObjectArray.id = formRequirementDocumentObject.id;
				    						attachmentObjectArray.documentName = formRequirementDocumentObject.documentName;
				    						attachmentObjectArray.documentPath = formRequirementDocumentObject.documentPath;
				    						$scope.attachmentListArray.push(attachmentObjectArray);
				    					}
				    					if(response.data.statusMessage == "Failure") {
				    						$scope.gridOptions.enablePaginationControls=false;
						    				$scope.alerts = [];
								            $scope.alerts.push({
								                type : response.data.statusType,
								                msg : response.data.statusMessage,
								                error : response.data.exceptionStackTrace,
								                errorClsName : response.data.exceptionClassName,
								                errorMsg : response.data.exceptionMessage
								            });
				    					}
				    					
				    					 $.unblockUI();
				    				});
								
								} else {
									$scope.gridOptions.enablePaginationControls = false;
									$scope.alerts = [];
									$scope.alerts.push({
									    type : response.data.statusType,
									    msg : response.data.statusMessage,
									    error : response.data.exceptionStackTrace,
									    errorClsName : response.data.exceptionClassName,
									    errorMsg : response.data.exceptionMessage
									});
								}
								$.unblockUI();
							} else {
								$scope.searchDataEror = response.data.statusMessage;
								$.unblockUI();
							}
						};
						
						$scope.editFormData = function() {
							$scope.summaryGridOptions.enableCellEditOnFocus= true;
							$scope.summaryGridOptions.columnDefs.enableCellEdit=true;
						};
					    
						
					    $scope.viewGridData =  function(response) {
							$scope.approvalGridOptions.data = [];
							if (response.data.objectList !== undefined && response.data.objectList !== null) {
								if (response.data.statusType === 'success') {
									$scope.approvalGridOptions.enablePaginationControls = true;
									$scope.approvalGridOptions.data = response.data.objectList;
								} else {
									$scope.gridOptions.enablePaginationControls = false;
									$scope.alerts = [];
									$scope.alerts.push({
									    type : response.data.statusType,
									    msg : response.data.statusMessage,
									    error : response.data.exceptionStackTrace,
									    errorClsName : response.data.exceptionClassName,
									    errorMsg : response.data.exceptionMessage
									});
								}
								$.unblockUI();
							} else {
								$scope.searchDataEror = response.data.statusMessage;
								$.unblockUI();
							}
						};
					 /*$scope.download = function(formID) {
						 $scope.searchPageData.formID = formID;
						 formRequirementSearchService.downloadFormSearchDataAsPDF(searchPageData).then(function(response){
							 $scope.gridOptions.data = [];
					    		console.log(response.data.objectList.length);
					    		if(response.data.objectList !== undefined && response.data.objectList !== null){
					    			if(response.data.statusType === 'success' ){
					    				formrequirementSearchService.getFile(response.data.objectList).then(function(response){
					    					
					    				})
					    			} else {
					    				$scope.gridOptions.enablePaginationControls=false;
					    				$scope.alerts = [];
							            $scope.alerts.push({
							                type : response.data.statusType,
							                msg : response.data.statusMessage,
							                error : response.data.exceptionStackTrace,
							                errorClsName : response.data.exceptionClassName,
							                errorMsg : response.data.exceptionMessage
							            });
					    			}
					    			$.unblockUI();
					    		} else {
					    			$scope.searchDataEror=response.data.statusMessage;	    			
						            $.unblockUI();
					    		} 
						 });
					 }*/
					// Clear the filter
					$scope.clearFilters = function() {
						$scope.gridApi.core.clearAllFilters();
				    };
				    
		}]);