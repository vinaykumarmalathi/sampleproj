wmsApp.controller('AgingAndAgedRanController', 
		[ '$scope','$window','$filter', '$location','$q', 'agedAgingService','locationService','uiGridTreeViewConstants', '$http','commonService','localStorageService','partNumberService','ranService',
        function($scope,$window,$filter, $location,$q, agedAgingService,locationService,uiGridTreeViewConstants, $http,commonService,localStorageService,partNumberService,ranService) {
			$scope.searchDataEror="Click search to fetch records.";
		    $scope.fromMaxDate=new Date();
               $scope.shiftDropdown=false;
			   $scope.endDate = null;
			   //$scope.endDate.setDate($scope.endDate.getDate()+14);
			   $scope.toMinDate = new Date();
			   $scope.toMinDate.setDate($scope.fromMaxDate.getDate()+14); 
			   $scope.transactionList = ["In", "Out"];	
			   $scope.shiftList = ["A", "B" ,"C"];
			    $scope.beginDatePickerOpen = false;
			    $scope.endDatePickerOpen = false;
			    
			    $scope.beginDate = null;
			    $scope.openBeginDatePicker = function ($event) {			    	
			    $event.preventDefault();
			    $event.stopPropagation();
			    $scope.beginDatePickerOpen = !$scope.beginDatePickerOpen;
			    };

			    $scope.openEndDatePicker = function ($event) {
			    $event.preventDefault();
			    $event.stopPropagation();
			    $scope.endDatePickerOpen = !$scope.endDatePickerOpen;			  
			    };
			 
			    
			
			// --------- Part Number List ---------
			$scope.partNumber='';
			$scope.searchClicked=false;
			$scope.tags=[];	 
			/*ON ADD NEW PART TAG*/
			$scope.transactionList= ["In", "Out"];
			$scope.tagAdded = function(tag) {
				
				  $scope.partArray = [];
				  
				     for (var j=0; j < $scope.tags.length; j++) {
				    	 
				    	 $scope.partArray.push($scope.tags[j].text);
				    	 console.log("Part Array",$scope.partArray);
				      }
				     $scope.partNumber=$scope.partArray.join(',');
				     console.log("Part Number",$scope.partNumber);
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			/*ON REMOVE ADDED PART TAG*/
			    
		    $scope.tagRemoved = function(tag) {			   
		    	 $scope.partArray = [];
			     for (var j=0; j < $scope.tags.length; j++) {

			    	 $scope.partArray.push($scope.tags[j].text);
			      }
			     $scope.partNumber=$scope.partArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    $scope.addingTag = function(tag) {
		    	console.log("Tag.text",tag.text);
		    	  tag.text = tag.text.replace(/ /g, ',');
		    	  console.log("Tag.text 2",tag.text);
		    	  return tag;
		    	};
		    	
			
		    /*AUTOCOMPLE PART ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadParts = function(query) {		    	
		    	var partInputObj = {"partNumber": query};			    	
		    	return partNumberService.partNumberList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    });			    				         
		    };
			    
			  
		    /*ON ADD NEW LOCATION TAG*/
		    
			$scope.location="";
			$scope.locationIdData=[];	 
		    $scope.locationAdded = function(tag) {					
		    $scope.locationArray = [];
			    for (var j=0; j < $scope.locationIdData.length; j++) {
			    	$scope.locationArray.push($scope.locationIdData[j].text);
			    }
			    $scope.location=$scope.locationArray.join(',');
			    $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    /*ON REMOVE ADDED LOCATION TAG*/
		    
		    $scope.locationRemoved = function(tag) {			   
		    	 $scope.locationArray = [];
			     for (var j=0; j < $scope.locationIdData.length; j++) {
			    	 $scope.locationArray.push($scope.locationIdData[j].text);
			     }
			     $scope.location=$scope.locationArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    /* RAN Auto Completion - Start */
		    $scope.ranData=[];	
		    
		    $scope.ranAdded = function(tag) {			
				console.log("tagAdded:",tag);
				  $scope.ranArray = [];
				     for (var j=0; j < $scope.ranData.length; j++) {
				    	 $scope.ranArray.push($scope.ranData[j].text);
				      }
				     $scope.agedAgingRan.ran=$scope.ranArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			};
		    
		    $scope.ranRemoved = function(tag) {			   
		    	 $scope.ranArray = [];
			     for (var j=0; j < $scope.ranData.length; j++) {

			    	 $scope.ranArray.push($scope.ranData[j].text);
			      }
			     $scope.agedAgingRan.ran=$scope.ranArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    $scope.loadRan = function(query) {
		    	var partInputObj = {"ranId": query};
		    	return ranService.getRanFmRANTbl(partInputObj).then(function(response){
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){	
		        			 console.log(response.data.object);
		        			  return response.data.object;                           
		        		 }
		        	 }		    		
			    });	
		    };
		    
		   /* $scope.pasteRanTags = function(event){
				  event.preventDefault();
				  
				  //For IE
				  if ($window.clipboardData && $window.clipboardData.getData) {
					  $scope.tagsCopies = $window.clipboardData.getData('Text').split(/[,\n\t\s]+/);
					  console.log("IE");
					  console.log("$scope.tagsCopies",$scope.tagsCopies);
				  }
				  // Other Browsers
				  else if (event.originalEvent.clipboardData && event.originalEvent.clipboardData.getData) { 
					  $scope.tagsCopies = event.originalEvent.clipboardData.getData('text/plain').split(/[,\n\t\s]+/);
					  console.log("Other Browser");
					  console.log("$scope.tagsCopies",$scope.tagsCopies);
				  }
			      
			      $scope.tagsCopies = $scope.findDuplicate($scope.tagsCopies);
			      $scope.partNumberArray = [];
			      if($scope.agedAgingRan.ran != undefined){
			    	  $scope.partNumberArray = $scope.agedAgingRan.ran.split(',');
			      }
			      for (var j=0; j < $scope.tagsCopies.length; j++) {
			    	      var obj = {};
			    	      // Condition to check if string is not empty and whitespace
			    	      $scope.tagsCopies[j] = $scope.tagsCopies[j].trim();
			    	      // Checking duplication for copy content with existing tags
			    	      var Index = $scope.partNumberArray.indexOf($scope.tagsCopies[j]);
			    	      if($scope.tagsCopies[j] != "" && Index == -1){
			    	    	  obj['text'] = $scope.tagsCopies[j];
			    	    	  $scope.ranData.push(obj);
			    	    	  $scope.ranAdded(obj);
			    	      }
				  }
			      setTimeout(function(){
			    	    $scope.$digest();
			      }, 100);
			     
			};*/
		    /*RAN Auto Completion - End */
		    
		    
		 // --------- Location drop down list -------

			  if($window.sessionStorage.getItem('locationDPCollection') == null || $window.sessionStorage.getItem('locationDPCollection')=='undefined' || $window.sessionStorage.getItem('locationDPCollection')==undefined){
				  commonService.getAllPlants()
				  .success(function(response){					 
					  $scope.locations = response.objectList;				
					  $window.sessionStorage.setItem('locationDPCollection',JSON.stringify($scope.locations));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.locations = JSON.parse(sessionStorage.locationDPCollection);
			  }
			  
			  // --------- Section drop down list ---------

			  if($window.sessionStorage.getItem('sectionDPCollection') == null || $window.sessionStorage.getItem('sectionDPCollection')=='undefined' || $window.sessionStorage.getItem('sectionDPCollection')==undefined){
				  commonService.getAllSections()
				  .success(function(response){					 
					  $scope.sections = response.objectList;	
					  $window.sessionStorage.setItem('sectionDPCollection',JSON.stringify($scope.sections));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.sections = JSON.parse(sessionStorage.sectionDPCollection);
			  }
			  
			// --------- Shops drop down list ---------
			  
			    $scope.loadShopLine = function(){
			    	 $scope.agedAgingRan.line = '';
			    	 $scope.agedAgingRan.shop = '';
			    	 commonService.getLineList($scope.agedAgingRan.plant)
					  .success(function(response){
						  $scope.lines = response.objectList;				
					  })
					  .error(function(response){
					  });
			    	 commonService.getShopList($scope.agedAgingRan.plant)
					  .success(function(response){
						  $scope.shops = response.objectList;				
					  })
					  .error(function(response){
					  });

			    }
			   
			  /*if($window.sessionStorage.getItem('shopDPCollection') == null || $window.sessionStorage.getItem('shopDPCollection')=='undefined' || $window.sessionStorage.getItem('shopDPCollection')==undefined){
				  commonService.getAllShop()
				  .success(function(response){						  
					  $scope.shops = response.objectList;				
					  $window.sessionStorage.setItem('shopDPCollection',JSON.stringify($scope.shops));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.shops = JSON.parse(sessionStorage.shopDPCollection);
			  }*/
			 // --------- Line drop down list ---------

			  /*if($window.sessionStorage.getItem('linesDPCollection') == null || $window.sessionStorage.getItem('linesDPCollection')=='undefined' || $window.sessionStorage.getItem('linesDPCollection')==undefined){
				  commonService.getAllLines()
				  .success(function(response){					 
					  $scope.lines = response.objectList;
					  $window.sessionStorage.setItem('linesDPCollection',JSON.stringify($scope.lines));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.lines = JSON.parse(sessionStorage.linesDPCollection);
			  }*/
		    
				    
		    /*AUTOCOMPLE LOCATION ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadLocation = function(query) {
		    	
		    	var locationInputObj = {"locationId": query};			    	
		    	return locationService.locationList(locationInputObj).then(function(response){	
		    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    	});			    				         
		    };
			    			    		  
		    $scope.agedAgingRan = {				
		    	  partNo : $scope.partNumber,
                  ran : $scope.auditRAN,
                  location : $scope.location,
                  startIndex : 0,
                  maxResult : 0
              };
			
		    $scope.agedAgingRan.reportType = "1";
			
			 var paginationOptions = {
				 	startIndex : 0,
				 	maxResult : 0,
				    pageNumber: 1,
				    pageSize: 100,
				    sort: null
				  };
			 
		
			 //Grid
			 $scope.gridOptions = {
			 enablePaginationControls:false,
			 enableGridMenu: true,
             enableFiltering: true,            
             enableColumnResize: true,
             paginationPageSizes: [100,250,500,750,1000],
     	     paginationPageSize: 100,         
             useExternalPagination: true,
             autoResize:true,
             enableSorting: true,
             enableColumnMenus: false,
             enablePinning: true,            
             columnDefs: [
                          { field: 'ran', displayName: 'RAN' },
                          { field: 'partNo', displayName: 'Part Number'},                          
			       	     /* { field: 'mfgDate', displayName: 'MfgDate'},*/
                          { field: 'mfgDate', displayName: 'Shipping Date'},
			       	      { field: 'lppd', displayName: 'LPPD'},
			       	      { field: 'location', displayName: 'Location'},
			       	      { field: 'stock', displayName: 'Stock'}
                        ],
                        exporterPdfAlign:'left',
                        exporterCsvFilename: 'AgedAgingDetailsReport.csv',
                        exporterMenuVisibleData: false,
                        exporterPdfDefaultStyle: {fontSize: 9},
                        exporterPdfTableStyle: {margin: [70, 5, 0, 5]},
                        exporterPdfTableHeaderStyle: {fontSize: 10, bold: true, italics: true, color: 'red'},
                        exporterPdfHeader: { text: "Aged Aging Ran Report", style: 'headerStyle' },
                        exporterPdfFooter: function ( currentPage, pageCount ) {
                          return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
                        },
                        exporterPdfCustomFormatter: function ( docDefinition ) {
                        	 docDefinition.styles.headerStyle = { fontSize: 20, bold: true, alignment: 'center', margin: [0, 0, 20, 0] }; 
                             docDefinition.styles.footerStyle = { fontSize: 10, bold: true, alignment: 'center',  margin: [5, 0, 20, 0] }; 
                          return docDefinition;
                        },
                        exporterPdfOrientation: 'landscape',
                        exporterPdfPageSize: 'LETTER',
                        exporterPdfMaxGridWidth: 500,
                        exporterPdfFilename: 'AgedAgingRanDetailsReport.pdf',
                        exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
                       
                        onRegisterApi: function( gridApi ) {
                        	 $scope.gridApi = gridApi;
                        	 //Pagination
                        	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                        		 $scope.blockUI();
             		          paginationOptions.pageNumber = newPage;
             		          paginationOptions.pageSize = pageSize;
             		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
             		        paginationOptions.maxResult   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
             		        $scope.load();
             		        });
                        
                	    }
		    };
			 
			 $scope.gridOptions.exporterFieldCallback = function ( grid, row, col, value ){
				 
				 if ( col.name === 'partInOutTime' || col.name === 'scanTime'){					 	
					    value =  $filter('date')(value, 'dd/MM/yyyy HH:mm:ss');					   
					}				      
				  return value;
				 
			 };
 // Clear the filter
	 $scope.clearFilters = function() {
		 $scope.gridApi.core.clearAllFilters();
     };
// Reset the values
	    $scope.resetData = function(){
	    	$scope.shops = "";
	    	$scope.lines = "";
	    	$scope.beginDate = null;
			$scope.endDate = null;
			//$scope.endDate.setDate($scope.endDate.getDate()+14); 
			$scope.fromMaxDate=new Date();
			$scope.toMinDate.setDate($scope.fromMaxDate.getDate()+14); 
	    	$scope.gridOptions.data = [];
	    	$scope.clearFilters();	  
	    	$scope.agedAgingRan = {};
	    	$scope.agedAgingRan.reportType = "1";
	    	$scope.partNumber="";	    	
	    	$scope.agedAgingRan.startIndex = 0;
	    	$scope.agedAgingRan.maxResult = 0;
	    	$scope.tags=[];
	    	$scope.ranData=[];
	    	$scope.locationIdData=[];	
	    	$scope.gridOptions.totalItems=0;
	    	$scope.location="";
	    	$scope.partNumber="";
	    	$scope.gridOptions.enablePaginationControls=false;	 
	    	$scope.searchDataEror="Click search to fetch records.";
	    	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    $scope.shiftDropdown=false;
	    };	    
     $scope.agedAgingRanData = function(){    	    	 
    	 agedAgingService.getAgedAgingRAN($scope.agedAgingRan).then(function(response){
	    		$scope.gridOptions.data = [];
	    		if(response.objectList !== undefined && response.objectList !== null && response.statusMessage !== "No Data Found !!!"){
	    			
	    			if(response.statusType === 'success' ){
	    				$scope.gridOptions.enablePaginationControls=true;
	    				$scope.masterData = response.objectList;
	    				
	    				//Dummy For Local development Check
//	    				$scope.masterData = [{
//	    					"ran": "3MCHE02",
//	    					"partNo": "802856681R",
//	    					"lppd": "2017-01-08",
//	    					"mfgDate": "2015-12-18",
//	    					"stock": "1542"
//	    				}, {
//	    					"ran": "3MCHE06",
//	    					"partNo": "822839162R",
//	    					"lppd": "2017-01-08",
//	    					"mfgDate": "2015-12-18",
//	    					"stock": "128"
//	    				}, {
//	    					"ran": "3MCHE02",
//	    					"partNo": "7703179099",
//	    					"lppd": "2017-01-10",
//	    					"mfgDate": "2016-01-13",
//	    					"stock": "4"
//	    				}];
	    				
	    				$scope.AgingAndAgedData = [];
	    				
	    				//Finding Duplicate RAN in list
	    				$scope.checkIfArrayIsUnique($scope.masterData);
	    				//End
	    				
	    				for (var i = 0; i < $scope.masterData.length; i++) {
	    					var rowObj = {};
	    					if($scope.masterData[i].isDuplicate == false){
	    						rowObj["ran"] = $scope.masterData[i].ran;
	    						$scope.childRecords = [];
	    						var stackCount = [];
	    						// Creating child Record
	    						for (var j = 0; j < $scope.masterData.length; j++) {
	    							if(rowObj.ran == $scope.masterData[j].ran){
	    								var childRowObj = {};
	    								stackCount.push(Number($scope.masterData[j].stock));
	    								childRowObj["partNo"] = $scope.masterData[j].partNo;
	    								childRowObj["lppd"] = $scope.masterData[j].lppd;
	    								childRowObj["mfgDate"] = $scope.masterData[j].mfgDate;
	    								childRowObj["stock"] = $scope.masterData[j].stock;
	    								childRowObj["location"] = $scope.masterData[j].location;
	    								$scope.childRecords.push(childRowObj);
	    							}
	    						}
	    						// StockCount
	    						rowObj["stock"] = stackCount.reduce($scope.sumStackCount, 0);
	    						rowObj["childRecords"] = $scope.childRecords;
	    						//Adding child Records to Main List
	    						$scope.AgingAndAgedData.push(rowObj);
	    					}
	    				}
	    				// Method for tree view creation in Data grid
	    				writeoutNode($scope.AgingAndAgedData, 0, $scope.gridOptions.data);
	    			} else {
	    				$scope.gridOptions.enablePaginationControls=false;
	    				$scope.alerts = [];
			            $scope.alerts.push({
			                type : response.statusType,
			                msg : response.statusMessage,
			                error : response.exceptionStackTrace,
			                errorClsName : response.exceptionClassName,
			                errorMsg : response.exceptionMessage
			            });
	    			}
	    			$.unblockUI();
	    		} else {
	    			$scope.searchDataEror=response.statusMessage;	    			
		            $.unblockUI();
	    		}
	    	});
     };
     
			$scope.sumStackCount = function(a, b) {
			    return a + b;
			};
			
			$scope.checkIfArrayIsUnique =function(myArray) 
		    {
		        for (var i = 0; i < myArray.length; i++) 
		        {
		        	myArray[i]["isDuplicate"] = false;
		            for (var j = i+1; j < myArray.length; j++) 
		            {                  
		                    if (myArray[i].ran == myArray[j].ran) 
		                    {
		                        myArray[i]["isDuplicate"] = true;
		                    }

		            }
		        }
		    };
		    
		     /* Tree view */
		     var writeoutNode = function( childArray, currentLevel, dataArray ){
					if (typeof childArray !== 'undefined') {					
					      childArray.forEach(function(childNode) {
					        if (typeof childNode.childRecords !== 'undefined') {
					          if (childNode.childRecords.length >= 0) {
					            childNode.$$treeLevel = currentLevel;
					          }
					        }
					        dataArray.push(childNode);
					        writeoutNode(childNode.childRecords, currentLevel + 1, dataArray);
					      });
					    }
			};
		
	 		/* Load data in grid */
		    $scope.load = function () {
		    	$scope.agedAgingRan.maxResult = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

		    	if(paginationOptions.maxResult === 0){
		    		$scope.agedAgingRan.maxResult = $scope.gridOptions.paginationPageSize;
		    	}
		    	$scope.agedAgingRan.startIndex = paginationOptions.startIndex;
		    	$scope.agedAgingRan.maxResult = paginationOptions.pageSize;
		    	$scope.agedAgingRan.location = $scope.location;
		    	$scope.agedAgingRan.partNo = $scope.partNumber;
		    	$scope.agedAgingRan.fromDate = $scope.fromDate;
		    	$scope.agedAgingRan.toDate = $scope.toDate;
		    	
		    	agedAgingService.getAgedAgingRANCount($scope.agedAgingRan).then(function(response){
		    		$scope.gridOptions.totalItems = response.object;		    		
		    		$scope.recordCount = response.object;		    		
		    		$scope.agedAgingRanData();
		    	});
		    	
		    };
		    
		    // --------- search button ---------
            $scope.searchData = function() {
            	if($scope.beginDate <= $scope.endDate){
            		$scope.blockUI();
            		$scope.fromDate = $filter('date')($scope.beginDate, 'yyyy-MM-dd');
            		$scope.toDate = $filter('date')($scope.endDate, 'yyyy-MM-dd');
            		
            		$scope.alerts = [];
            		$scope.gridOptions.data = [];
            		$scope.agedAgingRan.partNo=$scope.partNumber;
            		$scope.agedAgingRan.location=$scope.location;
            		paginationOptions.startIndex= 0;
            		paginationOptions.maxResult= 0;
            		paginationOptions.pageNumber= 1;
            		paginationOptions.pageSize= 100; 
            		$scope.gridOptions.paginationCurrentPage=1;
            		$scope.gridOptions.paginationPageSize=100;
            		$scope.searchClicked=true;
            		$scope.clearFilters();                	
            		$scope.load();
            		$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
            	}else{
            		$scope.alerts = [];
	       			$scope.alerts.push({
	       				 type : 'danger',
	       				 msg : 'To Date should not be smaller than From Date'
	       			});
            	}
            };
		    
            
            $scope.downloadRAN =function(){
            	$scope.blockUI();
		    	$scope.agedAgingRan.partNo=$scope.partNumber;
            	return agedAgingService.getAgedAgingRANDownload($scope.agedAgingRan).then(function(response){
            		if(response.objectList != null){
            			for (var i = 0; i < response.objectList.length; i++) {
            				response.objectList[i].partNumber = '="'+response.objectList[i].partNo+'"';
            				/*response.objectList[i].mfgDate = response.objectList[i].mfgDate;
            				response.objectList[i].lppd = response.objectList[i].lppd;*/
            				
            			}
            			$.unblockUI();
            			return response.objectList;
            		}else{
            			$scope.alerts = [];
    	       			$scope.alerts.push({
    	       				 type : 'danger',
    	       				 msg : 'Data is not available'
    	       			});
            		}
            		$.unblockUI();
            	});
        
            };
         
            $scope.getDownloadRANReportHeader = function () {
            	/*return ["Ran","Part Number","Mfg Date","Lppd","Location","Stock"];//Shipping Date*/
            	 return ["Ran","Part Number","Shipping Date","Lppd","Location","Stock"];//Shipping Date
           };
           $scope.csvColumnOrder=['ran','partNumber','mfgDate','lppd','location','stock'];
           
			//Close the alert msg
            $scope.closeAlert = function(index) {
		        $scope.alerts.splice(index, 1);
		    };
		    
		    $scope.selectEndDate = function(endDate) {		    	
		    	//$scope.fromMaxDate=$filter('date')(endDate, 'yyyy-MM-dd');
		    	if($filter('date')(endDate, 'yyyy-MM-dd')== $filter('date')($scope.beginDate, 'yyyy-MM-dd')){
		    		$scope.shiftDropdown=false;
		    	}else{
		    		$scope.shiftDropdown=true;
		    	}		    	
		    };
		    
		    $scope.selectStartDate = function(startDate) {		    	
		    	if($filter('date')(startDate, 'yyyy-MM-dd')== $filter('date')($scope.endDate, 'yyyy-MM-dd')){
		    		$scope.shiftDropdown=false;
		    	}else{
		    		$scope.shiftDropdown=true;
		    	}		    	
		    };
		    
		    $scope.setDates = function(){
		    	if($scope.agedAgingRan.reportType == "1"){
		    		$scope.beginDate = null;
		    		$scope.endDate = null;
		    	}else{
		    		$scope.beginDate = new Date();
		    		$scope.endDate = new Date();
		    		$scope.endDate.setDate($scope.fromMaxDate.getDate()+14);
		    	}
		    };
		     
} ]);

wmsApp.factory('agedAgingService',['commonService','$http','$q',function(commonService,$http,$q){
    var fact={};
	fact.getAgedAgingRAN=function(part)
    {    
    	var deferred = $q.defer();
        $http({
			method : 'POST',
			url : 'rest/agedRan/getAgedAgingRAN',
			data : part,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			 deferred.resolve(data);
			
		});
        return deferred.promise;
				
	};
	
	fact.getAgedAgingRANCount=function(part)
    {    
    	var deferred = $q.defer();
        $http({
			method : 'POST',
			url : 'rest/agedRan/getAgedAgingRANCount',
			data : part,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			 deferred.resolve(data);
			
		});
        return deferred.promise;
				
	};
	
	fact.getAgedAgingRANDownload=function(part)
    {    
    	var deferred = $q.defer();
        $http({
			method : 'POST',
			url : 'rest/agedRan/getAgedAgingRANDownload',
			data : part,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			 deferred.resolve(data);
			
		});
        return deferred.promise;
				
	 };
	
	return fact;
	
	
}]);