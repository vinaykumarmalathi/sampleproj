wmsApp.controller('liveReceiptQuantityMismatchController',
		[ '$scope','$window','$filter', '$location','$q', 'liveReceiptQuantityMismatchService','locationService','uiGridTreeViewConstants', '$http','commonService','localStorageService','partNumberService','ranService','lineFeedingDetailsService',
	        function($scope,$window,$filter, $location,$q, liveReceiptQuantityMismatchService,locationService,uiGridTreeViewConstants, $http,commonService,localStorageService,partNumberService,ranService,lineFeedingDetailsService) {
			$scope.searchDataError="Click search to fetch records.";
				    
		    $scope.auditBeginDate=new Date();
		    $scope.auditEndDate=new Date();
		    
		    $scope.fromMaxDate=new Date();
		    $scope.todayDate = new Date();
		    
		   
		    
		    var numberOfDaysToAdd = 180; 
		    
		    $scope.fromMaxDate.setDate($scope.fromMaxDate.getDate() - numberOfDaysToAdd); 
		    console.log("$scope.fromMaxDate : " +$scope.fromMaxDate);
		    
		    var myDate = new Date();		    
		    var previousMonth = new Date(myDate);
		    previousMonth.setMonth(myDate.getMonth()-1);		    
		    console.log("previousMonth : " +previousMonth);

		    var nextMonth = new Date(myDate);
		    nextMonth.setMonth(myDate.getMonth()+1);		    
		    console.log("nextMonth : " +nextMonth);
		    
		    $scope.auditBeginDatePickerOpen = false;
		    $scope.auditEndDatePickerOpen = false;
			    
			    $scope.openAuditBeginDatePicker = function ($event) {			    	
		    		$event.preventDefault();
		    		$event.stopPropagation();
		    		$scope.auditBeginDatePickerOpen = !$scope.auditBeginDatePickerOpen;
			    };

			    $scope.openAuditEndDatePicker = function ($event) {
			    	$event.preventDefault();
			    	$event.stopPropagation();
			    	$scope.auditEndDatePickerOpen = !$scope.auditEndDatePickerOpen;			  
			    };
			    
			    $scope.liveReceiptQtyMismatch = {	
			    		  plant : '',
						  shop : '',
						  line:'',
						  zone : '',
						  partType : '',
				    	  partNumber : $scope.partNumber,
				    	  supplier : $scope.supplierList,
						  dNote :$scope.dNoteList,
						  containerNo :$scope.cntNoList,
						  recPlace :$scope.recPlaceList,
						  ran:$scope.ranList,
						  receipt:'',
						  /*mismatch:'M',
		                  fromDate : $scope.beginDate,
		                  toDate : $scope.endDate,*/
		                  fromDate : $scope.auditBeginDate,
		                  toDate : $scope.auditEndDate,
		                  fromTime : $scope.beginTime,
		          	      toTime : $scope.endTime,
		                  startIndex : 0,
		                  endIndex : 0,
		                  colName : '',
		                  input : ''
		               
		              };
			    
			    var boxcatsTemplate = '<div> <a href="" ng-show="row.entity.childRecord" data-toggle="modal" data-target="#liveReceiptModal" ng-click=grid.appScope.setId(row.entity.boxRecCats);>{{COL_FIELD}} </a> <span ng-show="!row.entity.childRecord" >{{COL_FIELD}}</span> </div>';
			    var containercatsTemplate = '<div> <a href="" ng-show="row.entity.childRecord" data-toggle="modal" data-target="#liveReceiptModal" ng-click=grid.appScope.setId(row.entity.containerNo);>{{COL_FIELD}} </a> <span ng-show="!row.entity.childRecord" >{{COL_FIELD}}</span> </div>';
 			    var dnotecatsTemplate = '<div> <a href="" ng-show="row.entity.childRecord" data-toggle="modal" data-target="#liveReceiptModal" ng-click=grid.appScope.setId(row.entity.dNote);>{{COL_FIELD}} </a> <span ng-show="!row.entity.childRecord" >{{COL_FIELD}}</span> </div>';
 			    var qtycatsTemplate = '<div> <a href="" ng-show="row.entity.childRecord" data-toggle="modal" data-target="#liveReceiptModal" ng-click=grid.appScope.setId(row.entity.dNoteQty);>{{COL_FIELD}} </a> <span ng-show="!row.entity.childRecord" >{{COL_FIELD}}</span> </div>';
 				var dateCatsTemplate = '<div> <a href="" ng-show="row.entity.childRecord" data-toggle="modal" data-target="#liveReceiptModal"  ng-click=grid.appScope.setId(row.entity.liveReceiptUpdatedTime);>{{COL_FIELD}} </a> <span ng-show="!row.entity.childRecord" >{{COL_FIELD}}</span> </div>';
 				
 				var boxwmsTemplate = '<div> <a href="" ng-show="row.entity.childRecord" data-toggle="modal" data-target="#liveReceiptModal" ng-click=grid.appScope.setId(row.entity.boxRecWms);>{{COL_FIELD}} </a> <span ng-show="!row.entity.childRecord" >{{COL_FIELD}}</span> </div>';
  			    var qtywmsTemplate = '<div> <a href="" ng-show="row.entity.childRecord" data-toggle="modal" data-target="#liveReceiptModal" ng-click=grid.appScope.setId(row.entity.auditQuantity);>{{COL_FIELD}} </a> <span ng-show="!row.entity.childRecord" >{{COL_FIELD}}</span> </div>';
  				var datewmsTemplate = '<div> <a href="" ng-show="row.entity.childRecord" data-toggle="modal" data-target="#liveReceiptModal"  ng-click=grid.appScope.setId(row.entity.auditScanTime);>{{COL_FIELD}} </a> <span ng-show="!row.entity.childRecord" >{{COL_FIELD}}</span> </div>';
			    
  				var paginationOptions = {
						 	startIndex : 0,
						 	endIndex : 0,
						    pageNumber: 1,
						    pageSize: 100,
						    sort: null
						  };	
					 
					 //Grid
					 $scope.gridOptions = {
					 enablePaginationControls:false,
					 enableGridMenu: true,
		             enableFiltering: true,            
		             enableColumnResize: true,
		             paginationPageSizes: [100,250,500,750,1000],
		     	     paginationPageSize: 100,         
		             useExternalPagination: true,
		             autoResize:true,
		             enableSorting: true,
		             enableColumnMenus: false,
		             enablePinning: true,   
		             headerTemplate: 'app/partials/liveReceipt-header-template.html',
		             category: 
			            	 [{name:  'Part Type', visible: true },
			            	 { name:  'Part Number', visible: true },
			            	 { name:  'Process Code',visible: true },
			            	 { name:  'Location', visible: true },
	                         { name:  'RAN', visible: true },
	                         { name:  'Supplier', visible: true },
	                         { name:  'SNP', visible: true },
	                         { name:  'CATS', visible: true},
	                         { name:  'WMS',visible: true },
	                         { name:  'No.of Box Mismatch', visible: true },     
	                         { name:  'Qty Mismatch', visible: true},
	                         { name:  'Remarks', visible: true}], 
		            	 
		            	  /*     [{name:  'Part Type', width:30, visible: true },
			            	 { name:  'Part Number', width:90, visible: true },
			            	 { name:  'Process Code',width:70,visible: true },
			            	 { name:  'Location', width:90,visible: true },
	                         { name:  'RAN', width:70,visible: true },
	                         { name:  'Supplier', width:70,visible: true },
	                         { name:  'SNP', width:200,visible: true },
	                         { name:  'CATS', width:200,visible: true},
	                         { name:  'WMS',width:50,visible: true },
	                         { name:  'No.of Box Mismatch', width:30,visible: true },     
	                         { name:  'Qty Mismatch', width:50,visible: true},
	                         { name:  'Remarks', width:110,visible: true}], */
	                         
		             columnDefs: [
		            	 { field: 'partType', displayName: 'Part Type', category:"Part Type", width:30 , visible:true},
		            	 { field: 'partNumber', displayName: 'Part Number',category: 'Part Number', width:90, visible:true },
		            	 { field: 'processCode', displayName: 'Process Code',category: 'Process Code', width:70, visible:true },
		            	 { field: 'location', displayName: 'Location', category: 'Location', width:90, visible:true },
                         { field: 'ran', displayName: 'RAN', category: 'RAN', width:70, visible:true },
                         { field: 'supplier', displayName: 'Supplier',category: 'Supplier',  width:70, visible:true },
                         { field: 'snp', displayName: 'SNP', category: 'SNP', width:50, visible:true }, 
                         
                         { field: 'boxRecCats', displayName: 'No.of Box Received', category:"CATS", width:40, visible:true },
                         { field: 'containerNo', displayName: 'Container No', category: "CATS", width:90, visible:true },
                         { field: 'dNote', displayName: 'DNote', category:"CATS", width:90,  visible:false },
                         { field: 'dNoteQty', displayName: 'Qty', category:"CATS", width:50,  visible:true },
                         { field: 'liveReceiptUpdatedTime', displayName: 'Live Receipt Date', category:"CATS", width:100, cellFilter: 'date:\'MMM d, yyyy HH:mm:ss a\'' , visible:true},
                         
                         { field: 'boxRecWms', displayName: 'No.of Box Received', category:"WMS", width:40 , visible:true},
                         { field: 'auditQuantity', displayName: 'WH-IN Qty', category:"WMS", width:50, visible:true},
                         { field: 'auditScanTime', displayName: 'WH-IN Date Time', category:"WMS", width:100, cellFilter: 'date:\'MMM d, yyyy HH:mm:ss a\'' , visible:true},
                         
                         { field: 'boxMismatch', displayName: 'No.of Box Mismatch', category: 'No.of Box Mismatch', width:40, visible:true },     
                         { field: 'qtyMismatch', displayName: 'Qty Mismatch', category: 'Qty Mismatch', width:50, visible:true},
                         { field: 'remarks', displayName: 'Remarks', category: 'Remarks', width:110, visible:true},        
		            	 
		            	 /*{ field: 'partType', displayName: 'Part Type', category:"Part Type", visible:true},
		            	 { field: 'partNumber', displayName: 'Part Number',category: 'Part Number',  visible:true },
		            	 { field: 'processCode', displayName: 'Process Code',category: 'Process Code',visible:true },
		            	 { field: 'location', displayName: 'Location', category: 'Location',  visible:true },
                         { field: 'ran', displayName: 'RAN', category: 'RAN',  visible:true },
                         { field: 'supplier', displayName: 'Supplier',category: 'Supplier',   visible:true },
                         { field: 'snp', displayName: 'SNP', category: 'SNP',  visible:true }, 
                         
                         { field: 'boxRecCats', displayName: 'No.of Box Received', category:"CATS",   visible:true },
                         { field: 'containerNo', displayName: 'Container No', category: "CATS",   visible:true },
                         { field: 'dNote', displayName: 'DNote', category:"CATS", visible:false },
                         { field: 'dNoteQty', displayName: 'DNote Qty', category:"CATS",  visible:true },
                         { field: 'liveReceiptUpdatedTime', displayName: 'Live Receipt Date', category:"CATS",  cellFilter: 'date:\'MMM d, yyyy HH:mm:ss a\'' , visible:true},
                         
                         { field: 'boxRecWms', displayName: 'No.of Box Received', category:"WMS", visible:true},
                         { field: 'auditQuantity', displayName: 'WH-IN Qty', category:"WMS",  visible:true},
                         { field: 'auditScanTime', displayName: 'WH-IN Date Time', category:"WMS",   cellFilter: 'date:\'MMM d, yyyy HH:mm:ss a\'' , visible:true},
                         
                         { field: 'boxMismatch', displayName: 'No.of Box Mismatch', category: 'No.of Box Mismatch',  visible:true },     
                         { field: 'qtyMismatch', displayName: 'Qty Mismatch', category: 'Qty Mismatch',  visible:true},
                         { field: 'remarks', displayName: 'Remarks', category: 'Remarks',  visible:true},  */
                         
                         
                         ],
		                        exporterPdfAlign:'left',
		                        exporterCsvFilename: 'LiveReceiptQuantityMismatch.csv',
		                        exporterMenuVisibleData: false,
		                        exporterPdfDefaultStyle: {fontSize: 9},
		                        exporterPdfTableStyle: {margin: [70, 5, 0, 5]},
		                        exporterPdfTableHeaderStyle: {fontSize: 10, bold: true, italics: true, color: 'red'},
		                        exporterPdfHeader: { text: "Live Receipt Quantity Mismatch", style: 'headerStyle' },
		                        exporterPdfFooter: function ( currentPage, pageCount ) {
		                          return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
		                        },
		                        exporterPdfCustomFormatter: function ( docDefinition ) {
		                        	 docDefinition.styles.headerStyle = { fontSize: 20, bold: true, alignment: 'center', margin: [0, 0, 20, 0] }; 
		                             docDefinition.styles.footerStyle = { fontSize: 10, bold: true, alignment: 'center',  margin: [5, 0, 20, 0] }; 
		                          return docDefinition;
		                        },
		                        exporterPdfOrientation: 'landscape',
		                        exporterPdfPageSize: 'LETTER',
		                        exporterPdfMaxGridWidth: 500,
		                        exporterPdfFilename: 'LiveReceiptQuantityMismatch.pdf',
		                        exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
		                       
		                        onRegisterApi: function( gridApi ) {
		                        	 $scope.gridApi = gridApi;
		                        	 //Pagination
		                        	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
		                        		 $scope.blockUI();
		             		          paginationOptions.pageNumber = newPage;
		             		          paginationOptions.pageSize = pageSize;
		             		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
		             		        /*paginationOptions.endIndex   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);*/
		             		        paginationOptions.endIndex   = paginationOptions.pageSize;
		             		       $scope.load();
		             		        });
		                	    }
				    };
					 
					 				 

					 $scope.getDisplayName = function(partType) {						 
						 var pos = $scope.gridOptions.columnDefs.map(function (e) { return e.field; }).indexOf('containerNo');
						 var dNote = $scope.gridOptions.columnDefs.map(function (e) { return e.field; }).indexOf('dNote');	
								if ($scope.liveReceiptQtyMismatch.partType != undefined
										&& $scope.liveReceiptQtyMismatch.partType != ""
										&& $scope.liveReceiptQtyMismatch.partType != null) {
									if ($scope.liveReceiptQtyMismatch.partType == 'A') {
										$scope.gridOptions.columnDefs[pos].visible = true;
										$scope.gridOptions.columnDefs[dNote].visible = false;
									} else {
										$scope.gridOptions.columnDefs[pos].visible = false;
										$scope.gridOptions.columnDefs[dNote].visible = true;
									}
								} else {
									$scope.gridOptions.columnDefs[pos].visible = true;
									$scope.gridOptions.columnDefs[dNote].visible = false;
								}
					  };	
					  
		     // --------- Container Number List ---------
			    $scope.cntNoList=''; 
			    $scope.cntNoData=[];
					  
			    /*ON ADD NEW CONTAINER NO TAG*/
				$scope.contNoAdded = function(tag) {
					  $scope.contNoArray = [];					  
					     for (var j=0; j < $scope.cntNoData.length; j++) {					    	 
					    	 $scope.contNoArray.push($scope.cntNoData[j].text);
					    	 console.log("Part Array",$scope.contNoArray);
					      }
					     $scope.cntNoList=$scope.contNoArray.join(',');
					     console.log("Part Number",$scope.partNumber);
					     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
				    };
				/*ON REMOVE ADDED CONTAINER NO TAG*/	  
			    
				    $scope.contNoRemoved = function(tag) {			   
				    	 $scope.contNoArray = [];
					     for (var j=0; j < $scope.cntNoData.length; j++) {
					    	 $scope.contNoArray.push($scope.cntNoData[j].text);
					      }
					     $scope.cntNoList=$scope.contNoArray.join(',');
					     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
				    };
				    
				    $scope.dnoteData=[];
				    $scope.dNoteList='';
				    
				    /*ON ADD NEW DNOTE NO TAG*/
					$scope.dNoteNoAdded = function(tag) {
						  $scope.dNoteNoArray = [];					  
						     for (var j=0; j < $scope.dnoteData.length; j++) {					    	 
						    	 $scope.dNoteNoArray.push($scope.dnoteData[j].text);
						    	 console.log("Part Array",$scope.dNoteNoArray);
						      }
						     $scope.dNoteList=$scope.dNoteNoArray.join(',');
						     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
					    };
					/*ON REMOVE ADDED DNOTE NO TAG*/	  
				    
					    $scope.dNoteNoRemoved = function(tag) {			   
					    	 $scope.dNoteNoArray = [];
						     for (var j=0; j < $scope.dnoteData.length; j++) {
						    	 $scope.dNoteNoArray.push($scope.dnoteData[j].text);
						      }
						     $scope.dNoteList=$scope.dNoteNoArray.join(',');
						     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
					    };
					    
					    $scope.recPlaceData=[];
					    $scope.recPlaceList='';
					    
					    /*ON ADD NEW RECEIVING PLACE TAG*/
						$scope.recPlaceAdded = function(tag) {
							  $scope.recPlaceArray = [];					  
							     for (var j=0; j < $scope.recPlaceData.length; j++) {					    	 
							    	 $scope.recPlaceArray.push($scope.recPlaceData[j].text);
							    	 console.log("Part Array",$scope.recPlaceArray);
							      }
							     $scope.recPlaceList=$scope.recPlaceArray.join(',');
							     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
						    };
						/*ON REMOVE ADDED RECEIVING PLACE TAG*/	  
					    
						    $scope.recPlaceRemoved = function(tag) {			   
						    	 $scope.recPlaceArray = [];
							     for (var j=0; j < $scope.recPlaceData.length; j++) {
							    	 $scope.recPlaceArray.push($scope.recPlaceData[j].text);
							      }
							     $scope.recPlaceList=$scope.recPlaceArray.join(',');
							     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
						    };
				    
				    $scope.loadLiveReceiptData = function(query,colName){
				    	var partInputObj = {"text": query};
				    	$scope.liveReceiptQtyMismatch.input=partInputObj;
				    	$scope.liveReceiptQtyMismatch.colName=colName;
						return liveReceiptQuantityMismatchService.getLiveReceiptForAutoComplete($scope.liveReceiptQtyMismatch).then(function(response){
							console.log(response.data.object);
							if(response.data.statusType == "success"){
								if(response.data.object != 'null' && response.data.object != null){
									return response.data.object;
								}
							}
						});
					};
				    
			 // --------- Part Number List ---------
				$scope.partNumber='';
				$scope.searchClicked=false;
				$scope.tags=[];	 
				/*ON ADD NEW PART TAG*/
				$scope.transactionList= ["In", "Out", "Move"];
				$scope.tagAdded = function(tag) {
					  $scope.partArray = [];					  
					     for (var j=0; j < $scope.tags.length; j++) {					    	 
					    	 $scope.partArray.push($scope.tags[j].text);
					    	 console.log("Part Array",$scope.partArray);
					      }
					     $scope.partNumber=$scope.partArray.join(',');
					     console.log("Part Number",$scope.partNumber);
					     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
				    };
				/*ON REMOVE ADDED PART TAG*/
				    
			    $scope.tagRemoved = function(tag) {			   
			    	 $scope.partArray = [];
				     for (var j=0; j < $scope.tags.length; j++) {
				    	 $scope.partArray.push($scope.tags[j].text);
				      }
				     $scope.partNumber=$scope.partArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			    
			 // --------- SUPPLIER CODE LIST ---------		
			    $scope.supplierList=''; 
			    $scope.supplierTags=[];	 
				/*ON ADD NEW Supplier TAG*/
				
				$scope.supplierTagsAdded = function(tag) {				
					  $scope.supplierArray = [];
					     for (var j=0; j < $scope.supplierTags.length; j++) {
					    	 $scope.supplierArray.push($scope.supplierTags[j].text);
					      }
					     $scope.supplierList=$scope.supplierArray.join(',');
					     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
				    };
				/*ON REMOVE ADDED Supplier TAG*/
				    
			    $scope.supplierTagsRemoved = function(tag) {			   
			    	 $scope.supplierArray = [];
				     for (var j=0; j < $scope.supplierTags.length; j++) {
				    	 $scope.supplierArray.push($scope.supplierTags[j].text);
				      }
				     $scope.supplierList=$scope.supplierArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
				
			   /* AUTOCOMPLE SUPPLIER ON ENTER MIN 3 CHAR DATA */
			    
			    $scope.loadSupplier = function(query) {		    	
			    	var partInputObj = {"text": query};			    	
			    	return liveReceiptQuantityMismatchService.getSupList(partInputObj).then(function(response){			    		
			    		if(response.data.statusType=='success'){
			        		 if(response.data.object!='null' && response.data.object!=null){				        		
			        			  return response.data.object;                           
			        		 }
			        	 }else{
			        		console.log("empty");
			        	 }			    		
				    });			    				         
			    };
			    
			    /* AUTOCOMPLE ZONE ON ENTER MIN 3 CHAR DATA */
			    
			    $scope.loadZones = function(){
					/*lineFeedingDetailsService.zonesListService().then(function(response) {
						$scope.zones = response.objectList;
					});*/
			    	liveReceiptQuantityMismatchService.getZoneList().then(function(response) {
						$scope.zones = response.objectList;
					});
				}
			    
			 // --------- Shops drop down list ---------
			    
			    $scope.loadShopLine = function(){
			    	 $scope.part.line = '';
			    	 $scope.part.shop = '';
			    	 commonService.getLineList($scope.part.plant)
					  .success(function(response){
						  console.log(response.objectList);
						  $scope.lines = response.objectList;				
					  })
					  .error(function(response){
					  });
			    	 /*commonService.getShopList($scope.part.plant)*/
			    	 lineFeedingDetailsService.getShopList($scope.part.plant)//.success(function(response) {
					  .success(function(response){
						  console.log(response.objectList);
						  $scope.shops = response.objectList;				
					  })
					  .error(function(response){
					  });
			    	 
			    	 liveReceiptQuantityMismatchService.getZoneList().then(function(response) {
							$scope.zones = response.data.objectList;
						});
			    	 
			    	/* $scope.loadZones();*/
			    }
				   
			    commonService.getAllPlants()
				  .success(function(response){	
					  $scope.locations = response.objectList;				
					  $window.sessionStorage.setItem('locationDPCollection',JSON.stringify($scope.locations));
				  })
				  .error(function(response){
				  });
			    
			    $scope.addingTag = function(tag) {
			    	console.log("Tag.text",tag.text);
			    	  tag.text = tag.text.replace(/ /g, ',');
			    	  console.log("Tag.text 2",tag.text);
			    	  return tag;
			    	};
			    	
				
			    /*AUTOCOMPLE PART ON ENTER MIN 3 CHAR DATA*/
			    
			    $scope.loadParts = function(query) {		    	
			    	var partInputObj = {"partNumber": query};			    	
			    	return partNumberService.partNumberList(partInputObj).then(function(response){			    		
			    		 if(response.data.statusType=='success'){
			        		 if(response.data.object!='null' && response.data.object!=null){				        		
			        			  return response.data.object;                           
			        		 }
			        	 }else{
			        		
			        	 }			    		
				    });			    				         
			    };
			    
			    
			    /* RAN Auto Completion - Start */
			    $scope.ranData=[];	
			    $scope.ranList='';
			    
			    $scope.ranAdded = function(tag) {			
					console.log("tagAdded:",tag);
					  $scope.ranArray = [];
					     for (var j=0; j < $scope.ranData.length; j++) {
					    	 $scope.ranArray.push($scope.ranData[j].text);
					      }
					     $scope.ranList=$scope.ranArray.join(',');
					     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
				};
			    
			    $scope.ranRemoved = function(tag) {			   
			    	 $scope.ranArray = [];
				     for (var j=0; j < $scope.ranData.length; j++) {
				    	 $scope.ranArray.push($scope.ranData[j].text);
				      }
				     $scope.ranList=$scope.ranArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			    
			   /* $scope.loadRan = function(query) {
			    	var partInputObj = {"ranId": query};
			    	return ranService.ranList(partInputObj).then(function(response){			    		
			    		 if(response.data.statusType=='success'){
			        		 if(response.data.object!='null' && response.data.object!=null){	
			        			 console.log(response.data.object);
			        			  return response.data.object;                           
			        		 }
			        	 }		    		
				    });	
			    };*/		    
			    
			    $scope.loadRan = function(query){ 
					/*var partInputObj = {"ranId": query};*/
			    	var partInputObj = {"partNumber": query};
					return liveReceiptQuantityMismatchService.getranList(partInputObj).then(function(response){
						console.log(response.data.object);
						if(response.data.statusType == "success"){
							if(response.data.object != 'null' && response.data.object != null){
								return response.data.object;
							}
						}
					});
				};
			    /*RAN Auto Completion - End */
			    
				/* Live Receipt table data Auto Completion - Start */
/*			    $scope.liveReceiptData=[];	
			    
			    $scope.liveReceiptDataAdded = function(tag) {			
					console.log("tagAdded:",tag);
					  $scope.liveReceiptDataArray = [];
					     for (var j=0; j < $scope.liveReceiptDataData.length; j++) {
					    	 $scope.liveReceiptDataArray.push($scope.liveReceiptDataData[j].text);
					      }
					     $scope.liveReceiptQtyMismatch.dNote=$scope.liveReceiptDataArray.join(',');
					     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
				};
			    
			    $scope.liveReceiptDataRemoved = function(tag) {			   
			    	 $scope.liveReceiptDataArray = [];
				     for (var j=0; j < $scope.liveReceiptDataData.length; j++) {

				    	 $scope.ranArray.push($scope.liveReceiptDataData[j].text);
				      }
				     $scope.liveReceiptQtyMismatch.dNote=$scope.liveReceiptDataArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			    
			    $scope.loadRan = function(query){ 
					var partInputObj = {"ranId": query};
			    	var partInputObj = {"text": query};
					return liveReceiptQuantityMismatchService.getranList(partInputObj).then(function(response){
						console.log(response.data.object);
						if(response.data.statusType == "success"){
							if(response.data.object != 'null' && response.data.object != null){
								return response.data.object;
							}
						}
					});
				};*/
			    
				/*Live Receipt table data Auto Completion - End */
					    
					// Clear the filter
					$scope.clearFilters = function() {
						$scope.gridApi.core.clearAllFilters();
				    };
				    
				    $scope.setId = function(Id) {		    			    
				    	//Location.location=locationId;
				    	$scope.id=Id;
				     };
				    
				 // Reset the values
				    $scope.resetLiveReceipt = function(){	
				    	
				    	$scope.beginDate=new Date();
					    $scope.endDate=new Date(); 
					    $scope.auditBeginDate=new Date();
					    $scope.auditEndDate=new Date();
					    $scope.beginTime = new Date();
						$scope.endTime = new Date();
						$scope.fromTime1='';
						$scope.fromTime2='';
						$scope.fromTime3='';
						$scope.toTime1='';
						$scope.toTime2='';
						$scope.toTime3='';
					    $scope.part.plant = '';
					    $scope.part.shop = '';
					    $scope.part.line = '';
					    $scope.liveReceiptQtyMismatch.zone='';
					    $scope.liveReceiptQtyMismatch.partType='';
					    $scope.liveReceiptQtyMismatch.receipt='';
				    	$scope.gridOptions.data = [];
				    	$scope.clearFilters();	  
				    	$scope.liveReceiptQtyMismatch = {};
				    	$scope.partNumber="";	    	
				    	$scope.liveReceiptQtyMismatch.startIndex = 0;
				    	$scope.liveReceiptQtyMismatch.endIndex = 0;
				    	$scope.tags=[];
				    	$scope.ranData=[];	
				    	$scope.supplierList=''; 
					    $scope.supplierTags=[];	 
					    $scope.recPlaceData=[];
					    $scope.cntNoData=[];
					    $scope.dnoteData=[];
					    $scope.dNoteList='';
	            		$scope.cntNoList=''; 
	            		$scope.recPlaceList='';
	            		$scope.ranList=''; 
				    	$scope.gridOptions.totalItems=0;				    	
				    	$scope.gridOptions.enablePaginationControls=false;	    
				    	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 						   
				    };
				    
				 					 
					 $scope.liveReceiptQtyMismatchData = function(){    	    
						 liveReceiptQuantityMismatchService.getLiveReceiptQtyMismatchList($scope.liveReceiptQtyMismatch).then(function(response){
					    		$scope.gridOptions.data = [];
					    		
					    		if(response.data.objectList !== undefined && response.data.objectList !== null){
					    			if(response.data.statusType === 'success' ){
					    				$scope.gridOptions.enablePaginationControls=true;
					    				 response.data.objectList.forEach(function(row){	    	    	         	          
					    	    	           $scope.gridOptions.data = response.data.objectList;	 
					    	    	          });
					    			} else {
					    				$scope.gridOptions.enablePaginationControls=false;
					    				$scope.alerts = [];
							            $scope.alerts.push({
							                type : response.data.statusType,
							                msg : response.data.statusMessage,
							                error : response.data.exceptionStackTrace,
							                errorClsName : response.data.exceptionClassName,
							                errorMsg : response.data.exceptionMessage
							            });
					    			}
					    			$.unblockUI();
					    		} else {
					    			$scope.searchDataError=response.data.statusMessage;	    			
						            $.unblockUI();
					    		}
					    	});
				     };
				     
				     /* Load data in grid */
					   $scope.load = function () {
					    	/*$scope.liveReceiptQtyMismatch.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

					    	if(paginationOptions.endIndex === 0){
					    		$scope.liveReceiptQtyMismatch.endIndex = $scope.gridOptions.paginationPageSize;
					    	}
					    	$scope.liveReceiptQtyMismatch.startIndex = paginationOptions.startIndex;
					    	$scope.liveReceiptQtyMismatch.endIndex = paginationOptions.pageSize;*/
						   
						   $scope.liveReceiptQtyMismatch.endIndex = paginationOptions.pageSize;
					    	if(paginationOptions.endIndex === 0){
					    		$scope.liveReceiptQtyMismatch.endIndex = $scope.gridOptions.paginationPageSize;
					    	}
					    	$scope.liveReceiptQtyMismatch.startIndex = paginationOptions.startIndex;
					     	$scope.liveReceiptQtyMismatch.endIndex = paginationOptions.pageSize;
					     	
					    	$scope.liveReceiptQtyMismatch.partNumber = $scope.partNumber;
					    	
					    	//get hours minutes and seconds from begin times
					    	console.log("$scope.liveReceiptQtyMismatch.fromDate : "  +$scope.liveReceiptQtyMismatch.fromDate);
					    	console.log("$scope.auditBeginDate : "  +$scope.auditBeginDate);
					    	console.log("$scope.auditEndDate : "  +$scope.auditEndDate);
					    	
					    	$scope.auditBeginDate
							var datesFrom = new Date($scope.auditBeginDate);
							if(!$scope.fromTime1){
								$scope.fromTime1 = 0;
							}
							if(!$scope.fromTime2){
								$scope.fromTime2 = 0;
							}
							if(!$scope.fromTime3){
								$scope.fromTime3 = 0;
							}
							datesFrom.setHours($scope.fromTime1);
							datesFrom.setMinutes($scope.fromTime2);
							datesFrom.setSeconds(0);
							
							var datesTo = new Date($scope.auditEndDate);
							
							if(!$scope.toTime1){
								$scope.toTime1 = 0;
							}
							if(!$scope.toTime2){
								$scope.toTime2 = 0;
							}
							if(!$scope.toTime3){
								$scope.toTime3 = 0;
							}
							
							datesTo.setHours($scope.toTime1);
							datesTo.setMinutes($scope.toTime2);
							datesTo.setSeconds(0);
							
							$scope.liveReceiptQtyMismatch.fromDate = datesFrom;
							$scope.liveReceiptQtyMismatch.toDate = datesTo;
					    	
					    	liveReceiptQuantityMismatchService.getLiveReceiptQtyMismatchListCount($scope.liveReceiptQtyMismatch).then(function(response){
					    		$scope.gridOptions.totalItems = response.data.object;		    		
					    		$scope.recordCount = response.data.object;	
					    		if($scope.recordCount==null || $scope.recordCount==0){
					    			$scope.searchDataError="No Records Found!!!";
					    			$.unblockUI();
					    			$scope.gridOptions.enablePaginationControls=false;	
					    			$scope.alerts = [];
					    			
					    		}else{
					    			$scope.liveReceiptQtyMismatchData();
					    		}
					    		
					    	});
					    	
					    };
					    
					 
					// --------- search button ---------
			            $scope.searchLiveReceiptQuantityMismatch = function() {
			            	if( $scope.validateFilter() == true){
			            		if($scope.validateFilters() == true){
			            		$scope.blockUI();
			            		$scope.alerts = [];
			            		$scope.gridOptions.data = [];
			            		$scope.liveReceiptQtyMismatch.plant =$scope.part.plant;
			            		$scope.liveReceiptQtyMismatch.shop =$scope.part.shop;
			            		$scope.liveReceiptQtyMismatch.line =$scope.part.line;
			            		$scope.liveReceiptQtyMismatch.partNumber=$scope.partNumber;	
			            		$scope.liveReceiptQtyMismatch.supplier=$scope.supplierList;	
			            		$scope.liveReceiptQtyMismatch.dNote=$scope.dNoteList;	
			            		$scope.liveReceiptQtyMismatch.containerNo=$scope.cntNoList;	
			            		$scope.liveReceiptQtyMismatch.recPlace=$scope.recPlaceList;	
			            		$scope.liveReceiptQtyMismatch.ran=$scope.ranList;
			            		$scope.liveReceiptQtyMismatch.fromDate = $filter('date')($scope.auditBeginDate, 'yyyy-MM-dd');
			            		$scope.liveReceiptQtyMismatch.toDate = $filter('date')($scope.auditEndDate, 'yyyy-MM-dd');			            		
			            		console.log("liveReceiptQtyMismatch From Date == "+$scope.liveReceiptQtyMismatch.fromDate);
			            		console.log("liveReceiptQtyMismatch to Date == "+$scope.liveReceiptQtyMismatch.toDate);			            		
			            		if( $scope.part!=undefined && $scope.part.plant!=undefined) {
			            			$scope.liveReceiptQtyMismatch.plant = $scope.part.plant;
			            		}
			            		$scope.liveReceiptQtyMismatch.isFullDownload=0;
			            		paginationOptions.startIndex= 0;			            		
			            		paginationOptions.endIndex= 0;
			            		paginationOptions.pageNumber= 1;
			            		paginationOptions.pageSize= 100; 
			            		$scope.gridOptions.paginationCurrentPage=1;
			            		$scope.gridOptions.paginationPageSize=100;
			            		$scope.liveReceiptQtyMismatch.startIndex=0;
			        			$scope.liveReceiptQtyMismatch.endIndex=0;
			            		$scope.searchClicked=true;
			            		$scope.clearFilters();                	
			            		$scope.load();
			            		$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
			            		} else {
					       			$scope.alerts = [];
					       			$scope.alerts.push({
					       				 type : 'danger',
					       				 msg : 'Part Type/Receipt is mandatory'
					       			});
				            	}
			            	} else {
				       			$scope.alerts = [];
				       			$scope.alerts.push({
				       				 type : 'danger',
				       				 msg : 'Plant/Shop is mandatory'
				       			});
			            	}
			            };
			            
			            
			            $scope.downloadLiveReceiptQuantityMismatch =function(){
			            	$scope.alerts = [];
			            	//$scope.blockUI();
			            	
			            	/*$scope.liveReceiptQtyMismatch.fromDate=$filter('date')($scope.auditBeginDate, 'yyyy-MM-dd');;
					    	$scope.liveReceiptQtyMismatch.toDate=$filter('date')($scope.auditEndDate, 'yyyy-MM-dd');*/
					    	
					    	 $scope.fromMaxDate =  previousMonth;
							 $scope.todayDate = new Date();
					    	
					    					    	
					    	/*var validateFlag = $scope.validateFilterForDownload();
					    	if( validateFlag == true){	*/
					    	 var filter1 = $scope.validateFilter();
					    	 var filter2 = $scope.validateFilters();
					    	if( filter1){
					    		if(filter2){			
					    			$scope.blockUI();
						    	$scope.liveReceiptQtyMismatch.partNumber=$scope.partNumber;
				            	
				            	$scope.liveReceiptQtyMismatch.isFullDownload=1;
				            	return liveReceiptQuantityMismatchService.liveReceiptQtyMismatchDownload($scope.liveReceiptQtyMismatch).then(function(response){
				            		
				            			if(response.objectList != null){
					            			for (var i = 0; i < response.objectList.length; i++) {
					            				response.objectList[i].partNumber = '="'+response.objectList[i].partNumber+'"';
					            				response.objectList[i].liveReceiptUpdatedTime =$filter('date')(response.objectList[i].liveReceiptUpdatedTime, 'dd/MM/yyyy HH:mm:ss');
					            				response.objectList[i].auditScanTime =$filter('date')(response.objectList[i].auditScanTime, 'dd/MM/yyyy HH:mm:ss');
					            			}
					            			$.unblockUI();
					            			return response.objectList;
					            		}else{
					            			$.unblockUI();
					            			$scope.alerts = [];
					    	       			$scope.alerts.push({
					    	       				 type : 'danger',
					    	       				msg : response.statusMessage
					    	       			});
					    	       			var temp=null;
							       			console.log("Temp1 length",temp.length);	  
					            		}
				            	});
					    	}else {
					    		$scope.alerts = [];
				       			$scope.alerts.push({
				       				 type : 'danger',
				       				 msg : 'Part Type/Receipt is mandatory'
				       			});
				       			var temp=null;
				       			console.log("Temp2 length",temp.length);	  
			            	}
					    	} else {				       			
				       			$scope.alerts = [];
				       			$scope.alerts.push({
				       				 type : 'danger',
				       				 msg : 'Plant/Shop is mandatory'
				       			});
				       			var temp=null;
				       			console.log("Temp3 length",temp.length);	       		
			            	}
					    	
					    	/*}
					    	else{
					    		$.unblockUI();
			            		$scope.alerts = [];
				       			$scope.alerts.push({
				       				 type : 'danger',
				       				 msg : 'Date Fields Should not be Empty. Please select the Date Range.'
				       			});
				       			//Throwing null pointer error intentionally as a temporary fix to stop downloading.
				       			var temp=null;
				       			console.log("Temp length",temp.length);	       			
			            	}*/
			            };
			            
			           /* $scope.getDownloadLiveReceiptAtyMismatchHeader = function () {
			            	return ["RAN", "Plant", "Part Number", "Live Receipt Date","WH-IN Date Time","Live Receipt Quantity","WH-IN Quantity"];
			           };
			           
			           $scope.csvColumnOrder=['ran','plant', 'partNumber','liveReceiptUpdatedTime','auditScanTime','liveReceiptQuantity','auditQuantity'];
			           */
			            
			            $scope.getDownloadLiveReceiptAtyMismatchHeader = function () {
			            	if($scope.liveReceiptQtyMismatch.partType=='A'){
			            		return ["Part Type", "Part Number", "Process Code","Location","RAN","Supplier","SNP","No.Of Boxes in CATS","Container No","Live Receipt Qty", "Live Receipt Date","No.Of Boxes in WMS","WH-IN Qty","WH-IN Date Time","No.Of Box Mismatch","Qty Mismatch","Remarks"];
			            	}else{
			            		return ["Part Type", "Part Number", "Process Code","Location","RAN","Supplier","SNP","No.Of Boxes in CATS","DNote No","Live Receipt Qty", "Live Receipt Date","No.Of Boxes in WMS","WH-IN Qty","WH-IN Date Time","No.Of Box Mismatch","Qty Mismatch","Remarks"];
			            	}
			            	
			           };
			           
			           if($scope.liveReceiptQtyMismatch.partType=='A'){
			        	   $scope.csvColumnOrder=['partType','partNumber', 'processCode','location','ran','supplier','snp','boxRecCats','containerNo','Qty','liveReceiptUpdatedTime','boxRecWms','auditQuantity','auditScanTime','boxMismatch','qtyMismatch','remarks'];
			           }else{
			        	   $scope.csvColumnOrder=['partType','partNumber', 'processCode','location','ran','supplier','snp','boxRecCats','dNote','Qty','liveReceiptUpdatedTime','boxRecWms','auditQuantity','auditScanTime','boxMismatch','qtyMismatch','remarks'];
			           }
			           
			             $scope.validateFilter = function() {
								if ($scope.part != undefined
										&& $scope.part.plant !== ""
										&& $scope.part.plant !== null
										&& $scope.part.plant !== undefined
										&& $scope.part.shop !== ""
										&& $scope.part.shop !== null
										&& $scope.part.shop !== undefined) {
									return true;
								}
								return false;
							};
							
							 $scope.validateFilters = function() {
								 if ($scope.liveReceiptQtyMismatch.partType !== ""
										&& $scope.liveReceiptQtyMismatch.partType !== null
										&& $scope.liveReceiptQtyMismatch.partType !== undefined
										&& $scope.liveReceiptQtyMismatch.receipt !== ""
										&& $scope.liveReceiptQtyMismatch.receipt !== null
										&& $scope.liveReceiptQtyMismatch.receipt !== undefined) {
									return true;
								}
								return false;
							 };
			           

						  /* $scope.validateFilterForDownload = function() {

								if ($scope.liveReceiptQtyMismatch.fromDate == null
										|| $scope.liveReceiptQtyMismatch.fromDate == ''
										|| $scope.liveReceiptQtyMismatch.toDate == null
										|| $scope.liveReceiptQtyMismatch.toDate == '') {
									return false;
								}

								if ($scope.liveReceiptQtyMismatch.auditFromDate == null
										|| $scope.liveReceiptQtyMismatch.auditFromDate == ''
										|| $scope.liveReceiptQtyMismatch.auditToDate == null
										|| $scope.liveReceiptQtyMismatch.auditToDate == '') {
									return false;
								}
								console
										.log("From Date and To Date is not null");
								return true;
							};*/
			
		}]);