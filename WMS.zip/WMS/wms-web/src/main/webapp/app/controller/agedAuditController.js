wmsApp.controller('agedAuditController', 
		[ '$scope','$window','$filter', '$location','$q', 'agedAuditService','locationService','uiGridTreeViewConstants', '$http','commonService','localStorageService','partNumberService','ranService',
        function($scope,$window,$filter, $location,$q, agedAuditService,locationService,uiGridTreeViewConstants, $http,commonService,localStorageService,partNumberService,ranService) {
			$scope.searchDataEror="Click search to fetch records.";
			$scope.beginDate=new Date();
		    $scope.endDate=new Date();
		    $scope.fromMaxDate=new Date();
		    $scope.downloadAuditData =[];
               $scope.shiftDropdown=false;
			   $scope.todayDate = new Date();
			  // $scope.transactionList = ["In", "Out"];	
			   $scope.shiftList = ["A", "B" ,"C"];
			    $scope.beginDatePickerOpen = false;
			    $scope.endDatePickerOpen = false;

			    $scope.openBeginDatePicker = function ($event) {			    	
			    $event.preventDefault();
			    $event.stopPropagation();
			    $scope.beginDatePickerOpen = !$scope.beginDatePickerOpen;
			    };

			    $scope.openEndDatePicker = function ($event) {
			    $event.preventDefault();
			    $event.stopPropagation();
			    $scope.endDatePickerOpen = !$scope.endDatePickerOpen;			  
			    };
			 
			    
			
			// --------- Part Number List ---------
			$scope.partNumber='';
			$scope.searchClicked=false;
			$scope.tags=[];	 
			/*ON ADD NEW PART TAG*/
			//$scope.transactionList= ["In", "Out"];
			$scope.tagAdded = function(tag) {
				
				  $scope.partArray = [];
				  
				     for (var j=0; j < $scope.tags.length; j++) {
				    	 
				    	 $scope.partArray.push($scope.tags[j].text);
				    	 console.log("Part Array",$scope.partArray);
				      }
				     $scope.partNumber=$scope.partArray.join(',');
				     console.log("Part Number",$scope.partNumber);
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			/*ON REMOVE ADDED PART TAG*/
			    
		    $scope.tagRemoved = function(tag) {			   
		    	 $scope.partArray = [];
			     for (var j=0; j < $scope.tags.length; j++) {

			    	 $scope.partArray.push($scope.tags[j].text);
			      }
			     $scope.partNumber=$scope.partArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    $scope.addingTag = function(tag) {
		    	console.log("Tag.text",tag.text);
		    	  tag.text = tag.text.replace(/ /g, ',');
		    	  console.log("Tag.text 2",tag.text);
		    	  return tag;
		    	};
		    	
			
		    /*AUTOCOMPLE PART ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadParts = function(query) {		    	
		    	var partInputObj = {"partNumber": query};			    	
		    	return partNumberService.partNumberList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    });			    				         
		    };
			    
			  
		    /*ON ADD NEW LOCATION TAG*/
		    
			$scope.location="";
			$scope.locationIdData=[];	 
		    $scope.locationAdded = function(tag) {					
		    $scope.locationArray = [];
			    for (var j=0; j < $scope.locationIdData.length; j++) {
			    	$scope.locationArray.push($scope.locationIdData[j].text);
			    }
			    $scope.location=$scope.locationArray.join(',');
			    $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    /*ON REMOVE ADDED LOCATION TAG*/
		    
		    $scope.locationRemoved = function(tag) {			   
		    	 $scope.locationArray = [];
			     for (var j=0; j < $scope.locationIdData.length; j++) {
			    	 $scope.locationArray.push($scope.locationIdData[j].text);
			     }
			     $scope.location=$scope.locationArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    /* RAN Auto Completion - Start */
		    $scope.ranData=[];	
		    
		    $scope.ranAdded = function(tag) {			
				console.log("tagAdded:",tag);
				  $scope.ranArray = [];
				     for (var j=0; j < $scope.ranData.length; j++) {
				    	 $scope.ranArray.push($scope.ranData[j].text);
				      }
				     $scope.agedAudit.ran=$scope.ranArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			};
		    
		    $scope.ranRemoved = function(tag) {			   
		    	 $scope.ranArray = [];
			     for (var j=0; j < $scope.ranData.length; j++) {

			    	 $scope.ranArray.push($scope.ranData[j].text);
			      }
			     $scope.agedAudit.ran=$scope.ranArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    $scope.loadRan = function(query) {
		    	var partInputObj = {"ranId": query};
		    	return ranService.ranList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){	
		        			 console.log(response.data.object);
		        			  return response.data.object;                           
		        		 }
		        	 }		    		
			    });	
		    };
		    

		    /*RAN Auto Completion - End */
		    
		    
		 // --------- Location drop down list -------

			  if($window.sessionStorage.getItem('locationDPCollection') == null || $window.sessionStorage.getItem('locationDPCollection')=='undefined' || $window.sessionStorage.getItem('locationDPCollection')==undefined){
				  commonService.getAllPlants()
				  .success(function(response){					 
					  $scope.locations = response.objectList;				
					  $window.sessionStorage.setItem('locationDPCollection',JSON.stringify($scope.locations));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.locations = JSON.parse(sessionStorage.locationDPCollection);
			  }
			  
			  // --------- Section drop down list ---------

			  if($window.sessionStorage.getItem('sectionDPCollection') == null || $window.sessionStorage.getItem('sectionDPCollection')=='undefined' || $window.sessionStorage.getItem('sectionDPCollection')==undefined){
				  commonService.getAllSections()
				  .success(function(response){					 
					  $scope.sections = response.objectList;	
					  $window.sessionStorage.setItem('sectionDPCollection',JSON.stringify($scope.sections));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.sections = JSON.parse(sessionStorage.sectionDPCollection);
			  }
			  
			// --------- Shops drop down list ---------
			  
			  $scope.loadShopLine = function(){
			    	 $scope.agedAudit.line = '';
					 $scope.agedAudit.shop = '';
			    	 commonService.getLineList($scope.agedAudit.plant)
					  .success(function(response){
						  $scope.lines = response.objectList;				
					  })
					  .error(function(response){
					  });
			    	 commonService.getShopList($scope.agedAudit.plant)
					  .success(function(response){
						  $scope.shops = response.objectList;				
					  })
					  .error(function(response){
					  });

			    }
			 /*  
			  if($window.sessionStorage.getItem('shopDPCollection') == null || $window.sessionStorage.getItem('shopDPCollection')=='undefined' || $window.sessionStorage.getItem('shopDPCollection')==undefined){
				  commonService.getAllShop()
				  .success(function(response){						  
					  $scope.shops = response.objectList;				
					  $window.sessionStorage.setItem('shopDPCollection',JSON.stringify($scope.shops));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.shops = JSON.parse(sessionStorage.shopDPCollection);
			  }*/
			 // --------- Line drop down list ---------

			 /* if($window.sessionStorage.getItem('linesDPCollection') == null || $window.sessionStorage.getItem('linesDPCollection')=='undefined' || $window.sessionStorage.getItem('linesDPCollection')==undefined){
				  commonService.getAllLines()
				  .success(function(response){					 
					  $scope.lines = response.objectList;
					  $window.sessionStorage.setItem('linesDPCollection',JSON.stringify($scope.lines));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.lines = JSON.parse(sessionStorage.linesDPCollection);
			  }*/
		    
				    
		    /*AUTOCOMPLE LOCATION ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadLocation = function(query) {
		    	
		    	var locationInputObj = {"locationId": query};			    	
		    	return locationService.locationList(locationInputObj).then(function(response){	
		    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    	});			    				         
		    };
			    			    		  
		    $scope.agedAudit = {				
		    	  partNumber : $scope.partNumber,
		    	  location : $scope.location, 
                  fromDate : $scope.beginDate,
                  toDate : $scope.endDate,
                  ran : $scope.auditRAN,
                  startIndex : 0,
                  endIndex : 0
              };
			
		    $scope.agedAudit.transactionType = "1";
			
			 var paginationOptions = {
				 	startIndex : 0,
				 	endIndex : 0,
				    pageNumber: 1,
				    pageSize: 100,
				    sort: null
				  };
			 
			//trial data
			/*$scope.mydata = [{"partNumber":"484B92152R","location":"GB1WPG20","transactionType":"IN","count":10,"ran":"*","userId":"ADMIN","deviceId":"","partInOutTime":1485766436243,"partsReasonCode":null,"partPk":0,"noOfBoxes":0,"reasonCode":"","reason":"","comments":"","fromDate":null,"toDate":null,"startIndex":0,"endIndex":0,"shift":"A","isFullDownload":0,"partList":null,"locationList":null,"shop":null,"plant":null,"line":null,"section":null,"snp":3800,"scanTime":1485766436243,"ranList":null,"ranExpiryDate":"2017-01-18"},
			                 {"partNumber":"484B92152R","location":"GB1WPG19","transactionType":"OUT","count":10,"ran":"*","userId":"ADMIN","deviceId":"","partInOutTime":1485766436243,"partsReasonCode":null,"partPk":0,"noOfBoxes":0,"reasonCode":"","reason":"","comments":"","fromDate":null,"toDate":null,"startIndex":0,"endIndex":0,"shift":"A","isFullDownload":0,"partList":null,"locationList":null,"shop":null,"plant":null,"line":null,"section":null,"snp":3800,"scanTime":1485766436243,"ranList":null,"ranExpiryDate":"2017-01-22"},
			                 {"partNumber":"484B92152R","location":"GB1WPG19","transactionType":"IN","count":9,"ran":"*","userId":"ADMIN","deviceId":"","partInOutTime":1485766426547,"partsReasonCode":null,"partPk":0,"noOfBoxes":0,"reasonCode":"","reason":"","comments":"","fromDate":null,"toDate":null,"startIndex":0,"endIndex":0,"shift":"A","isFullDownload":0,"partList":null,"locationList":null,"shop":null,"plant":null,"line":null,"section":null,"snp":3800,"scanTime":1485766426547,"ranList":null,"ranExpiryDate":1485766436243},
			                 {"partNumber":"484B92152R","location":"GB1WPG20","transactionType":"OUT","count":9,"ran":"*","userId":"ADMIN","deviceId":"","partInOutTime":1485766426547,"partsReasonCode":null,"partPk":0,"noOfBoxes":0,"reasonCode":"","reason":"","comments":"","fromDate":null,"toDate":null,"startIndex":0,"endIndex":0,"shift":"A","isFullDownload":0,"partList":null,"locationList":null,"shop":null,"plant":null,"line":null,"section":null,"snp":3800,"scanTime":1485766426547,"ranList":null},
			                 {"partNumber":"484B92152R","location":"GB1WPG20","transactionType":"IN","count":9,"ran":"*","userId":"ADMIN","deviceId":"","partInOutTime":1485766377820,"partsReasonCode":null,"partPk":0,"noOfBoxes":0,"reasonCode":"","reason":"","comments":"","fromDate":null,"toDate":null,"startIndex":0,"endIndex":0,"shift":"A","isFullDownload":0,"partList":null,"locationList":null,"shop":null,"plant":null,"line":null,"section":null,"snp":3800,"scanTime":1485766377820,"ranList":null},
			                 {"partNumber":"484B92152R","location":"GB1WPG19","transactionType":"OUT","count":9,"ran":"*","userId":"ADMIN","deviceId":"","partInOutTime":1485766377820,"partsReasonCode":null,"partPk":0,"noOfBoxes":0,"reasonCode":"","reason":"","comments":"","fromDate":null,"toDate":null,"startIndex":0,"endIndex":0,"shift":"A","isFullDownload":0,"partList":null,"locationList":null,"shop":null,"plant":null,"line":null,"section":null,"snp":3800,"scanTime":1485766377820,"ranList":null},
			                 {"partNumber":"484B92152R","location":"GB1WPG19","transactionType":"IN","count":10,"ran":"*","userId":"ADMIN","deviceId":"","partInOutTime":1485766347280,"partsReasonCode":null,"partPk":0,"noOfBoxes":0,"reasonCode":"","reason":"","comments":"","fromDate":null,"toDate":null,"startIndex":0,"endIndex":0,"shift":"A","isFullDownload":0,"partList":null,"locationList":null,"shop":null,"plant":null,"line":null,"section":null,"snp":3800,"scanTime":1485766347280,"ranList":null,"ranExpiryDate":2017-01-18}];*/
			 
			 //Grid
			 $scope.gridOptions = {
			 enablePaginationControls:false,
			 enableGridMenu: true,
             enableFiltering: true,            
             enableColumnResize: true,
             paginationPageSizes: [100,250,500,750,1000],
     	     paginationPageSize: 100,         
             useExternalPagination: true,
             autoResize:true,
             enableSorting: true,
             enableColumnMenus: false,
             enablePinning: true,            
             columnDefs: [
                          { field: 'partNumber', displayName: 'Part Number', width:150, pinnedLeft:true },                          
			       	      { field: 'location', displayName: 'Location', width:150, pinnedLeft:true },
			       	      { field: 'ran', displayName: 'RAN', width:100 },
			       	      { field: 'transactionType', displayName: 'Txn', width:50},
			       	      { field: 'count', displayName: 'Stock', width:80},
			       	      { field: 'deviceId', displayName: 'Device', width:100},
			       	      { field: 'partInOutTime',type: 'date', displayName: 'In Out Time', width:200,cellFilter: 'date:\'MMM d, yyyy HH:mm:ss a\'' },
			       	      { field: 'scanTime',type: 'date', displayName: 'Scan Time', width:200,cellFilter: 'date:\'MMM d, yyyy HH:mm:ss a\'' },
			       	      /*{ field: 'shift', displayName: 'Shift', width:50},
			       	      { field: 'reason', displayName: 'Reason', width:100},
			       	      { field: 'comments', displayName: 'Comments', width:100},
			       	      */{ field: 'lppd', displayName: 'Ran Expiry Date', width:130,cellFilter: 'date:\'MMM d, yyyy \''}
                        ],
                        exporterPdfAlign:'left',
                        exporterCsvFilename: 'agedAuditReport.csv',
                        exporterMenuVisibleData: false,
                        exporterPdfDefaultStyle: {fontSize: 9},
                        exporterPdfTableStyle: {margin: [70, 5, 0, 5]},
                        exporterPdfTableHeaderStyle: {fontSize: 10, bold: true, italics: true, color: 'red'},
                        exporterPdfHeader: { text: "Aged Audit Report", style: 'headerStyle' },
                        exporterPdfFooter: function ( currentPage, pageCount ) {
                          return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
                        },
                        exporterPdfCustomFormatter: function ( docDefinition ) {
                        	 docDefinition.styles.headerStyle = { fontSize: 20, bold: true, alignment: 'center', margin: [0, 0, 20, 0] }; 
                             docDefinition.styles.footerStyle = { fontSize: 10, bold: true, alignment: 'center',  margin: [5, 0, 20, 0] }; 
                          return docDefinition;
                        },
                        exporterPdfOrientation: 'landscape',
                        exporterPdfPageSize: 'LETTER',
                        exporterPdfMaxGridWidth: 500,
                        exporterPdfFilename: 'AgedAuditReport.pdf',
                        exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
                       
                        onRegisterApi: function( gridApi ) {
                        	 $scope.gridApi = gridApi;
                        	 //Pagination
                        	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                        		 $scope.blockUI();
             		          paginationOptions.pageNumber = newPage;
             		          paginationOptions.pageSize = pageSize;
             		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
             		        paginationOptions.endIndex   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
             		       $scope.load();
             		        });
                        
                	    }
		    };
			 
			 $scope.gridOptions.exporterFieldCallback = function ( grid, row, col, value ){
				 
				 if ( col.name === 'partInOutTime' || col.name === 'scanTime'){					 	
					    value =  $filter('date')(value, 'dd/MM/yyyy HH:mm:ss');					   
					}				      
				  return value;
				 
			 };
 // Clear the filter
	 $scope.clearFilters = function() {
		 $scope.gridApi.core.clearAllFilters();
     };
// Reset the values
	    $scope.resetAgedAudit = function(){
	    	$scope.shops = "";
	    	$scope.lines = "";
	    	$scope.beginDate=new Date();
		    $scope.endDate=new Date();    	  
	    	$scope.gridOptions.data = [];
	    	$scope.clearFilters();	  
	    	$scope.agedAudit = {};
	    	$scope.agedAudit.transactionType = "1";
	    	$scope.partNumber="";	    	
	    	$scope.agedAudit.startIndex = 0;
	    	$scope.agedAudit.endIndex = 0;
	    	$scope.tags=[];
	    	$scope.ranData=[];
	    	$scope.locationIdData=[];	
	    	$scope.gridOptions.totalItems=0;
	    	$scope.location="";
	    	$scope.partNumber="";
	    	$scope.gridOptions.enablePaginationControls=false;	    
	    	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
	    	
		    $scope.shiftDropdown=false;
		    $scope.agedAudit.deviceId="";
	    };	    
   $scope.agedAuditData = function(){    	    	 
    	 agedAuditService.agedAuditReport($scope.agedAudit).then(function(response){
	    		$scope.gridOptions.data = [];
	    		if(response.data.objectList !== undefined && response.data.objectList !== null){
	    			
	    			if(response.data.statusType === 'success' ){
	    				$scope.gridOptions.enablePaginationControls=true;
	    				 response.data.objectList.forEach(function(row){	    	    	         	          
	    	    	           $scope.gridOptions.data = response.data.objectList;	 
	    	    	          });
	    				 
	    				 	
	    			} else {
	    				$scope.gridOptions.enablePaginationControls=false;
	    				$scope.alerts = [];
			            $scope.alerts.push({
			                type : response.data.statusType,
			                msg : response.data.statusMessage,
			                error : response.data.exceptionStackTrace,
			                errorClsName : response.data.exceptionClassName,
			                errorMsg : response.data.exceptionMessage
			            });
	    			}
	    			$.unblockUI();
	    		} else {
	    			$scope.searchDataEror=response.data.statusMessage;	    			
		            $.unblockUI();
	    		}
	    	});
     };
     
	 		/* Load data in grid */
		   $scope.load = function () {
		    	$scope.agedAudit.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

		    	if(paginationOptions.endIndex === 0){
		    		$scope.agedAudit.endIndex = $scope.gridOptions.paginationPageSize;
		    	}
		    	$scope.agedAudit.startIndex = paginationOptions.startIndex;
		    	$scope.agedAudit.endIndex = paginationOptions.pageSize;
		    	$scope.agedAudit.partNumber = $scope.partNumber;
		    	$scope.agedAudit.location = $scope.location;		
		    	
		    	$scope.agedAudit.fromDate = $scope.fromDate;
		    	$scope.agedAudit.toDate = $scope.toDate;
		    	
		    	agedAuditService.agedAuditReportCount($scope.agedAudit).then(function(response){
		    		$scope.gridOptions.totalItems = response.data.object;		    		
		    		$scope.recordCount = response.data.object;	
		    		$scope.agedAuditData();
		    	});
		    	
		    };
		    
		    // --------- search button ---------
            $scope.searchAgedAudit = function() {
            	if( $scope.validateFilter() == true){
            		$scope.blockUI();
            		$scope.fromDate = $filter('date')($scope.beginDate, 'yyyy-MM-dd');
            		$scope.toDate = $filter('date')($scope.endDate, 'yyyy-MM-dd');
            		$scope.alerts = [];
            		$scope.gridOptions.data = [];
            		$scope.agedAudit.partNumber=$scope.partNumber;
            		$scope.agedAudit.location=$scope.location;
            		$scope.agedAudit.isFullDownload=0;
            		paginationOptions.startIndex= 0;
            		paginationOptions.endIndex= 0;
            		paginationOptions.pageNumber= 1;
            		paginationOptions.pageSize= 100; 
            		$scope.gridOptions.paginationCurrentPage=1;
            		$scope.gridOptions.paginationPageSize=100;
            		$scope.searchClicked=true;
            		$scope.clearFilters();
            		//$.unblockUI();
            		$scope.load();
            		//$scope.agedAuditData();
            		$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
            	}else{
            		$scope.alerts = [];
	       			$scope.alerts.push({
	       				 type : 'danger',
	       				 msg : 'Plant/Shop or Part or RAN or Location is/are mandatory'
	       			});
            	}
            };
		    
            $scope.downloadAgedAudit =function(){
            	$scope.agedAudit.fromDate=$filter('date')($scope.beginDate, 'yyyy-MM-dd');;
		    	$scope.agedAudit.toDate=$filter('date')($scope.endDate, 'yyyy-MM-dd');
		    	$scope.agedAudit.partNumber=$scope.partNumber;
            	$scope.agedAudit.location=$scope.location;
            	$scope.agedAudit.isFullDownload=1;
            	return  agedAuditService.agedAuditDownload($scope.agedAudit).then(function(response){
            		for (var i = 0; i < response.objectList.length; i++) {
            			response.objectList[i].partNumber = '="'+response.objectList[i].partNumber+'"';
						response.objectList[i].partInOutTime =$filter('date')(response.objectList[i].partInOutTime, 'dd/MM/yyyy HH:mm:ss');
						response.objectList[i].scanTime =$filter('date')(response.objectList[i].scanTime, 'dd/MM/yyyy HH:mm:ss');
						response.objectList[i].lppd =$filter('date')(response.objectList[i].lppd, 'dd/MM/yyyy');
					}
					return response.objectList;
            	});
        
            };
         
            $scope.getDownloadAgedAuditReportHeader = function () {
            	return ["Part Number", "Location","Txn Type","Stock","Device","Ran","In-Out Time","Scan Time","Ran Expiry Date"];
           };
           $scope.csvColumnOrder=['partNumber','location','transactionType','count','deviceId','ran','partInOutTime','scanTime','lppd'];

			//Close the alert msg
            $scope.closeAlert = function(index) {
		        $scope.alerts.splice(index, 1);
		    };
		    
		    $scope.selectEndDate = function(endDate) {		    	
		    	$scope.fromMaxDate=$filter('date')(endDate, 'yyyy-MM-dd');
		    	 $scope.agedAudit.shift='';
		    	if($filter('date')(endDate, 'yyyy-MM-dd')== $filter('date')($scope.beginDate, 'yyyy-MM-dd')){
		    		$scope.shiftDropdown=false;
		    	}else{
		    		$scope.shiftDropdown=true;
		    	}		    	
		    };
		    
		    $scope.selectStartDate = function(startDate) {		    	
		    	 $scope.agedAudit.shift='';
		    	if($filter('date')(startDate, 'yyyy-MM-dd')== $filter('date')($scope.endDate, 'yyyy-MM-dd')){
		    		$scope.shiftDropdown=false;
		    	}else{
		    		$scope.shiftDropdown=true;
		    	}		    	
		    };
		    
		    $scope.validateFilter = function(){
		    	 if($scope.agedAudit.plant !== "" && $scope.agedAudit.plant !== null && $scope.agedAudit.plant !== undefined && $scope.agedAudit.shop !== "" && $scope.agedAudit.shop !== null && $scope.agedAudit.shop !== undefined)
				 {
					 return true;
				 }
		    	 else if($scope.ranData.length>0 || $scope.tags.length>0 || $scope.locationIdData.length>0){
		    		 return true;
		    	 }
		    	 else{
					 return false;
				 }
		     };
		
} ]);