wmsApp.controller('userMenuController', [ '$scope','userMenuService','$location','$window',
                        function($scope,userMenuService,$location,$window) {
	 $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"});
	$scope.searchUser = false;
	$scope.userMenus = [];
	$scope.menu={"userMenu":{}};
	$scope.menu.userId="";
	
	//search menu for user
	$scope.searchUserMenu = function(){
		$scope.blockUI();
		if($scope.menu.userId != ""){
			$scope.alerts = [];
			userMenuService.getUserMenus($scope.menu.userId).then(function(response){
				 if(response.data.objectList!== undefined && response.data.objectList!=null){	
		    			if(response.data.statusType === 'success' && response.data.objectList.length>0){
		    				$scope.userMenus = response.data.objectList;
		    				$scope.isAllSelected = $scope.userMenus.every(function(parent){
		    					if(parent.checked == false){
		    						return parent.checked;
		    					}
		    					else{
			    					  return parent.childMenu.every(function(child){
			    						return child.checked;
			    					});	
		    					}
		    				});
		    				$scope.searchUser = true;
		    			}
		    			else{
		    				$scope.searchUser = false;
		    				$scope.alerts = [];
		    				$scope.alerts.push({
		    					 type : response.data.statusType,
		    					 msg : response.data.statusMessage
		    				});
		    			}
		    			$.unblockUI();
				 }
				 $.unblockUI();
			});
		}
		else{
			$scope.alerts = [];
				$scope.alerts.push({
					 type : 'danger',
					 msg : 'Enter User ID'
				});
			$.unblockUI();
		}
	};

	
	//check & uncheck parent
	  $scope.clicker = function(parent){
		  parent.childMenu.forEach(function(child){
			  child.checked = parent.checked;
			  
			  /*AJ00482484 -- START*/
			  child.childMenu.forEach(function(subChild){
				  subChild.checked = child.checked;
			  });
			  /*AJ00482484 -- END*/
			  
	      });
		  
		  $scope.isAllSelected = $scope.userMenus.every(function(parent){
					return parent.checked;
		  });
	  };
	
	 //check & uncheck child
	 $scope.clickParent = function(parent){
		 var count = 0;
		   for(var i=0;i<parent.childMenu.length;i++){   
			  if(parent.childMenu[i].checked == false){
				  count++;
				  if(count ==parent.childMenu.length){
					  parent.checked = false;
				  }
				  else{
					  parent.checked = true;
				  }
			  }
			  
			  /*AJ00482484 -- START*/
			  child = parent.childMenu[i];
			  if(child.childMenu.length > 0){
				   console.log("child have Sub Childs == "+child.childMenu.length);
				   console.log("child Checked Status == "+child.checked);
				   angular.forEach(child.childMenu, function(subChild){
		    			 subChild.checked = child.checked;
		    		 });
			   }
			   /*AJ00482484 -- END*/
		   }
		   
		   $scope.isAllSelected = $scope.userMenus.every(function(parent){
				if(parent.checked == false){
					return parent.checked;
				}
				else{
					  return parent.childMenu.every(function(child){
						return child.checked;
					});	
				}
			});
	 };
	 
	 /*AJ00482484 -- START*/
	 $scope.clickChild = function(child){
		 var count = 0;
		   for(var i=0;i<child.childMenu.length;i++){   
			  if(child.childMenu[i].checked == false){
				  count++;
				  if(count ==child.childMenu.length){
					  child.checked = false;
				  }
				  else{
					  child.checked = true;
				  }
			  }
		   }
		   $scope.isAllSelected = $scope.userMenus.every(function(child){
				if(child.checked == false){
					return child.checked;
				}
				else{
					  return child.childMenu.every(function(subChild){
						return subChild.checked;
					});	
				}
			});
	 };
	 /*AJ00482484 -- END*/

	 //check & uncheck selectAll
	 $scope.selectAll = function(){
		 var checkAll = $scope.isAllSelected;
	     angular.forEach($scope.userMenus, function(parent){ 
	    	 parent.checked = checkAll; 
	    	 angular.forEach(parent.childMenu,function(child){
	    		 child.checked = checkAll;
	    		 /*AJ00482484 -- START*/
	    		 angular.forEach(child.childMenu, function(subChild){
	    			 subChild.checked = checkAll;
	    			 
	    		 });
	    		 /*AJ00482484 -- END*/
	    		 
	    	 });
	     });
	 };
		    
	//save menus 
	$scope.save = function(){
		//$scope.menu=[];
		if($scope.menu.userId!=""){
			$scope.menuArray=[];
			$scope.userMenus.forEach(function(child){
				if(child.checked == true){
					$scope.menuArray.push(child.menuId);
					if(child.childMenu.length>0){
						child.childMenu.forEach(function(child){
							if(child.checked == true){
								$scope.menuArray.push(child.menuId);
								/*AJ00482484 -- START*/
								if(child.childMenu.length>0){
									child.childMenu.forEach(function(child){
										if(child.checked == true){
											$scope.menuArray.push(child.menuId);
										}
									});
								}
								/*AJ00482484 -- END*/
							}
						});
					}
				}
			});
			$scope.menu.userMenu = $scope.menuArray.join(',');
			console.log("userMenu",$scope.menu.userMenu);
			if($scope.menu.userMenu != ""){
				$scope.blockUI();
				userMenuService.addUserMenu($scope.menu).then(function(response){
					if(response.data.statusType === 'failure'){
						$scope.searchUser = false;
						$scope.alerts = [];
						$scope.alerts.push({
							 type : response.data.statusType,
							 msg : response.data.statusMessage
						});
					}
					else{
						$scope.searchUser = true;
						$scope.alerts = [];
						$scope.alerts.push({
							 type : 'success',
							 msg : 'Data Saved Successfully! '
						});
					}
					$.unblockUI();
				});
			}
			else{
				$scope.alerts = [];
				$scope.alerts.push({
					 type : 'danger',
					 msg : 'Check atleast one menu'
				});
			}
		}
		else{
			$scope.searchUser = false;
			$scope.alerts = [];
			$scope.alerts.push({
				 type : 'danger',
				 msg : 'Enter User Id'
			});
		}
	};

	 $scope.closeAlert = function(index) {
	        $scope.alerts.splice(index, 1);
	 };

}]);