wmsApp.controller('reviewerListController', 
		[ '$scope','$window','$filter', '$rootScope', '$location','$q', 'reviewerListService','$http',
        function($scope,$window,$filter, $rootScope, $location,$q,reviewerListService,$http) {
			$scope.searchDataEror="Click search to fetch records.";
			
			 var paginationOptions = {
				 	startIndex : 0,
				 	maxResult : 0,
				    pageNumber: 1,
				    pageSize: 100,
				    sort: null
				  };
			 var input;
			 var fileObject;
			 $scope.reviewerResultData = [];
			 $rootScope.uploadPathImage = {
			    url: ''
			 }
			 $scope.reviewerAddList = {
					 id: -1
			 };
			 $scope.reviewerFetchList = {
					 	id: -1,
						zID:'',
						active: true,
						reviewerAmount:'',
						reviewerType:'',
						email:'',
						uploadDigitalSignaturePath:'',
						startIndex: 0,
						endIndex: 0
				};
			 $scope.deleteReviewerList = {
					 id:-1,
					 active:false
			 }
			 $scope.updateParticularReviewerListData = {
					 id: -1,
					 zID: '',
					 active: true,
					 reviewerAmount:'',
					 reviewerType:'',
					 email:'',
					 uploadDigitalSignaturePath:'',
					 startIndex:0,
					 endIndex:0
			 };
		
			 //Grid
			 $scope.gridOptions = {
			 enablePaginationControls:false,
			 enableGridMenu: true,
             enableFiltering: true,            
             enableColumnResize: true,
             paginationPageSizes: [100,250,500,750,1000],
     	     paginationPageSize: 100,         
             useExternalPagination: true,
             autoResize:true,
             enableSorting: true,
             enableColumnMenus: false,
             enablePinning: true,            
             columnDefs: [
            	 		  { field: 'id', displayName: 'ID'},
                          { field: 'zID', displayName: 'Z ID' },
                          { field: 'employeeName', displayName: 'Employee Name'},                          
			       	      { field: 'email', displayName: 'Email'},
			       	      //{ field: 'uploadDigitalSignaturePath', displayName: 'Sign', cellTemplate:'<button ng-click="grid.appScope.openInNewWindow($rootScope)" disabled="disabled">View</button>'},
			       	      //{field: 'uploadDigitalSignaturePath', displayName: 'Sign' , cellTemplate: '<img ng-src="grid.appScope.uploadDigitalSignaturePath" width="50%" height="50%">View</img>'},
			       	      { field: 'editAction',type: 'object',displayName: 'Edit Action', width:80, headerCellClass: 'center editableField',cellTemplate:'<button ng-click="grid.appScope.updateReviewerListData(row.entity.id)">Edit</button>'},
			       	      { field: 'deleteAction',type: 'object',displayName: 'Delete Action', width:80, headerCellClass: 'center editableField', cellTemplate: '<button ng-click="grid.appScope.deleteReviewerListData(row.entity.id)">Delete</button>'}
                        ],
                       
                        onRegisterApi: function( gridApi ) {
                        	 $scope.gridApi = gridApi;
                        	 //Pagination
                        	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                        		 $scope.blockUI();
             		          paginationOptions.pageNumber = newPage;
             		          paginationOptions.pageSize = pageSize;
             		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
             		        paginationOptions.maxResult   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
             		        $scope.loadPaginationGrid();
             		        });
                        
                	    }
		    };
			 
			 
			 $scope.loadPaginationGrid = function () {
			    	if(paginationOptions.endIndex === 0){
			    		paginationOptions.endIndex = $scope.gridOptions.paginationPageSize;
			    	}
			    	
			    	$scope.reviewerFetchList.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

			    	if(paginationOptions.endIndex === 0){
			    		$scope.reviewerFetchList.endIndex = $scope.gridOptions.paginationPageSize;
			    	}
			    	$scope.reviewerFetchList.startIndex = paginationOptions.startIndex;
			    	$scope.reviewerFetchList.endIndex = paginationOptions.pageSize;
			    	
			    	reviewerListService.reviewerListCount().then(function(response){
		    			$scope.gridOptions.totalItems = response.data.object;
		    			$scope.recordCount = response.data.object;
		    			
		    		});
				    // --End
			    };

			 $scope.openInNewWindow = function($rootScope){
				 	console.log($rootScope.uploadPathImage.url)
			    	//$scope.click($rootScope.uploadPathImage.url);
			    };
			    
			 
			    
			    $scope.setReviewerAmount = function(reviewerType) {
			    	console.log(reviewerType)
			    	console.log(document.getElementById('reviewerAmount').disabled)
			    	if(reviewerType != undefined) {
			    		if(reviewerType == 'DefaultReviewer') {
				    		 $scope.reviewerFetchList.reviewerAmount = 0;
				    		 $scope.updateParticularReviewerListData.reviewerAmount =0;
				    		 document.getElementById('reviewerAmount').disabled = 'disabled';
				    		 console.log(document.getElementById('reviewerAmount').disabled)
				    	}else if(reviewerType == 'AdditionalReviewer') {
				    		$scope.reviewerFetchList.reviewerAmount = '';
				    		$scope.updateParticularReviewerListData = '';
				    		$("#reviewerAmount").removeAttr("disabled");
				    	}	
			    	}
			    };
			 
			 $scope.updateReviewerList = function() {
				 $scope.blockUI();
				 $scope.gridOptions.data = [];
				 var updateListError = false;
				 var zid = $('#zID').val();
				 if(zid == "" || zid == undefined){
					 document.getElementById('zIDError').innerHTML ='Please provide Z ID';
					 updateListError = true;
				 } else {
					 $scope.reviewerFetchList.zID = zid;
				 }
         		var emailAddressValidation = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
				 var email = $("#email").val();

        		if(!email.match(emailAddressValidation)) {
        			document.getElementById('emailError').innerHTML = 'Please enter the valid email address';
        			addErrorList = true;
        		} 

				 if(email == "" || email == undefined) {
					 document.getElementById('emailError').innerHTML = 'Please enter the email address';
					 updateListError = true;
				 }
				 $scope.reviewerFetchList.email = email;
				 
				 
				 
				 if($("#uploadDigitalSignatureFile").val()!=""){
					 
					 
					 var ext = $("#uploadDigitalSignatureFile").val().split('.').pop().toLowerCase();
		        		var validExtension = true;
		        		var colorPhotograph = document.getElementById('uploadDigitalSignatureFile').files.length;
		        		if(colorPhotograph>0){
		        			if($.inArray(ext,['png','jpg','jpeg']) == -1){
		        				document.getElementById('uploadDigitalSignaturePathError').innerHTML = 'Please upload file whose extension ends with png, jpg or jpeg';
		        				updateListError = true;
		        				validExtension = false;
		        			}
		        		}
				 }
				 input = document.getElementById('uploadDigitalSignatureFile').files;
	        		var fileSize = 0;
	        		var name;
	        		if(input!=undefined && input.length!=0) {
	        			fileSize = input[0].size;
	        			name = input[0].name;
	        		}
	        		var colorPhotographSize = fileSize/1024/1024 + "MB";
	        		if(validExtension == true && colorPhotographSize > "2MB") {
	        			document.getElementById('uploadDigitalSignaturPathError').innerHTML = 'Please upload file which is less than 2 MB';
	        			updateListError = true;
	        		} 
	        		
	        		if(name!=undefined) {
	        			$scope.reviewerFetchList.uploadDigitalSignaturePath = name;
	        		}else {
	        			document.getElementById('uploadDigitalSignatureId').style.display = 'none';
	        			$scope.reviewerFetchList.uploadDigitalSignaturePath = $scope.reviewerFetchList.uploadDigitalSignaturePath;
	        		}
        		console.log($scope.reviewerFetchList.id)
        		
        		
        		
        		if($scope.reviewerFetchList.id > 0) {
        			$scope.reviewerFetchList.id = $scope.reviewerFetchList.id;
        		} else {
        			$scope.reviewerFetchList.id = 0;
        		}
        		
        		
        		var reviewerType = $("#reviewerType").val();
        		 if(reviewerType == "" || reviewerType == undefined) {
					 document.getElementById('reviewerTypeError').innerHTML = 'Please select reviewer type';
					 updateListError = true;
				 }
        		$scope.reviewerFetchList.reviewerType = reviewerType;
        		
        		 var reviewerAmount = $("#reviewerAmount").val();
				 if((reviewerAmount == "" || reviewerAmount == undefined) && reviewerType!='DefaultReviewer'){
					 document.getElementById('reviewerAmountError').innerHTML = 'Please provide reviewer amount';
					 updateListError = true;
				 }
		/*		 if(reviewerAmount.startsWith("-")) {
					 document.getElementById('reviewerAmountError').innerHTML = 'Reviewer Amount cannot be Negative ';
					 updateListError = true;
				 } else {*/
					 $scope.reviewerFetchList.reviewerAmount = reviewerAmount;
				 //}
        		
        		
        		console.log("updatelisterror"+updateListError)
        		
        		if(updateListError == true) {
        			$.unblockUI();
        			return;
        		}
        		
        		if(updateListError == false) {
        			reviewerListService.addReviewerList($scope.reviewerFetchList).then(function(response){
        				
        				
        				console.log(response)
        				if(response.data.object.id == -1){
    						document.getElementById('zIDError').innerHTML = 'Please enter the valid Z ID';
    						$.unblockUI();
    						return;
    					} else if (response.data.object.id == -2) {
    						document.getElementById('reviewerTypeError').innerHTML = 'Already two default reviewer has been added for the user';
    						$.unblockUI();
    						return;
    					}else if(response.data.object.id == -3) {
    						document.getElementById('reviewerAmountError').innerHTML = 'Reviewer Amount already exists in the database';
    						$.unblockUI();
    						return;
    					} else if(response.data.object.id == -4) {
    						document.getElementByID('zIDError').innerHTML = 'Duplicate entries are not allowed';
    						$.unblockUI();
    						return;
    					}
			    		$scope.gridOptions.totalItems = response.data.object;
		    			$scope.recordCount = response.data.object;
			    		$scope.updateReviewerData($scope.reviewerFetchList,response);
			    	});
        		}
			 };
			 
			 $scope.updateReviewerData = function(reviewerFetchList, response) {
				     			 
				 $scope.reviewerFetchList = reviewerFetchList;
				 
    			 reviewerListService.getReviewerList($scope.reviewerFetchList).then(function(response){
			    		if(response.data.objectList !== undefined && response.data.objectList !== null && response.data.statusMessage !== "No Data Found !!!"){
			    			console.log(response.data.statusType)
			    			if(response.data.statusType === 'success' ){
			    				$scope.gridOptions.enablePaginationControls=true;
			    				
			    				
			    				$scope.updateReviewerListGridData = [];
			    				
			    				
			    				$scope.idValue = [];
			    				
			    				
			    				for (var i = 0; i < response.data.objectList.length; i++) {
			    					
			    					var rowObj = {};
			    					rowObj["id"] = response.data.objectList[i].id;
			    					rowObj["zID"] =response.data.objectList[i].zID;
			    					//rowObj["employeeName"] = response.data.objectList[i].employeeName;
			    					//rowObj["employeeName"] = "Sudharsan R";
			    					rowObj["employeeName"] = response.data.objectList[i].employeeName;
			    					rowObj["email"] = response.data.objectList[i].email;
			    					rowObj["uploadDigitalSignaturePath"] = response.data.objectList[i].uploadDigitalSignaturePath;
			    					
			    					//grid.appScope.uploadDigitalSignaturePath = response.data.objectList[i].uploadDigitalSignaturePath;
			    					
			    						
			    						$scope.updateReviewerListGridData.push(rowObj);
			    						
			    				}
			    				$scope.gridOptions.data = [];
			    				// Method for tree view creation in Data grid
			    				writeoutNode($scope.updateReviewerListGridData, 0, $scope.gridOptions.data);
			    				$scope.reviewerFetchList.id = '';
			    				$scope.reviewerFetchList.zID = '';
			    				$scope.reviewerFetchList.reviewerAmount = '';
			    				$scope.reviewerFetchList.reviewerType = '';
			    				$scope.reviewerFetchList.email = '';
			    				$scope.reviewerFetchList.uploadDigitalSignaturePath = '';
			    				document.getElementById('updateMessage').innerHTML = 'Reviewer Updated Successfully !!';
			    				document.getElementById('addMessage').style.display = 'none';
			    			} else {
			    				$scope.gridOptions.enablePaginationControls=false;
			    				$scope.alerts = [];
					            $scope.alerts.push({
					                type : response.data.statusType,
					                msg : response.data.statusMessage,
					                error : response.data.exceptionStackTrace,
					                errorClsName : response.data.exceptionClassName,
					                errorMsg : response.data.exceptionMessage
					            });
			    			}
			    			$.unblockUI();
			    		} else {
			    			$scope.searchDataEror=response.data.statusMessage;	    			
				            $.unblockUI();
			    		}
			    	});
			 }
			 $scope.addReviewerList = function() {
	            		$scope.blockUI();
	            		$scope.gridOptions.data = [];
	            		var addErrorList = false;
	            		console.log($scope.reviewerFetchList.zID)
	            		
	            		var zid = $("#zID").val();
	            		console.log(zid)
	            		if(zid == undefined || zid == "") {
	            			document.getElementById('zIDError').innerHTML = 'Please provide Z ID';
	            			addErrorList =true;
	            		}
	            		else {
	            			$scope.reviewerFetchList.zID = $scope.reviewerFetchList.zID;
	            		} 
	            		var email = $("#email").val();
	            		var emailAddressValidation = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	            		if(!email.match(emailAddressValidation)) {
	            			document.getElementById('emailError').innerHTML = 'Please enter the valid email address';
	            			addErrorList = true;
	            		} 
	            		
	            		
	            		var reviewerType = $("#reviewerType").val();
	            		if(reviewerType == "" || reviewerType == undefined) {
	            			document.getElementById('reviewerTypeError').innerHTML = 'Please select reviewer type';
	            			addErrorList = true;
	            		}
	            		
	            		
	            		var reviewerAmount = $("#reviewerAmount").val();
	            		console.log(reviewerAmount)
	            		
	            		if((reviewerAmount == "" || reviewerAmount == undefined) && reviewerType!='Default Reviewer') {
	            			document.getElementById('reviewerAmountError').innerHTML = 'Please provide reviewer amount';
	            			addErrorList = true;
	            		}
	            		/*if(reviewerAmount.startsWith("-") ) {
	            			document.getElementById('reviewerAmountError').innerHTML = 'Reviewer Amount Cannot be Negative';
	            			addErrorList = true;
	            		} else {*/
	            			$scope.reviewerFetchList.reviewerAmount = $scope.reviewerFetchList.reviewerAmount;
	            		//}
	            		if(email== undefined || email == "") {
	            			document.getElementById('emailError').innerHTML = 'Please enter the email address';
	            			addErrorList = true;
	            		}
	            		
	            		if($("#uploadDigitalSignatureFile").val()!="") {
	            			var ext = $("#uploadDigitalSignatureFile").val().split('.').pop().toLowerCase();
		            		var colorPhotograph = document.getElementById('uploadDigitalSignatureFile').files.length;
		            		var validExtension = true;
		            		if(colorPhotograph>0){
		            			if($.inArray(ext,['png','jpg','jpeg']) == -1){
		            				document.getElementById('uploadDigitalSignaturePathError').innerHTML = 'Please upload file whose extension ends with png, jpg or jpeg';
		            				addErrorList = true;
		            				validExtension = false;
		            			}
		            		}
	            		}
	            		
	            		input = document.getElementById('uploadDigitalSignatureFile').files;
	            		var fileSize =0;
	            		var name;
	            		if(input!=undefined && input.length!=0){
	            			fileSize = input[0].size;
	            			name = input[0].name;
	            		}
	            		var colorPhotographSize = fileSize/1024/1024 + "MB";
	            		if(validExtension == true && colorPhotographSize > "2MB") {
	            			document.getElementById('uploadDigitalSignaturePathError').innerHTML = 'Please upload file which is less than 2 MB';
	            			addErrorList = true;
	            		} 
	            		
	            		console.log(name)
	            		
	            		if(name!=undefined){
	            			$scope.reviewerFetchList.uploadDigitalSignaturePath = name;
	            		} else {
	            			document.getElementById('uploadDigitalSignaturePathError').innerHTML = 'Please select upload digital signature file';
	            			addErrorList = true;
	            		}
	            		
	            		paginationOptions.startIndex= 0;
	            		paginationOptions.maxResult= 0;
	            		paginationOptions.pageNumber= 1;
	            		paginationOptions.pageSize= 100; 
	            		$scope.gridOptions.paginationCurrentPage=1;
	            		$scope.gridOptions.paginationPageSize=100;
	            		console.log(addErrorList)
	            		
	            		
	            		if(addErrorList == true) {
	            			$.unblockUI();
	            			return;
	            		}
	            		
	            		if(addErrorList == false){
	            			$scope.load();
	            		}
	            		$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
	            };
			    
	            
	            
	            
	            $scope.load = function () {
	            	$scope.reviewerFetchList.id = 0;
			    	$scope.reviewerFetchList.zID = $("#zID").val();
			    	$scope.reviewerFetchList.reviewerAmount = $("#reviewerAmount").val();
			    	$scope.reviewerFetchList.reviewerType = $("#reviewerType").val();
			    	$scope.reviewerFetchList.email = document.getElementById('email').value;
			    	if(document.getElementById('uploadDigitalSignatureFile').files[0]!=undefined){
			    		$scope.reviewerFetchList.uploadDigitalSignaturePath = document.getElementById('uploadDigitalSignatureFile').files[0].name;
			    	}
			    	
			    	$scope.reviewerFetchList.active = true;
			    	console.log($scope.reviewerFetchList.zID)
			    	console.log($scope.reviewerFetchList.id)
			    	console.log($scope.reviewerFetchList.reviewerAmount)
			    	console.log($scope.reviewerFetchList.reviewerType)
			    	console.log($scope.reviewerFetchList.email)
			    	console.log($scope.reviewerFetchList.uploadDigitalSignaturePath)
			    	reviewerListService.addReviewerList($scope.reviewerFetchList).then(function(response){
			    		console.log(response)
			    		if(response!=null && response!=undefined) {
			    			if(response.data.object.id == -1){
	    						document.getElementById('zIDError').innerHTML = 'Please enter the valid Z ID';
	    						$.unblockUI();
	    						return;
	    					} else if (response.data.object.id == -2) {
	    						document.getElementById('reviewerTypeError').innerHTML = 'Already two default reviewer has been added for the user';
	    						$.unblockUI();
	    						return;
	    					}else if(response.data.object.id == -3) {
	    						document.getElementById('reviewerAmountError').innerHTML = 'Reviewer Amount already exists in the database';
	    						$.unblockUI();
	    						return;
	    					} else if(response.data.object.id == -4) {
	    						document.getElementById('zIDError').innerHTML = 'Duplicate entries are not allowed';
	    						$.unblockUI();
	    						return;
	    					}
			    		}
    					
			    		$scope.gridOptions.totalItems = response.data.object;
		    			$scope.recordCount = response.data.object;
			    		$scope.reviewerListData($scope.reviewerFetchList,response);
			    	});
			    	
			    };
			 
			    
			    
			    $scope.deleteReviewerListData = function(idValue){
			    	var isDeleteReviewerConfirmed = confirm("Are you sure you want to delete the record?");
			    	if(isDeleteReviewerConfirmed) {
			    		$scope.deleteReviewerList.id = idValue;
				    	$scope.deleteReviewerList.active = false;
				    	$("#zID").val('');
				    	$("#reviewerAmount").val('');
				    	$("#reviewerType").val('');
				    	$("#email").val('');
				    	$("#uploadDigitalSignatureFile").val('');
				    	reviewerListService.deleteReviewerList($scope.deleteReviewerList).then(function(response){
				    			console.log(response)
				    			if(response.data.objectList!=undefined && response.data.objectList!=null && response.data.objectList!="No Data Found !!!") {
				    				console.log(response.data.objectList)
				    				if(response.data.statusType == 'success') {
				    					$scope.gridOptions.enablePaginationControls=true;
				    					$scope.gridOptions.data = [];
				    					$scope.gridOptions.data = response.data.objectList;
				    					document.getElementById('deleteMessage').innerHTML = response.data.statusMessage;
				    					document.getElementById('addMessage').innerHTML = '';
				    					document.getElementById('updateMessage').innerHTML = '';
				    				}
				    			} else {
				    				$scope.gridOptions.data = [];
				    			}
				    	});
			    	} else {
			    		return false;
			    	}
			    };
			    
			    
			    $scope.clearReviewerData = function() {
			    	$scope.reviewerFetchList.id = -1;
			    	$("#zID").val("");
			    	document.getElementById('zIDError').innerHTML = '';
			    	$("#reviewerAmount").val("");
			    	document.getElementById('reviewerAmountError').innerHTML = '';
			    	$("#reviewerType").val("");
			    	document.getElementById('reviewerTypeError').innerHTML = '';
			    	$("#email").val("");
			    	document.getElementById('emailError').innerHTML = '';
			    	$("#uploadDigitalSignatureFile").val("");
			    	document.getElementById('uploadDigitalSignaturePathError').innerHTML = '';
			    	$("#addButton").removeAttr("disabled");
			    	$("#reviewerAmount").removeAttr("disabled");
			    	document.getElementById('uploadDigitalSignatureId').style.display = 'block';
			    }
			    
			    
			    
				 $scope.updateReviewerListData = function(idValue){
					 console.log(idValue)
					 $scope.reviewerFetchList.id = idValue;
					 $scope.reviewerFetchList.active = true;
					 $scope.reviewerFetchList.zID = '';
					 $scope.reviewerFetchList.reviewerAmount = '';
					 $scope.reviewerFetchList.reviewerType = '';
					 $scope.reviewerFetchList.email = '';
					 $scope.reviewerFetchList.uploadDigitalSignaturePath = '';
					 document.getElementById('addButton').disabled = 'disabled';
					 document.getElementById('addMessage').innerHTML = '';
					 document.getElementById('updateMessage').innerHTML = '';
					 document.getElementById('deleteMessage').innerHTML = '';
					 document.getElementById('uploadDigitalSignatureId').style.display = 'none';
					 reviewerListService.getReviewerList($scope.reviewerFetchList).then(function(response){
				    		if(response.data.objectList !== undefined && response.data.objectList !== null && response.data.statusMessage !== "No Data Found !!!"){
				    			if(response.data.statusType === 'success' ){
				    				$scope.gridOptions.enablePaginationControls=true;
				    				

			    					for (var i = 0; i < response.data.objectList.length; i++) {
				    					
				    					$("#zID").val(response.data.objectList[i].zID);
				    					$("#reviewerAmount").val(response.data.objectList[i].reviewerAmount);
				    					$("#reviewerType").val(response.data.objectList[i].reviewerType);
				    					$("#email").val(response.data.objectList[i].email);
				    					$("#uploadDigitalSignaturePath").val(response.data.objectList[i].uploadDigitalSignaturePath);
				    					
				    				}
				    			} else {
				    				$scope.gridOptions.enablePaginationControls=false;
				    				$scope.alerts = [];
						            $scope.alerts.push({
						                type : response.data.statusType,
						                msg : response.data.statusMessage,
						                error : response.data.exceptionStackTrace,
						                errorClsName : response.data.exceptionClassName,
						                errorMsg : response.data.exceptionMessage
						            });
				    			}
				    			$.unblockUI();
				    		} else {
				    			$scope.searchDataEror=response.data.statusMessage;	    			
					            $.unblockUI();
				    		}
				    	});
				 };
				 
				 
			    
			    $scope.reviewerListData = function(reviewerFetchList,response,searchParameter){    
			    		
			    		$("#zIDError").innerHTML = '';
			    		$("#reviewerAmountError").innerHTML = '';
			    		$("#reviewerTypeError").innerHTML = '';
			    		$("#emailError").innerHTML = '';
			    		$("#uploadDigitalSignaturePathError").innerHTML = '';
			    	
			    		$.blockUI();
			    		
			    		console.log("reviewer lis add"+reviewerFetchList)
			    		if(reviewerFetchList!=undefined) {
			    			if(reviewerFetchList.zID!=undefined) {
				    			$scope.reviewerFetchList.zID = reviewerFetchList.zID;
				    		}
				    		if(reviewerFetchList.employeeName!=undefined){
				    			$scope.reviewerFetchList.employeeName = reviewerFetchList.employeeName;
				    		}
				    		if(reviewerFetchList.reviewerAmount!=undefined) {
				    			$scope.reviewerFetchList.reviewerAmount = reviewerFetchList.reviewerAmount;
				    		}
				    		if(reviewerFetchList.reviewerType !=undefined) {
				    			$scope.reviewerFetchList.reviewerType = reviewerFetchList.reviewerType;
				    		}
				    		if(reviewerFetchList.email!=undefined) {
				    			$scope.reviewerFetchList.email = reviewerFetchList.email;
				    		}
				    		$scope.reviewerFetchList.active = true;
				    		if(reviewerFetchList.uploadDigitalSignaturePath!=undefined) {
				    			$scope.reviewerFetchList.uploadDigitalSignaturePath = reviewerFetchList.uploadDigitalSignaturePath;
				    		}
			    		} else {
			    			if($scope.reviewerFetchList.id > 0) {
			    				$scope.reviewerFetchList.id = $scope.reviewerFetchList.id;
			    			} else {
			    				$scope.reviewerFetchList.id = -1;
			    			}
			    			if($("#reviewerAmount").val() !=undefined && $("#reviewerAmount").val()!=""){
			    				$scope.reviewerFetchList.reviewerAmount = $("#reviewerAmount").val();
			    			} else {
			    				$scope.reviewerFetchList.reviewerAmount = -1;
			    			}
			    			if($('#zID').val()!=undefined && $("#zID").val()!=""){
			    				$scope.reviewerFetchList.zID = $("#zID").val();
			    			} else {
			    				$scope.reviewerFetchList.zID = '';
			    			} 
			    			if($("#reviewerType").val()!=undefined && $("#reviewerType").val() !="") {
			    				$scope.reviewerFetchList.reviewerType = $("#reviewerType").val();
			    			} else {
			    				$scope.reviewerFetchList.reviewerType = '';
			    			}
			    			//$scope.reviewerFetchList.employeeName = '';
			    			if($("#email").val()!=undefined && $("#email").val()!=""){
			    				$scope.reviewerFetchList.email = $("#email").val();
			    			} else {
			    				$scope.reviewerFetchList.email = '';
			    			}
			    			$scope.reviewerFetchList.active = true;
			    			if($("#uploadDigitalSignatureFile").val() !=undefined && $("#uploadDigitalSignatureFile").val()!="") {
			    				$scope.reviewerFetchList.uploadDigitalSignaturePath = $("#ploadDigtialSignatureFile").val();
			    			} else {
			    				$scope.reviewerFetchList.uploadDigitalSignaturePath = '';
			    			}
			    		}
			    	 reviewerListService.getReviewerList($scope.reviewerFetchList).then(function(response){
				    		console.log(response);
				    		if(response.data.objectList !== undefined && response.data.objectList !== null && response.data.statusMessage !== "No Data Found !!!"){
				    			console.log(response.data.statusType)
				    			if(response.data.statusType === 'success' ){
				    				$scope.gridOptions.enablePaginationControls=true;
				    				angular.forEach(response.data.objectList, function(reviewerListObject, reviewerListKey){
						    					
						    					$scope.reviewerAddList.id= reviewerListObject.id;
						    					reviewerListObject["id"] = reviewerListObject.id;
						    					console.log("zid comas "+reviewerListObject.zID);
						    					reviewerListObject["zID"] = reviewerListObject.zID;
						    					//reviewerListObject["employeeName"] = "Sudharsan R";
						    					reviewerListObject["employeeName"] = reviewerListObject.employeeName;
						    					console.log("enail comes"+reviewerListObject.email)
						    					reviewerListObject["email"] = reviewerListObject.email;
						    					$rootScope.uploadPathImage.url = reviewerListObject.uploadDigitalSignaturePath;
						    					//grid.appScope.uploadDigitalSignaturePath = reviewerListObject.uploadDigitalSignaturePath;
						    					reviewerListObject["uploadDigitalSignaturePath"] = reviewerListObject.uploadDigitalSignaturePath;
						    					
						    					$scope.gridOptions.data = response.data.objectList;
						    					$scope.reviewerResultData.push(reviewerListObject);
						    					$scope.reviewerFetchList.zID = '';
						    					$scope.reviewerFetchList.reviewerAmount = '';
						    					$scope.reviewerFetchList.email='';
						    					$scope.reviewerFetchList.reviewerType = '';
						    					$scope.reviewerFetchList.uploadDigitalSignaturePath = '';
						    					if(searchParameter == undefined ) {
						    						document.getElementById('addMessage').innerHTML = 'Reviewer Added Successfully!!';
						    					}
						    					document.getElementById('updateMessage').style.display = 'none';
						    					
						    					
						    					if(response.data.statusMessage == "Failure") {
						    						$scope.gridOptions.enablePaginationControls=false;
								    				$scope.alerts = [];
										            $scope.alerts.push({
										                type : response.data.statusType,
										                msg : response.data.statusMessage,
										                error : response.data.exceptionStackTrace,
										                errorClsName : response.data.exceptionClassName,
										                errorMsg : response.data.exceptionMessage
										            });
						    					}
						    					
						    					 $.unblockUI();
						    				});
				    				
				    				
				    			}
				    		} else {
				    			$.unblockUI();
				    		}
			    	 });
			    };
				    				 
			    
			    $scope.getDownloadLiveReceiptAtyMismatchHeader = function () {
	            	return ["ID", "Z ID", "Employee Name", "Email"];
	           };
	           
	           $scope.csvColumnOrder=['id','zID', 'employeeName','email'];
	           
			     
			     var writeoutNode = function( childArray, currentLevel, dataArray ){
						if (typeof childArray !== 'undefined') {
						      childArray.forEach(function(childNode) {
						        if (typeof childNode.locations !== 'undefined') {
						          if (childNode.locations.length >= 0) {
						            childNode.$$treeLevel = currentLevel;
						          }
						        }
						        dataArray.push(childNode);
						        writeoutNode(childNode.locations, currentLevel + 1, dataArray);
						      });
						    }
					};
	
					var handleFileSelect = function( event ){
					    var target = event.srcElement || event.target;
					    
					    if (target && target.files && target.files.length === 1) {
					    	 
					       fileObject = target.files[0];
					      console.log("fileObject",fileObject);
					      console.log(fileObject.name)
						    }	
					  };
					 
					  var fileChooser = document.querySelectorAll('#uploadDigitalSignatureFile');
					  
					  if ( fileChooser.length !== 1 ){
					    console.log('Found > 1 or < 1 file choosers within the menu item, error, cannot continue');
					  } else {
					    fileChooser[0].addEventListener('change', handleFileSelect, false);
					  }
}]);