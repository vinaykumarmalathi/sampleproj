wmsApp.controller('FifoController', 
		[ '$scope','$window','$filter', '$location','$q', 'fifoService','locationService','uiGridTreeViewConstants', '$http','commonService','localStorageService','partNumberService','ranService',
        function($scope,$window,$filter, $location,$q, fifoService,locationService,uiGridTreeViewConstants, $http,commonService,localStorageService,partNumberService,ranService) {
			$scope.searchDataEror="Click search to fetch records.";
			$scope.beginDate=new Date();
		    $scope.endDate=new Date();
		    $scope.fromMaxDate=new Date();
               $scope.shiftDropdown=false;
			   $scope.todayDate = new Date();
			   $scope.transactionList = ["In", "Out"];	
			   $scope.shiftList = ["A", "B" ,"C"];
			    $scope.beginDatePickerOpen = false;
			    $scope.endDatePickerOpen = false;

			    $scope.openBeginDatePicker = function ($event) {			    	
			    $event.preventDefault();
			    $event.stopPropagation();
			    $scope.beginDatePickerOpen = !$scope.beginDatePickerOpen;
			    };

			    $scope.openEndDatePicker = function ($event) {
			    $event.preventDefault();
			    $event.stopPropagation();
			    $scope.endDatePickerOpen = !$scope.endDatePickerOpen;			  
			    };
			 
			    
			
			// --------- Part Number List ---------
			$scope.partNumber='';
			$scope.searchClicked=false;
			$scope.tags=[];	 
			/*ON ADD NEW PART TAG*/
			$scope.transactionList= ["In", "Out"];
			$scope.tagAdded = function(tag) {
				
				  $scope.partArray = [];
				  
				     for (var j=0; j < $scope.tags.length; j++) {
				    	 
				    	 $scope.partArray.push($scope.tags[j].text);
				    	 console.log("Part Array",$scope.partArray);
				      }
				     $scope.partNumber=$scope.partArray.join(',');
				     console.log("Part Number",$scope.partNumber);
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			    };
			/*ON REMOVE ADDED PART TAG*/
			    
		    $scope.tagRemoved = function(tag) {			   
		    	 $scope.partArray = [];
			     for (var j=0; j < $scope.tags.length; j++) {

			    	 $scope.partArray.push($scope.tags[j].text);
			      }
			     $scope.partNumber=$scope.partArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    $scope.addingTag = function(tag) {
		    	console.log("Tag.text",tag.text);
		    	  tag.text = tag.text.replace(/ /g, ',');
		    	  console.log("Tag.text 2",tag.text);
		    	  return tag;
		    	};
		    	
			
		    /*AUTOCOMPLE PART ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadParts = function(query) {		    	
		    	var partInputObj = {"partNumber": query};			    	
		    	return partNumberService.partNumberList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    });			    				         
		    };
			    
			  
		    /*ON ADD NEW LOCATION TAG*/
		    
			$scope.location="";
			$scope.locationIdData=[];	 
		    $scope.locationAdded = function(tag) {					
		    $scope.locationArray = [];
			    for (var j=0; j < $scope.locationIdData.length; j++) {
			    	$scope.locationArray.push($scope.locationIdData[j].text);
			    }
			    $scope.location=$scope.locationArray.join(',');
			    $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    /*ON REMOVE ADDED LOCATION TAG*/
		    
		    $scope.locationRemoved = function(tag) {			   
		    	 $scope.locationArray = [];
			     for (var j=0; j < $scope.locationIdData.length; j++) {
			    	 $scope.locationArray.push($scope.locationIdData[j].text);
			     }
			     $scope.location=$scope.locationArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    /* RAN Auto Completion - Start */
		    $scope.ranData=[];	
		    
		    $scope.ranAdded = function(tag) {			
				console.log("tagAdded:",tag);
				  $scope.ranArray = [];
				     for (var j=0; j < $scope.ranData.length; j++) {
				    	 $scope.ranArray.push($scope.ranData[j].text);
				      }
				     $scope.fifo.ran=$scope.ranArray.join(',');
				     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
			};
		    
		    $scope.ranRemoved = function(tag) {			   
		    	 $scope.ranArray = [];
			     for (var j=0; j < $scope.ranData.length; j++) {

			    	 $scope.ranArray.push($scope.ranData[j].text);
			      }
			     $scope.fifo.ran=$scope.ranArray.join(',');
			     $(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
		    };
		    
		    $scope.loadRan = function(query) {
		    	var partInputObj = {"ranId": query};
		    	return ranService.ranList(partInputObj).then(function(response){			    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){	
		        			 console.log(response.data.object);
		        			  return response.data.object;                           
		        		 }
		        	 }		    		
			    });	
		    };
		    
		   /* $scope.pasteRanTags = function(event){
				  event.preventDefault();
				  
				  //For IE
				  if ($window.clipboardData && $window.clipboardData.getData) {
					  $scope.tagsCopies = $window.clipboardData.getData('Text').split(/[,\n\t\s]+/);
					  console.log("IE");
					  console.log("$scope.tagsCopies",$scope.tagsCopies);
				  }
				  // Other Browsers
				  else if (event.originalEvent.clipboardData && event.originalEvent.clipboardData.getData) { 
					  $scope.tagsCopies = event.originalEvent.clipboardData.getData('text/plain').split(/[,\n\t\s]+/);
					  console.log("Other Browser");
					  console.log("$scope.tagsCopies",$scope.tagsCopies);
				  }
			      
			      $scope.tagsCopies = $scope.findDuplicate($scope.tagsCopies);
			      $scope.partNumberArray = [];
			      if($scope.fifo.ran != undefined){
			    	  $scope.partNumberArray = $scope.fifo.ran.split(',');
			      }
			      for (var j=0; j < $scope.tagsCopies.length; j++) {
			    	      var obj = {};
			    	      // Condition to check if string is not empty and whitespace
			    	      $scope.tagsCopies[j] = $scope.tagsCopies[j].trim();
			    	      // Checking duplication for copy content with existing tags
			    	      var Index = $scope.partNumberArray.indexOf($scope.tagsCopies[j]);
			    	      if($scope.tagsCopies[j] != "" && Index == -1){
			    	    	  obj['text'] = $scope.tagsCopies[j];
			    	    	  $scope.ranData.push(obj);
			    	    	  $scope.ranAdded(obj);
			    	      }
				  }
			      setTimeout(function(){
			    	    $scope.$digest();
			      }, 100);
			     
			};*/
		    /*RAN Auto Completion - End */
		    
		    
		 // --------- Location drop down list -------

			  if($window.sessionStorage.getItem('locationDPCollection') == null || $window.sessionStorage.getItem('locationDPCollection')=='undefined' || $window.sessionStorage.getItem('locationDPCollection')==undefined){
				  commonService.getAllPlants()
				  .success(function(response){					 
					  $scope.locations = response.objectList;				
					  $window.sessionStorage.setItem('locationDPCollection',JSON.stringify($scope.locations));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.locations = JSON.parse(sessionStorage.locationDPCollection);
			  }
			  
			  // --------- Section drop down list ---------

			  if($window.sessionStorage.getItem('sectionDPCollection') == null || $window.sessionStorage.getItem('sectionDPCollection')=='undefined' || $window.sessionStorage.getItem('sectionDPCollection')==undefined){
				  commonService.getAllSections()
				  .success(function(response){					 
					  $scope.sections = response.objectList;	
					  $window.sessionStorage.setItem('sectionDPCollection',JSON.stringify($scope.sections));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.sections = JSON.parse(sessionStorage.sectionDPCollection);
			  }
			  
			// --------- Shops drop down list ---------
			  
			    $scope.loadShopLine = function(){
			    	 $scope.fifo.line = '';
			    	 $scope.fifo.shop = '';
			    	 $scope.fifo.supplier='';
			    	 commonService.getLineList($scope.fifo.plant)
					  .success(function(response){
						  $scope.lines = response.objectList;				
					  })
					  .error(function(response){
					  });
			    	 commonService.getShopList($scope.fifo.plant)
					  .success(function(response){
						  $scope.shops = response.objectList;				
					  })
					   commonService.getSupplier($scope.fifo.plant)
					  .success(function(response){
						  console.log("supplier list called");
						  $scope.supplier = response.objectList;				
					  })
					  .error(function(response){
					  });

			    }
			 /*  
			  if($window.sessionStorage.getItem('shopDPCollection') == null || $window.sessionStorage.getItem('shopDPCollection')=='undefined' || $window.sessionStorage.getItem('shopDPCollection')==undefined){
				  commonService.getAllShop()
				  .success(function(response){						  
					  $scope.shops = response.objectList;				
					  $window.sessionStorage.setItem('shopDPCollection',JSON.stringify($scope.shops));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.shops = JSON.parse(sessionStorage.shopDPCollection);
			  }*/
			 // --------- Line drop down list ---------

			 /* if($window.sessionStorage.getItem('linesDPCollection') == null || $window.sessionStorage.getItem('linesDPCollection')=='undefined' || $window.sessionStorage.getItem('linesDPCollection')==undefined){
				  commonService.getAllLines()
				  .success(function(response){					 
					  $scope.lines = response.objectList;
					  $window.sessionStorage.setItem('linesDPCollection',JSON.stringify($scope.lines));
				  })
				  .error(function(response){
				  });
			  }else{
				  $scope.lines = JSON.parse(sessionStorage.linesDPCollection);
			  }*/
		    
				    
		    /*AUTOCOMPLE LOCATION ON ENTER MIN 3 CHAR DATA*/
		    
		    $scope.loadLocation = function(query) {
		    	
		    	var locationInputObj = {"locationId": query};			    	
		    	return locationService.locationList(locationInputObj).then(function(response){	
		    		
		    		 if(response.data.statusType=='success'){
		        		 if(response.data.object!='null' && response.data.object!=null){				        		
		        			  return response.data.object;                           
		        		 }
		        	 }else{
		        		
		        	 }			    		
			    	});			    				         
		    };
			    			    		  
		    $scope.fifo = {				
		    	  partNumber : $scope.partNumber,
		    	  location : $scope.location, 
                  fromDate : $scope.beginDate,
                  toDate : $scope.endDate,
                  startIndex : 0,
                  endIndex : 0
              };
			
			
			
			 var paginationOptions = {
				 	startIndex : 0,
				 	endIndex : 0,
				    pageNumber: 1,
				    pageSize: 100,
				    sort: null
				  };
			 
		
			 //Grid
			 $scope.gridOptions = {
			 enablePaginationControls:false,
			 enableGridMenu: true,
             enableFiltering: true,            
             enableColumnResize: true,
             paginationPageSizes: [100,250,500,750,1000],
     	     paginationPageSize: 100,         
             useExternalPagination: true,
             autoResize:true,
             enableSorting: true,
             enableColumnMenus: false,
             enablePinning: true,            
             columnDefs: [
                          { field: 'partNumber', displayName: 'Part Number', width:150, pinnedLeft:true },                          
			       	      { field: 'location', displayName: 'Location', width:150, pinnedLeft:true },
			       	      { field: 'pickedRan', displayName: 'Picked RAN', width:100 },
			       	      { field: 'correctRan', displayName: 'Correct RAN', width:100 },
			       	      { field: 'pickedRanInTime', displayName: 'Picked Ran Intime', width:100,cellFilter: 'date:\'MMM d, yyyy\''},
			       	      { field: 'correctRanInTime', displayName: 'Correct Ran Intime', width:100,cellFilter: 'date:\'MMM d, yyyy\'' },
			       	      { field: 'ranDateDifference', displayName: 'Difference', width:100 },
			       	     /* { field: 'quantityAvail', displayName: 'Quantity Avail', width:100 },*/
			       	      { field: 'snp', displayName: 'SNP', width:50 },
			       	   /*   { field: 'transactionType', displayName: 'Txn', width:50},*/
			       	      { field: 'count', displayName: 'Count', width:80},
			       	      { field: 'ran', displayName: 'RAN',visible:false,width:100},
			       	      { field: 'userId', displayName: 'User', width:100},
			       	      { field: 'deviceId', displayName: 'Device', width:100},
			       	      { field: 'partInOutTime',type: 'date', displayName: 'In Out Time', width:200,cellFilter: 'date:\'MMM d, yyyy HH:mm:ss a\'' },
			       	      { field: 'scanTime',type: 'date', displayName: 'Scan Time', width:200,cellFilter: 'date:\'MMM d, yyyy HH:mm:ss a\'' },
			       	      { field: 'shift', displayName: 'Shift', width:50},
			       	      /*{ field: 'reason', displayName: 'Reason', width:100},*/
			       	      { field: 'comments', displayName: 'Comments', width:100}
                        ],
                        exporterPdfAlign:'left',
                        exporterCsvFilename: 'FIFODetailsReport.csv',
                        exporterMenuVisibleData: false,
                        exporterPdfDefaultStyle: {fontSize: 9},
                        exporterPdfTableStyle: {margin: [70, 5, 0, 5]},
                        exporterPdfTableHeaderStyle: {fontSize: 10, bold: true, italics: true, color: 'red'},
                        exporterPdfHeader: { text: "FIFO Report", style: 'headerStyle' },
                        exporterPdfFooter: function ( currentPage, pageCount ) {
                          return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
                        },
                        exporterPdfCustomFormatter: function ( docDefinition ) {
                        	 docDefinition.styles.headerStyle = { fontSize: 20, bold: true, alignment: 'center', margin: [0, 0, 20, 0] }; 
                             docDefinition.styles.footerStyle = { fontSize: 10, bold: true, alignment: 'center',  margin: [5, 0, 20, 0] }; 
                          return docDefinition;
                        },
                        exporterPdfOrientation: 'landscape',
                        exporterPdfPageSize: 'LETTER',
                        exporterPdfMaxGridWidth: 500,
                        exporterPdfFilename: 'FIFODetailsReport.pdf',
                        exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
                       
                        onRegisterApi: function( gridApi ) {
                        	 $scope.gridApi = gridApi;
                        	 //Pagination
                        	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                        		 $scope.blockUI();
             		          paginationOptions.pageNumber = newPage;
             		          paginationOptions.pageSize = pageSize;
             		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
             		        paginationOptions.endIndex   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
             		        $scope.load();
             		        });
                        
                	    }
		    };
			 
			 $scope.gridOptions.exporterFieldCallback = function ( grid, row, col, value ){
				 
				 if ( col.name === 'partInOutTime' || col.name === 'scanTime'){					 	
					    value =  $filter('date')(value, 'dd/MM/yyyy HH:mm:ss');					   
					}				      
				  return value;
				 
			 };
 // Clear the filter
	 $scope.clearFilters = function() {
		 $scope.gridApi.core.clearAllFilters();
     };
// Reset the values
	    $scope.resetFifo = function(){
	    	$scope.shops = "";
	    	$scope.lines = "";
	    	$scope.beginDate=new Date();
		    $scope.endDate=new Date();    	  
	    	$scope.gridOptions.data = [];
	    	$scope.clearFilters();	  
	    	$scope.fifo = {};
	    	$scope.partNumber="";	    	
	    	$scope.fifo.startIndex = 0;
	    	$scope.fifo.endIndex = 0;
	    	$scope.tags=[];
	    	$scope.ranData=[];
	    	$scope.locationIdData=[];	
	    	$scope.gridOptions.totalItems=0;
	    	$scope.location="";
	    	$scope.partNumber="";
	    	$scope.gridOptions.enablePaginationControls=false;	    
	    	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
	    	
		    $scope.shiftDropdown=false;
		    $scope.fifo.deviceId="";
	    };	    
     $scope.fifoGridData = function(){    	    	 
    	 fifoService.fifoCheckReport($scope.fifo).then(function(response){
	    		$scope.gridOptions.data = [];
	    		if(response.data.objectList !== undefined && response.data.objectList !== null){
	    			
	    			if(response.data.statusType === 'success' ){
	    				$scope.gridOptions.enablePaginationControls=true;
	    				 response.data.objectList.forEach(function(row){	    	    	         	          
	    	    	           $scope.gridOptions.data = response.data.objectList;	 
	    	    	          });
	    				 
	    				 	
	    			} else {
	    				$scope.gridOptions.enablePaginationControls=false;
	    				$scope.alerts = [];
			            $scope.alerts.push({
			                type : response.data.statusType,
			                msg : response.data.statusMessage,
			                error : response.data.exceptionStackTrace,
			                errorClsName : response.data.exceptionClassName,
			                errorMsg : response.data.exceptionMessage
			            });
	    			}
	    			$.unblockUI();
	    		} else {
	    			$scope.searchDataEror=response.data.statusMessage;	    			
		            $.unblockUI();
	    		}
	    	});
     };
     
	 		/* Load data in grid */
		    $scope.load = function () {
		    	$scope.fifo.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

		    	if(paginationOptions.endIndex === 0){
		    		$scope.fifo.endIndex = $scope.gridOptions.paginationPageSize;
		    	}
		    	$scope.fifo.startIndex = paginationOptions.startIndex;
		    	$scope.fifo.endIndex = paginationOptions.pageSize;
		    	$scope.fifo.partNumber = $scope.partNumber;
		    	$scope.fifo.location = $scope.location;		
		    	
		    	$scope.fifo.fromDate = $scope.fromDate;
		    	$scope.fifo.toDate = $scope.toDate;
		    	
		    	fifoService.fifoCheckCount($scope.fifo).then(function(response){
		    		$scope.gridOptions.totalItems = response.object;		    		
		    		$scope.recordCount = response.object;		    		
		    		$scope.fifoGridData();
		    	});
		    	
		    };
		    
		    // --------- search button ---------
            $scope.searchFifo = function() {
            	alert("inside FIFO Controller searchFifo function");
            	if( $scope.validateFilter() == true){
            		$scope.blockUI();
            		$scope.fromDate = $filter('date')($scope.beginDate, 'yyyy-MM-dd');
            		$scope.toDate = $filter('date')($scope.endDate, 'yyyy-MM-dd');
            		$scope.alerts = [];
            		$scope.gridOptions.data = [];
            		$scope.fifo.partNumber=$scope.partNumber;
            		$scope.fifo.location=$scope.location;
            		//$scope.fifo.isFullDownload=0;
            		paginationOptions.startIndex= 0;
            		paginationOptions.endIndex= 0;
            		paginationOptions.pageNumber= 1;
            		paginationOptions.pageSize= 100; 
            		$scope.gridOptions.paginationCurrentPage=1;
            		$scope.gridOptions.paginationPageSize=100;
            		$scope.searchClicked=true;
            		$scope.clearFilters();                	
            		$scope.load();
            		$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
            	}else{
            		$scope.alerts = [];
	       			$scope.alerts.push({
	       				 type : 'danger',
	       				 msg : 'Plant/Shop or Part or RAN or Location is/are mandatory'
	       			});
            	}
            };
		    
            $scope.downloadFifo =function(){
            	$scope.blockUI();
            	$scope.fifo.fromDate=$filter('date')($scope.beginDate, 'yyyy-MM-dd');;
		    	$scope.fifo.toDate=$filter('date')($scope.endDate, 'yyyy-MM-dd');
		    	$scope.fifo.partNumber=$scope.partNumber;
            	$scope.fifo.location=$scope.location;
            	//$scope.fifo.isFullDownload=1;
            	return fifoService.fifoCheckDownload($scope.fifo).then(function(response){
            		if(response.objectList != null){
            			for (var i = 0; i < response.objectList.length; i++) {
            				response.objectList[i].partNumber = '="'+response.objectList[i].partNumber+'"';
            				response.objectList[i].partInOutTime =$filter('date')(response.objectList[i].partInOutTime, 'dd/MM/yyyy HH:mm:ss');
            				response.objectList[i].scanTime =$filter('date')(response.objectList[i].scanTime, 'dd/MM/yyyy HH:mm:ss');
            				response.objectList[i].pickedRanInTime =$filter('date')(response.objectList[i].pickedRanInTime, 'dd/MM/yyyy');
            				response.objectList[i].correctRanInTime =$filter('date')(response.objectList[i].correctRanInTime, 'dd/MM/yyyy');
            			}
            			$.unblockUI();
            			return response.objectList;
            		}else{
            			$scope.alerts = [];
    	       			$scope.alerts.push({
    	       				 type : 'danger',
    	       				 msg : 'Data is not available'
    	       			});
            		}
            		$.unblockUI();
            	});
        
            };
         
            $scope.getDownloadFifoReportHeader = function () {
            	return ["Part Number", "Location","SNP","Count","Picked Ran","Correct Ran","Picked Ran In Time","Correct Ran In Time","Ran Date Difference","User","Device","In-Out Time","Scan Time","Shift","Comments"];
           };
           $scope.csvColumnOrder=['partNumber','location','snp','count','pickedRan','correctRan','pickedRanInTime','correctRanInTime','ranDateDifference','userId','deviceId','partInOutTime','scanTime','shift','comments'];

			//Close the alert msg
            $scope.closeAlert = function(index) {
		        $scope.alerts.splice(index, 1);
		    };
		    
		    $scope.selectEndDate = function(endDate) {		    	
		    	$scope.fromMaxDate=$filter('date')(endDate, 'yyyy-MM-dd');
		    	 $scope.fifo.shift='';
		    	if($filter('date')(endDate, 'yyyy-MM-dd')== $filter('date')($scope.beginDate, 'yyyy-MM-dd')){
		    		$scope.shiftDropdown=false;
		    	}else{
		    		$scope.shiftDropdown=true;
		    	}		    	
		    };
		    
		    $scope.selectStartDate = function(startDate) {		    	
		    	 $scope.fifo.shift='';
		    	if($filter('date')(startDate, 'yyyy-MM-dd')== $filter('date')($scope.endDate, 'yyyy-MM-dd')){
		    		$scope.shiftDropdown=false;
		    	}else{
		    		$scope.shiftDropdown=true;
		    	}		    	
		    };
		    
		    $scope.validateFilter = function(){
		    	 if($scope.fifo.plant !== "" && $scope.fifo.plant !== null && $scope.fifo.plant !== undefined && $scope.fifo.shop !== "" && $scope.fifo.shop !== null && $scope.fifo.shop !== undefined)
				 {
					 return true;
				 }
		    	 else if($scope.ranData.length>0 || $scope.tags.length>0 || $scope.locationIdData.length>0){
		    		 return true;
		    	 }
		    	 else{
					 return false;
				 }
		     };
		
} ]);



wmsApp.factory('fifoService',['commonService','$http','$q',function(commonService,$http,$q){
    var fact={};
    
    fact.fifoCheckReport=function(param)
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/FIFOCheck/getFifoNotFollowed',	
			data : param,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});
				
	};
	
    fact.fifoCheckDownload=function(param)
    {    
    	var deferred = $q.defer();
        $http({
			method : 'POST',
			url : 'rest/FIFOCheck/getFifoNotFollowedDownload',	
			data : param,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			 deferred.resolve(data);
			
		});
        return deferred.promise;
				
	};
	
	fact.fifoCheckCount=function(param)
    {    
    	var deferred = $q.defer();
        $http({
			method : 'POST',
			url : 'rest/FIFOCheck/getFifoNotFollowedCount',
			data : param,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			 deferred.resolve(data);
			
		});
        return deferred.promise;
				
	};
	
	

	
	return fact;
	
	
}]);