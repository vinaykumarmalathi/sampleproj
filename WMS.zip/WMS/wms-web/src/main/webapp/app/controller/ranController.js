wmsApp.controller('ranController',['$scope','partNumberService','$http','$window','ranService','ranDataService',
                                  function($scope,partNumberService,$http,$window,ranService,ranDataService){
	
	$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"});
	$scope.searchDataError="Click search to fetch records.";
	$scope.beginDatePickerOpen = false;
	$scope.lppdDate=new Date();
	// part number
	$scope.tags = [];
	$scope.partNumber='';
	
	$scope.openBeginDatePicker = function ($event) {
		
	$event.preventDefault();
	$event.stopPropagation();
	$scope.beginDatePickerOpen = !$scope.beginDatePickerOpen;
	console.log($scope.beginDatePickerOpen);
	};
	
	//partno tag added
	$scope.tagAdded = function(tag){
		$scope.partArray = [];
		for(var j=0; j<$scope.tags.length; j++){
			$scope.partArray.push($scope.tags[j].text);
		}
		$scope.partNumber = $scope.partArray.join(',');
		//$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
	};
	
	// tag removed
	$scope.tagRemoved = function(tag){
		$scope.partArray = [];
		for(var j=0;j<$scope.tags.length;j++){
			$scope.partArray.push($scope.tags[j].text);
		}
		$scope.partNumber = $scope.partArray.join(',');
		//$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 	
	};

	//load parts
	$scope.loadParts = function(query){
		var partInputObj = {"partNumber" : query};
		return partNumberService.partNumberList(partInputObj).then(function(response){
			if(response.data.statusType == "success"){
				if(response.data.object!= 'null' && response.data.object!=null){
					console.log(response.data.object);
					return response.data.object;
				}
			}else{
				
			}
		});
	}
	
	// ran number
	$scope.ranData1 = [];
	//tag added
	$scope.ranAdded = function(tag){
		$scope.ranArray = [];
		for(var j=0;j<$scope.ranData1.length;j++){
			$scope.ranArray.push($scope.ranData1[j].text);
		}
		$scope.ranData.ran = $scope.ranArray.join(',');
		console.log($scope.ranData.ran);
		//$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
	};
	
	//tag removed
	$scope.ranRemoved = function(tag){
		$scope.ranArray = [];
		for(var j=0;j<$scope.ranData1.length;j++){
			$scope.ranArray.push($scope.ranData1[j].text);
		}
		$scope.ranData.ran = $scope.ranArray.join(',');
		//$(".appViewDiv").css({"height":$(window).height()-130, "overflow": "auto"}); 
	};
	
	//load ran
	$scope.loadRan = function(query){
		var partInputObj = {"ranId": query};
		return ranService.ranList(partInputObj).then(function(response){
			console.log(response.data.object);
			if(response.data.statusType == "success"){
				if(response.data.object != 'null' && response.data.object != null){
					return response.data.object;
				}
			}
		});
	};
	
	
	 $scope.ranData = {				
	    	  partNos : $scope.partNumber,
              startIndex : 0,
              endIndex : 0
         };
	 	$scope.ranData.lppd=$scope.lppdDate;
	 	
	 var paginationOptions = {
			 	startIndex : 0,
			 	endIndex : 0,
			    pageNumber: 1,
			    pageSize: 100,
			    sort: null
			  };
	 
	//grid options
	
	$scope.gridOptions = {
			 enablePaginationControls:false,
			 enableGridMenu: true,
			 enableFiltering: true,            
			 enableColumnResize: true,
			 paginationPageSizes: [100,250,500,750,1000],
    	     paginationPageSize: 100,         
    	     useExternalPagination: true,
    	     autoResize:true,
    	     enableSorting: true,
    	     enableColumnMenus: false,
    	     enablePinning: true,      
    	     columnDefs: [
                         { field: 'ran', displayName: 'RAN' },
                         { field: 'partNos', displayName: 'Part Number', pinnedLeft:true},                          
			       	      { field: 'lppd', type: 'date', displayName: 'LPPD', width:200,cellFilter: 'date:\'MMM d, yyyy HH:mm:ss a\''}
                       ],
                       exporterPdfAlign:'left',
                       exporterCsvFilename: 'RanDetailsReport.csv',
                       exporterMenuVisibleData: false,
                       exporterPdfDefaultStyle: {fontSize: 9},
                       exporterPdfTableStyle: {margin: [70, 5, 0, 5]},
                       exporterPdfTableHeaderStyle: {fontSize: 10, bold: true, italics: true, color: 'red'},
                       exporterPdfHeader: { text: "Ran Details Report", style: 'headerStyle' },
                       exporterPdfFooter: function ( currentPage, pageCount ) {
                         return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
                       },
                       exporterPdfCustomFormatter: function ( docDefinition ) {
                       	 docDefinition.styles.headerStyle = { fontSize: 20, bold: true, alignment: 'center', margin: [0, 0, 20, 0] }; 
                            docDefinition.styles.footerStyle = { fontSize: 10, bold: true, alignment: 'center',  margin: [5, 0, 20, 0] }; 
                         return docDefinition;
                       },
                       exporterPdfOrientation: 'landscape',
                       exporterPdfPageSize: 'LETTER',
                       exporterPdfMaxGridWidth: 500,
                       exporterPdfFilename: 'RanDetailsReport.pdf',
                       exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
                      
                       onRegisterApi: function( gridApi ) {
                       	 $scope.gridApi = gridApi;
                       	 //Pagination
                       	 gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                       		// $scope.blockUI();
            		          paginationOptions.pageNumber = newPage;
            		          paginationOptions.pageSize = pageSize;
            		         paginationOptions.startIndex = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
            		        paginationOptions.maxResult   = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);
            		        $scope.load();
            		        });
                       
               	    }
		    };
	

	$scope.searchRan = function(){
		console.log("SearchRan");
		$scope.alerts = [];
		$scope.gridOptions.data = [];
		$scope.ranData.partNos=$scope.partNumber;
		console.log("rans",$scope.ranData.ran);
		//$scope.ranData.isFullDownload=0;
		paginationOptions.startIndex= 0;
		paginationOptions.endIndex= 0;
		paginationOptions.pageNumber= 1;
		paginationOptions.pageSize= 100; 
		$scope.gridOptions.paginationCurrentPage=1;
		$scope.gridOptions.paginationPageSize=100;
		$scope.searchClicked=true;
		//$scope.clearFilters();                	
		$scope.load();
	};


	
	$scope.load = function () {
    	$scope.ranData.endIndex = (((paginationOptions.pageSize * paginationOptions.pageNumber) < $scope.recordCount) ? (paginationOptions.pageSize * paginationOptions.pageNumber) : $scope.recordCount);

    	if(paginationOptions.endIndex === 0){
    		$scope.ranData.endIndex = $scope.gridOptions.paginationPageSize;
    	}
    	$scope.ranData.startIndex = paginationOptions.startIndex;
    	$scope.ranData.endIndex = paginationOptions.pageSize;
    	$scope.ranData.partNos = $scope.partNumber;	
    	$scope.ranData.lppd = $scope.lppdDate;
    	
    	ranDataService.ranDataCount($scope.ranData).then(function(response){
    		console.log("countRan");
    		$scope.gridOptions.totalItems = response.data.object;
    		$scope.recordCount = response.data.object;
    		console.log("Record count",$scope.recordCount);
    		if($scope.recordCount>0){
    			$scope.ranTrialData();
    		}
    		else{
    			$scope.searchDataError=response.data.statusMessage;	 
    			console.log("count",$scope.searchDataError);
    		}
    	});
    	
    };
    
    $scope.ranTrialData = function(){    
    	console.log("ranTrialData");
   	 ranDataService.ranReport($scope.ranData).then(function(response){
	    		$scope.gridOptions.data = [];
	    		console.log("Response",response.data);
	    		if(response.data.objectList !== null && response.data.objectList.length > 0){
	    			console.log(response.data.objectList);
	    			if(response.data.statusType === 'success' ){
	    				$scope.gridOptions.enablePaginationControls=true;
	    				 response.data.objectList.forEach(function(row){
	    	    	           $scope.gridOptions.data = response.data.objectList;	
	    	    	          });
	    				 
	    				 	
	    			} else {
	    				 console.log("failure");
	    				$scope.gridOptions.enablePaginationControls=false;
	    				$scope.alerts = [];
			            $scope.alerts.push({
			                type : response.data.statusType,
			                msg : response.data.statusMessage,
			                error : response.data.exceptionStackTrace,
			                errorClsName : response.data.exceptionClassName,
			                errorMsg : response.data.exceptionMessage
			            });
	    			}
	    		}
	    		else {
	    			$scope.searchDataError=response.data.statusMessage;	 
	    			console.log($scope.searchDataError);
	    		}
	    	});
    };
	
	
}]);
	
