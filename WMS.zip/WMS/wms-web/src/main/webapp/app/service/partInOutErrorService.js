
var wmsApp = angular.module('wmsApp');

wmsApp.factory('partInOutErrorService',['commonService','$http',function(commonService,$http){
    var fact={};
    
    fact.errorReport=function(part)
    {
    	  
    	
    	return $http({
			method : 'POST',
			url : 'rest/errorSearch/partsInOutAuditErrorSearch',	
			data : part,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});
				
	};
		
	  fact.errorReportCount=function(part)
	    {
    	
	    	return $http({
				method : 'POST',
				url : 'rest/errorSearch/partsInOutAuditErrorCount',
			//	url : 'app/data/partlist.json',
				data : part,
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {				
				return data;
				
			});
					
		};

	
	return fact;
	
	
}]);