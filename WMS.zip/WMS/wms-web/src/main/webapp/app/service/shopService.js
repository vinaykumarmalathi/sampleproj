wmsApp.factory('shopService', [ 'commonService', function(commonService) {
    //var serviceURL = mainService.getAppURL() + '/rest/coreMnemonic/';
    return {
    	listAllShops : commonService.callRestService('GET','http://localhost:8080/wms-web/rest/shops/allshops','')
    };
}]);