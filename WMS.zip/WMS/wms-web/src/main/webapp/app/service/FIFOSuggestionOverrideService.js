wmsApp.factory('FIFOSuggestionOverrideService',['commonService','$http','$q',function(commonService,$http,$q){
    var fact={};
    
    fact.fifoSuggestionReport=function(param)
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/FIFOSuggestion/getFifoSuggestion',	
			data : param,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});
				
	};
	
    fact.fifoSuggestionDownload=function(param)
    {    
    	var deferred = $q.defer();
        $http({
			method : 'POST',
			url : 'rest/FIFOSuggestion/getFifoSuggestionDownload',	
			data : param,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			 deferred.resolve(data);
			
		});
        return deferred.promise;
				
	};
	
	fact.fifoSuggestionCount=function(param)
    {    
    	var deferred = $q.defer();
        $http({
			method : 'POST',
			url : 'rest/FIFOSuggestion/getFifoSuggestionCount',
			data : param,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			 deferred.resolve(data);
			
		});
        return deferred.promise;
				
	};

	return fact;
	
	
}]);