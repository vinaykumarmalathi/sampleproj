var wmsApp = angular.module('wmsApp');

wmsApp.factory('RanUploadService',['$http','$q',function($http,$q){
	var RanUploadService={};
		RanUploadService.uploadRAN = function(file,url){
		var fd = new FormData();
        fd.append('file', file);
        result = $http.post( url,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        });
        return result;
    };
    
    RanUploadService.downloadErrorRecords = function(runId){  
    	var deferred = $q.defer();
    	$http({
    		method : 'POST',
    		url : 'rest/RanUpload/getDownloadRanErrorRecord',	
    		data: runId,
    		headers:{'Content-Type': 'application/json'},
    	}).success(function(data){
    		 deferred.resolve(data);
    	});
        return deferred.promise;
    };
    
    RanUploadService.getAllRANUploadDetails = function(){
    	return $http({
    		method : 'POST',
    		url: 'rest/RanUpload/getAllRANUploadDetails',
    		headers:{'Content-Type': 'application/json'},
    	}).success(function(data){
    		return data;
    		});
    };
    
	return RanUploadService;
}]);


