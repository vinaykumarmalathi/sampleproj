var wmsApp = angular.module('wmsApp');

wmsApp.factory('liveReceiptQuantityMismatchService', ['commonService','$http','$q',function(commonService,$http,$q){
	 var fact={};
	 
	 fact.getLiveReceiptQtyMismatchList=function(part)
	    {    	      
	    	return $http({
				method : 'POST',
				url : 'rest/liveReceipt/getLiveReceiptQtyMismatchList',	
				data : part,
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {			
				return data;
				
			});
					
		};
		
		fact.getLiveReceiptQtyMismatchListCount=function(part)
	    {
	    	return $http({
				method : 'POST',
				url : 'rest/liveReceipt/getLiveReceiptQtyMismatchListCount',		
				data : part,
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {
				return data;
				
			});
					
		};
		
		fact.liveReceiptQtyMismatchDownload=function(part)
	    {    
	    	var deferred = $q.defer();
	        $http({
				method : 'POST',
				url : 'rest/liveReceipt/getLiveReceiptQtyMismatchList',	
				data : part,
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {
				 deferred.resolve(data);
				
			});
	        return deferred.promise;
					
		};
		
		fact.getranList=function(inputObj)
	    {
	    	return $http({
				method : 'POST',
				url : 'rest/liveReceipt/getRanList',		
				data : JSON.stringify(inputObj),
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {		
				return data;
			});
		};
		
		fact.getSupList=function(inputObj)
	    {
	    	return $http({
				method : 'POST',
				url : 'rest/liveReceipt/getSupList',		
				data : JSON.stringify(inputObj),
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {		
				return data;
			});
		};
		
		fact.getLiveReceiptForAutoComplete=function(dto)
	    {
	    	return $http({
				method : 'POST',
				url : 'rest/liveReceipt/getLiveReceiptForAutoComplete',		
				data : dto,
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {		
				return data;
			});
		};
		
		fact.getZoneList=function(inputObj)
	    {
	    	return $http({
				method : 'POST',
				url : 'rest/liveReceipt/getZoneList',		
				data : JSON.stringify(inputObj),
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {		
				return data;
			});
		};
		
	 return fact;
}
]);