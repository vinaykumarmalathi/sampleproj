var wmsApp = angular.module('wmsApp');

wmsApp.factory('missingPartsService', ['commonService','$http','$q',function(commonService,$http,$q){
	 var fact={};
	 
	 fact.getMissingPartsList=function(part)
	    {    	      
	    	return $http({
				method : 'POST',
				url : 'rest/missingParts/getMissingPartsList',	
				data : part,
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {			
				return data;
				
			});
					
		};
		
		fact.getMissingPartsListCount=function(part)
	    {
	    	return $http({
				method : 'POST',
				url : 'rest/missingParts/getMissingPartsListCount',		
				data : part,
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {
				return data;
				
			});
					
		};
		
		fact.missingPartsDownload=function(part)
	    {    
	    	var deferred = $q.defer();
	        $http({
				method : 'POST',
				url : 'rest/missingParts/getMissingPartsList',	
				data : part,
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {
				 deferred.resolve(data);
				
			});
	        return deferred.promise;
					
		};
		
	 return fact;
}
]);