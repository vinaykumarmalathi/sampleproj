
var wmsApp = angular.module('wmsApp');

wmsApp.factory('shortageAlarmService',['commonService','$http','$q','$window',function(commonService,$http,$q,$window){
    var fact={};    
    
    fact.getShortageAlmListCount = function(searchParams)
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/shortageAlarm/shortageAlmCount',
			data : searchParams,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});		
	};
	
	fact.getShortageAlmList = function(searchParams)
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/shortageAlarm/shortageAlmList',	
			data : searchParams,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;			
		});		
	};
	
	 fact.partNumberList=function(partInputObj)
	    {
	    	return $http({
				method : 'POST',
				url : 'rest/shortageAlarm/byPartNumber',		
				data : JSON.stringify(partInputObj),
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {		
				return data;
			});	
		};
		
	 fact.supplierList=function(partInputObj)
	    {
	    	return $http({
				method : 'POST',
				url : 'rest/shortageAlarm/bySupCode',		
				data : JSON.stringify(partInputObj),
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {		
				return data;
			});	
		};
		
	 fact.depoCodeList=function(partInputObj)
	    {
	    	return $http({
				method : 'POST',
				url : 'rest/shortageAlarm/byDepoCode',		
				data : JSON.stringify(partInputObj),
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {		
				return data;
			});	
		};
		
		/*Added by Meena - To get all zones from common parameter table - Start*/
		fact.getAllZones= function()
		{
			var serviceURL = 'rest/shortageAlarm/allzones';
			var serviceType ='GET';
			var params='';
			
			return $http({
				method : serviceType,
				url : serviceURL,
				data : JSON.stringify(params),
				headers: {'Content-Type': 'application/json'}
			});
		};
		/*Added by Meena - To get all zones from common parameter table - End*/
		
		
		fact.getWips= function()
		{
			var serviceURL = 'rest/shortageAlarm/wips';
			var serviceType ='GET';
			var params='';
			
			return $http({
				method : serviceType,
				url : serviceURL,
				data : JSON.stringify(params),
				headers: {'Content-Type': 'application/json'}
			});
		};
		
		 fact.pcCodeList=function(partInputObj)
		    {
		    	return $http({
					method : 'POST',
					url : 'rest/shortageAlarm/byPcCode',		
					data : JSON.stringify(partInputObj),
					headers: {'Content-Type': 'application/json'}
				})
				.success(function (data) {		
					return data;
				});	
			};
			
			fact.downloadFile= function(fileName)
		    {    
		    $http({       
		     method: 'GET',        
		     url: 'rest/shortageAlarm/downloadFile?fileName='+fileName,      
		     responseType: 'arraybuffer'    
		     }).success(function (data, status, headers) {        
		     headers = headers();         
			     var filename = headers['x-filename'];        
			     var contentType = headers['content-type'];         
			     var linkElement = document.createElement('a');        
			     try {    
			            var blob = new Blob([data], { type: contentType });            
			            var url = window.URL.createObjectURL(blob);     
			            linkElement.setAttribute('href', url);       
			            console.log("filename is : " +filename);        
			            linkElement.setAttribute("download", filename);			           
			            if ($window.navigator && $window.navigator.msSaveOrOpenBlob) {
			           $window.navigator.msSaveOrOpenBlob(blob, filename);
			         } else{
			           var e = document.createEvent('MouseEvents');
			           e.initEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
			           linkElement.dispatchEvent(e);
			       }   
	        			$.unblockUI();
			       } catch (ex) {        
			    	   $.unblockUI();
			             console.log("exception in catch" + ex);        
			         }    
			      }).error(function (data) {
			    	  $.unblockUI();
			              console.log("failure : " +data);   
			         });
		    };
		    
		    fact.getDownloadNameFmDB = function(searchParams)
		    {    	      
		    	return $http({
					method : 'POST',
					url : 'rest/shortageAlarm/getDownloadName',	
					data : searchParams,
					headers: {'Content-Type': 'application/json'}
				})
				.success(function (data) {			
					return data;			
				});		
			};
			
			fact.getUserForAllPartsCoverage = function(userId)
		    {    	      
		    	return $http({
					method : 'POST',
					url : 'rest/shortageAlarm/getUserIdForAllPartsCats',	
					data : userId,
					headers: {'Content-Type': 'application/json'}
				})
				.success(function (data) {			
					return data;			
				});		
			};
			
			fact.getlstCalTime = function(plant)
		    {    	      
		    	return $http({
					method : 'POST',
					url : 'rest/shortageAlarm/getLstCalTime',	
					data : plant,
					headers: {'Content-Type': 'application/json'}
				})
				.success(function (data) {			
					return data;			
				});		
			};
			
			
			fact.getShortageAlmDownload= function(searchParams)
		    {    
		    $http({       
		     method: 'POST',        
		     url: 'rest/shortageAlarm/shortageAlmDownload',    
		     data : searchParams,
		     responseType: 'arraybuffer'    
		     }).success(function (data, status, headers) {        
		     headers = headers();         
			     var filename = headers['x-filename'];        
			     var contentType = headers['content-type'];         
			     var linkElement = document.createElement('a');  
			     try {
			    	 if(status==200){
			    		 var blob = new Blob([data], { type: contentType }); 
				            var url = window.URL.createObjectURL(blob);     
				            linkElement.setAttribute('href', url);       
				             console.log("filename is : " +filename);        
				            linkElement.setAttribute("download", filename);			           
				            if ($window.navigator && $window.navigator.msSaveOrOpenBlob) {
				           $window.navigator.msSaveOrOpenBlob(blob, filename);
				         } else{
				           var e = document.createEvent('MouseEvents');
				           e.initEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
				           linkElement.dispatchEvent(e);
				       } 
			    	 }else{
			    		 console.log("error - No records found")
			    	 }			    	 
			    	 $.unblockUI();
			       } catch (ex) {
			    	   $.unblockUI();
			           console.log("exception in catch" + ex);        
			         }  
			       //return data;
			      }).error(function (data) {
			    	  $.unblockUI();
			          console.log("failure : " +data);   
			         });
		    };
		    
		    
		  //Get locations by part id service
		    fact.getLocationsByPartNumber = function(partNo) {
				return $http({
					method : 'POST',
					/*url : 'rest/manageLocationByPartNo/getLocationsByPartNo',*/
					url : 'rest/shortageAlarm/getLocationsByPartNo',
					data : partNo,
					headers : {
						'Content-Type' : 'application/json'
					}
				}).success(function(result) {
					return result;
				}).error(function(data, status, headers, config) {
					alert("Error :: " + status);
				});
			};
			
			//ADDED FOR UAT REQ TO MERGE T&K SHOP DROP DOWN -START
			fact.getShopByPlantId = function(param){
				 return $http({
						method : 'POST',
						url : 'rest/shortageAlarm/getShopByPlantId',			
						data : param,
						headers: {'Content-Type': 'application/json'}
				 }).success(function (data) {
						return data;
				 });
			};
			//ADDED FOR UAT REQ TO MERGE T&K SHOP DROP DOWN -END 
			
			fact.getlinesByShopId = function(param){
				 return $http({
						method : 'POST',
						url : 'rest/shortageAlarm/getlinesByShopId',			
						data : param,
						headers: {'Content-Type': 'application/json'}
				 }).success(function (data) {
						return data;
				 });
			};
			
			fact.getMaxDate = function(plant)
		    {    	      
		    	return $http({
					method : 'POST',
					url : 'rest/shortageAlarm/getMaxDate',	
					headers: {'Content-Type': 'application/json'}
				})
				.success(function (data) {			
					return data;			
				});		
			};
			
	return fact;
}]);