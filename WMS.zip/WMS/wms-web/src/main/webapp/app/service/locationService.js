/*wmsApp.factory('locationService', [ 'commonService', function(commonService) {
    //var serviceURL = mainService.getAppURL() + '/rest/coreMnemonic/';
    return {
    	listAllLocations : commonService.callRestService('GET','http://localhost:8080/wms-web/rest/shops/allshops','')
    };
}]);*/

wmsApp.factory('locationService',['$http',function($http){
    var fact={};    
    fact.locationList=function(locationInputObj)
    {
    	return $http({
			method : 'POST',
			url : 'rest/location/locationByLocationID',		
			data : JSON.stringify(locationInputObj),
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {		
			return data;
			
		});				
	};
	return fact;
}]);