var wmsApp = angular.module('wmsApp');
wmsApp.factory('pitTransactionReportService',['commonService','$http','$q', function(commonService,$http, $q){
    var fact={};
    
    fact.pitTransactionReport=function(part)
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/pit/pitTransactionReport',	
			data : part,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});
				
	};
	
    fact.pitTransactionDownload=function(part)
    {    
    	var deferred = $q.defer();
        $http({
			method : 'POST',
			url : 'rest/pit/pitTransactionReport',	
			data : part,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			 deferred.resolve(data);
			
		});
        return deferred.promise;
				
	};
	
    fact.pitTransactionReportCount=function(part)
    {
	
    	return $http({
			method : 'POST',
			url : 'rest/pit/pitTransactionReportCount',		
			data : part,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			return data;
			
		});
				
	};
    
    return fact;
	
}]);