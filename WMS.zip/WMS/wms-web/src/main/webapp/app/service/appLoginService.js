wmsApp.factory('appLoginService',['$http',function($http){
    var appLoginService={};
    
    appLoginService.loginToApp = function(param)
    {
    	return $http({
			method : 'POST',
			url : 'rest/login/validate',		
			data : JSON.stringify(param),
			headers: {'Content-Type': 'application/json'}
		});
	};
	
	/*appLoginService.rolesPrivilegeService = function()
    {
    	return $http({
			method : 'POST',
			url : 'app/data/rolesPrivilege.json',		
			headers: {'Content-Type': 'application/json'}
		});
	};*/
	
	appLoginService.rolesPrivilegeService = function()
    {
    	return $http({
			method : 'POST',
			url : 'rest/user/rolesPrivilege',		
			headers: {'Content-Type': 'application/json'}
		});
	};
	
	return appLoginService;
}]);