wmsApp.factory('stockCorrectionService',['$http','$q',function($http,$q){
    var stockCorrectionService={};
    
    stockCorrectionService.searchPartNumber = function(param)
    {
    	return $http({
			method : 'POST',
			url : 'rest/stockcorrection/getStockCorrectionReport',		
			data : JSON.stringify(param),
			headers: {'Content-Type': 'application/json'}
		});
				
	};

	stockCorrectionService.stockLocationReportCount=function(part)
	    {
  	
	    	return $http({
				method : 'POST',
				url : 'rest/stockcorrection/stockCorrectionReportCount',
			//	url : 'app/data/partlist.json',
				data : part,
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {
				var test = JSON.stringify(data.objectList);
				//console.log("In Location report JSON Print",test);
				return data;
				
			});
					
		};
	stockCorrectionService.updateStockCorrection = function(param)
    {
    	return $http({
			method : 'POST',
			url : 'rest/stockcorrection/correction',		
			data : JSON.stringify(param),
			headers: {'Content-Type': 'application/json'}
        });
				
	};
	stockCorrectionService.addRAN= function(location) {
		return $http({
			method : 'POST',
			url : 'rest/stockcorrection/addRAN',
			data : location,
			headers : {
				'Content-Type' : 'application/json'
			}
		}).success(function(result) {
			return result;
		}).error(function(data, status, headers, config) {
			alert("Error :: " + status);
		});
	};
	stockCorrectionService.moveAllRanToDifferentLoc= function(MoveAllRanData) {
		return $http({
			method : 'POST',
			url : 'rest/stockcorrection/moveAllRanToDifferentLoc',
			data : MoveAllRanData,
			headers : {
				'Content-Type' : 'application/json'
			}
		}).success(function(result) {
			return result;
		}).error(function(data, status, headers, config) {
			alert("Error :: " + status);
		});
	};
	
	
	function searchPartNumberNew(param)
    {
    	return $http({
			method : 'POST',
			url : 'rest/stockcorrection/getStockCorrectionReport',		
			data : JSON.stringify(param),
			headers: {'Content-Type': 'application/json'}
		});
				
	};
    function getStockCorrectionReason()
    {
    	return $http({
			method : 'POST',
			url : 'rest/stockcorrection/getStockCorrectionReason',		
			data : '',
			headers: {'Content-Type': 'application/json'}
		});
				
	};
	
	stockCorrectionService.stockCorrectionReport=function(param)
    {    
    /*	var deferred = $q.defer();
        $http({
        	method : 'POST',
			url : 'rest/stockcorrection/getStockCorrectionReport',		
			data : JSON.stringify(param),
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			 deferred.resolve(data);
			
		});
        return deferred.promise;*/
    	console.log("In Stick Correction report q all");
    	  return $q.all([searchPartNumberNew(param), getStockCorrectionReason()]).then(function(results){
    	       // OPTIONAL  aggregate results before resolving
    		  console.log("Comments values", results);
    	       return results;
    	    });
				
	};
	
	
		
	return stockCorrectionService;
	
}]);