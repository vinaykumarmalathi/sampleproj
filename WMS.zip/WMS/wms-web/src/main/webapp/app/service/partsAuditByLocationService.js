
var wmsApp = angular.module('wmsApp');

wmsApp.factory('partsAuditByLocationService',['commonService','$http',function(commonService,$http){
    var fact={};
    
    fact.locationreport=function(location)
    {
   	return $http({
			method : 'POST',
			url : 'rest/parts/partsInOutAuditByLocation',		
			data : location,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;			
		});
				
	};
	
	return fact;
	
	
}]);