var wmsApp = angular.module('wmsApp');

wmsApp.factory('formRequirementSearchService',['$http',function($http){
    var formRequirementService={};
    formRequirementService.getSearchPageData = function(searchPageData)
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/searchList/getSearchPageData',	
			data : searchPageData,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});		
	};
	formRequirementService.searchListCount = function()
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/searchList/searchListCount',	
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});		
	};
	formRequirementService.downloadFormSearchDataAsPDF = function()
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/searchList/downloadFormSearchDataAsPDF',	
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});		
	};

	formRequirementService.getFile = function()
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/searchList/getFile',	
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});		
	};
	formRequirementService.getFormData = function(formSearchData)
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/searchList/getFormData',	
			data: formSearchData,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});		
	};
	return formRequirementService;
}]);