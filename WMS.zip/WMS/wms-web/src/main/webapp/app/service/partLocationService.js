
var wmsApp = angular.module('wmsApp');

wmsApp.factory('partLocationService',['commonService','$http','$q',function(commonService,$http,$q){
    var fact={};
    
    fact.locationreport=function(part)
    {
    	  
    	/*	var serviceresponse=commonService.callRestService('GET','rest/partslocation/locationreport','');
				console.log("Rest Service return",serviceresponse.$$state);
				console.log("Rest Service return",serviceresponse.$$state.data);
			//	console.log("Rest Service return1",serviceresponse.value.data);
				return data;*/
    	console.log(JSON.stringify(part));
    	return $http({
			method : 'POST',
			url : 'rest/partslocation/locationreport',
		//	url : 'app/data/partlist.json',
			data : part,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			var test = JSON.stringify(data.objectList);
			//console.log("In Location report JSON Print",test);
			return data;
			
		});
				
	};
		
	  fact.locationreportCount=function(part)
	    {
    	
	    	return $http({
				method : 'POST',
				url : 'rest/partslocation/locationreportCount',
			//	url : 'app/data/partlist.json',
				data : part,
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {
				var test = JSON.stringify(data.objectList);
				//console.log("In Location report JSON Print",test);
				return data;
				
			});
					
		};
		
		fact.PartLocationDownload=function(part)
	    {    
	    	var deferred = $q.defer();
	        $http({
				method : 'POST',
				url : 'rest/partslocation/downloadPartLocation',	
				data : part,
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {
				 deferred.resolve(data);
				
			});
	        return deferred.promise;
					
		};
		
		fact.PartLocationDataDownload=function(part)
	    {    
	    	var deferred = $q.defer();
	        $http({
				method : 'POST',
				url : 'rest/manageParts/partDownload',	
				data : part,
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {
				 deferred.resolve(data);
				
			});
	        return deferred.promise;
					
		};

	
	return fact;
	
	
}]);