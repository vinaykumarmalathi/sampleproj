
var wmsApp = angular.module('wmsApp');

//Service for managing locations based on part number.
wmsApp.factory('manageLocationByPartNoService', function($http) {
	
	var locationObject = {};
	//Get locations by part id service
	locationObject.getLocationsByPartNumber = function(partNo) {
		return $http({
			method : 'POST',
			url : 'rest/manageLocationByPartNo/getLocationsByPartNo',
			data : partNo,
			headers : {
				'Content-Type' : 'application/json'
			}
		}).success(function(result) {
			return result;
		}).error(function(data, status, headers, config) {
			alert("Error :: " + status);
		});
	};
	
	//delete location from part location 
	locationObject.deleteLocation = function(locations) {
		return $http({
			method : 'POST',
			url : 'rest/manageLocationByPartNo/deleteLocations',
			data : locations,
			headers : {
				'Content-Type' : 'application/json'
			}
		}).success(function(result) {
			return result;
		}).error(function(data, status, headers, config) {
			alert("Error :: " + status);
		});
	};
	
	//add location to part location 
	locationObject.addLocation = function(location) {
		return $http({
			method : 'POST',
			url : 'rest/manageLocationByPartNo/addLocation',
			data : location,
			headers : {
				'Content-Type' : 'application/json'
			}
		}).success(function(result) {
			return result;
		}).error(function(data, status, headers, config) {
			alert("Error :: " + status);
		});
	};
	
	//save location in part location 
	locationObject.saveLocations = function(locations) {
		return $http({
			method : 'POST',
			url : 'rest/manageLocationByPartNo/saveLocations',
			data : locations,
			headers : {
				'Content-Type' : 'application/json'
			}
		}).success(function(result) {
			return result;
		}).error(function(data, status, headers, config) {
			alert("Error :: " + status);
		});
	};
	locationObject.populatPartsInfo=function(part)
    {
	
    	return $http({
			method : 'POST',
			url : 'rest/manageParts/managePartsByPartNumber',			
			data : part,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {				
			return data;
			
		});
				
	};

	return locationObject;
});




