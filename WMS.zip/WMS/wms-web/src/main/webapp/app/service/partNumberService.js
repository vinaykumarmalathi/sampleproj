wmsApp.factory('partNumberService',['$http',function($http){
    var fact={};
    
    fact.partNumberList=function(partInputObj)
    {
    	return $http({
			method : 'POST',
			url : 'rest/parts/partsByPartNumber',		
			data : JSON.stringify(partInputObj),
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {		
			return data;
			
		});
				
	};
		

	
	return fact;
	
	
}]);