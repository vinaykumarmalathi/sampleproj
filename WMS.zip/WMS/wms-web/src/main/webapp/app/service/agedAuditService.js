
var wmsApp = angular.module('wmsApp');

wmsApp.factory('agedAuditService',['commonService','$http','$q',function(commonService,$http,$q){
    var fact={};
    
    fact.agedAuditReport=function(part)
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/AgedAudit/agedAuditSearch',	
			data : part,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});
				
	};
	
    fact.agedAuditDownload=function(part)
    {    
    	var deferred = $q.defer();
        $http({
			method : 'POST',
			url : 'rest/AgedAudit/agedAuditSearch',	
			data : part,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			 deferred.resolve(data);
			
		});
        return deferred.promise;
				
	};
	
    fact.agedAuditReportCount=function(part)
    {
	
    	return $http({
			method : 'POST',
			url : 'rest/AgedAudit/agedAuditSearchCount',		
			data : part,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			return data;
			
		});
				
	};

	
	return fact;
	
	
}]);