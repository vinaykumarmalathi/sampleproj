wmsApp.factory('partInOutUploadService',['$http',function($http){
    var partInOutUploadService={};
    
    partInOutUploadService.uploadStockDetailSheet = function(param)
    {
    	return $http({
			method : 'POST',
			url : 'rest/parts/partsInOutStaging',		
			data : JSON.stringify(param),
			headers: {'Content-Type': 'application/json'}
		});
				
	};
		
	return partInOutUploadService;
	
}]);