
var wmsApp = angular.module('wmsApp');

wmsApp.factory('partsMasterService',['commonService','$http',function(commonService,$http){
    var fact={};
    
    fact.parts=function(part)
    {
    	  
    	
    	return $http({
			method : 'POST',
			url : 'rest/manageParts/partSearch',	
			data : part,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});
				
	};
		
	  fact.partsCount=function(part)
	    {
    	
	    	return $http({
				method : 'POST',
				url : 'rest/manageParts/partCount',
			//	url : 'app/data/partlist.json',
				data : part,
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {				
				return data;
				
			});
					
		};
		
		
		 fact.populatPartsInfo=function(part)
		    {
	    	
		    	return $http({
					method : 'POST',
					url : 'rest/manageParts/managePartsByPartNumber',			
					data : part,
					headers: {'Content-Type': 'application/json'}
				})
				.success(function (data) {				
					return data;
					
				});
						
			};
			
			fact.savePartsMapDetails=function(part)
		    {
	    	
		    	return $http({
					method : 'POST',
					url : 'rest/manageParts/updatePart',			
					data : part,
					headers: {'Content-Type': 'application/json'}
				})
				.success(function (data) {				
					return data;
					
				});
						
			};
			
			fact.addPartsMapDetails=function(part)
		    {
	    	
		    	return $http({
					method : 'POST',
					url : 'rest/manageParts/insertPart',			
					data : part,
					headers: {'Content-Type': 'application/json'}
				})
				.success(function (data) {				
					return data;
					
				});
						
			};
			fact.deleteMaster=function(part)
		    {
	    	
		    	return $http({
					method : 'POST',
					url : 'rest/manageParts/deletePart',			
					data : part,
					headers: {'Content-Type': 'application/json'}
				})
				.success(function (data) {				
					return data;
					
				});
						
			};


	
	return fact;
	
	
}]);