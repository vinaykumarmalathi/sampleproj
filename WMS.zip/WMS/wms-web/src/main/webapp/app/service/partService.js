    //var serviceURL = mainService.getAppURL() + '/rest/coreMnemonic/';
wmsApp.factory('partFactory', [ 'commonService', function(commonService) {
    return {
        partsLocationList: commonFactory.commonService('GET', 'app/data/partlist.json', ''),
    };
}]);