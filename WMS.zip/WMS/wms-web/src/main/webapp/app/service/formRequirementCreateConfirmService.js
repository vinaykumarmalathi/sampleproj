var wmsApp = angular.module('wmsApp');

wmsApp.factory('formRequirementCreateConfirmService', ['$http','$q',function($http,$q){
	 var formRequirementCreateConfirmService={};
	 formRequirementCreateConfirmService.formRequirementCreateFetchList = function(formRequirementCreateFetchList)
	    {    	      
	    	return $http({
				method : 'POST',
				url : 'rest/formRequirementCreateFetch/formRequirementCreateFetchList',	
				data : formRequirementCreateFetchList,
				headers: {'Content-Type': 'application/json'}
			})
			.success(function (data) {			
				return data;
				
			});		
		};
		
	 return formRequirementCreateConfirmService;
}
]);