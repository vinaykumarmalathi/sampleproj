var wmsApp = angular.module('wmsApp');

wmsApp.factory('tagSheetService',['$http',function($http){
    var fact={};
    fact.getTagSheetData = function()
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/tagSheet/tagSheetDetails',	
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});		
	};
	
	fact.downloadTagSheet = function(data)
    {    	   
/*		var jsonObj = JSON.stringify(data);
		jsonObj = jsonObj.replace(/"PARTNUMBER":/g, '"partNumber":');
		jsonObj = jsonObj.replace(/"LOCATION":/g, '"location":');
		jsonObj = jsonObj.replace(/"SNP":/g, '"snp":');
		jsonObj = jsonObj.replace(/"NO_OF_BOXES":/g, '"noOfBoxes":');
		jsonObj = jsonObj.replace(/"OPENQUANTITY":/g, '"openQty":');
		jsonObj = jsonObj.replace(/"TOTALQUANTITY":/g, '"totalQty":');
		jsonObj = jsonObj.replace(/"DEVICE_ID":/g, '"deviceId":');
		jsonObj = jsonObj.replace(/"TRANSACTION_TYPE":/g, '"txnType":');*/
		return $http({
			method : 'POST',
			url : 'rest/tagSheet/tagSheetPdf',		
			data : JSON.stringify(data),
			headers: {'Content-Type': 'application/json'}
		})
		.success(function () {
			window.location.href="rest/tagSheet/txt"
		});		
	};
	return fact;
}]);