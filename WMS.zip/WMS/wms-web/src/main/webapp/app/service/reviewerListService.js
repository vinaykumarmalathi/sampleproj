var wmsApp = angular.module('wmsApp');

wmsApp.factory('reviewerListService',['$http',function($http){
    var reviewerListService={};
    reviewerListService.addReviewerList = function(reviewerFetchList)
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/reviewerList/addReviewerList',	
			data : reviewerFetchList,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});		
	};
	reviewerListService.getReviewerList = function(reviewerFetchList)
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/reviewerList/getReviewerList',	
			data : reviewerFetchList,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});		
	};
	reviewerListService.reviewerListCount = function()
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/reviewerList/reviewerListCount',	
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});		
	};
	reviewerListService.deleteReviewerList = function(deleteReviewerList) {
		return $http({
			method : 'POST',
			url : 'rest/reviewerList/deleteReviewerList',
			data : deleteReviewerList,
			headers : {'Content-Type':'application/json'}
		}).success(function(data){
			return data;
		})
	};
	return reviewerListService;
}]);