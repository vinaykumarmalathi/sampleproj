var wmsApp = angular.module('wmsApp');
wmsApp.factory('pitCumulativeReportService',['commonService','$http','$q', function(commonService,$http, $q){
    var fact={};
    
    fact.pitCumulativeReport=function(part)
    {    	      
    	return $http({
			method : 'POST',
			url : 'rest/pit/pitCumulativeReport',	
			data : part,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {			
			return data;
			
		});
				
	};
	
    fact.pitCumulativeDownload=function(part)
    {    
    	var deferred = $q.defer();
        $http({
			method : 'POST',
			url : 'rest/pit/pitCumulativeReport',	
			data : part,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			 deferred.resolve(data);
			
		});
        return deferred.promise;
				
	};
	
    fact.pitCumulativeReportCount=function(part)
    {
	
    	return $http({
			method : 'POST',
			url : 'rest/pit/pitCumulativeReportCount',		
			data : part,
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {
			return data;
			
		});
				
	};
    
    return fact;
	
}]);