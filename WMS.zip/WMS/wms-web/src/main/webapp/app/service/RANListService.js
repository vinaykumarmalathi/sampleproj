wmsApp.factory('ranService',['$http',function($http){
    var fact={};
    
    fact.ranList=function(inputObj)
    {
    	return $http({
			method : 'POST',
			url : 'rest/ran/getRan',		
			data : JSON.stringify(inputObj),
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {		
			return data;
			
		});
				
	};
	
	fact.getRanFmRANTbl=function(inputObj)
    {
    	return $http({
			method : 'POST',
			url : 'rest/ran/getRanFmRANTbl',		
			data : JSON.stringify(inputObj),
			headers: {'Content-Type': 'application/json'}
		})
		.success(function (data) {		
			return data;
			
		});
				
	};
		

	
	return fact;
	
	
}]);