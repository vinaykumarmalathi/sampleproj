package com.rnaipl.wms.service.reports;

import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.PartsInOutAuditSearch;
import com.rnaipl.wms.bean.reports.FIFOCheck;
import com.rnaipl.wms.dto.PartsInOutAuditSearchDTO;
import com.rnaipl.wms.dto.reports.FIFOCheckDTO;
import com.rnaipl.wms.dto.reports.FIFOCheckInputDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

@Path("/FIFOCheck")
public class FIFOCheckService {

	private static final Logger LOGGER = Logger.getLogger(FIFOCheckService.class);
	
	 @Inject
	 FIFOCheck fifoCheckBean;
	 
	 
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getFifoNotFollowed")
    @SuppressWarnings("null")
	public ServiceResponse getFIFONotFollowed(FIFOCheckInputDTO fifoCheckInputDTO){
		
		ServiceResponse serviceResponse = null;		
		try {
		//	serviceResponse.getStatusCode();
			
			if(fifoCheckInputDTO.getPartNumber() != null) {
        		List<String> partList = Arrays.asList(fifoCheckInputDTO.getPartNumber().split(","));
        		fifoCheckInputDTO.setPartList(partList);
        	}
        	if(fifoCheckInputDTO.getLocation() != null) {
        		List<String> locationList = Arrays.asList(fifoCheckInputDTO.getLocation().split(","));
        		fifoCheckInputDTO.setLocationList(locationList);
        	}
        	
        	if(fifoCheckInputDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(fifoCheckInputDTO.getRan().split(","));        	
        		fifoCheckInputDTO.setRanList(ranList);
        	}
			List<FIFOCheckDTO> fifoCheckDTOs = fifoCheckBean.getFIFONotFollowed(fifoCheckInputDTO);
			if (!fifoCheckDTOs.isEmpty()
					|| fifoCheckDTOs.size() > 0) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.PARTS_FETCH_SUCCESS,
						fifoCheckDTOs);
			} else {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			}
		

		} catch (Exception ex) {
			LOGGER.error("PartsInOutStagingService -- > getPartsInOutAuditByLocation()  Exception : " , ex);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.PARTS_FETCH_ERROR, ex);
		}
		LOGGER.debug("**IN Class->getPartsAuditDetails() Exit");
		return serviceResponse;
	}	
		
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getFifoNotFollowedCount")
    @SuppressWarnings("null")
	public ServiceResponse getFIFONotFollowedCount(FIFOCheckInputDTO fifoCheckInputDTO){
		
		ServiceResponse serviceResponse = null;		
		try {
		//	serviceResponse.getStatusCode();
			int noOfRecords=0;
			if(fifoCheckInputDTO.getPartNumber() != null) {
        		List<String> partList = Arrays.asList(fifoCheckInputDTO.getPartNumber().split(","));
        		fifoCheckInputDTO.setPartList(partList);
        	}
        	if(fifoCheckInputDTO.getLocation() != null) {
        		List<String> locationList = Arrays.asList(fifoCheckInputDTO.getLocation().split(","));
        		fifoCheckInputDTO.setLocationList(locationList);
        	}
        	
        	if(fifoCheckInputDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(fifoCheckInputDTO.getRan().split(","));        	
        		fifoCheckInputDTO.setRanList(ranList);
        	}
        	fifoCheckInputDTO.setDownload(true);
			List<FIFOCheckDTO> fifoCheckDTOs = fifoCheckBean.getFIFONotFollowed(fifoCheckInputDTO);
			if(fifoCheckDTOs!=null)
        	{
        		noOfRecords=fifoCheckDTOs.size();
        	}
			LOGGER.debug("**FIFO  Record Count " + noOfRecords);
			if (noOfRecords > 0) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.PARTS_FETCH_SUCCESS,
						noOfRecords);
			} else {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			}
		

		} catch (Exception ex) {
			LOGGER.error("PartsInOutStagingService -- > getPartsInOutAuditByLocation()  Exception : " , ex);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.PARTS_FETCH_ERROR, ex);
		}
		LOGGER.debug("**IN Class->getPartsAuditDetails() Exit");
		return serviceResponse;
	}	
		
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getFifoNotFollowedDownload")
    @SuppressWarnings("null")
	public ServiceResponse getFIFONotFollowedDownload(FIFOCheckInputDTO fifoCheckInputDTO){
		
		ServiceResponse serviceResponse = null;		
		try {
		//	serviceResponse.getStatusCode();
			
			if(fifoCheckInputDTO.getPartNumber() != null) {
        		List<String> partList = Arrays.asList(fifoCheckInputDTO.getPartNumber().split(","));
        		fifoCheckInputDTO.setPartList(partList);
        	}
        	if(fifoCheckInputDTO.getLocation() != null) {
        		List<String> locationList = Arrays.asList(fifoCheckInputDTO.getLocation().split(","));
        		fifoCheckInputDTO.setLocationList(locationList);
        	}
        	
        	if(fifoCheckInputDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(fifoCheckInputDTO.getRan().split(","));        	
        		fifoCheckInputDTO.setRanList(ranList);
        	}
        	fifoCheckInputDTO.setDownload(true);
			List<FIFOCheckDTO> fifoCheckDTOs = fifoCheckBean.getFIFONotFollowed(fifoCheckInputDTO);
			if (!fifoCheckDTOs.isEmpty()
					|| fifoCheckDTOs.size() > 0) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.PARTS_FETCH_SUCCESS,
						fifoCheckDTOs);
			} else {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			}
		

		} catch (Exception ex) {
			LOGGER.error("PartsInOutStagingService -- > getPartsInOutAuditByLocation()  Exception : " , ex);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.PARTS_FETCH_ERROR, ex);
		}
		LOGGER.debug("**IN Class->getPartsAuditDetails() Exit");
		return serviceResponse;
	}
		
}
