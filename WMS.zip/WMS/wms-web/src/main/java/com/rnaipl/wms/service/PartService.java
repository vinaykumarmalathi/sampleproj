package com.rnaipl.wms.service;

import java.util.List;
import java.util.Set;

import javax.ejb.EJBException;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.Line;
import com.rnaipl.wms.bean.Part;
import com.rnaipl.wms.bean.PartBean;
import com.rnaipl.wms.dto.LineDTO;
import com.rnaipl.wms.dto.PartDTO;
import com.rnaipl.wms.dto.PartLocationSynchroInputDTO;
import com.rnaipl.wms.dto.PartLocationSynchroServiceDTO;
import com.rnaipl.wms.dto.PartNumberDTO;
import com.rnaipl.wms.dto.PartSearchDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

/**
 * This Restful service class to process the requests from html and call the
 * respective EJB methods of Parts
 * 
 * 
 * @CreatedBy TechM
 * @CreatedOn 08-Apr-2016 10:25:44 am
 */
@Path("/parts")
@RequestScoped
public class PartService {

	private static final Logger LOGGER = Logger.getLogger(PartService.class);
	
    @Inject
    Part partBean;


    /**
     * This method is used to fetch the all plant details from the table
     * 
     * @return List of Part
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/allParts")
    public ServiceResponse getAllParts() {
        ServiceResponse serviceReponse = null;
        List<PartDTO> parts = null;
        try {
        	parts = partBean.getAllParts();
        	LOGGER.debug("Fetching all the Part details");
        	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PARTS_FETCH_SUCCESS, parts);
        } catch (Exception e) {
        	LOGGER.error("PartService -- > getAllParts()  Exception : " , e);
        	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
        LOGGER.debug("Fetching all the shop details");
        return serviceReponse;
    }
    
    /**
     * This method is used to fetch the all plant details from the table
     * 
     * @return List of Part
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/partsByPartNumber")
    public ServiceResponse getPartsByPartNumber(PartDTO part) {
        ServiceResponse serviceReponse = null;
        Set<PartNumberDTO> parts = null;
        try {
        	parts = partBean.getPartNumbers(part.getPartNumber());
        	LOGGER.debug("Fetching all the Part Number details");
        	if(!parts.isEmpty() && parts.size() > 0) {
        		serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PARTS_FETCH_SUCCESS, parts);
        	} else {
        		serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PARTS_EMPTY);
        	}
        } catch (Exception e) {
        	LOGGER.error("PartService -- > getPartsByPartNumber()  Exception : " , e);
        	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
        LOGGER.debug("Fetching all the shop details");
        return serviceReponse;
    }
    
    
    @POST
    @Produces(MediaType.APPLICATION_XML)
    @Path("/partLocationSynchroByShop")
    public List<PartLocationSynchroServiceDTO> getPartLocationSynchroService(PartLocationSynchroInputDTO partLocationSynchroInputDTO){
    	
    	LOGGER.debug("** In getPartLocationSynchroService function with param ");    	
    	return partBean.getPartLocationSynchroService(partLocationSynchroInputDTO);  
    }
    

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/PartLocationSynchroByShopAndroid")
    public List<PartLocationSynchroServiceDTO> getPartLocationSynchroServiceAndroid(PartLocationSynchroInputDTO partLocationSynchroInputDTO){
    	LOGGER.debug("** In getPartLocationSynchroService function with param ");    	
    	//return partBean.getPartLocationSynchroService(partLocationSynchroInputDTO);
    	return partBean.getPartLocationSynchroServiceAndroid(partLocationSynchroInputDTO);
    }

    @GET
    @Produces(MediaType.APPLICATION_XML)
    @Path("/partLocationSynchro")
    public List<PartLocationSynchroServiceDTO> getPartLocationSynchroService(){    	
    	LOGGER.debug("** In getPartLocationSynchroService function with param ");
    	//Create a dummy partLocationSynchroInputDTO
    	PartLocationSynchroInputDTO partLocationSynchroInputDTO=null;
    	return partBean.getPartLocationSynchroService(partLocationSynchroInputDTO);    	
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/partLocationSynchroAndroid")
    public List<PartLocationSynchroServiceDTO> getPartLocationSynchroServiceAndroid(){    	
    	LOGGER.debug("** In getPartLocationSynchroService function with param ");
    	//Create a dummy partLocationSynchroInputDTO
    	PartLocationSynchroInputDTO partLocationSynchroInputDTO=null;
    	return partBean.getPartLocationSynchroService(partLocationSynchroInputDTO);  
    	
    }
 
    
    
    
}
