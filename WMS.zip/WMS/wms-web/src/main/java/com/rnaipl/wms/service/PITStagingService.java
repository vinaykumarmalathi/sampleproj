package com.rnaipl.wms.service;

import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.PITStaging;
import com.rnaipl.wms.dto.PITCumulativeReportDTO;
import com.rnaipl.wms.dto.PITStagingDTO;
import com.rnaipl.wms.dto.PITTransactionReportDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;
import com.rnaipl.wms.service.util.XMLServiceResponse;

/*AJ00482484 -- PIT Automation -- START */

@Path("/pit")
public class PITStagingService {
	
	private static final Logger LOGGER = Logger.getLogger(PITStagingService.class);
	
	@Inject
	PITStaging pitStaging; 
	
	@POST
    @Produces(MediaType.APPLICATION_XML)
    @Path("/pitStaging")
    public XMLServiceResponse updatePitDetails(List<PITStagingDTO> pitDetails) {
		LOGGER.debug("**********************************************************************"); 
    	LOGGER.debug("*In updatePitDetails service entry");
    	
    	long startTime= System.currentTimeMillis();
    	XMLServiceResponse serviceResponse = new XMLServiceResponse();
    	try{
    		LOGGER.debug("List of PIT details Size == "+pitDetails.size());
    		if(!pitDetails.isEmpty() || pitDetails.size() > 0){
    			pitStaging.insertPitStaging(pitDetails);

        		serviceResponse.setStatusType(ServiceConstants.SERVICE_RESPONSE_SUCCESS);
    			serviceResponse.setStatusCode(ServiceConstants.PARTS_INSERT_SUCCESS);
    			serviceResponse.setStatusMessage("PIT Records Inserted Successfully");
    		}else{
    			serviceResponse.setStatusCode(ServiceConstants.NO_INPUT_DATA);
				serviceResponse.setStatusMessage("No Input data found..");
    		}
    	}catch(Exception ex){
    		LOGGER.error("PITStagingService -- > updatePitDetails()  Exception : " , ex);
			serviceResponse.setStatusType(ServiceConstants.SERVICE_RESPONSE_ERROR);
			serviceResponse.setStatusCode(ServiceConstants.PARTS_INSERT_FAIURE);
			serviceResponse.setStatusMessage("PIT Insert Failure");
    	}
    	long timeTaken = System.currentTimeMillis() - startTime;
    	LOGGER.debug("Time taken for Processing PIT details =  " + timeTaken); 
    	LOGGER.debug("********************************************************************************");
    	
    	return serviceResponse;
	}
	
	
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/pitStagingAndroid")
    public XMLServiceResponse updatePitDetailsAndroid(List<PITStagingDTO> pitDetails) {
		LOGGER.debug("**********************************************************************"); 
    	LOGGER.debug("*In updatePitDetails service entry");
    	
    	long startTime= System.currentTimeMillis();
    	XMLServiceResponse serviceResponse = new XMLServiceResponse();
    	try{
    		LOGGER.debug("List of PIT details Size == "+pitDetails.size());
    		if(!pitDetails.isEmpty() || pitDetails.size() > 0){
    			pitStaging.insertPitStaging(pitDetails);

        		serviceResponse.setStatusType(ServiceConstants.SERVICE_RESPONSE_SUCCESS);
    			serviceResponse.setStatusCode(ServiceConstants.PARTS_INSERT_SUCCESS);
    			serviceResponse.setStatusMessage("PIT Records Inserted Successfully");
    		}else{
    			serviceResponse.setStatusCode(ServiceConstants.NO_INPUT_DATA);
				serviceResponse.setStatusMessage("No Input data found..");
    		}
    	}catch(Exception ex){
    		LOGGER.error("PITStagingService -- > updatePitDetails()  Exception : " , ex);
			serviceResponse.setStatusType(ServiceConstants.SERVICE_RESPONSE_ERROR);
			serviceResponse.setStatusCode(ServiceConstants.PARTS_INSERT_FAIURE);
			serviceResponse.setStatusMessage("PIT Insert Failure");
    	}
    	long timeTaken = System.currentTimeMillis() - startTime;
    	LOGGER.debug("Time taken for Processing PIT details =  " + timeTaken); 
    	LOGGER.debug("********************************************************************************");
    	
    	return serviceResponse;
	}
	
	
	@SuppressWarnings("rawtypes")
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/pitTransactionReportCount")
	public ServiceResponse getPitTransactionReportCount(PITTransactionReportDTO pitTransactionReportDto){
		ServiceResponse serviceResponse = null;
		
		LOGGER.debug("***** PIT Transaction Report Count Method ENTRY ****");
		LOGGER.debug("PLANT == "+pitTransactionReportDto.getPlant());
		LOGGER.debug("SHOP == "+pitTransactionReportDto.getShop());
		LOGGER.debug("RECOUNT == "+pitTransactionReportDto.getRecount());
		LOGGER.debug("DEVICE ID == "+pitTransactionReportDto.getDeviceId());
		LOGGER.debug("RAN == "+pitTransactionReportDto.getRan());
		LOGGER.debug("PART NUMBER == "+pitTransactionReportDto.getPartNumber());
		LOGGER.debug("LOCATION == "+pitTransactionReportDto.getLocation());
		LOGGER.debug("SCANNED == "+pitTransactionReportDto.getScanned());
		
		try {
			if(null != pitTransactionReportDto.getPartNumber() && pitTransactionReportDto.getPartNumber().trim().length() > 0) {
        		List<String> partList = Arrays.asList(pitTransactionReportDto.getPartNumber().split(","));
        		pitTransactionReportDto.setPartList(partList);
        	}
			if(null != pitTransactionReportDto.getLocation() && pitTransactionReportDto.getLocation().trim().length() > 0) {
        		List<String> locationList = Arrays.asList(pitTransactionReportDto.getLocation().split(","));
        		pitTransactionReportDto.setLocationList(locationList);
        	}
        	if(null != pitTransactionReportDto.getRan() && pitTransactionReportDto.getRan().trim().length() > 0) {
        		List<String> ranList = Arrays.asList(pitTransactionReportDto.getRan().split(","));
        		pitTransactionReportDto.setRanList(ranList);
        	}
        	
        	int noOfRecords = pitStaging.getTransactionReportCount(pitTransactionReportDto);
        	
        	if (noOfRecords > 0) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.PARTS_FETCH_SUCCESS,
						noOfRecords);
			} else {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			}
			
		}catch (Exception ex) {
			LOGGER.error("PIT Staging Service -- > getPitTransactionReportCount()  Exception : " , ex);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.PARTS_FETCH_ERROR, ex);
		}
		LOGGER.debug("***** PIT Transaction Report Count Method EXIT ****");
		return serviceResponse;
	}
	
	@SuppressWarnings("rawtypes")
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/pitTransactionReport")
	public ServiceResponse getPitTransactionReport(PITTransactionReportDTO pitTransactionReportDto){
		LOGGER.debug("***** PIT Transaction Report Method ENTRY ****");
		ServiceResponse serviceResponse = null;
		
		try {
			if(null != pitTransactionReportDto.getPartNumber() && pitTransactionReportDto.getPartNumber().trim().length() > 0) {
        		List<String> partList = Arrays.asList(pitTransactionReportDto.getPartNumber().split(","));
        		pitTransactionReportDto.setPartList(partList);
        	}
			if(null != pitTransactionReportDto.getLocation() && pitTransactionReportDto.getLocation().trim().length() > 0) {
        		List<String> locationList = Arrays.asList(pitTransactionReportDto.getLocation().split(","));
        		pitTransactionReportDto.setLocationList(locationList);
        	}
        	if(null != pitTransactionReportDto.getRan() && pitTransactionReportDto.getRan().trim().length() > 0) {
        		List<String> ranList = Arrays.asList(pitTransactionReportDto.getRan().split(","));
        		pitTransactionReportDto.setRanList(ranList);
        	}
        	
        	List<PITTransactionReportDTO> pitTransactionReportList = pitStaging.getPitTransactionReportList(pitTransactionReportDto);
        	
        	if (!pitTransactionReportList.isEmpty()
					|| pitTransactionReportList.size() > 0) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.PARTS_FETCH_SUCCESS,
						pitTransactionReportList);
			} else {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			}
			
		}catch (Exception ex) {
			LOGGER.error("PIT Staging Service -- > getPitTransactionReport()  Exception : " , ex);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.PARTS_FETCH_ERROR, ex);
		}
		LOGGER.debug("***** PIT Transaction Report Method EXIT ****");
		return serviceResponse;
	}
	
	
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/pitCumulativeReportCount")
	public ServiceResponse getPitCumulativeReportCount(PITCumulativeReportDTO pitCumulativeReportDto){
		ServiceResponse serviceResponse = null;
		
		LOGGER.debug("***** PIT Cumulative Report Count Method ENTRY ****");
		LOGGER.debug("PLANT == "+pitCumulativeReportDto.getPlant());
		LOGGER.debug("SHOP == "+pitCumulativeReportDto.getShop());
		LOGGER.debug("RECOUNT == "+pitCumulativeReportDto.getRecount());
		LOGGER.debug("DEVICE ID == "+pitCumulativeReportDto.getDeviceId());
		LOGGER.debug("RAN == "+pitCumulativeReportDto.getRan());
		LOGGER.debug("PART NUMBER == "+pitCumulativeReportDto.getPartNumber());
		LOGGER.debug("LOCATION == "+pitCumulativeReportDto.getLocation());
		LOGGER.debug("SCANNED == "+pitCumulativeReportDto.getScanned());
		
		try {
			if(null != pitCumulativeReportDto.getPartNumber() && pitCumulativeReportDto.getPartNumber().trim().length() > 0) {
        		List<String> partList = Arrays.asList(pitCumulativeReportDto.getPartNumber().split(","));
        		pitCumulativeReportDto.setPartList(partList);
        	}
			if(null != pitCumulativeReportDto.getLocation() && pitCumulativeReportDto.getLocation().trim().length() > 0) {
        		List<String> locationList = Arrays.asList(pitCumulativeReportDto.getLocation().split(","));
        		pitCumulativeReportDto.setLocationList(locationList);
        	}
        	if(null != pitCumulativeReportDto.getRan() && pitCumulativeReportDto.getRan().trim().length() > 0) {
        		List<String> ranList = Arrays.asList(pitCumulativeReportDto.getRan().split(","));
        		pitCumulativeReportDto.setRanList(ranList);
        	}
        	
        	int noOfRecords = pitStaging.getCumulativeReportCount(pitCumulativeReportDto);
        	
        	if (noOfRecords > 0) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.PARTS_FETCH_SUCCESS,
						noOfRecords);
			} else {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			}
			
		}catch (Exception ex) {
			LOGGER.error("PIT Staging Service -- > getPitTransactionReportCount()  Exception : " , ex);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.PARTS_FETCH_ERROR, ex);
		}
		LOGGER.debug("***** PIT Cumulative Report Count Method EXIT ****");
		return serviceResponse;
	}
	
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/pitCumulativeReport")
	public ServiceResponse getPitCumulativeReport(PITCumulativeReportDTO pitCumulativeReportDto){
		LOGGER.debug("***** PIT Cumulative Report Method ENTRY ****");
		ServiceResponse serviceResponse = null;
		
		try {
			if(null != pitCumulativeReportDto.getPartNumber() && pitCumulativeReportDto.getPartNumber().trim().length() > 0) {
        		List<String> partList = Arrays.asList(pitCumulativeReportDto.getPartNumber().split(","));
        		pitCumulativeReportDto.setPartList(partList);
        	}
			if(null != pitCumulativeReportDto.getLocation() && pitCumulativeReportDto.getLocation().trim().length() > 0) {
        		List<String> locationList = Arrays.asList(pitCumulativeReportDto.getLocation().split(","));
        		pitCumulativeReportDto.setLocationList(locationList);
        	}
        	if(null != pitCumulativeReportDto.getRan() && pitCumulativeReportDto.getRan().trim().length() > 0) {
        		List<String> ranList = Arrays.asList(pitCumulativeReportDto.getRan().split(","));
        		pitCumulativeReportDto.setRanList(ranList);
        	}
        	
        	List<PITCumulativeReportDTO> pitCumulativeReportList = pitStaging.getPitCumulativeReportList(pitCumulativeReportDto);
        	
        	if (!pitCumulativeReportList.isEmpty()
					|| pitCumulativeReportList.size() > 0) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.PARTS_FETCH_SUCCESS,
						pitCumulativeReportList);
			} else {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			}
			
		}catch (Exception ex) {
			LOGGER.error("PIT Staging Service -- > getPitCumulativeReport()  Exception : " , ex);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.PARTS_FETCH_ERROR, ex);
		}
		LOGGER.debug("***** PIT Cumulative Report Method EXIT ****");
		return serviceResponse;
	}

}

/*AJ00482484 -- PIT Automation -- END */
