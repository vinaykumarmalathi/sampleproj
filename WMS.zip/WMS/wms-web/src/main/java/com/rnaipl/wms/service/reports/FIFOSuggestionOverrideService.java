package com.rnaipl.wms.service.reports;

import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.reports.FIFOSuggestionOverride;
import com.rnaipl.wms.dto.reports.FIFOCheckDTO;
import com.rnaipl.wms.dto.reports.FIFOCheckInputDTO;
import com.rnaipl.wms.dto.reports.FIFOSuggestionDTO;
import com.rnaipl.wms.dto.reports.FIFOSuggestionOverrideDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

@Path("/FIFOSuggestion")
public class FIFOSuggestionOverrideService {

	private static final Logger LOGGER = Logger.getLogger(FIFOSuggestionOverrideService.class);
	
	 @Inject
	 FIFOSuggestionOverride fifoSuggestionBean;
	 
	 
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getFifoSuggestion")
	public ServiceResponse getFifoSuggestion(FIFOSuggestionOverrideDTO fifoSuggestionOverrideDTO){
		
		ServiceResponse serviceResponse = null;		
		LOGGER.debug("**IN Class->()getFifoSuggestion Entry");
		try {
			if(fifoSuggestionOverrideDTO.getPartNumber() != null) {
        		List<String> partList = Arrays.asList(fifoSuggestionOverrideDTO.getPartNumber().split(","));
        		fifoSuggestionOverrideDTO.setPartList(partList);
        	}
        	if(fifoSuggestionOverrideDTO.getLocation() != null) {
        		List<String> locationList = Arrays.asList(fifoSuggestionOverrideDTO.getLocation().split(","));
        		fifoSuggestionOverrideDTO.setLocationList(locationList);
        	}
        	
        	if(fifoSuggestionOverrideDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(fifoSuggestionOverrideDTO.getRan().split(","));        	
        		fifoSuggestionOverrideDTO.setRanList(ranList);
        	}
			List<FIFOSuggestionDTO> fifoSuggestionDTOs = fifoSuggestionBean.getFIFOSuggestion(fifoSuggestionOverrideDTO);
			if (!fifoSuggestionDTOs.isEmpty()
					|| fifoSuggestionDTOs.size() > 0) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.PARTS_FETCH_SUCCESS,
						fifoSuggestionDTOs);
			} else {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			}
		

		} catch (Exception ex) {
			LOGGER.error("FIFOSuggestionOverrideService -- > getFifoSuggestion()  Exception : " , ex);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR, ex);
		}
		LOGGER.debug("**IN Class->()getFifoSuggestion Exit");
		return serviceResponse;
	}	
		
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getFifoSuggestionCount")
	public ServiceResponse getFifoSuggestionCount(FIFOSuggestionOverrideDTO fifoSuggestionOverrideDTO){	
		ServiceResponse serviceResponse = null;		
		LOGGER.debug("**IN Class->getFifoSuggestionCount() Entry");
		try {
			int noOfRecords=0;
			if(fifoSuggestionOverrideDTO.getPartNumber() != null) {
        		List<String> partList = Arrays.asList(fifoSuggestionOverrideDTO.getPartNumber().split(","));
        		fifoSuggestionOverrideDTO.setPartList(partList);
        	}
        	if(fifoSuggestionOverrideDTO.getLocation() != null) {
        		List<String> locationList = Arrays.asList(fifoSuggestionOverrideDTO.getLocation().split(","));
        		fifoSuggestionOverrideDTO.setLocationList(locationList);
        	}
        	
        	if(fifoSuggestionOverrideDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(fifoSuggestionOverrideDTO.getRan().split(","));        	
        		fifoSuggestionOverrideDTO.setRanList(ranList);
        	}
        	fifoSuggestionOverrideDTO.setDownload(true);
			List<FIFOSuggestionDTO> fifoSuggestionDTOs = fifoSuggestionBean.getFIFOSuggestion(fifoSuggestionOverrideDTO);
			if(fifoSuggestionDTOs!=null)
        	{
        		noOfRecords=fifoSuggestionDTOs.size();
        	}
			LOGGER.debug("**FIFO Suggestion Record Count " + noOfRecords);
			if (noOfRecords > 0) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.PARTS_FETCH_SUCCESS,
						noOfRecords);
			} else {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			}
		

		} catch (Exception ex) {
			LOGGER.error("FIFOSuggestionOverrideService -- > getFifoSuggestionCount()  Exception : " , ex);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR, ex);
		}
		LOGGER.debug("**IN Class->getFifoSuggestionCount() Exit");
		return serviceResponse;
	}	
	
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getFifoSuggestionDownload")
    @SuppressWarnings("null")
	public ServiceResponse getFifoSuggestionDownload(FIFOSuggestionOverrideDTO fifoSuggestionOverrideDTO){
		
		ServiceResponse serviceResponse = null;	
		LOGGER.debug("**IN Class->()getFifoSuggestionDownload Entry");
		try {
		//	serviceResponse.getStatusCode();
			
			if(fifoSuggestionOverrideDTO.getPartNumber() != null) {
        		List<String> partList = Arrays.asList(fifoSuggestionOverrideDTO.getPartNumber().split(","));
        		fifoSuggestionOverrideDTO.setPartList(partList);
        	}
        	if(fifoSuggestionOverrideDTO.getLocation() != null) {
        		List<String> locationList = Arrays.asList(fifoSuggestionOverrideDTO.getLocation().split(","));
        		fifoSuggestionOverrideDTO.setLocationList(locationList);
        	}
        	
        	if(fifoSuggestionOverrideDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(fifoSuggestionOverrideDTO.getRan().split(","));        	
        		fifoSuggestionOverrideDTO.setRanList(ranList);
        	}
        	fifoSuggestionOverrideDTO.setDownload(true);
        	List<FIFOSuggestionDTO> fifoSuggestionDTOs = fifoSuggestionBean.getFIFOSuggestion(fifoSuggestionOverrideDTO);
        	if (!fifoSuggestionDTOs.isEmpty()
					|| fifoSuggestionDTOs.size() > 0) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.PARTS_FETCH_SUCCESS,
						fifoSuggestionDTOs);
			} else {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			}
        	
		} catch (Exception ex) {
			LOGGER.error("FIFOSuggestionOverrideService -- > getFifoSuggestionDownload()  Exception : " , ex);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR, ex);
		}
		LOGGER.debug("**IN Class->()getFifoSuggestionDownload Exit");
		return serviceResponse;
	}
}

