package com.rnaipl.wms.service.ran;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
//import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import com.rnaipl.wms.bean.ran.DuplicateRAN;
import com.rnaipl.wms.bean.ran.RanUpload;
import com.rnaipl.wms.bean.ran.RanUploadBean;
import com.rnaipl.wms.dto.ran.AgedAgingRanDTO;
import com.rnaipl.wms.dto.ran.AgedAgingRanInputDTO;
import com.rnaipl.wms.dto.ran.RanUploadDTO;
import com.rnaipl.wms.dto.ran.RanUploadErrorDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;
import com.rnaipl.wms.util.WMSConstants;



@Path("/RanUpload")
public class RanUploadService {
	private static final Logger LOGGER = Logger.getLogger(RanUploadService.class);
	 @Inject
	 RanUpload ranUpload;
	

@POST
@Path("/uploadRanRecordPV")
@Consumes(MediaType.MULTIPART_FORM_DATA)	
public  ServiceResponse  uploadRanRecordPV(MultipartFormDataInput input){
	LOGGER.debug("**IN Class->uploadFile() entry");
	ServiceResponse serviceResponse = null;
	InputStream inputStream = null;
	
	List<Integer> statusInProgress = ranUpload.isRanUploadInProgress();
	
	if(statusInProgress != null && statusInProgress.size() > 0){	
		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR, ServiceConstants.BLANK_STATUS_MESSAGE,ServiceConstants.FILE_UPLOAD_PROGRESS);
	}
	
	else{
	Map<String, List<InputPart>> uploadForm = input.getFormDataMap();
	List<InputPart> inputParts = uploadForm.get("file");

	for (InputPart inputPart : inputParts) {
		
		try	{
		inputStream = inputPart.getBody(InputStream.class,null);	
		byte[] bytes = IOUtils.toByteArray(inputStream);
		MultivaluedMap<String, String> header = inputPart.getHeaders();
		
		String uploadDestinationPath = ranUpload.getParamUploadDestinationPath("PV"); 
		String sourceFile = getFileName(header);
		String uploadFileName;
		if(sourceFile.contains("\\")){
			uploadFileName = sourceFile.substring(sourceFile.lastIndexOf("\\")+1);
		}
		else{
			uploadFileName = sourceFile;	
		}
		String uploadedDestination=uploadDestinationPath + uploadFileName;
		//readExcelData()
		Set<String> set =  readExcelData(bytes);
		LOGGER.debug("UploadFileService---->"+set);
		
		Set<String> compareSet = new TreeSet<String>();
		compareSet.add("PART_NO");
		compareSet.add("RAN");
		compareSet.add("MFG_DATE");
		
		//compare excel data & writeFile()
		if(set.equals(compareSet))	{
			writeFile(bytes,uploadedDestination);
			ranUpload.triggerJob(uploadFileName);
			LOGGER.debug("UploadFileService---->writeFile() success");
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS, ServiceConstants.BLANK_STATUS_MESSAGE,ServiceConstants.UPLOAD_SUCCESS);
			}
		
		else {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR, ServiceConstants.BLANK_STATUS_MESSAGE,ServiceConstants.UPLOAD_COLUMN_MISMATCH);
			}	
	}
		catch (Exception e) {
			LOGGER.error("UploadFileService---->uploadFile()", e);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
		  }
	}
}
	return serviceResponse;

}



@POST
@Path("/uploadRanRecordPT")
@Consumes(MediaType.MULTIPART_FORM_DATA)	
public  ServiceResponse  uploadRanRecordPT(MultipartFormDataInput input){
	LOGGER.debug("**IN Class->uploadFile() entry");
	ServiceResponse serviceResponse = null;
	InputStream inputStream = null;
	
	List<Integer> statusInProgress = ranUpload.isRanUploadInProgress();
	
	if(statusInProgress != null && statusInProgress.size() > 0){	
		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR, ServiceConstants.BLANK_STATUS_MESSAGE,ServiceConstants.FILE_UPLOAD_PROGRESS);
	}
	
	else{
	Map<String, List<InputPart>> uploadForm = input.getFormDataMap();
	List<InputPart> inputParts = uploadForm.get("file");

	for (InputPart inputPart : inputParts) {
		
		try	{
		inputStream = inputPart.getBody(InputStream.class,null);	
		byte[] bytes = IOUtils.toByteArray(inputStream);
		MultivaluedMap<String, String> header = inputPart.getHeaders();
		
		String uploadDestinationPath = ranUpload.getParamUploadDestinationPath("PT"); 
		String sourceFile = getFileName(header);
		String uploadFileName;
		if(sourceFile.contains("\\")){
			uploadFileName = sourceFile.substring(sourceFile.lastIndexOf("\\")+1);
		}
		else{
			uploadFileName = sourceFile;	
		}
		String uploadedDestination=uploadDestinationPath + uploadFileName;
		//readExcelData()
		Set<String> set =  readExcelData(bytes);
		LOGGER.debug("UploadFileService---->"+set);
		
		Set<String> compareSet = new TreeSet<String>();
		compareSet.add("PART_NO");
		compareSet.add("RAN");
		compareSet.add("MFG_DATE");
		
		//compare excel data & writeFile()
		if(set.equals(compareSet))	{
			writeFile(bytes,uploadedDestination);
			ranUpload.triggerJob(uploadFileName);
			LOGGER.debug("UploadFileService---->writeFile() success");
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS, ServiceConstants.BLANK_STATUS_MESSAGE,ServiceConstants.UPLOAD_SUCCESS);
			}
		
		else {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR, ServiceConstants.BLANK_STATUS_MESSAGE,ServiceConstants.UPLOAD_COLUMN_MISMATCH);
			}	
	}
		catch (Exception e) {
			LOGGER.error("UploadFileService---->uploadFile()", e);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
		  }
	}
}
	return serviceResponse;

}

//save to destination
private void writeFile(byte[] content, String filename) throws IOException {

	File file = new File(filename);

	if (!file.exists()) {
			file.createNewFile();
	}

	FileOutputStream fop = new FileOutputStream(file);
	fop.write(content);
	fop.flush();
	fop.close();

}	

//getSourceFileName
private String getFileName(MultivaluedMap<String, String> header) {

	String[] contentDisposition = header.getFirst("Content-Disposition").split(";");

	for (String filename : contentDisposition) {
		if ((filename.trim().startsWith("filename"))) {

			String[] name = filename.split("=");

			String finalFileName = name[1].trim().replaceAll("\"", "");
			LOGGER.debug("**IN Class->uploadFile() entry filename"+finalFileName);
			return finalFileName;
		}
		}
	return "unknown";
	
	}

		
//read content in excel file
public static Set<String> readExcelData(byte[] input) throws InvalidFormatException {
	LOGGER.debug("readExcelData");
	
	Set<String> list = new TreeSet<String>();
	
	try {
		Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(input));
		int numberOfSheets = workbook.getNumberOfSheets();
		
		for(int i=0; i < numberOfSheets; i++){
			Sheet sheet = workbook.getSheetAt(i);
		
			Iterator<Row> rowIterator = sheet.iterator();
			if(rowIterator.hasNext()) 
	        {
				Row row = rowIterator.next();
				
				Iterator<Cell> cellIterator = row.cellIterator();
	            while (cellIterator.hasNext()) 
	            {
	            	Cell cell = cellIterator.next();
	            
	            	String value = cell.getStringCellValue().trim();
	            	list.add(value);
	            	
	            } 
	        } 
		} 
		
	} catch (Exception e) {
		LOGGER.debug("uploadFileService---->readExcelData()"+ e);
		ServiceResponse serviceResponse = null;
		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
	}
	
	return list;
}
	
@POST
@Produces(MediaType.APPLICATION_JSON)
@Path("/getAllRANUploadDetails")
public ServiceResponse getAllRanUpload() {
    ServiceResponse serviceReponse = null;
    List<RanUploadDTO> ranUploadList = null;
    ranUploadList = ranUpload.getRanUploadData();
    try {
    if(ranUploadList!=null && ranUploadList.size()>0){
    	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, ranUploadList);
    }
    else{
    	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND, ranUploadList);
    }
} catch (Exception e) {
	LOGGER.error("RanUploadService----> getRanUpload : ",e);
        serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
    }
		return serviceReponse;      
        
 }
	   
	   
@POST
@Produces(MediaType.APPLICATION_JSON)
@Path("/getDownloadRanErrorRecord")
public ServiceResponse getDownloadRanErrorRecord(int runId) {
    ServiceResponse serviceReponse = null;
    List<RanUploadErrorDTO> ranUploadErrorList = null;
    ranUploadErrorList = ranUpload.getRanDownloadDetails(runId);  
    try {
	    if(ranUploadErrorList!=null && ranUploadErrorList.size()>0){
	    	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, ranUploadErrorList);
	    }
	    else{
	    	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND, ranUploadErrorList);
	    }
    } 
    catch (Exception e) {
    	LOGGER.error("RanUploadService----> getRanUpload : ",e);
    	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
    }
	return serviceReponse;      
    
}

	    


	
	
}








