package com.rnaipl.wms.service;

import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.MissingPartsBean;
import com.rnaipl.wms.dto.LiveReceiptQtyMismatchDTO;
import com.rnaipl.wms.dto.MissingPartsDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

@Path("/missingParts")
public class MissingPartService {
	private static final Logger LOGGER = Logger.getLogger(MissingPartService.class);
	
	@Inject
	MissingPartsBean missingPartBean;
	
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getMissingPartsList")
	public ServiceResponse getMissingPartsList(MissingPartsDTO missingPartDto) {
		
		LOGGER.debug("**IN voking Service ->getMissingPartsList() --> entry");
        ServiceResponse serviceReponse = null;
        List<MissingPartsDTO> missingPartsList = null;
        try {
        	
        	if(missingPartDto!=null && missingPartDto.getPartNumber()!=null && !missingPartDto.getPartNumber().trim().equals("")){        		
        		List<String> partList = Arrays.asList(missingPartDto.getPartNumber().split(","));
        		missingPartDto.setPartList(partList);
        	}
        	LOGGER.debug("getMissingPartsList == Part Number Search List == "+missingPartDto.getPartList());
        	
        	missingPartsList = missingPartBean.getMissingPartsList(missingPartDto);
            if(missingPartsList!=null && missingPartsList.size()>0){
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, missingPartsList);
            }
            else{
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND, missingPartsList);
            }
        } catch (Exception e) {
        	LOGGER.error("Get RAN List : ",e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
        }
        return serviceReponse;
		
	}
	
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getMissingPartsListCount")
	public ServiceResponse getMissingPartsListCount(MissingPartsDTO missingPartDto) {
		
		LOGGER.debug("**Invoking Service ->getMissingPartsListCount() --> entry");
        ServiceResponse serviceReponse = null;
        List<LiveReceiptQtyMismatchDTO> lrQtyMismatch = null;
        try {
        	
        	if(missingPartDto!=null && missingPartDto.getPartNumber()!=null && !missingPartDto.getPartNumber().trim().equals("")){        		
        		List<String> partList = Arrays.asList(missingPartDto.getPartNumber().split(","));
        		missingPartDto.setPartList(partList);
        	}
        	LOGGER.debug("getMissingPartsListCount == Part Number Search List == "+missingPartDto.getPartList());
        	int noOfRecords = missingPartBean.getMissingPartsListCount(missingPartDto);
        	
        	if (noOfRecords > 0) {
        		serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.PARTS_FETCH_SUCCESS,
						noOfRecords);
			} else {
				serviceReponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			}
        	LOGGER.debug("**Service ->getMissingPartsListCount() --> exit");
        } catch (Exception e) {
        	LOGGER.error("Exception on getting Missing Part Count : ",e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
        }
        return serviceReponse;
	}

}
