package com.rnaipl.wms.service;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.PartsInOutStaging;
import com.rnaipl.wms.dto.PartsInOutStagingByDeviceDTO;
import com.rnaipl.wms.dto.PartsInOutStagingDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;
import com.rnaipl.wms.service.util.XMLServiceResponse;
import com.rnaipl.wms.util.WMSConstants;

@Path("/parts")
public class PartsInOutStagingService {

	private static final Logger LOGGER = Logger.getLogger(PartsInOutStagingService.class);
	private static final Logger LOGGER_PART_INOUT = Logger.getLogger(WMSConstants.INOUT_LOGFILE);
	
	
    @Inject
    PartsInOutStaging partsInOutStaging;
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/partsInOutStaging")
    public ServiceResponse updatePartsInOutDetails(List<PartsInOutStagingByDeviceDTO> partsInOutInfo) {
    	LOGGER_PART_INOUT.debug("**********************************************************************");
    	LOGGER_PART_INOUT.debug("*In updatePartsInOutDetails service entry");
        ServiceResponse serviceResponse = null;
		try {	
			partsInOutStaging.insertPartsInOutStaging(partsInOutInfo);
			//partsInOutStaging.executeStoreProcedure();
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.FILE_PROCESSED);
			
		} catch (Exception ex) {
			LOGGER_PART_INOUT.error("PartsInOutStagingService -- > updatePartsInOutDetailsByDevice()  Exception : " , ex);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
			
		}
		LOGGER_PART_INOUT.debug("**********************************************************************"); 
		return serviceResponse;
    }
    
    

    @POST
    @Produces(MediaType.APPLICATION_XML)
    @Path("/partsInOutStagingByDevice")
    public XMLServiceResponse updatePartsInOutDetailsByDevice(List<PartsInOutStagingByDeviceDTO> partsInOutInfo) {
    	LOGGER_PART_INOUT.debug("**********************************************************************"); 
    	LOGGER_PART_INOUT.debug("*In updatePartsInOutDetailsByDevice service entry");
    	String deviceID="";
    	if(partsInOutInfo!=null && partsInOutInfo.get(0)!=null){
    		 deviceID= partsInOutInfo.get(0).getDeviceId();	
    	}
    	long startTime= System.currentTimeMillis();
		XMLServiceResponse serviceResponse = new XMLServiceResponse();		
		try {
			/*System.out.println("**Starts");
    		Thread.sleep(7000);
    		System.out.println("**Ends");*/
			if (!partsInOutInfo.isEmpty() || partsInOutInfo.size() > 0) {	
				partsInOutStaging.insertPartsInOutStaging(partsInOutInfo);
				//partsInOutStaging.executeStoreProcedure();
				serviceResponse.setStatusType(ServiceConstants.SERVICE_RESPONSE_SUCCESS);
				serviceResponse.setStatusCode(ServiceConstants.PARTS_INSERT_SUCCESS);
				serviceResponse.setStatusMessage("Records Inserted Successfully");
			} else {
				serviceResponse.setStatusCode(ServiceConstants.NO_INPUT_DATA);
				serviceResponse.setStatusMessage("No Input data found..");
			}
		} catch (Exception ex) {
			LOGGER_PART_INOUT.error("PartsInOutStagingService -- > updatePartsInOutDetailsByDevice()  Exception : " , ex);
			serviceResponse.setStatusType(ServiceConstants.SERVICE_RESPONSE_ERROR);
			serviceResponse.setStatusCode(ServiceConstants.PARTS_INSERT_FAIURE);
			serviceResponse.setStatusMessage("Parts Insert Failure");
		}
		 long timeTaken = System.currentTimeMillis() - startTime;
		 LOGGER_PART_INOUT.debug("Time taken for Part In Out Staging by Device," + deviceID +"," + timeTaken); 
		 LOGGER_PART_INOUT.debug("********************************************************************************"); 
		return serviceResponse;
    }
    
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/partsInOutStagingByDeviceAndroid")
    public XMLServiceResponse updatePartsInOutDetailsByDeviceAndroid(List<PartsInOutStagingByDeviceDTO> partsInOutInfo) {
    	LOGGER_PART_INOUT.debug("**********************************************************************"); 
    	LOGGER_PART_INOUT.debug("*In updatePartsInOutDetailsByDevice service entry");
    	String deviceID="";
    	if(partsInOutInfo!=null && partsInOutInfo.get(0)!=null){
    		 deviceID= partsInOutInfo.get(0).getDeviceId();	
    	}
    	long startTime= System.currentTimeMillis();
		XMLServiceResponse serviceResponse = new XMLServiceResponse();		
		try {
			/*System.out.println("**Starts");
    		Thread.sleep(7000);
    		System.out.println("**Ends");*/
			if (!partsInOutInfo.isEmpty() || partsInOutInfo.size() > 0) {	
				partsInOutStaging.insertPartsInOutStaging(partsInOutInfo);
				//partsInOutStaging.executeStoreProcedure();
				serviceResponse.setStatusType(ServiceConstants.SERVICE_RESPONSE_SUCCESS);
				serviceResponse.setStatusCode(ServiceConstants.PARTS_INSERT_SUCCESS);
				serviceResponse.setStatusMessage("Records Inserted Successfully");
			} else {
				serviceResponse.setStatusCode(ServiceConstants.NO_INPUT_DATA);
				serviceResponse.setStatusMessage("No Input data found..");
			}
		} catch (Exception ex) {
			LOGGER_PART_INOUT.error("PartsInOutStagingService -- > updatePartsInOutDetailsByDevice()  Exception : " , ex);
			serviceResponse.setStatusType(ServiceConstants.SERVICE_RESPONSE_ERROR);
			serviceResponse.setStatusCode(ServiceConstants.PARTS_INSERT_FAIURE);
			serviceResponse.setStatusMessage("Parts Insert Failure");
		}
		 long timeTaken = System.currentTimeMillis() - startTime;
		 LOGGER_PART_INOUT.debug("Time taken for Part In Out Staging by Device," + deviceID +"," + timeTaken); 
		 LOGGER_PART_INOUT.debug("********************************************************************************"); 
		return serviceResponse;
    }
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/partsInOutAuditByLocation")
    @SuppressWarnings("null")
	public ServiceResponse getPartsInOutAuditByLocation(PartsInOutStagingDTO partsInOutAudit) {
		ServiceResponse serviceResponse = null;
		try {
			String location = partsInOutAudit.getLocation();
			if (location == null || "".equals(location.trim())) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_INPUT_DATA);
			} else {
				List<PartsInOutStagingDTO> partsInOutDataByLocation = partsInOutStaging
						.getPartsInOutAuditByLocaiton(partsInOutAudit);
				if (!partsInOutDataByLocation.isEmpty()
						|| partsInOutDataByLocation.size() > 0) {
					serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PARTS_FETCH_SUCCESS,
							partsInOutDataByLocation);
				} else {
					serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
				}
			}

		} catch (Exception ex) {
			LOGGER.error("PartsInOutStagingService -- > getPartsInOutAuditByLocation()  Exception : " , ex);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, ex);
		}
		return serviceResponse;
	}
    
}
