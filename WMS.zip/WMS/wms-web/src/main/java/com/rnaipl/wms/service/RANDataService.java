package com.rnaipl.wms.service;

import java.util.Arrays;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.RANData;
import com.rnaipl.wms.dto.PartsInOutAuditSearchDTO;
import com.rnaipl.wms.dto.RANDataDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

@Path("/rans")
@RequestScoped
public class RANDataService {
	
	private static final Logger LOGGER = Logger.getLogger(RANDataService.class);
	
	@Inject 
	RANData RANDataBean;
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getAllran")
	
	public ServiceResponse getRanDetails(RANDataDTO ranDTO){
		LOGGER.debug("RANService -- > getRanDetails() starts");
		ServiceResponse serviceResponse = null;
		List<RANDataDTO> rans = null;
		try{
			if(ranDTO.getPartNos() != null) {
        		List<String> partList = Arrays.asList(ranDTO.getPartNos().split(","));
        		ranDTO.setPartNoList(partList);
        	}
			if(ranDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(ranDTO.getRan().split(","));
        		ranDTO.setRanList(ranList);
        	}
			LOGGER.debug("RANService -- > getRanDetails() starts");
			rans = RANDataBean.getAllRan(ranDTO);
			
			if(rans != null && rans.size()>0){
				LOGGER.debug("RANService -- > getRanDetails() success" );
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, rans);
			}
			else{
				LOGGER.debug("RANService -- > getRanDetails() no data found" );
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND, rans);
			}
		}
		catch(Exception e){
			LOGGER.error("RANService -- > getRanDetails() Exception : ",e);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
		}
		LOGGER.debug("RANService -- > getRanDetails() ends");
		return serviceResponse;
	}

	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/ranDataCount")
	public ServiceResponse getRanDetailsCount(RANDataDTO ranDTO){
		LOGGER.debug("RANService -- > getRanDetailsCount() starts");
		ServiceResponse serviceResponse = null;
		try{
			if(ranDTO.getPartNos() != null) {
        		List<String> partList = Arrays.asList(ranDTO.getPartNos().split(","));
        		ranDTO.setPartNoList(partList);
        	}
			if(ranDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(ranDTO.getRan().split(","));
        		ranDTO.setRanList(ranList);
        	}
			int noOfRecords = RANDataBean.getRanCount(ranDTO);
			
			if(noOfRecords > 0){
				LOGGER.debug("RANService -- > getRanDetailsCount() success" );
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, noOfRecords);
			}
			else{
				LOGGER.debug("RANService -- > getRanDetailsCount() no data found" );
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND, noOfRecords);
			}
		}
		catch(Exception e){
			LOGGER.error("RANService -- > getRanDetailsCount() Exception : ",e);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
		}
		LOGGER.debug("RANService -- > getRanDetailsCount() ends");
		return serviceResponse;
	}
}