package com.rnaipl.wms.service;

import java.util.List;
import javax.ejb.EJBException;
import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.apache.log4j.Logger;
import com.rnaipl.wms.bean.ManageLocationByPart;
import com.rnaipl.wms.dto.LocationByPartDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

@Path("/manageLocationByPartNo")
public class ManageLocationByPartNoService {

private static final Logger LOGGER = Logger.getLogger(ManageLocationByPartNoService.class);
	
    @Inject
    ManageLocationByPart manageLocBean;
 

    /**
     * This method is used to fetch Location details based in input partNumber
     * 
     * @return PartDTO
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getLocationsByPartNo")
    public ServiceResponse getLocationsByPartNumber(String partNo) {
        ServiceResponse serviceResponse = null;
        List<LocationByPartDTO> locationsList = null;
       
        try { 
        	locationsList = manageLocBean.getLocationsByPartNo(partNo);
        	if(null != locationsList && locationsList.size() > 0) {
        		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.LOCATION_FETCH_SUCCESS, locationsList);
        	} else {
        		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.LOCATION_EMPTY);
        	}
        } catch (Exception e) {
        	LOGGER.error("ManageLocationByPartNoService -- > getPartsByPartNumber()  Exception : " , e);
        	serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
        return serviceResponse;
    }
    
    /**
     * This method is used to delete Location details based in input locations
     * 
     * @return PartDTO
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/deleteLocations")
    public ServiceResponse deleteLocationsByPartNumber(List<LocationByPartDTO> locationList) {
        ServiceResponse serviceResponse = null;
        String result = "";
        
        
        try {
        	result = manageLocBean.deleteLocations(locationList);
			if (result != null && result.equals("0")) {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.NO_DATA_FOUND);
			} else {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.LOCATION_DELETED);
			} 
		} catch (EJBException ejbe) {
			LOGGER.error("ManageLocationByPartNoService -- > deleteLocation()  Exception : ", ejbe);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, ejbe);
		} catch (Exception e) {
			LOGGER.error("ManageLocationByPartNoService -- > deleteLocation()  Exception : ", e);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
		}
		LOGGER.debug("IN ManageLocationByPartNoService deleteLocation Exit");
		return serviceResponse;
    }
    
    /**
     * This method is used to add  Location details in to a part number.
     * 
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/addLocation")
    public ServiceResponse addLocation(LocationByPartDTO location) {
    	LOGGER.debug("IN add locations:"+location);
    	LOGGER.debug("IN add location:"+location.getPartNo());
    	String result = null;
        ServiceResponse serviceResponse = null;
        try { 
        	System.out.println("adding location...");  
     
             	result = manageLocBean.addLocation(location);
             	if (result.equals("0")) {
     				serviceResponse = ServiceResponseHandler
     						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.LOCATION_INSERT_SUCCESS);
     			}else if (result.equals("1")) {
     				serviceResponse = ServiceResponseHandler
     						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.LOCATION_NOT_FOUND);
     			}else if (result != null && result.equals("2")) {
     				serviceResponse = ServiceResponseHandler
     						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.LOCATION_ALREADY_FOUND);
     			}else if(result!=null && result.equals("3")){
    				LOGGER.debug("result 3");
    				serviceResponse = ServiceResponseHandler
    						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.LOCATION_ALREADY_MAPPED);
    			}
     		} catch (EJBException ejbe) {
     			LOGGER.error("ManageLocationByPartNoService -- > addLocation()  ejbe Exception : ", ejbe);
     			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
     					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, ejbe);
     		} catch (Exception e) {
     			LOGGER.error("ManageLocationByPartNoService -- > addLocation()  Exception : ", e);
     			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
     					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
     		}
     		LOGGER.debug("IN ManageLocationByPartNoService --add location Exit");
     		return serviceResponse;
    } 
    
    
    /**
     * This method is used to save Location details based in input partNumber
     * 
     * @return PartDTO
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/saveLocations")
    public ServiceResponse saveLocationsByPartNumber(List<LocationByPartDTO> locationList) {
        ServiceResponse serviceResponse = null;
        String result = "";
        
        
        try {
        	result = manageLocBean.saveLocations(locationList);
			if (result != null && result.equals("2")) {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			} else if (result.equals("0")) {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.LOCATION_UPDATE_SUCCESS);
			} else if (result.equals("1")) {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.LOCATION_FOUND);
			}
		} catch (EJBException ejbe) {
			LOGGER.error("ManageLocationByPartNoService -- > saveLocation()  Exception : ", ejbe);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, ejbe);
		} catch (Exception e) {
			LOGGER.error("ManageLocationByPartNoService -- > saveLocation()  Exception : ", e);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
		}
		LOGGER.debug("IN ManageLocationByPartNoService saveLocation Exit");
		return serviceResponse;
    }
    
    
}


