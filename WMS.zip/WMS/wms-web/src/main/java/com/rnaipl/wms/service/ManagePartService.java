package com.rnaipl.wms.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.ejb.EJBException;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.Part;
import com.rnaipl.wms.dto.LocationCountDTO;
import com.rnaipl.wms.dto.PartDTO;
import com.rnaipl.wms.dto.PartLocationDownloadReportDTO;
import com.rnaipl.wms.dto.PartNumberDTO;
import com.rnaipl.wms.dto.PartSearchDTO;
import com.rnaipl.wms.dto.PartsDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;
import com.rnaipl.wms.service.util.XMLServiceResponse;

/**
 * This Restful service class to process the requests from html and call the
 * respective EJB methods of Parts
 * 
 * 
 * @CreatedBy TechM
 * @CreatedOn 08-Apr-2016 10:25:44 am
 */
@Path("/manageParts")
@RequestScoped
public class ManagePartService {

	private static final Logger LOGGER = Logger.getLogger(ManagePartService.class);
	
    @Inject
    Part partBean;


    /**
     * This method is used to fetch Part details based in input partNumber
     * 
     * @return PartDTO
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/managePartsByPartNumber")
    public ServiceResponse getPartsByPartNumber(PartSearchDTO partDto) {
    	LOGGER.debug("IN PartService getPartsByPartNumber Entry");
        ServiceResponse serviceReponse = null;
        PartSearchDTO part = null;
        try { 
        	part = partBean.getPartByPartNumber(partDto.getPartNumber());
        	LOGGER.debug("Fetching all the Part Number details");
        	if(part != null) {
        		serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PARTS_FETCH_SUCCESS, part);
        	} else {
        		serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PARTS_EMPTY);
        	}
        } catch (Exception e) {
        	LOGGER.error("PartService -- > getPartsByPartNumber()  Exception : " , e);
        	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
        LOGGER.debug("IN PartService getPartsByPartNumber Entry");
        return serviceReponse;
    }
    
    
    /**
     * This method is used to fetch Part details based in input partNumber
     * 
     * @return PartDTO
     */
    @POST
    @Produces(MediaType.APPLICATION_XML)
  //  @Consumes(MediaType.APPLICATION_XML)
    @Path("/getPartsByPartNumberAsXML")
    public PartSearchDTO getPartsByPartNumberAsXML(PartSearchDTO partDto) {
    	LOGGER.debug("IN PartService getPartsByPartNumber Entry");
        PartSearchDTO part = null;
        try { 
        	part = partBean.getPartByPartNumber(partDto.getPartNumber());
        	LOGGER.debug("Fetching all the Part Number details");
        } catch (Exception ex) {
        	part = new PartSearchDTO();
        	part.setStatus(3);
        	part.setPartNumber(partDto.getPartNumber());
        	LOGGER.error("PartService -- > getPartsByPartNumber()  Exception : " , ex);
        }
        return part;
    }
    
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getPartsByPartNumberAsAndroid")
    public PartsDTO getPartsByPartNumberAsAndroid(PartSearchDTO partDto) {
    	LOGGER.debug("IN PartService getPartsByPartNumber Entry");
    	PartSearchDTO part = null;
    	PartsDTO part1=null;
        try { 
        	part = partBean.getPartByPartNumber(partDto.getPartNumber());
        	part1=prepareParts(part);
        	LOGGER.debug("Fetching all the Part Number details");
        } catch (Exception ex) {
        	part1 = new PartsDTO();
        	part1.setStatus(3);
        	part1.setPartNumber(partDto.getPartNumber());
        	LOGGER.error("PartService -- > getPartsByPartNumber()  Exception : " , ex);
        }
        return part1;
    }
    
    
    private PartsDTO prepareParts(PartSearchDTO partOld) {
    	PartsDTO part=new PartsDTO();
    	Map<String, Integer> hm =(Map<String, Integer>) partOld.getLocationCount();
    	List<LocationCountDTO> newList=new ArrayList<LocationCountDTO>();
    	LocationCountDTO locationCount=null;
    	for (Map.Entry mapElement : hm.entrySet()) { 
            String key = (String)mapElement.getKey(); 
            Integer value = (Integer)mapElement.getValue(); 
            locationCount=new LocationCountDTO();
            locationCount.setLocation(key);
            if(null!=value)locationCount.setQuantity(String.valueOf(value));
            newList.add(locationCount);
        } 
    	part.setLocationCount(newList);
    	part.setStatus(partOld.getStatus());
    	part.setPartNumber(partOld.getPartNumber());
    	part.setPartName(partOld.getPartName());
    	part.setPartName(partOld.getPartName());
    	part.setSnp(partOld.getSnp());
    	part.setPartType(partOld.getPartType());
    	part.setCategory(partOld.getCategory());
    	part.setLeadTime(partOld.getLeadTime());
    	part.setSafetyStock(partOld.getSafetyStock());
    	part.setSupplierCode(partOld.getSupplierCode());
    	part.setCreatedOn(partOld.getCreatedOn());
    	part.setCreatedBy(partOld.getCreatedBy());
    	part.setUpdatedOn(partOld.getUpdatedOn());
    	part.setUpdatedBy(partOld.getUpdatedBy());
    	part.setDepoCode(partOld.getDepoCode());
    	part.setDtlFlag(partOld.getDtlFlag());
    	part.setRePackingFlag(partOld.getRePackingFlag());
    	part.setUserId(partOld.getUserId());
    	part.setComments(partOld.getComments());
    	part.setLogs(partOld.getLogs());
    	part.setPartList(partOld.getPartList());
    	part.setSupplierCodeList(partOld.getSupplierCodeList());
    	part.setLocations(partOld.getLocations());
    	part.setLocationList(partOld.getLocationList());
    	part.setPlant(partOld.getPlant());
    	part.setShop(partOld.getShop());
    	part.setLine(partOld.getLine());
    	part.setUnreleasedParts(partOld.isUnreleasedParts());
    	part.setPcCode(partOld.getPcCode());
    	part.setStartIndex(partOld.getStartIndex());
    	part.setEndIndex(partOld.getEndIndex());
		return part;
	}


	/**
     * This method is used to fetch part count
     * 
     * @return - int
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/partCount")
    public ServiceResponse getPartsCount(PartSearchDTO partDto) {
    	LOGGER.debug("IN PartService getPartsCount Entry");
    	ServiceResponse serviceResponse = null; 
        int partCount = 0;
		try { 
			if(partDto.getPartNumber() != null) {
         		List<String> partList = Arrays.asList(partDto.getPartNumber().split(","));
         		partDto.setPartList(partList);
         	}
        	if(partDto.getSupplierCode() != null) {
          		List<String> supplierCodeList = Arrays.asList(partDto.getSupplierCode().split(","));
          		partDto.setSupplierCodeList(supplierCodeList);
          	}
        	
        	if(partDto.getLocations() != null) {
          		List<String> locationList = Arrays.asList(partDto.getLocations().split(","));
          		partDto.setLocationList(locationList);
          	}
        	
        	partCount = partBean.getPartCount(partDto);
			if (partCount > 0) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.PARTS_FETCH_SUCCESS,
						partCount);
			} else {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			}
        } catch (Exception e) {
        	LOGGER.error("PartService -- > getPartsByPartNumber()  Exception : " , e);
        	serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
        LOGGER.debug("IN PartService getPartsCount EXIT");
        return serviceResponse;
    }
    
    /**
     * This method used to return the List of PartNumber based on given input
     * @param part
     * @return - List<String>
     */
    
  
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/partSearch")
    public ServiceResponse getPartSearchResults(PartSearchDTO part){
    	LOGGER.debug("IN PartService getPartSearchResults Entry");
    	 ServiceResponse serviceReponse = null;
         List<PartDTO> parts = new LinkedList<PartDTO>();
         try {
        	 if(part.getPartNumber() != null) {
         		List<String> partList = Arrays.asList(part.getPartNumber().split(","));
         		part.setPartList(partList);
         	}
        	if(part.getSupplierCode() != null) {
          		List<String> supplierCodeList = Arrays.asList(part.getSupplierCode().split(","));
          		part.setSupplierCodeList(supplierCodeList);
          	}
        	if(part.getLocations() != null) {
          		List<String> locationList = Arrays.asList(part.getLocations().split(","));
          		part.setLocationList(locationList);
          	}
        	
         	parts = partBean.getPartSearchData(part);
         	if(parts.isEmpty() || parts.size() == 0) {
         		serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND,parts);
         	} else {
         		serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PARTS_FETCH_SUCCESS,parts);
         	}
         } catch (EJBException ejbe) {
         	LOGGER.error("PartService -- > getPartSearchResults()  EJBException : " , ejbe);
         	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, ejbe);
         } catch (Exception e) {
          	LOGGER.error("PartService -- > getPartSearchResults()  Exception : " , e);
          	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
          }
         LOGGER.debug("IN PartService getPartSearchResults Exit");
         return serviceReponse;
    }
    
    /**
	 * This method used for insert PART.
	 * @param locationDto
	 * @return - "success" or "failure"
	 */
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/insertPart")
	public ServiceResponse insertPart(PartDTO part) {
		LOGGER.debug("IN PartService insertPart Entry");
		ServiceResponse serviceReponse = null;
		String result = null;
		try {
			result = partBean.insertPart(part);
			if (result != null && result.equals("1")) {
				serviceReponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PARTS_ALREADY_FOUND);
			} else if (result.equals("0")) {
				serviceReponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PARTS_INSERT_SUCCESS);
			}
		} catch (EJBException ejbe) {
			LOGGER.error("PartService -- > insertPart()  EJBException : ", ejbe);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, ejbe);
		} catch (Exception e) {
          	LOGGER.error("PartService -- > insertPart()  Exception : " , e);
          	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
          }
		LOGGER.debug("IN PartService insertPart Exit");
		return serviceReponse;
	}
	
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/partDownload")
    public ServiceResponse partDownload(PartSearchDTO part){
    	LOGGER.debug("IN PartService getPartSearchResults Entry");
    	 ServiceResponse serviceReponse = null;
         List<PartLocationDownloadReportDTO> parts = new LinkedList<PartLocationDownloadReportDTO>();
         try {
        	 if(part.getPartNumber() != null) {
         		List<String> partList = Arrays.asList(part.getPartNumber().split(","));
         		part.setPartList(partList);
         	}
        	if(part.getSupplierCode() != null) {
          		List<String> supplierCodeList = Arrays.asList(part.getSupplierCode().split(","));
          		part.setSupplierCodeList(supplierCodeList);
          	}
        	if(part.getLocations() != null) {
          		List<String> locationList = Arrays.asList(part.getLocations().split(","));
          		part.setLocationList(locationList);
          	}
        	
        	LOGGER.debug("Before partDownload");
        	parts=partBean.partDownload(part);
         	if(parts.isEmpty() || parts.size() == 0) {
         		serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND,parts);
         	} else {
         		serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PARTS_FETCH_SUCCESS,parts);
         	}
         } catch (EJBException ejbe) {
         	LOGGER.error("PartService -- > getPartSearchResults()  EJBException : " , ejbe);
         	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, ejbe);
         } catch (Exception e) {
          	LOGGER.error("PartService -- > getPartSearchResults()  Exception : " , e);
          	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
          }
         LOGGER.debug("IN PartService getPartSearchResults Exit");
         return serviceReponse;
    }
    
    
	/**
	 * This method used for update the Part.
	 * @param locationDto
	 * @return - "success" or "failure"
	 */
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/updatePart")
	public ServiceResponse updatePart(List<PartDTO> part) {
		LOGGER.debug("IN PartService updatePart Entry");
		ServiceResponse serviceReponse = null;
		String result = null;
		try {
			result = partBean.updatePart(part);
			if (result != null && result.equals("1")) {
				serviceReponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			} else if (result.equals("0")) {
				serviceReponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PARTS_UPDATE_SUCCESS);
			}
		} catch (EJBException ejbe) {
			LOGGER.error("PartService -- > updatePart()  Exception : ", ejbe);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, ejbe);
		} catch (Exception e) {
			LOGGER.error("PartService -- > updatePart()  Exception : ", e);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
		}
		LOGGER.debug("IN PartService updatePart Exit");
		return serviceReponse;
	}
	
	/**
	 * This method used for delete the Part.
	 * @param locationDto
	 * @return - "success" or "failure"
	 */
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/deletePart")
	public ServiceResponse deletePart(PartSearchDTO part) {
		LOGGER.debug("IN PartService deletePart Entry");
		ServiceResponse serviceReponse = null;
		String result = null;
		try {
			result = partBean.deletePart(part);
			if (result != null && result.equals("2")) {
				serviceReponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			} else if (result.equals("0")) {
				serviceReponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PARTS_DELETED);
			} else if (result.equals("1")) {
				serviceReponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.LOCATION_FOUND);
			}
		} catch (EJBException ejbe) {
			LOGGER.error("PartService -- > deletePart()  Exception : ", ejbe);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, ejbe);
		} catch (Exception e) {
			LOGGER.error("PartService -- > deletePart()  Exception : ", e);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
		}
		LOGGER.debug("IN PartService deletePart Exit");
		return serviceReponse;
	}
    
    
    
}
