package com.rnaipl.wms.service;

import java.util.Arrays;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.MasterScreenDetails;
import com.rnaipl.wms.dto.MasterScreenDetailsDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;


@Path("/masterscreen")
@RequestScoped
public class MasterScreenDetailsService {

	private static final Logger LOGGER = Logger.getLogger(MasterScreenDetailsService.class);

	@Inject
	MasterScreenDetails masterScreenBean;

	@SuppressWarnings("unchecked")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/masterdetailslistcount")
	public ServiceResponse getMasterDetailsCount(MasterScreenDetailsDTO masterScreenDTO) {

		LOGGER.debug("Entering getMasterDetailsCount:: start" + masterScreenDTO);

		ServiceResponse serviceResponse = null;

		if (masterScreenDTO.getPartNumber() != null) {
			List<String> partList = Arrays.asList(masterScreenDTO.getPartNumber().split(","));
			masterScreenDTO.setPartList(partList);
		}
		if (masterScreenDTO.getLocation() != null) {
			List<String> locationList = Arrays.asList(masterScreenDTO.getLocation().split(","));
			masterScreenDTO.setLocationList(locationList);
		}

		int noOfRecords = masterScreenBean.getMasterListCount(masterScreenDTO);
		LOGGER.debug("noOfRecords in Service class : " + noOfRecords);

		if (noOfRecords > 0) {
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
					ServiceConstants.PICKINGLIST_FETCH_SUCCESS, noOfRecords);
		} else {
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
					ServiceConstants.NO_DATA_FOUND);
		}
		LOGGER.debug("Exiting getMasterDetailsCount:: end ");
		return serviceResponse;
	}

	@SuppressWarnings("unchecked")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/search")
	public ServiceResponse<MasterScreenDetailsDTO> getMasterDetailsCheckCount(MasterScreenDetailsDTO masterScreenDTO) {
		LOGGER.debug("Entering getMasterDetailsCheckCount:: start" + masterScreenDTO);
		ServiceResponse<MasterScreenDetailsDTO> serviceResponse = null;

		if (masterScreenDTO.getPartNumber() != null) {
			List<String> partList = Arrays.asList(masterScreenDTO.getPartNumber().split(","));
			masterScreenDTO.setPartList(partList);
		}
		if (masterScreenDTO.getLocation() != null) {
			List<String> locationList = Arrays.asList(masterScreenDTO.getLocation().split(","));
			masterScreenDTO.setLocationList(locationList);
		}

		List<MasterScreenDetailsDTO> pickinglistResultsDTOList = masterScreenBean
				.getMasterScreenDetails(masterScreenDTO);
		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
				ServiceConstants.PICKINGLIST_FETCH_SUCCESS, pickinglistResultsDTOList);

		LOGGER.debug("Exiting getMasterDetailsCheckCount:: end ");
		return serviceResponse;
	}

	@SuppressWarnings("unchecked")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/download")
	public ServiceResponse<MasterScreenDetailsDTO> getMasterDetailsDownload(MasterScreenDetailsDTO masterScreenDTO) {
		LOGGER.debug("Entering getMasterDetailsDownload:: start" + masterScreenDTO);
		ServiceResponse<MasterScreenDetailsDTO> serviceResponse = null;

		if (masterScreenDTO.getPartNumber() != null) {
			List<String> partList = Arrays.asList(masterScreenDTO.getPartNumber().split(","));
			masterScreenDTO.setPartList(partList);
		}
		if (masterScreenDTO.getLocation() != null) {
			List<String> locationList = Arrays.asList(masterScreenDTO.getLocation().split(","));
			masterScreenDTO.setLocationList(locationList);
		}
		masterScreenDTO.setIsFullDownload(1);
		List<MasterScreenDetailsDTO> pickinglistResultsDTOList = masterScreenBean
				.getMasterScreenDetails(masterScreenDTO);
//		if (!pickinglistResultsDTOList.isEmpty() || pickinglistResultsDTOList.size() > 0) {
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
					ServiceConstants.PICKINGLIST_FETCH_SUCCESS, pickinglistResultsDTOList);
//		} else {
//			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
//					ServiceConstants.NO_DATA_FOUND);
//		}

		LOGGER.debug("Exiting getMasterDetailsDownload:: end ");
		return serviceResponse;
	}

}