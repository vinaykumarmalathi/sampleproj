package com.rnaipl.wms.service;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.ejb.EJBException;
import javax.ejb.Stateless;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.Location;
import com.rnaipl.wms.dto.LocationDTO;
import com.rnaipl.wms.dto.PartDTO;
import com.rnaipl.wms.dto.PartLocationDTO;
import com.rnaipl.wms.dto.PartNumberDTO;
import com.rnaipl.wms.dto.PartSearchDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

@Path("/manageLocation")
@RequestScoped
public class ManageLocationService {

	private static final Logger LOGGER = Logger
			.getLogger(ManageLocationService.class);

	@Inject
	Location locationBean;

	/**
	 * This service fetch all the location details based on input value
	 * 
	 * @param location 
	 * @return
	 */
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/locationSearch")
	public ServiceResponse getLocationSearchResults(PartLocationDTO locationDto) {
		LOGGER.debug("IN ManageLocationService getLocationSearchResults Entry");
		ServiceResponse serviceReponse = null;
		List<PartNumberDTO> locations = null;
		try {
			if(locationDto.getLocationId() != null) {
         		List<String> locationList = Arrays.asList(locationDto.getLocationId().split(","));
         		locationDto.setLocationList(locationList);
         	}
			
			locations = locationBean.getLocationSearchData(locationDto);
			if (!locations.isEmpty() && locations.size() > 0) {
				serviceReponse = ServiceResponseHandler.prepareMessage(
						ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.LOCATION_FETCH_SUCCESS, locations);
			} else {
				serviceReponse = ServiceResponseHandler.prepareMessage(
						ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.LOCATION_EMPTY);
			}
		} catch (EJBException ejbe) {
			LOGGER.error(
					"ManageLocationService -- > getLocationSearchResults()  Exception : ",
					ejbe);
			serviceReponse = ServiceResponseHandler.prepareMessage(
					ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE,
					ejbe);
		} catch (Exception ejbe) {
			LOGGER.error(
					"ManageLocationService -- > getLocationSearchResults()  Exception : ",
					ejbe);
			serviceReponse = ServiceResponseHandler.prepareMessage(
					ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE,
					ejbe);
		}
		LOGGER.debug("IN ManageLocationService getLocationSearchResults Exit");
		return serviceReponse;
	}
	
	
	/**
     * This method is used to fetch the all Location count 
     * 
     * @return count
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/locationCount")
    public ServiceResponse getLocationCount(PartLocationDTO locationDto) {
    	LOGGER.debug("IN LocationService getLocationCount Entry");
    	ServiceResponse serviceResponse = null; 
        int locationCount = 0;
		try { 
			if(locationDto.getLocationId() != null) {
         		List<String> locationList = Arrays.asList(locationDto.getLocationId().split(","));
         		locationDto.setLocationList(locationList);
         	}
			locationCount = locationBean.getLocationCount(locationDto);
			if (locationCount > 0) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.LOCATION_FETCH_SUCCESS,
						locationCount);
			} else {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			}
        } catch (Exception e) {
        	LOGGER.error("LocationService getLocationCount  Exception : " , e);
        	serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
        LOGGER.debug("IN LocationService getLocationCount EXIT");
        return serviceResponse;
    }
	
	/**
     * This method is used to insert the location
     * 
     * @return "success" / "failure"
     */
   	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/insertLocation")
	public ServiceResponse insertLocation(LocationDTO location) {
		LOGGER.debug("IN ManageLocationService insertLocation Entry");
		
		ServiceResponse serviceReponse = null;
		String result = null;
		String locationID = location.getLocationId();
		try {
		LOGGER.debug("**The entered location is " + locationID);
		location.setPlant(locationID.substring(0,1));
		location.setShop(locationID.substring(1,2));
		location.setLine(locationID.substring(2,3));
		location.setSection(locationID.substring(3,4));
		location.setZone(locationID.substring(4,5));
		location.setSeries(locationID.substring(5,6));
		location.setLocationSeries1(locationID.substring(6,7));
		location.setLocationSeries2(locationID.substring(7,8));
		if(locationID.length()==10){
			location.setLocationLevel(locationID.substring(8,9));
			location.setCellId(locationID.substring(9,10));
		}
		location.setLocationType(locationID.substring(3,4));
		LOGGER.debug("**The entered location type " + location.getLocationType());
		
	
			result = locationBean.insertLocation(location);
			if (result != null && result.equals("data found")) {
				serviceReponse = ServiceResponseHandler.prepareMessage(
						ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.LOCATION_ALREADY_FOUND);
			} else if (result.equals("success")) {
				serviceReponse = ServiceResponseHandler.prepareMessage(
						ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.LOCATION_INSERT_SUCCESS);
			}
		} catch (Exception e) {
			LOGGER.error(
					"ManageLocationService -- > insertLocation()  Exception : ",
					e);
			serviceReponse = ServiceResponseHandler.prepareMessage(
					ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
		}
		LOGGER.debug("IN ManageLocationService insertLocation Exit");
		return serviceReponse;
	}

   	/**
   	 * This method used for update the location 
   	 * 
   	 * @param location
   	 * @return - "success" / "failure"
   	 */
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/updateLocation")
	public ServiceResponse updateLocation(LocationDTO location) {
		LOGGER.debug("IN ManageLocationService updateLocation Entry");
		ServiceResponse serviceReponse = null;
		String result = null;
		try {
			result = locationBean.updateLocation(location);
			if (result != null && result.equals("No Data Found")) {
				serviceReponse = ServiceResponseHandler.prepareMessage(
						ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.NO_DATA_FOUND);
			} else if (result.equals("success")) {
				serviceReponse = ServiceResponseHandler.prepareMessage(
						ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.LOCATION_UPDATE_SUCCESS);
			}
		} catch (EJBException ejbe) {
			LOGGER.error(
					"ManageLocationService -- > updateLocation()  Exception : ",
					ejbe);
			serviceReponse = ServiceResponseHandler.prepareMessage(
					ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, ejbe);
		}
		catch (Exception ejbe) {
			LOGGER.error(
					"ManageLocationService -- > updateLocation()  Exception : ",
					ejbe);
			serviceReponse = ServiceResponseHandler.prepareMessage(
					ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, ejbe);
		}
		LOGGER.debug("IN ManageLocationService updateLocation Exit");
		return serviceReponse;
	}

	
	/**
	 * This method used to retrive the location details based on input location Id
	 * @param locationDto
	 * @return - LocationDTO
	 */
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/manageLocationByLocationId")
	public ServiceResponse getLocationByLocationId(LocationDTO locationDto) {
		LOGGER.debug("IN ManageLocationService getLocationByLocationId Entry");
		ServiceResponse serviceReponse = null;
		LocationDTO location = null;
		try {
			location = locationBean.getLocationByLocationId(locationDto
					.getLocationId());
			LOGGER.debug("Fetching all the Location details");
			if (location != null) {
				serviceReponse = ServiceResponseHandler.prepareMessage(
						ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.LOCATION_FETCH_SUCCESS, location);
			} else {
				serviceReponse = ServiceResponseHandler.prepareMessage(
						ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.LOCATION_EMPTY);
			}
		} catch (Exception e) {
			LOGGER.error(
					"ManageLocationService -- > getLocationByLocationId()  Exception : ",
					e);
			serviceReponse = ServiceResponseHandler.prepareMessage(
					ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
		}
		LOGGER.debug("IN ManageLocationService getLocationByLocationId Entry");
		return serviceReponse;
	}
	
	/**
	 * This method used for delete the location.
	 * @param locationDto
	 * @return - "success" or "failure"
	 */
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/deleteLocation")
	public ServiceResponse deleteLocation(LocationDTO locationDto) {
		LOGGER.debug("IN LocationService deleteLocation Entry");
		ServiceResponse serviceReponse = null;
		String result = null;
		try {
			result = locationBean.deleteLocation(locationDto);
			if (result != null && result.equals("1")) {
				serviceReponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.NO_DATA_FOUND);
			} else if (result.equals("0")) {
				serviceReponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.LOCATION_DELETED);
			} else if (result.equals("2")) {
				serviceReponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.PART_FOUND);
			}
		} catch (EJBException ejbe) {
			LOGGER.error("LocationService -- > deleteLocation()  Exception : ", ejbe);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, ejbe);
		} catch (Exception ejbe) {
			LOGGER.error("LocationService -- > deleteLocation()  Exception : ", ejbe);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, ejbe);
		}
		LOGGER.debug("IN LocationService deleteLocation Exit");
		return serviceReponse;
	}
}
