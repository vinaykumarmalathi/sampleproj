package com.rnaipl.wms.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ejb.EJBException;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.PartLocation;
import com.rnaipl.wms.bean.stockcorrection.StockCorrection;
import com.rnaipl.wms.dto.LocationSearchDTO;
import com.rnaipl.wms.dto.PartLocationDTO;
import com.rnaipl.wms.dto.PartLocationTrackerReportDTO;
import com.rnaipl.wms.dto.PartLocationTypeQtyDTO;
import com.rnaipl.wms.dto.StockCorrectionDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

/**
 * This Restful service class to process the requests from html and call the
 * respective EJB methods of Parts
 * 
 * 
 * @CreatedBy TechM
 * @CreatedOn 08-Apr-2016 10:25:44 am
 */
@Path("/partslocation")
@RequestScoped
public class PartLocationTrackerService {

    private static final Logger LOGGER = Logger.getLogger(PartLocationTrackerService.class);

    @Inject
    PartLocation partLocation;
    
      
    
    @SuppressWarnings("null")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/locationreport")
    public ServiceResponse getLocationReport(PartLocationDTO partLocationDTO) {
    	//LOGGER.debug("**jobJson ---------> "+jobJson);
        ServiceResponse serviceReponse = null;
        List<PartLocationTrackerReportDTO> partLocationTrackerList = new ArrayList<PartLocationTrackerReportDTO>();
        List<PartLocationTrackerReportDTO> partLocationTrackerList1 = new ArrayList<PartLocationTrackerReportDTO>();
        PartLocationDTO partLoc = new PartLocationDTO();
        try {
        	if(partLocationDTO.getPartNo() != null) {
        		List<String> partList = Arrays.asList(partLocationDTO.getPartNo().split(","));
        		partLocationDTO.setPartList(partList);
        	}
        	if(partLocationDTO.getLocationId() != null) {
        		List<String> locationList = Arrays.asList(partLocationDTO.getLocationId().split(","));
        		partLocationDTO.setLocationList(locationList);
        	}
        	if(partLocationDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(partLocationDTO.getRan().split(","));
        		partLocationDTO.setRanList(ranList);
        	}
        	
        	LOGGER.debug("** Part Number" + partLocationDTO.getPartNo());
        	LOGGER.debug("** Plant" + partLocationDTO.getPlant());
            List<PartLocationDTO> partLocationDTOList = partLocation.getPartLocations(partLocationDTO);
           
         
           // LOGGER.debug("########### Before Calling the Part Location Bean " + partLocationDTOList.size());
            PartLocationTrackerReportDTO partLocationTrackerReportDTO;
            
            HashMap<String, PartLocationTrackerReportDTO> partLocationTrackerReportDTOMap = new HashMap<String, PartLocationTrackerReportDTO>();

            for (PartLocationDTO partLocation : partLocationDTOList) {
                // System.out.println("Part Location and Location"+partLocation.getPartNo()+"--"+partLocation.getLocationId());
                // LOGGER.debug("Part Location and Location"+partLocation.getPartNo()+"--"+partLocation.getLocationId());
            	LOGGER.debug("**InComing Part No Details"+partLocation.getPartNo());
                PartLocationTrackerReportDTO partLocationReportDTO = partLocationTrackerReportDTOMap.get(partLocation.getPartNo());
                
                
                PartLocationTypeQtyDTO partLocationTypeQtyDTO = new PartLocationTypeQtyDTO();
                if (partLocationReportDTO != null) {
                	LOGGER.debug("**Part Already exist in map"+partLocation.getPartNo());
                	 LOGGER.debug("**partLocation.getLocationType() : "+partLocation.getLocationType());
                    if (partLocation.getLocationType() != null && (partLocation.getLocationType().equalsIgnoreCase("W") || partLocation.getLocationType().equalsIgnoreCase("U")) ) {
                    	LOGGER.debug("**LocationType 1 : "+partLocation.getLocationType());
                        partLocationReportDTO.setWareHouseQty(partLocationReportDTO.getWareHouseQty() + partLocation.getCurrentQty());
                        partLocationTypeQtyDTO.setChildRecord(true);
                        partLocationTypeQtyDTO.setWareHouseQty(partLocation.getLocationId() + " - " + partLocation.getCurrentQty());
                    }
                    else if (partLocation.getLocationType() != null && partLocation.getLocationType().equalsIgnoreCase("S")) {
                    	LOGGER.debug("**LocationType 1 : "+partLocation.getLocationType());
                        partLocationReportDTO.setWareHouseQty(partLocationReportDTO.getWareHouseQty() + partLocation.getCurrentQty());
                        partLocationTypeQtyDTO.setChildRecord(true);
                        partLocationTypeQtyDTO.setWareHouseQty(partLocation.getLocationId() + " - " + partLocation.getCurrentQty());
                    }
                    else if (partLocation.getLocationType() != null && partLocation.getLocationType().equalsIgnoreCase("P")) {
                    	LOGGER.debug("**LocationType 1 : "+partLocation.getLocationType());
                        partLocationReportDTO.setWareHouseQty(partLocationReportDTO.getWareHouseQty() + partLocation.getCurrentQty());
                        partLocationTypeQtyDTO.setChildRecord(true);
                        partLocationTypeQtyDTO.setWareHouseQty(partLocation.getLocationId() + " - " + partLocation.getCurrentQty());
                    }
                    else if (partLocation.getLocationType() != null && partLocation.getLocationType().equalsIgnoreCase("F")) {
                    	LOGGER.debug("**LocationType 2 : "+partLocation.getLocationType());
                        partLocationReportDTO.setOverflowQty(partLocationReportDTO.getOverflowQty() + partLocation.getCurrentQty());
                        partLocationTypeQtyDTO.setChildRecord(true);
                        partLocationTypeQtyDTO.setOverflowQty(partLocation.getLocationId() + " - " + partLocation.getCurrentQty());
                    }
                    else if (partLocation.getLocationType() != null && 
                    		!partLocation.getLocationType().equalsIgnoreCase("F") && 
                    		!partLocation.getLocationType().equalsIgnoreCase("S") && 
                    		!partLocation.getLocationType().equalsIgnoreCase("W") && 
                    		!partLocation.getLocationType().equalsIgnoreCase("U") && 
                    		!partLocation.getLocationType().equalsIgnoreCase("LS") &&
                    		!partLocation.getLocationType().equalsIgnoreCase("P"))
                    {
                    	//added by arun for T&C CR
                    	LOGGER.debug("**LocationType 3 : "+partLocation.getLocationType());
                        partLocationReportDTO.setOtherQty(partLocationReportDTO.getOtherQty() + partLocation.getCurrentQty());
                        partLocationTypeQtyDTO.setChildRecord(true);
                        partLocationTypeQtyDTO.setOtherQty(partLocation.getLocationId() + " - " + partLocation.getCurrentQty());
                        //
                    }
                    if (partLocation.getLocationType() != null && partLocation.getLocationType().equals("LS")) {
                    	LOGGER.debug("**LocationType 4 : "+partLocation.getLocationType());
                        partLocationReportDTO.setLineQty(partLocationReportDTO.getLineQty() + partLocation.getCurrentQty());
                        partLocationTypeQtyDTO.setChildRecord(true);
                        partLocationTypeQtyDTO.setLineQty(partLocation.getLocationId() + " - " + partLocation.getCurrentQty());
                    }
                    //added by arun for T&C CR
                    int totalQty = partLocationReportDTO.getWareHouseQty()+partLocationReportDTO.getOverflowQty()+partLocationReportDTO.getLineQty()+partLocationReportDTO.getOtherQty();
                    //int totalQty = partLocationReportDTO.getWareHouseQty()+partLocationReportDTO.getOverflowQty()+partLocationReportDTO.getLineQty();
                    //
                    partLocationReportDTO.setTotalQty(totalQty);
                    partLocationReportDTO.getPartLocationTypeQty().add(partLocationTypeQtyDTO);
                    partLocationTrackerReportDTOMap.put(partLocation.getPartNo(), partLocationReportDTO);

                } else {
                	LOGGER.debug("**Part Doesnt exist in map :"+partLocation.getPartNo());
                    partLocationReportDTO = new PartLocationTrackerReportDTO();
                    partLocationReportDTO.setPartNo(partLocation.getPartNo());
                    LOGGER.debug("**partLocation.getLocationType() : "+partLocation.getLocationType());
                    
                    if (partLocation.getLocationType() != null && (partLocation.getLocationType().equalsIgnoreCase("W") ||partLocation.getLocationType().equalsIgnoreCase("U") )) {
                    	LOGGER.debug("**LocationType 1 : "+partLocation.getLocationType());
                        partLocationReportDTO.setWareHouseQty(partLocation.getCurrentQty());
                        partLocationTypeQtyDTO.setChildRecord(true);
                        partLocationTypeQtyDTO.setWareHouseQty(partLocation.getLocationId() + " - " + partLocation.getCurrentQty());
                        partLocationReportDTO.getPartLocationTypeQty().add(partLocationTypeQtyDTO);
                    }
                    else if (partLocation.getLocationType() != null && partLocation.getLocationType().equalsIgnoreCase("S")) {
                    	LOGGER.debug("**LocationType 1 : "+partLocation.getLocationType());
                        partLocationReportDTO.setWareHouseQty(partLocation.getCurrentQty());
                        partLocationTypeQtyDTO.setChildRecord(true);
                        partLocationTypeQtyDTO.setWareHouseQty(partLocation.getLocationId() + " - " + partLocation.getCurrentQty());
                        partLocationReportDTO.getPartLocationTypeQty().add(partLocationTypeQtyDTO);
                    }
                    else if (partLocation.getLocationType() != null && partLocation.getLocationType().equalsIgnoreCase("P")) {
                    	LOGGER.debug("**LocationType 1 : "+partLocation.getLocationType());
                        partLocationReportDTO.setWareHouseQty(partLocation.getCurrentQty());
                        partLocationTypeQtyDTO.setChildRecord(true);
                        partLocationTypeQtyDTO.setWareHouseQty(partLocation.getLocationId() + " - " + partLocation.getCurrentQty());
                        partLocationReportDTO.getPartLocationTypeQty().add(partLocationTypeQtyDTO);
                    }
                    else if (partLocation.getLocationType() != null && partLocation.getLocationType().equalsIgnoreCase("F")) {
                    	LOGGER.debug("**LocationType 2 : "+partLocation.getLocationType());
                        partLocationReportDTO.setOverflowQty(partLocation.getCurrentQty());
                        LOGGER.debug("**OverflowQty : "+partLocationReportDTO.getOverflowQty());
                        partLocationTypeQtyDTO.setChildRecord(true);
                        partLocationTypeQtyDTO.setOverflowQty(partLocation.getLocationId() + " - " + partLocation.getCurrentQty());
                        partLocationReportDTO.getPartLocationTypeQty().add(partLocationTypeQtyDTO);
                    }
                    else if (partLocation.getLocationType() != null && 
                    		!partLocation.getLocationType().equalsIgnoreCase("F") && 
                    		!partLocation.getLocationType().equalsIgnoreCase("S") && 
                    		!partLocation.getLocationType().equalsIgnoreCase("W") && 
                    		!partLocation.getLocationType().equalsIgnoreCase("U") && 
                    		!partLocation.getLocationType().equalsIgnoreCase("LS") &&
                    		!partLocation.getLocationType().equalsIgnoreCase("P"))
                    {
                    	LOGGER.debug("**LocationType 3 : "+partLocation.getLocationType());
                        partLocationReportDTO.setOtherQty(partLocation.getCurrentQty());
                        LOGGER.debug("**Other Quantity : "+partLocationReportDTO.getOtherQty());
                        partLocationTypeQtyDTO.setChildRecord(true);
                        partLocationTypeQtyDTO.setOtherQty(partLocation.getLocationId() + " - " + partLocation.getCurrentQty());
                        LOGGER.debug("**Other Quantity Location Id : "+partLocationTypeQtyDTO.getOtherQty());
                        partLocationReportDTO.getPartLocationTypeQty().add(partLocationTypeQtyDTO);
                    }
                    if (partLocation.getLocationType() != null && partLocation.getLocationType().equals("LS")) {
                    	LOGGER.debug("**LocationType 4 : "+partLocation.getLocationType());
                        partLocationReportDTO.setLineQty(partLocation.getCurrentQty());
                        LOGGER.debug("**LineQty : "+partLocationReportDTO.getLineQty());
                        partLocationTypeQtyDTO.setChildRecord(true);
                        partLocationTypeQtyDTO.setLineQty(partLocation.getLocationId() + " - " + partLocation.getCurrentQty());
                        partLocationReportDTO.getPartLocationTypeQty().add(partLocationTypeQtyDTO);
                    }
                    //Added by arun for T&C CR
                    int totalQty = partLocationReportDTO.getWareHouseQty()+partLocationReportDTO.getOverflowQty()+partLocationReportDTO.getLineQty()+partLocationReportDTO.getOtherQty();
                    //int totalQty = partLocationReportDTO.getWareHouseQty()+partLocationReportDTO.getOverflowQty()+partLocationReportDTO.getLineQty();
                    //
                    partLocationReportDTO.setTotalQty(totalQty);
                    LOGGER.debug("**TotalQty : "+partLocationReportDTO.getTotalQty());
                    partLocationTrackerReportDTOMap.put(partLocation.getPartNo(), partLocationReportDTO);

                }

            }
            Iterator it = partLocationTrackerReportDTOMap.entrySet().iterator();
            int i=0;
            while (it.hasNext()) {
                Map.Entry pair = (Map.Entry) it.next();
                i++;
                partLocationTrackerList.add((PartLocationTrackerReportDTO) pair.getValue());
                it.remove(); // avoids a ConcurrentModificationException
            }
            LOGGER.debug("**Map Count***"+i);
            if(!partLocationTrackerList.isEmpty() && partLocationTrackerList.size() > 0) {
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PARTS_FETCH_SUCCESS, partLocationTrackerList);
            } else {
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND, partLocationTrackerList);
            }

        } catch (Exception ejbe) {
        	LOGGER.error("PartLocationTrackerService -- > getLocationReport() Exception : ",ejbe);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
        }
        return serviceReponse;
    }

    
	@SuppressWarnings("null")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/locationreportCount")
	public ServiceResponse getPartLocationCount(PartLocationDTO partLocationDTO) {
		ServiceResponse serviceReponse = null;
		PartLocationDTO partLoc = new PartLocationDTO();
		int count=0;
		try {
			if(partLocationDTO.getPartNo() != null) {
        		List<String> partList = Arrays.asList(partLocationDTO.getPartNo().split(","));
        		partLocationDTO.setPartList(partList);
        	}
        	if(partLocationDTO.getLocationId() != null) {
        		List<String> locationList = Arrays.asList(partLocationDTO.getLocationId().split(","));
        		partLocationDTO.setLocationList(locationList);
        	}
        	if(partLocationDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(partLocationDTO.getRan().split(","));
        		partLocationDTO.setRanList(ranList);
        	}
			 count = partLocation.getPartLocationCount(partLocationDTO);
			 
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PARTS_FETCH_SUCCESS, count);

		} catch (Exception e) {
			LOGGER.error("Location Report Count Exception : ",e);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
		}
		return serviceReponse;
	}
	
	@SuppressWarnings("null")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/downloadPartLocation")
	public ServiceResponse downloadPartLocation(PartLocationDTO partLocationDTO) {
		ServiceResponse serviceReponse = null;
		try {
			if (partLocationDTO.getPartNo() != null) {
				List<String> partList = Arrays.asList(partLocationDTO.getPartNo().split(","));
				partLocationDTO.setPartList(partList);
			}
			if(partLocationDTO.getLocationId() != null) {
        		List<String> locationList = Arrays.asList(partLocationDTO.getLocationId().split(","));
        		partLocationDTO.setLocationList(locationList);
        	}
			if(partLocationDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(partLocationDTO.getRan().split(","));
        		partLocationDTO.setRanList(ranList);
        	}
			List<PartLocationDTO> partLocationDTOList = partLocation.downloadPartLocations(partLocationDTO);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PARTS_FETCH_SUCCESS, partLocationDTOList);

		} catch (Exception e) {
			LOGGER.error("Download Part Location Exception : ",e);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
		}
		return serviceReponse;
	}
	
    
    
    
    
       
}
