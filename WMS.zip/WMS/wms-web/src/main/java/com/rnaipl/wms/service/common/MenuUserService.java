package com.rnaipl.wms.service.common;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.common.MenuUser;
import com.rnaipl.wms.dto.MenuDTO;
import com.rnaipl.wms.dto.common.MenuUserDTO;
import com.rnaipl.wms.service.UserMenuService;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

@Path("/userMenu")
@RequestScoped
public class MenuUserService {

private static final Logger LOGGER = Logger.getLogger(UserMenuService.class);
	
	@Inject
	MenuUser userBean;
	
	/**
     * This method is used to fetch the all plant details from the table
     * 
     * @return List of Part
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getUserMenus")
    public ServiceResponse getUserMenus(String userId) {
		ServiceResponse serviceResponse = null;
		LOGGER.debug("**IN Class->getUserMenus() entry");
		try{
			LinkedHashMap<Integer, MenuDTO> menuMap = userBean.getMenuForUser(userId);
			LinkedList<MenuDTO> menuList = userBean.getMenuTreeAsList(menuMap);
			 if(menuList!=null && menuList.size()>0){
	         	serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, menuList);
	         }
	         else{
	         	serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND, menuList);
	         }
		}
		catch(Exception e){
    		LOGGER.error("MenuUserService---->getUserMenus()", e);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
    	}
		LOGGER.debug("**IN Class->getUserMenus() Exit");
		return serviceResponse;
    }
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/mapUserMenu")
    public ServiceResponse mapUserMenu(MenuUserDTO userMenuDTO){
    	ServiceResponse serviceResponse = null;
    	LOGGER.debug("**IN Class->mapUserMenu() entry");
    	try{
			if(userMenuDTO.getUserMenu()!=null){
				List<String> menuList = Arrays.asList(userMenuDTO.getUserMenu().split(","));
				userMenuDTO.setMenuList(menuList);
			}
	    	userBean.addUserMenu(userMenuDTO);
    	}
    	catch(Exception e){
    		LOGGER.error("MenuUserService---->mapUserMenu()", e);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
    	}
    	LOGGER.debug("**IN Class->mapUserMenu() Exit");
		return serviceResponse;	
    }
  
}
