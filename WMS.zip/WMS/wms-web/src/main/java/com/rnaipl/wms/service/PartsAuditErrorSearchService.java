package com.rnaipl.wms.service;

import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.PartsAuditErrorSearch;
import com.rnaipl.wms.bean.PartsInOutAuditSearch;
import com.rnaipl.wms.bean.PartsInOutStaging;
import com.rnaipl.wms.dto.PartsInOutAuditErrorDTO;
import com.rnaipl.wms.dto.PartsInOutAuditSearchDTO;
import com.rnaipl.wms.dto.PartsInOutStagingDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

@Path("/errorSearch")
public class PartsAuditErrorSearchService {

	private static final Logger LOGGER = Logger.getLogger(PartsAuditErrorSearchService.class);
	
	 @Inject
	 PartsAuditErrorSearch partsAuditError;
	 
	 
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/partsInOutAuditErrorSearch")
    @SuppressWarnings("null")
	public ServiceResponse getPartsAuditErrorDetails(PartsInOutAuditErrorDTO partsInOutAuditErrorDTO){
		
		ServiceResponse serviceResponse = null;
		LOGGER.debug("**IN Class->getPartsAuditErrorDetails entry");
		try {
			LOGGER.debug("IN getPartsAuditSearch ENTRY");
			if(partsInOutAuditErrorDTO.getPartNumber() != null) {
        		List<String> partList = Arrays.asList(partsInOutAuditErrorDTO.getPartNumber().split(","));
        		partsInOutAuditErrorDTO.setPartList(partList);
        	}
        	if(partsInOutAuditErrorDTO.getLocation() != null) {
        		List<String> locationList = Arrays.asList(partsInOutAuditErrorDTO.getLocation().split(","));
        		partsInOutAuditErrorDTO.setLocationList(locationList);
        	}
        	LOGGER.debug("**Input Error RAN " + partsInOutAuditErrorDTO.getRan() );
        	if(partsInOutAuditErrorDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(partsInOutAuditErrorDTO.getRan().split(","));
        		partsInOutAuditErrorDTO.setRanList(ranList);
        	}
			List<PartsInOutAuditErrorDTO> PartsInOutAuditSearchDTOs = partsAuditError.getPartsAuditErrorSearch(partsInOutAuditErrorDTO);
			if (!PartsInOutAuditSearchDTOs.isEmpty()
					|| PartsInOutAuditSearchDTOs.size() > 0) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.PARTS_FETCH_SUCCESS,
						PartsInOutAuditSearchDTOs);
			} else {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			}
			LOGGER.debug("IN getPartsAuditErrorDetails EXIT");

		} catch (Exception ex) {
			LOGGER.error("PartsInOutStagingService -- > getPartsAuditErrorDetails()  Exception : " , ex);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.PARTS_FETCH_ERROR, ex);
		}
		LOGGER.debug("**IN Class->getPartsAuditErrorDetails Exit");
		return serviceResponse;
	}	
		
		
		@POST
	    @Produces(MediaType.APPLICATION_JSON)
	    @Path("/partsInOutAuditErrorCount")
	    @SuppressWarnings("null")
		public ServiceResponse getPartsAuditErrorCount(PartsInOutAuditErrorDTO partsInOutAuditErrorDto){
			
			ServiceResponse serviceResponse = null;
			LOGGER.debug("**IN Class->getPartsAuditErrorCount() entry");
			try {
				LOGGER.debug("IN getPartsAuditCount ENTRY");
				if(partsInOutAuditErrorDto.getPartNumber() != null) {
	        		List<String> partList = Arrays.asList(partsInOutAuditErrorDto.getPartNumber().split(","));
	        		partsInOutAuditErrorDto.setPartList(partList);
	        	}
	        	if(partsInOutAuditErrorDto.getLocation() != null) {
	        		List<String> locationList = Arrays.asList(partsInOutAuditErrorDto.getLocation().split(","));
	        		partsInOutAuditErrorDto.setLocationList(locationList);
	        	}
	        	if(partsInOutAuditErrorDto.getRan() != null) {
	        		List<String> ranList = Arrays.asList(partsInOutAuditErrorDto.getRan().split(","));
	        		partsInOutAuditErrorDto.setRanList(ranList);
	        	}
				int noOfRecords = partsAuditError.getPartInOutAuditErrorSearchCount(partsInOutAuditErrorDto);
				if (noOfRecords > 0) {
					serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
							ServiceConstants.PARTS_FETCH_SUCCESS,
							noOfRecords);
				} else {
					serviceResponse = ServiceResponseHandler
							.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
				}
				LOGGER.debug("IN getPartsAuditErrorCount EXIT");

			} catch (Exception ex) {
				LOGGER.error("PartsInOutStagingService -- > getPartsAuditErrorCount()  Exception : " , ex);
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
						ServiceConstants.PARTS_FETCH_ERROR, ex);
			}
			LOGGER.debug("**IN Class->getPartsAuditErrorCount() Exit");
			return serviceResponse;
			
		}
}
