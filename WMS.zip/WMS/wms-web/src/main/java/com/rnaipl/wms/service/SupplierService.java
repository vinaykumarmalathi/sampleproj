package com.rnaipl.wms.service;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.Supplier;
import com.rnaipl.wms.dto.SupplierDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

/**
 * This Restful service class to process the requests from html and call the
 * respective EJB methods of Parts
 * 
 * 
 * @CreatedBy TechM
 * @CreatedOn 08-Apr-2016 10:25:44 am
 */
@Path("/supplier")
@RequestScoped
public class SupplierService {

	private static final Logger LOGGER = Logger.getLogger(SupplierService.class);

	@Inject
	Supplier supplierBean;

	/**
	 * This method is used to fetch the all plant details from the table
	 * 
	 * @return List of Part
	 */
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/allsuppliers")
	public ServiceResponse getSuppliersList() {

		ServiceResponse serviceReponse = null;
		List<SupplierDTO> suppliers = null;
		try {
			suppliers = supplierBean.getSuppliersList();
			if (suppliers != null && suppliers.size() > 0) {
				serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.BLANK_STATUS_MESSAGE, suppliers);
			} else {
				serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.SHOP_FETCH_SUCCESS, suppliers);
			}
		} catch (Exception e) {
			LOGGER.error("LineService -- > getAllShops() Exception : ", e);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
		}
		return serviceReponse;
	}

}
