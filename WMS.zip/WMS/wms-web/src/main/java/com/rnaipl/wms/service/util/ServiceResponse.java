package com.rnaipl.wms.service.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class is for creating service message and will send to presentation
 * layer
 * 
 * @param <E>
 * @CreatedBy TechM
 * @CreatedOn 19-Apr-2016 10:49:31 am
 */
public class ServiceResponse<E> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ServiceResponse.class);

    /**
     * Member variable statusCode for message code
     */
    private final String statusType;
    /**
     * Member variable statusCode for message code
     */
    private final String statusCode;
    
    private final String statusMessage;
    
    
    private List<E> objectList;

    /**
     * Member variable object
     */
    private E object;
    
  
       
    
    

    /**
     * @param statusCode
     * @param statusType
     * @param statusMessage
     * @param exception
     * @param exceptionClassName
     * @param exceptionMessage
     */
    public ServiceResponse(String statusType, String statusCode, String statusMessage ) {
    	this.statusType=statusType;
        this.statusCode = statusCode;       
        this.statusMessage = statusMessage;
    }
       

    public ServiceResponse(String statusType, String statusCode, String statusMessage, E object) {
    	this.statusType=statusType;
        this.statusCode = statusCode;       
        this.statusMessage = statusMessage;
        this.object = object;
    }

    /**
     * @param statusCode
     * @param statusType
     * @param statusMessage
     * @param objectList
     */
    public ServiceResponse(String statusType, String statusCode, String statusMessage, List<E> objectList) {
    	this.statusType=statusType;
        this.statusCode = statusCode;       
        this.statusMessage = statusMessage;
        this.objectList = objectList;
    }

    /**
     * @return the statusCode String
     */
    public String getStatusCode() {
        return statusCode;
    }

    /**
     * @return the statusType String
     */
  
    /**
     * @return the statusMessage String
     */
    public String getStatusMessage() {
        return statusMessage;
    }

    /**
     * @return the exceptionStackTrace
     */
    
    /**
     * @return the objectList
     */
    public List<E> getObjectList() {
        return objectList;
    }

    /**
     * @return the object
     */
    public E getObject() {
        return object;
    }

    



	public String getStatusType() {
		return statusType;
	}


	public void setObjectList(List<E> objectList) {
		this.objectList = objectList;
	}


	public void setObject(E object) {
		this.object = object;
	}


	/**
     * @param exception
     * @return String
     */
    @SuppressWarnings("all")
    private String toStackTraceString(Throwable exception) {
        Writer result = new StringWriter();
        PrintWriter printWriter = new PrintWriter(result);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exception To Stack Trace String : " + exception);
            LOGGER.debug(printWriter.toString());
        }
        exception.printStackTrace(printWriter);
        return result.toString();

    }

}
