package com.rnaipl.wms.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ejb.EJBException;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.ManageLocationByPart;
import com.rnaipl.wms.bean.PartLocation;
import com.rnaipl.wms.bean.PartsInOutStaging;
import com.rnaipl.wms.bean.stockcorrection.StockCorrection;
import com.rnaipl.wms.dto.LocationByPartDTO;
import com.rnaipl.wms.dto.LocationSearchDTO;
import com.rnaipl.wms.dto.PartLocationCorrectionDTO;
import com.rnaipl.wms.dto.PartLocationDTO;
import com.rnaipl.wms.dto.PartsInOutStagingByDeviceDTO;
import com.rnaipl.wms.dto.StockCorrectionDTO;
import com.rnaipl.wms.dto.StockCorrectionReasonDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

/**
 * This Restful service class to process the requests from html and call the
 * respective EJB methods of Parts
 * 
 * 
 * @CreatedBy TechM
 * @CreatedOn 08-Apr-2016 10:25:44 am
 */
@Path("/stockcorrection")
@RequestScoped
public class StockLocationCorrectionService {

    private static final Logger LOGGER = Logger.getLogger(StockLocationCorrectionService.class);
/*
    @Inject
    PartLocation partLocation;*/
    
    @Inject
    StockCorrection stockCorrection;

    @Inject
    ManageLocationByPart manageLocBean;
    
    @Inject
    PartsInOutStaging partsInOutStaging;
    
    /**
     * This method is used to fetch the all plant details from the table
     * 
     * @return List of Part
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/correction")
    public ServiceResponse updateStockLocation(List<PartLocationCorrectionDTO> partLocationCorrDTOs) {
        LOGGER.debug("getCorrectionDetails - Starts");
        ServiceResponse serviceReponse = null;
        try {
        	stockCorrection.updatePartLocation(partLocationCorrDTOs);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.STOCK_LOC_CORR_SUCCESS);
        } catch (Exception e) {
        	LOGGER.error("StockLocationCorrectionService -- > updateStockLocation  Exception : " , e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
        LOGGER.debug("getCorrectionDetails - Ends");
        return serviceReponse;
    }
    
    /**
     * This method is used to fetch the all plant details from the table
     * 
     * @return List of Part
     */
    @SuppressWarnings("null")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getStockCorrectionReport")
    public ServiceResponse getStockCorrectionReport(PartLocationDTO partLoc) {
    	LOGGER.debug("**getStockCorrectionReport -- START-------> ");
        ServiceResponse serviceReponse = null;
        //PartLocationDTO partLoc = new PartLocationDTO();
        try {
        	if(partLoc.getPartNo() != null) {
        		List<String> partList = Arrays.asList(partLoc.getPartNo().split(","));
        		partLoc.setPartList(partList);
        	}
        	if(partLoc.getRan() != null) {
        		List<String> ranList = Arrays.asList(partLoc.getRan().split(","));
        		partLoc.setRanList(ranList);
        	}
        
        	LOGGER.debug("** Part Number" + partLoc.getPartNo());
            //List<StockCorrectionDTO> stockCorrectionList = partLocation.getStockCorrectionParts(partLoc);
        	List<PartLocationDTO> partLocationDTOList = stockCorrection.getStockCorrectionPartLocations(partLoc);
        	List<StockCorrectionDTO> stockCorrectionList = new ArrayList<StockCorrectionDTO>();
        	Map<String,StockCorrectionDTO> partLocationMap = new HashMap<String, StockCorrectionDTO>();
            LOGGER.debug("**getStockCorrectionReport -- stockCorrectionList Size-------> "+partLocationDTOList.size());
            
            for(PartLocationDTO partsLocationInfo : partLocationDTOList) {
            	StockCorrectionDTO stockCorrectionDto = null;
            	LocationSearchDTO locationSearchDTO = new LocationSearchDTO();
            	List<LocationSearchDTO> locationSearchDTOList = new ArrayList<LocationSearchDTO>();
            	List<String> newLocations = new ArrayList<String>();
            	//partsLocationInfo.getPartNo()!=null && 
            	if(partLocationMap.get(partsLocationInfo.getPartNo()) == null) {
            		stockCorrectionDto = new StockCorrectionDTO();
            		stockCorrectionDto.setPartNo(partsLocationInfo.getPartNo());
            		
            		locationSearchDTO.setLocationId(partsLocationInfo.getLocationId());
            		locationSearchDTO.setRan(partsLocationInfo.getRan());
            		locationSearchDTO.setCurrentQty(partsLocationInfo.getCurrentQty());            		
            		locationSearchDTOList.add(locationSearchDTO);            		
            		
            		stockCorrectionDto.setLocations(locationSearchDTOList);
            		
            		newLocations.add(partsLocationInfo.getLocationId());
            		stockCorrectionDto.setNewLocations(newLocations);
            		partLocationMap.put(partsLocationInfo.getPartNo(), stockCorrectionDto);
            	} else {
            		stockCorrectionDto = partLocationMap.get(partsLocationInfo.getPartNo());
            		stockCorrectionDto.setPartNo(partsLocationInfo.getPartNo());
            		locationSearchDTO.setLocationId(partsLocationInfo.getLocationId());
            		locationSearchDTO.setRan(partsLocationInfo.getRan());
            		locationSearchDTO.setCurrentQty(partsLocationInfo.getCurrentQty()); 
            		
            		//If the location already does not exist in new location list the  list then add
            		if(!stockCorrectionDto.getNewLocations().contains(partsLocationInfo.getLocationId()))
            		{
            			stockCorrectionDto.getNewLocations().add(partsLocationInfo.getLocationId());
            		}
            		stockCorrectionDto.getLocations().add(locationSearchDTO);
            	}
        		
            }
            Iterator it = partLocationMap.entrySet().iterator();
            int i=0;
            while (it.hasNext()) {
                Map.Entry pair = (Map.Entry) it.next();
                i++;
                stockCorrectionList.add((StockCorrectionDTO) pair.getValue());
                it.remove(); // avoids a ConcurrentModificationException
            }
            LOGGER.debug("**Map Count***"+i);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PARTS_FETCH_SUCCESS, stockCorrectionList);
        } catch (Exception e) {
        	LOGGER.error("PartLocationTrackerService -- > getStockCorrectionReport() Exception : ",e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
        LOGGER.debug("**getStockCorrectionReport -- END-------> ");
        return serviceReponse;
    }
    
    @SuppressWarnings("null")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/stockCorrectionReportCount")
	public ServiceResponse getPartLocationCount(PartLocationDTO partLocationDTO) {
		ServiceResponse serviceReponse = null;
		PartLocationDTO partLoc = new PartLocationDTO();
		int count=0;
		try {
			if(partLocationDTO.getPartNo() != null) {
        		List<String> partList = Arrays.asList(partLocationDTO.getPartNo().split(","));
        		partLocationDTO.setPartList(partList);
        	}
        	if(partLocationDTO.getLocationId() != null) {
        		List<String> locationList = Arrays.asList(partLocationDTO.getLocationId().split(","));
        		partLocationDTO.setLocationList(locationList);
        	}
        	if(partLocationDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(partLocationDTO.getRan().split(","));
        		partLocationDTO.setRanList(ranList);
        	}
			 count = stockCorrection.getStockCorrectionPartLocationCount(partLocationDTO);
			 
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PARTS_FETCH_SUCCESS, count);

		} catch (Exception e) {
			LOGGER.error("Location Report Count Exception : ",e);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
		}
		return serviceReponse;
	}
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/addRAN")
    public ServiceResponse addRAN(LocationByPartDTO location) {
    	LOGGER.debug("IN add locations:"+location);
    	LOGGER.debug("IN add location:"+location.getPartNo());
    	int result = 0;
        ServiceResponse serviceResponse = null;
        try { 
        	System.out.println("adding location...");  
     
             	//result = manageLocBean.addLocation(location);
             	List<PartsInOutStagingByDeviceDTO> partsInoutList = convertLocationByPartDTO(location);
             	 result =partsInOutStaging.insertPartsInOutStaging(partsInoutList);
             //	 partsInOutStaging.executeStoreProcedure();
             	
     		
             	 
             	 if(result==1){
             		serviceResponse = ServiceResponseHandler
     						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.RAN_ADD_SUCCESS);
             	 }
             	 else
             	 {
             		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
         					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
             	 }
     		} catch (EJBException ejbe) {
     			LOGGER.error("ManageLocationByPartNoService -- > addLocation()  ejbe Exception : ", ejbe);
     			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
     					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, ejbe);
     		} catch (Exception e) {
     			LOGGER.error("ManageLocationByPartNoService -- > addLocation()  Exception : ", e);
     			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
     					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
     		}
     		LOGGER.debug("IN ManageLocationByPartNoService --add location Exit");
     		return serviceResponse;
    } 
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/moveAllRanToDifferentLoc")
    public ServiceResponse moveAllRanToDifferentLoc(PartLocationCorrectionDTO partLocationCorrectionDTO) {
    	ServiceResponse serviceResponse = null;
    	try{
    		stockCorrection.moveAllRanToDifferentLoc(partLocationCorrectionDTO);
    		serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.RAN_MOVED_TO_DIFFERENT_LOCATION);
    	}
    	catch(Exception e){
    		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
 					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
    	}
    	return serviceResponse;
    }
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getStockCorrectionReason")
    public ServiceResponse getStockCorrectionReason() {
    	ServiceResponse serviceResponse = null;
    	List stockCorrectionReasonList = new ArrayList<StockCorrectionReasonDTO>();
    	stockCorrectionReasonList = stockCorrection.getAllStockCorrectionReason();
    /*	StockCorrectionReasonDTO stockCorrectionDTO1 = new StockCorrectionReasonDTO();
    	StockCorrectionReasonDTO stockCorrectionDTO2 = new StockCorrectionReasonDTO();
    	stockCorrectionDTO1.setReasonId("1");
    	stockCorrectionDTO1.setReasonName("Stock Correction");
    	stockCorrectionDTO2.setReasonId("2");
    	stockCorrectionDTO2.setReasonName("Location Correction");
    	stockCorrectionDTO2.setReasonId("3");
    	stockCorrectionDTO2.setReasonName("Design Change");
    	
    	stockCorrectionReasonList.add(stockCorrectionDTO1);
    	stockCorrectionReasonList.add(stockCorrectionDTO2);*/
    	
    	try{
    	
    		serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.RAN_MOVED_TO_DIFFERENT_LOCATION,stockCorrectionReasonList);
    	}
    	catch(Exception e){
    		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
 					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
    	}
    	return serviceResponse;
    }
    
    private List<PartsInOutStagingByDeviceDTO> convertLocationByPartDTO(LocationByPartDTO locationByPartDTO)
    {
    	List<PartsInOutStagingByDeviceDTO> partsInoutList = new ArrayList<PartsInOutStagingByDeviceDTO>();
    	PartsInOutStagingByDeviceDTO partsInOutStagingByDeviceDTO = new PartsInOutStagingByDeviceDTO();
    	partsInOutStagingByDeviceDTO.setPartNumber(locationByPartDTO.getPartNo());
    	partsInOutStagingByDeviceDTO.setLocation(locationByPartDTO.getLocationId());
    	partsInOutStagingByDeviceDTO.setRan(locationByPartDTO.getRan());
    	partsInOutStagingByDeviceDTO.setCount(locationByPartDTO.getCurrentQty());
    	partsInOutStagingByDeviceDTO.setTransactionType("In");
    	partsInoutList.add(partsInOutStagingByDeviceDTO);
    	return partsInoutList;
    	
    }
}
