/**
 * 
 */
package com.rnaipl.wms.service;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.ejb.EJBException;
import javax.inject.Inject;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ext.Provider;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;

import com.rnaipl.wms.bean.ShortageAlarm;
import com.rnaipl.wms.dto.LocationByPartDTO;
import com.rnaipl.wms.dto.PartDTO;
import com.rnaipl.wms.dto.PartNumberDTO;
import com.rnaipl.wms.dto.ShortageAlarmDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;
import com.rnaipl.wms.util.ApplicationUtility;
import com.rnaipl.wms.util.ExcelWorkBookUtil;
import com.rnaipl.wms.util.WMSConstants;

/**
 * @author z023761
 *
 */
@Path("/shortageAlarm")
@Provider
public class ShortageAlarmService {
	
	private static final Logger LOGGER = Logger.getLogger(ShortageAlarmService.class);
	
	@Inject
	ShortageAlarm shortageAlarm;
	
	
	@Context
	HttpServletRequest request;

	@Context
	HttpServletResponse response;
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/shortageAlmCount")
	public ServiceResponse getShortageAlmListCount(ShortageAlarmDTO shortageAlarmDTO) {
		ServiceResponse serviceReponse = null;
		int count = 0;
		try {
			if(shortageAlarmDTO.getPartNumber() != null) {
         		List<String> PartNumList = Arrays.asList(shortageAlarmDTO.getPartNumber().split(","));
         		shortageAlarmDTO.setPartList(PartNumList);
         	}
			
			if(shortageAlarmDTO.getSupCode() != null) {
         		List<String> supplierList = Arrays.asList(shortageAlarmDTO.getSupCode().split(","));
         		shortageAlarmDTO.setSupplierList(supplierList);
         	}
			
			if(shortageAlarmDTO.getDepotCode() != null) {
         		List<String> PartNumList = Arrays.asList(shortageAlarmDTO.getDepotCode().split(","));
         		shortageAlarmDTO.setDepoList(PartNumList);
         	}
			
			if(shortageAlarmDTO.getPcCode() != null) {
         		List<String> PartNumList = Arrays.asList(shortageAlarmDTO.getPcCode().split(","));
         		shortageAlarmDTO.setPcList(PartNumList);
         	}
			
			count = shortageAlarm.getShortageAlmListCount(shortageAlarmDTO);
			LOGGER.debug("count in Service : " +count);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
					ServiceConstants.SERVICE_RESPONSE_SUCCESS, count);
		} catch (EJBException ejbe) {
			LOGGER.error("getShortageAlmListCount  -- >   Exception : ", ejbe);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
		}
		return serviceReponse;
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/shortageAlmList")
	public ServiceResponse getShortageAlmList(ShortageAlarmDTO shortageAlarmDTO) {
		ServiceResponse serviceReponse = null;
		List<ShortageAlarmDTO> shortageAlmList = null;
		List<ShortageAlarmDTO> shortageAlmListByPagination = null;
		try {
			
			if(shortageAlarmDTO.getPartNumber() != null) {
         		List<String> PartNumList = Arrays.asList(shortageAlarmDTO.getPartNumber().split(","));
         		shortageAlarmDTO.setPartList(PartNumList);
         	}
			
			if(shortageAlarmDTO.getSupCode() != null) {
         		List<String> supplierList = Arrays.asList(shortageAlarmDTO.getSupCode().split(","));
         		shortageAlarmDTO.setSupplierList(supplierList);
         	}
			
			if(shortageAlarmDTO.getDepotCode() != null) {
         		List<String> PartNumList = Arrays.asList(shortageAlarmDTO.getDepotCode().split(","));
         		shortageAlarmDTO.setDepoList(PartNumList);
         	}
			
			if(shortageAlarmDTO.getPcCode() != null) {
         		List<String> PartNumList = Arrays.asList(shortageAlarmDTO.getPcCode().split(","));
         		shortageAlarmDTO.setPcList(PartNumList);
         	}
			
			shortageAlmList = shortageAlarm.getShortageAlmList(shortageAlarmDTO);
			
			if (shortageAlmList != null) {
				serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.SERVICE_RESPONSE_SUCCESS, shortageAlmList);
			} else {
				serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
						ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
			}
		} catch (EJBException ejbe) {
			LOGGER.error("getShortageAlmList  -- >   Exception : ", ejbe);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
		}
		return serviceReponse;
	}
	

	@GET
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	@Path("/downloadFile")
	public ServiceResponse downloadFile() throws IOException {
		ServiceResponse serviceReponse = null;
		try {
			String fileName = request.getParameter("fileName");
			if (fileName != null && !fileName.equals("")) {
				shortageAlarm.downloadFile(fileName);
				serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.SHORTAGEALARM_DOWNLOAD_SUCCESS);
				LOGGER.debug("rev service responce" + serviceReponse);
			} else {
				serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
						ServiceConstants.SHORTAGEALARM_DOWNLOAD_FAILURE);
			}
		} catch (EJBException ejbe) {
			LOGGER.error("download file Service -- > downloading file  Exception : ", ejbe);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
		}
		return serviceReponse;
	}
	
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/byPartNumber")
    public ServiceResponse getPartsByPartNumber(PartDTO part) {
        ServiceResponse serviceReponse = null;
        Set<PartNumberDTO> parts = null;
        try {
        	parts = shortageAlarm.getPartNumbers(part.getPartNumber());
        	LOGGER.debug("Fetching all the Part Number details");
        	if(!parts.isEmpty() && parts.size() > 0) {
        		serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PARTS_FETCH_SUCCESS, parts);
        	} else {
        		serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
        	}
        } catch (Exception e) {
        	LOGGER.error("ShortagealmService -- > getPartsByPartNumber()  Exception : " , e);
        	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
        LOGGER.debug("Fetching all the part details");
        return serviceReponse;
    }
	
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/bySupCode")
    public ServiceResponse getSupplierList(PartDTO supplier) {
        ServiceResponse serviceReponse = null;
        Set<PartNumberDTO> supplierList = null;
        try {
        	supplierList = shortageAlarm.getSupplierList(supplier.getPartNumber());
        	LOGGER.debug("Fetching all the Supplier details");
        	if(!supplierList.isEmpty() && supplierList.size() > 0) {
        		serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, supplierList);
        	} else {
        		serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
        	}
        } catch (Exception e) {
        	LOGGER.error("ShortagealmService -- > getSupplierList()  Exception : " , e);
        	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
        LOGGER.debug("Fetching all the part details");
        return serviceReponse;
    }
	
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/byDepoCode")
    public ServiceResponse getDepoCodeList(PartDTO depoCode) {
        ServiceResponse serviceReponse = null;
        Set<PartNumberDTO> depoList = null;
        try {
        	depoList = shortageAlarm.getDepoCodeList(depoCode.getPartNumber());
        	LOGGER.debug("Fetching all the depo code details");
        	if(!depoList.isEmpty() && depoList.size() > 0) {
        		serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, depoList);
        	} else {
        		serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
        	}
        } catch (Exception e) {
        	LOGGER.error("ShortagealmService -- > getDepoCodeList()  Exception : " , e);
        	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
        return serviceReponse;
    }
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/allzones")
	public ServiceResponse getAllZones() {
		ServiceResponse serviceReponse = null;		
		List<PartNumberDTO> zones = null;
        try {
        	zones = shortageAlarm.getAllZones();
            LOGGER.debug("Retrieved zone list size : " + zones.size());
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, zones);
        } catch (Exception e) {
        	LOGGER.error("ShortageAlarmService -- > getAllZones()  Exception : " , e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
		return serviceReponse;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/wips")
	public ServiceResponse getWips() {
		ServiceResponse serviceReponse = null;		
		List<PartNumberDTO> wips = null;
        try {
        	wips = shortageAlarm.getWips();
            LOGGER.debug("Retrieved wip list size : " + wips.size());
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, wips);
        } catch (Exception e) {
        	LOGGER.error("ShortageAlarmService -- > getWips()  Exception : " , e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
		return serviceReponse;
	}
	
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/byPcCode")
    public ServiceResponse getPcCodeList(PartDTO pcCode) {
        ServiceResponse serviceReponse = null;
        Set<PartNumberDTO> pcList = null;
        try {
        	pcList = shortageAlarm.getPcCodeList(pcCode.getPartNumber());
        	LOGGER.debug("Fetching all the depo code details");
        	if(!pcList.isEmpty() && pcList.size() > 0) {
        		serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, pcList);
        	} else {
        		serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
        	}
        } catch (Exception e) {
        	LOGGER.error("ShortagealmService -- > getDepoCodeList()  Exception : " , e);
        	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
        return serviceReponse;
    }
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getDownloadName")
	public ServiceResponse getDownloadNameFmDB(ShortageAlarmDTO shortgeDto) {
		ServiceResponse serviceReponse = null;
		String downloadName = "";
		//ShortageAlarmDTO shortgeDto =new ShortageAlarmDTO();
		try {
			if(shortgeDto.getFlag()!=null && !shortgeDto.getFlag().isEmpty()) {
				if(shortgeDto.getCalLogic().toString().trim().equalsIgnoreCase("W") && shortgeDto.getFlag().toString().trim().equalsIgnoreCase("SCREEN_DOWNLOAD")) {
					downloadName=WMSConstants.PV_SA_WH_DOWNLOAD;
				}else if (shortgeDto.getCalLogic().toString().trim().equalsIgnoreCase("L") && shortgeDto.getFlag().toString().trim().equalsIgnoreCase("SCREEN_DOWNLOAD")){
					downloadName=WMSConstants.PV_SA_WHCATS_DOWNLOAD;
				}else if(shortgeDto.getFlag().toString().trim().equalsIgnoreCase("MISSING_PARTS")) {
					downloadName=WMSConstants.PV_SA_MISSING_PARTS_DOWNLOAD;
				}else if(shortgeDto.getFlag().toString().trim().equalsIgnoreCase("ALLPARTS_CATS")) {
					downloadName=WMSConstants.PV_SA_ALLPARTS_CATS_DOWNLOAD;
				}
				shortgeDto = shortageAlarm.getDownloadNameFmDB(downloadName);
				LOGGER.debug("downloadName in Service : " +downloadName);
				serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.SERVICE_RESPONSE_SUCCESS, shortgeDto);
			}else {
				serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
						ServiceConstants.NO_DATA_FOUND, shortgeDto);
			}
		} catch (EJBException ejbe) {
			LOGGER.error("getDownloadNameFmDB  -- >   Exception : ", ejbe);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
		}
		return serviceReponse;
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getUserIdForAllPartsCats")
	public ServiceResponse getUserForAllPartsCoverage(String loggedInUser) {
		ServiceResponse serviceReponse = null;
		String downloadName = "";
		ShortageAlarmDTO shortgeDto =new ShortageAlarmDTO();
		try {
			LOGGER.debug("loggedInUser in Service : " +loggedInUser);
			if(loggedInUser!=null && !loggedInUser.isEmpty()) {				
				shortgeDto = shortageAlarm.getUserForAllPartsCoverage(loggedInUser);
				LOGGER.debug("userID in Service : " +shortgeDto.getUserId());
				serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.SERVICE_RESPONSE_SUCCESS, shortgeDto);
			}else {
				serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
						ServiceConstants.NO_DATA_FOUND, shortgeDto);
			}
		} catch (EJBException ejbe) {
			LOGGER.error("getUserForAllPartsCoverage  -- >   Exception : ", ejbe);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
		}
		return serviceReponse;
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getLstCalTime")
	public ServiceResponse getLstCalTime(String plant) {
		ServiceResponse serviceReponse = null;
		String downloadName = "";
		ShortageAlarmDTO shortgeDto = new ShortageAlarmDTO();
		try {
				shortgeDto = shortageAlarm.getLstCalTime(plant);
				Timestamp lastWmsCalDate = new java.sql.Timestamp((shortgeDto.getLastWmsCalDate()).getTime());
				String lastWmsCalStr = ApplicationUtility.displayDateStringToFromattedDateString(lastWmsCalDate.toString(),WMSConstants.DATE_TIME_FORMAT_DATABASE,"dd/MM/yy hh:mm");
				shortgeDto.setLastWmsCalStr(lastWmsCalStr);
				Timestamp lastCatsCalDate = new java.sql.Timestamp((shortgeDto.getLastCatsCalDate()).getTime());
				String lastCatsCalStr = ApplicationUtility.displayDateStringToFromattedDateString(lastCatsCalDate.toString(),WMSConstants.DATE_TIME_FORMAT_DATABASE,"dd/MM/yy hh:mm");
				shortgeDto.setLastCatsCalStr(lastCatsCalStr);
				if(shortgeDto.getLastWmsCalStr()!= null && shortgeDto.getLastCatsCalStr() != null){
					serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
							ServiceConstants.SERVICE_RESPONSE_SUCCESS, shortgeDto);
				} else {
					serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
							ServiceConstants.NO_DATA_FOUND, shortgeDto);
				}
		} catch (EJBException ejbe) {
			LOGGER.error("getLstCalTime  -- >   Exception : ", ejbe);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
		}
		return serviceReponse;
	}
	
	
	
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/shortageAlmDownload")
    public ServiceResponse getShortageAlmDownload(ShortageAlarmDTO shortageAlarmDTO) 
                		  throws IOException {
    	ServiceResponse serviceResponse = null;
    	ServletOutputStream out = null;
		try {	
			if(shortageAlarmDTO.getPartNumber() != null) {
         		List<String> PartNumList = Arrays.asList(shortageAlarmDTO.getPartNumber().split(","));
         		shortageAlarmDTO.setPartList(PartNumList);
         	}
			
			if(shortageAlarmDTO.getSupCode() != null) {
         		List<String> supplierList = Arrays.asList(shortageAlarmDTO.getSupCode().split(","));
         		shortageAlarmDTO.setSupplierList(supplierList);
         	}
			
			if(shortageAlarmDTO.getDepotCode() != null) {
         		List<String> PartNumList = Arrays.asList(shortageAlarmDTO.getDepotCode().split(","));
         		shortageAlarmDTO.setDepoList(PartNumList);
         	}
			
			if(shortageAlarmDTO.getPcCode() != null) {
         		List<String> PartNumList = Arrays.asList(shortageAlarmDTO.getPcCode().split(","));
         		shortageAlarmDTO.setPcList(PartNumList);
         	}
			
			   //To append the downloaded Date-time to the file name.
     	       java.util.Date today = new java.util.Date();
			   Timestamp current = new java.sql.Timestamp(today.getTime());

			  String curDate = ApplicationUtility.displayDateStringToFromattedDateString(current.toString(),WMSConstants.DATE_TIME_FORMAT_DATABASE,"dd_MM_yy_HH:mm");
			  LOGGER.debug("curDate : "+curDate);
			  /*String generatedDateTime = ApplicationUtility.displayDateStringToFromattedDateString(current.toString(),StockOrderConstants.DATE_TIME_FORMAT_DATABASE,"dd/MM/yy HH:mm");
				*/				
				List<ShortageAlarmDTO> shortagealmdownloadList = shortageAlarm.getShortageAlmDownload(shortageAlarmDTO);
				LOGGER.debug("List Size : " +shortagealmdownloadList.size());
				
				if(null != shortagealmdownloadList && shortagealmdownloadList.size() > 0) {
	        		
				HSSFWorkbook workbook = new HSSFWorkbook();
					
		        	 HSSFSheet sheet1 = workbook.createSheet("Shortage Alarm - Report");
		        	 //  sheet1.createFreezePane(0, 3);
		        	   int rowCount1 = 0;
		        	   int columnCount1 = 0;
		        	   Row headerRow1 = sheet1.createRow(rowCount1);
		        	   LOGGER.debug("headerRow1 : " +headerRow1);
		             //Applying Styles to the cells
		        	   CellStyle styleYellow = ExcelWorkBookUtil.getCustomizedStyle(workbook, "YELLOW",false,false,true);
		               CellStyle styleGreen = ExcelWorkBookUtil.getCustomizedStyle(workbook, "GREEN",false,false,true);
		               CellStyle styleRed = ExcelWorkBookUtil.getCustomizedStyle(workbook, "RED",false,false,true);
		               CellStyle styleGrey = ExcelWorkBookUtil.getCustomizedStyle(workbook, "GREY_50",false,false,true);
		               CellStyle styleAlignleft = ExcelWorkBookUtil.getCustomizedStyle(workbook, "",false,true,false);
		               CellStyle styleAlignright = ExcelWorkBookUtil.getCustomizedStyle(workbook, "",true,false,false);
		               CellStyle centerAlign = ExcelWorkBookUtil.getCustomizedStyle(workbook, "",false,false,true);
		               
		               
		               ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "Part Type", styleGrey);
		               ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "Part No", styleGrey);
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "PC_Code", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "Part Name", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "Sup Name", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "Depo Code", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "LS Zone", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "SNEP", styleGrey);
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "SNIP", styleGrey);
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "Trim WIP", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "PBS WIP", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "PA2 WIP", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "PA1 WIP", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "Metal WIP", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "Total WIP", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "TCF ClsStk", styleGrey);
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "PBS ClsStk", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "PA2 ClsStk", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "PA1 ClsStk", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "Metal ClsStk", styleGrey);
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "GrossDate", styleGrey);
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "Qty", styleGrey);
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "Last WH Out", styleGrey);
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "Last WH Out Qty", styleGrey);
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "Cats Stock", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "WMS Stock", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "LS Stock", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "EOP Mark", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "EOP Flag Qty", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "Hold Stock", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "Undelivered Qty", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "Pending Qty", styleGrey);
		        	   
	                  if(!shortagealmdownloadList.isEmpty() && shortagealmdownloadList.size() !=0){
		               for (ShortageAlarmDTO shortAlmListDto : shortagealmdownloadList) {
		            	    Row row2 = sheet1.createRow(++rowCount1);
		                   int columnCountVO1 = 0;		                   
		                                      
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPartType(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPartNumber(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPcCode(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPartName(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getSupName(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getDepotCode(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getZone(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getSnep(), styleAlignright);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getSnip(), styleAlignright);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getTrimWip(), styleAlignright);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPbsWip(), styleAlignright);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPa2Wip(), styleAlignright);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPa1Wip(), styleAlignright);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getMetalWip(), styleAlignright);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getTotWip(), styleAlignright);
		                   
		                   if(shortAlmListDto.getTcfClr().toString().equalsIgnoreCase("G")) {
		                	   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getTcf(), styleGreen);
		                   }else if(shortAlmListDto.getTcfClr().toString().equalsIgnoreCase("R")) {
		                	   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getTcf(), styleRed);
		                   }
                           else if(shortAlmListDto.getTcfClr().toString().equalsIgnoreCase("Y")) {
                        	   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getTcf(), styleYellow);
		                   }
		                  // ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getTcf(), styleAlignleft);
		                   if(shortAlmListDto.getPbsClr().toString().equalsIgnoreCase("G")) {
		                	   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPbs(), styleGreen);
		                   }else if(shortAlmListDto.getPbsClr().toString().equalsIgnoreCase("R")) {
		                	   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPbs(), styleRed);
		                   }
                           else if(shortAlmListDto.getPbsClr().toString().equalsIgnoreCase("Y")) {
                        	   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPbs(), styleYellow);
		                   }
		                   //ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPbs(), styleAlignright);
		                   if(shortAlmListDto.getPa2Clr().toString().equalsIgnoreCase("G")) {
		                	   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPa2(), styleGreen);
		                   }else if(shortAlmListDto.getPa2Clr().toString().equalsIgnoreCase("R")) {
		                	   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPa2(), styleRed);
		                   }
                           else if(shortAlmListDto.getPa2Clr().toString().equalsIgnoreCase("Y")) {
                        	   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPa2(), styleYellow);
		                   }
		                  // ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPa2(), styleAlignright);
		                   if(shortAlmListDto.getPa1Clr().toString().equalsIgnoreCase("G")) {
		                	   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPa1(), styleGreen);
		                   }else if(shortAlmListDto.getPa1Clr().toString().equalsIgnoreCase("R")) {
		                	   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPa1(), styleRed);
		                   }
                           else if(shortAlmListDto.getPa1Clr().toString().equalsIgnoreCase("Y")) {
                        	   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPa1(), styleYellow);
		                   }
		                 //  ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPa1(), styleAlignright);
		                   if(shortAlmListDto.getMetalClr().toString().equalsIgnoreCase("G")) {
		                	   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getMetal(), styleGreen);
		                   }else if(shortAlmListDto.getMetalClr().toString().equalsIgnoreCase("R")) {
		                	   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getMetal(), styleRed);
		                   }
                           else if(shortAlmListDto.getMetalClr().toString().equalsIgnoreCase("Y")) {
                        	   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getMetal(), styleYellow);
		                   }
		                  // ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getMetal(), styleAlignright);
		                   
		                   if(shortAlmListDto.getGrossDate()!=null) {
		                	   Timestamp grossTimestamp = new java.sql.Timestamp((shortAlmListDto.getGrossDate()).getTime());
							   String grossDate = ApplicationUtility.displayDateStringToFromattedDateString(grossTimestamp.toString(),WMSConstants.DATE_TIME_FORMAT_DATABASE,"dd-MM-yyyy");
							   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, grossDate, styleAlignright);
		                   }else {
		                	   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, "-", centerAlign);
		                   }						   
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getGrossQty(), styleAlignright);
		                   
		                   if(shortAlmListDto.getLastWhOut()!=null) {
		                	   Timestamp lastWhOutTime = new java.sql.Timestamp((shortAlmListDto.getLastWhOut()).getTime());
							   String lastWhOutTimeStr = ApplicationUtility.displayDateStringToFromattedDateString(lastWhOutTime.toString(),WMSConstants.DATE_TIME_FORMAT_DATABASE,"dd-MM-yyyy hh:mm:ss");
							   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, lastWhOutTimeStr, styleAlignright);
		                   }else {
		                	   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, "", styleAlignright);
		                   }
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getLastWhOutQty(), styleAlignright);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getCatsStk(), styleAlignright);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getWmsStock(), styleAlignright);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getLsStock(), styleAlignright);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getEopMark(), styleAlignright);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getEopFlagQty(), styleAlignright);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getHoldQty(), styleAlignright);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getUndeliveredQty(), styleAlignright);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPendingRanQty(), styleAlignright);
		               }
	        	   }
				 
				    String fileName = null;
				    //fileName = "ShortageAlarmReport-"+curDate+".xls";
				  
	               /* if(StockOrderConstants.PV.equals(category)){
	                	 fileName = "PV_ShortageAlarmReport-"+curDate+".xls";
	                }else if(StockOrderConstants.PT.equals(category)){
	                	 fileName = "PT_ShortageAlarmReport-"+curDate+".xls";
	                }*/
				    
				    if(shortageAlarmDTO.getCalLogic().toString().trim().equalsIgnoreCase("W")) {
				    	fileName=WMSConstants.PV_SA_WH_DOWNLOAD+".xls";
				    }else {
				    	fileName=WMSConstants.PV_SA_WHCATS_DOWNLOAD+".xls";
				    }
				    LOGGER.debug("fileName in Service class : "+fileName);
	                
	                response.setContentType("application/vnd.ms-excel"); // Set up mime type
	                response.addHeader("x-filename", fileName);
	                response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
	                out = response.getOutputStream();
	                workbook.write(out);
	                out.flush();
	                out.close();   
	                
	                serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SHORTAGEALARM_DOWNLOAD_SUCCESS, shortagealmdownloadList);
				} else {
	        		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SHORTAGEALARM_DOWNLOAD_FAILURE);
	        	}
	                
					
		}catch (Exception ex) {
            LOGGER.error("Error in download--->", ex);
     }
		finally {
			if(out!=null) {
				out.close();
			}
		}
		return serviceResponse;
}
	
	
	/**
     * This method is used to fetch Location details based in input partNumber
     * 
     * @return PartDTO
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getLocationsByPartNo")
    public ServiceResponse getLocationsByPartNumber(String partNo) {
        ServiceResponse serviceResponse = null;
        List<LocationByPartDTO> locationsList = null;
       
        try { 
        	locationsList = shortageAlarm.getLocationsByPartNo(partNo);
        	if(null != locationsList && locationsList.size() > 0) {
        		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.LOCATION_FETCH_SUCCESS, locationsList);
        	} else {
        		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.LOCATION_EMPTY);
        	}
        } catch (Exception e) {
        	LOGGER.error("shortagealarmservice -- > getPartsByPartNumber()  Exception : " , e);
        	serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
        return serviceResponse;
    }
    
    
    /**
     * This method is used to fetch Location details based in input partNumber
     * 
     * @return PartDTO
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getShopByPlantId")
    public ServiceResponse getShopByPlantId(String plantId) {
        ServiceResponse serviceResponse = null;
        List<ShortageAlarmDTO> shopList = null;
       
        try { 
        	shopList = shortageAlarm.getShopByPlantId(plantId);
        	if(null != shopList && shopList.size() > 0) {
        		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, shopList);
        	} else {
        		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
        	}
        } catch (Exception e) {
        	LOGGER.error("shortagealarmservice -- > getPartsByPartNumber()  Exception : " , e);
        	serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
        return serviceResponse;
    }
    
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getlinesByShopId")
    public ServiceResponse getlinesByShopId(String shopId) {
    	
        ServiceResponse serviceReponse = null;        
        List<ShortageAlarmDTO> lines = null;
        try {
        	lines = shortageAlarm.getlinesByShopId(shopId);
            if(lines!=null && lines.size()>0){
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.LINE_FETCH_SUCCESS, lines);
            }
            else{
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.LINE_FETCH_ERROR, lines);
            }
        } catch (Exception e) {
        	LOGGER.error("shortagealarmservice -- > getlinesByShopId() Exception : ",e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
        }
        return serviceReponse;
    }
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getMaxDate")
    public ServiceResponse getMaxDate() {
        ServiceResponse serviceReponse = null;     
        int dayCount = 0;
        try {
        	dayCount = shortageAlarm.getMaxDate();
        	
            if(dayCount!=0){
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SERVICE_RESPONSE_SUCCESS, dayCount);
            }
            else{
            	serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND, dayCount);
            }
        } catch (Exception e) {
        	LOGGER.error("shortagealarmservice -- > getMaxDate() Exception : ",e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
        }
        return serviceReponse;
    }
}
