package com.rnaipl.wms.service;

import java.util.List;

import javax.ejb.EJBException;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.Shop;
import com.rnaipl.wms.dto.ShopDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

/**
 * This Restful service class to process the requests from html and call the
 * respective EJB methods of Parts
 * 
 * 
 * @CreatedBy TechM
 * @CreatedOn 08-Apr-2016 10:25:44 am
 */
@Path("/shops")
@RequestScoped
public class ShopService {

	private static final Logger LOGGER = Logger.getLogger(ShopService.class);

    @Inject
    Shop shopBean;

    /**
     * This method is used to fetch the all plant details from the table
     * 
     * @return List of Part
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/allshops")
    public ServiceResponse getAllShops() {
        ServiceResponse serviceReponse = null;
        List<ShopDTO> shops = null;
        try {
            shops = shopBean.getAllShops();
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SHOP_FETCH_SUCCESS, shops);
        } catch (Exception e) {
        	LOGGER.error("ShopService -- > getAllShops  Exception : " , e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
        LOGGER.debug("Fetching all the shop details");
        return serviceReponse;
    }
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/shopsByPlantId")
    public ServiceResponse getShopsByPlant(String plantId) {
        ServiceResponse serviceReponse = null;
        List<ShopDTO> shops = null;
        try {
            shops = shopBean.getShopByPlantId(plantId);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SHOP_FETCH_SUCCESS, shops);
        } catch (Exception e) {
        	LOGGER.error("ShopService -- > getAllShops  Exception : " , e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
        LOGGER.debug("Fetching all the shop details");
        return serviceReponse;
    }
}
