package com.rnaipl.wms.service;

import java.util.List;

import javax.ejb.EJBException;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.Plant;
import com.rnaipl.wms.bean.PlantBean;
import com.rnaipl.wms.dto.PlantDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

/**
 * This Restful service class to process the requests from html and call the
 * respective EJB methods of Parts
 * 
 * 
 * @CreatedBy TechM
 * @CreatedOn 08-Apr-2016 10:25:44 am
 */
@Path("/plants")
@RequestScoped
public class PlantService {

	private static final Logger LOGGER = Logger.getLogger(PlantService.class);


    @Inject
    Plant plantBean;

    /**
     * This method is used to fetch the all plant details from the table
     * 
     * @return List of Part
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/allplants")
    public ServiceResponse getAllPlants() {
        ServiceResponse serviceReponse = null;
        List<PlantDTO> plants = null;
        try {
            plants = plantBean.getAllPlants();
            LOGGER.debug("Retrieved parts list size : " + plants.size());
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PLANT_FETCH_SUCCESS, plants);
        } catch (Exception e) {
        	LOGGER.error("PlantService -- > getAllPlants()  Exception : " , e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
        System.out.println("Restful Service getAllPlants - Ends");
        return serviceReponse;
    }
}
