package com.rnaipl.wms.service;

import java.util.Set;

import javax.ejb.EJBException;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.Location;
import com.rnaipl.wms.dto.LocationDTO;
import com.rnaipl.wms.dto.PartNumberDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;


@Path("/location")
@RequestScoped
public class LocationService {

	private static final Logger LOGGER = Logger
			.getLogger(LocationService.class);

	@Inject
	Location locationBean;

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/locationByLocationID")
	public ServiceResponse getLocationByLocationID(LocationDTO locationID) {
		ServiceResponse serviceReponse = null;
		Set<PartNumberDTO> locations = null;
		try {
			locations = locationBean.getLocation(locationID.getLocationId());
			if (!locations.isEmpty() && locations.size() > 0) {
				serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.LOCATION_FETCH_SUCCESS, locations);
			} else {
				serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.LOCATION_EMPTY);
			}
		} catch (EJBException ejbe) {
			LOGGER.error("Location Service -- > getLocationByLocationID  Exception : " , ejbe);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
		}
		
		return serviceReponse;
	}
}
