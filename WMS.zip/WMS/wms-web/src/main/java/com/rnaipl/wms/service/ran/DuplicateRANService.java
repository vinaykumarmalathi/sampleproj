package com.rnaipl.wms.service.ran;

import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.PartsInOutAuditSearch;
import com.rnaipl.wms.bean.ran.DuplicateRAN;
import com.rnaipl.wms.dto.PartsInOutAuditSearchDTO;
import com.rnaipl.wms.dto.ran.DuplicateRANDTO;
import com.rnaipl.wms.dto.ran.DuplicateRANInputDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

@Path("/DuplicateRAN")
public class DuplicateRANService {

	private static final Logger LOGGER = Logger.getLogger(DuplicateRANService.class);
	
	 @Inject
	 DuplicateRAN duplicateRAN;
	 
	 
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getDuplicateRAN")
    @SuppressWarnings("null")
	public ServiceResponse getDuplicateRAN(DuplicateRANInputDTO duplicateRANInputDTO){
		
		ServiceResponse serviceResponse = null;
		LOGGER.debug("**IN Class->getPartsAuditDetails() entry");
		LOGGER.debug("** Device ID --"+duplicateRANInputDTO.getDeviceId());
		try {
		//	serviceResponse.getStatusCode();
			
			if(duplicateRANInputDTO.getPartNumber() != null) {
        		List<String> partList = Arrays.asList(duplicateRANInputDTO.getPartNumber().split(","));
        		duplicateRANInputDTO.setPartList(partList);
        	}
        	if(duplicateRANInputDTO.getLocation() != null) {
        		List<String> locationList = Arrays.asList(duplicateRANInputDTO.getLocation().split(","));
        		duplicateRANInputDTO.setLocationList(locationList);
        	}
        	
        	if(duplicateRANInputDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(duplicateRANInputDTO.getRan().split(","));        	
        		duplicateRANInputDTO.setRanList(ranList);
        	}
			List<DuplicateRANDTO> duplicateRANList = duplicateRAN.getDuplicateRANs(duplicateRANInputDTO);
			if (!duplicateRANList.isEmpty()
					|| duplicateRANList.size() > 0) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.PARTS_FETCH_SUCCESS,
						duplicateRANList);
			} else {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			}
		

		} catch (Exception ex) {
			LOGGER.error("PartsInOutStagingService -- > getPartsInOutAuditByLocation()  Exception : " , ex);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.PARTS_FETCH_ERROR, ex);
		}
		LOGGER.debug("**IN Class->getPartsAuditDetails() Exit");
		return serviceResponse;
	}	
		
		
		@POST
	    @Produces(MediaType.APPLICATION_JSON)
	    @Path("/getDuplicateRANCount")
	    @SuppressWarnings("null")
		public ServiceResponse getDuplicateRANCount(DuplicateRANInputDTO duplicateRANInputDTO){
			
			ServiceResponse serviceResponse = null;
			LOGGER.debug("**IN Class->getPartsAuditCount() entry");
			LOGGER.debug("** Device ID --"+duplicateRANInputDTO.getDeviceId());
			
			try {
				LOGGER.debug("IN getPartsAuditCount ENTRY");
				int noOfRecords =0;
				if(duplicateRANInputDTO.getPartNumber() != null) {
	        		List<String> partList = Arrays.asList(duplicateRANInputDTO.getPartNumber().split(","));
	        		duplicateRANInputDTO.setPartList(partList);
	        	}
	        	if(duplicateRANInputDTO.getLocation() != null) {
	        		List<String> locationList = Arrays.asList(duplicateRANInputDTO.getLocation().split(","));
	        		duplicateRANInputDTO.setLocationList(locationList);
	        	}
	        	if(duplicateRANInputDTO.getRan() != null) {
	        		List<String> ranList = Arrays.asList(duplicateRANInputDTO.getRan().split(","));
	        		duplicateRANInputDTO.setRanList(ranList);
	        	}
	        	duplicateRANInputDTO.setDownloadAllRecords(true);
	        	List<DuplicateRANDTO> duplicateRANList = duplicateRAN.getDuplicateRANs(duplicateRANInputDTO);
//				int noOfRecords = duplicateRAN.getPartInOutAuditSearchCount(duplicateRANInputDTO);
	        	if(duplicateRANList!=null)
	        	{
	        		noOfRecords=duplicateRANList.size();
	        	}
				if (noOfRecords > 0) {
					serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
							ServiceConstants.PARTS_FETCH_SUCCESS,
							noOfRecords);
				} else {
					serviceResponse = ServiceResponseHandler
							.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
				}
				LOGGER.debug("IN getPartsAuditSearch EXIT");

			} catch (Exception ex) {
				LOGGER.error("PartsInOutStagingService -- > getPartsInOutAuditByLocation()  Exception : " , ex);
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
						ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, ex);
			}
			LOGGER.debug("**IN Class->getPartsAuditDetails() Exit");
			return serviceResponse;
			
		}
		
		@POST
	    @Produces(MediaType.APPLICATION_JSON)
	    @Path("/getDuplicateRANDownload")
	    @SuppressWarnings("null")
		public ServiceResponse getDuplicateRANDownload(DuplicateRANInputDTO duplicateRANInputDTO){
			
			ServiceResponse serviceResponse = null;
			LOGGER.debug("**IN Class->getPartsAuditDetails() entry");
			LOGGER.debug("** Device ID --"+duplicateRANInputDTO.getDeviceId());
			try {
			//	serviceResponse.getStatusCode();
				
				if(duplicateRANInputDTO.getPartNumber() != null) {
	        		List<String> partList = Arrays.asList(duplicateRANInputDTO.getPartNumber().split(","));
	        		duplicateRANInputDTO.setPartList(partList);
	        	}
	        	if(duplicateRANInputDTO.getLocation() != null) {
	        		List<String> locationList = Arrays.asList(duplicateRANInputDTO.getLocation().split(","));
	        		duplicateRANInputDTO.setLocationList(locationList);
	        	}
	        	
	        	if(duplicateRANInputDTO.getRan() != null) {
	        		List<String> ranList = Arrays.asList(duplicateRANInputDTO.getRan().split(","));        	
	        		duplicateRANInputDTO.setRanList(ranList);
	        	}
	        	duplicateRANInputDTO.setDownloadAllRecords(true);
				List<DuplicateRANDTO> duplicateRANList = duplicateRAN.getDuplicateRANs(duplicateRANInputDTO);
				if (!duplicateRANList.isEmpty()
						|| duplicateRANList.size() > 0) {
					serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
							ServiceConstants.PARTS_FETCH_SUCCESS,
							duplicateRANList);
				} else {
					serviceResponse = ServiceResponseHandler
							.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
				}
			

			} catch (Exception ex) {
				LOGGER.error("PartsInOutStagingService -- > getPartsInOutAuditByLocation()  Exception : " , ex);
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
						ServiceConstants.PARTS_FETCH_ERROR, ex);
			}
			LOGGER.debug("**IN Class->getPartsAuditDetails() Exit");
			return serviceResponse;
		}	
			
}
