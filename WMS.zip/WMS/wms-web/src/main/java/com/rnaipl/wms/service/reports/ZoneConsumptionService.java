package com.rnaipl.wms.service.reports;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;

import javax.ejb.EJBException;
import javax.inject.Inject;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;

import com.rnaipl.wms.bean.reports.IZoneConsumption;
import com.rnaipl.wms.dto.reports.ZoneConsumptionDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;
import com.rnaipl.wms.util.ApplicationUtility;
import com.rnaipl.wms.util.ExcelWorkBookUtil;
import com.rnaipl.wms.util.WMSConstants;

@Path("/zoneconsumption")
public class ZoneConsumptionService {
	private static final Logger LOGGER = Logger.getLogger(ZoneConsumptionService.class);

	private static String FILE_PATH = null;

	@Inject
	IZoneConsumption zoneConsumption;


	@Context
	static HttpServletRequest request;

	@Context
	HttpServletResponse response;

	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/zonelistCount")
	public ServiceResponse getzonelistCount(ZoneConsumptionDTO zoneConsumptionDTO) {
		ServiceResponse serviceReponse = null;
		int count = 0;
		try {
			
			if(zoneConsumptionDTO.getPartNumber() != null) {
				
	     		List<String> PartNumList = Arrays.asList(zoneConsumptionDTO.getPartNumber().split(","));
	     		zoneConsumptionDTO.setPartList(PartNumList);
	     	}
			
			count = zoneConsumption.getZoneListCount(zoneConsumptionDTO);
			LOGGER.debug("count in Service : " +count);
			
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
					ServiceConstants.SERVICE_RESPONSE_SUCCESS, count);
			
		} catch (EJBException ejbe) {
			LOGGER.error("getShortageAlmListCount  -- >   Exception : ", ejbe);
			serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE);
		}
		return serviceReponse;
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/zonelist")
	public ServiceResponse<ZoneConsumptionDTO> getZoneWiseList(ZoneConsumptionDTO zoneConsumptionDTO) {
		LOGGER.debug("Zone consumption List ");
		ServiceResponse<ZoneConsumptionDTO> serviceResponse = null;
		
		if(zoneConsumptionDTO.getPartNumber() != null) {
			
     		List<String> PartNumList = Arrays.asList(zoneConsumptionDTO.getPartNumber().split(","));
     		LOGGER.debug("Zone consumption Part List : "+PartNumList.get(0));
     		zoneConsumptionDTO.setPartList(PartNumList);
     	}
		
		List<ZoneConsumptionDTO> zoneConsumptionDTOList = zoneConsumption.getZoneList(zoneConsumptionDTO,"N");
		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
				ServiceConstants.PICKINGLIST_FETCH_SUCCESS, zoneConsumptionDTOList);
		return serviceResponse;
	}
	
	
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/zoneconsumptionDownload")
    public ServiceResponse zoneconsumptionDownload(ZoneConsumptionDTO zoneConsumptionDTO) 
                		  throws IOException {
		LOGGER.debug("Inside download method");
    	ServiceResponse serviceResponse = null;
    	ServletOutputStream out = null;
		try {	
			if(zoneConsumptionDTO.getPartNumber() != null) {
         		List<String> PartNumList = Arrays.asList(zoneConsumptionDTO.getPartNumber().split(","));
         		zoneConsumptionDTO.setPartList(PartNumList);
         	}			
			
			//To append the downloaded Date-time to the file name.
     	       java.util.Date today = new java.util.Date();
			   Timestamp current = new java.sql.Timestamp(today.getTime());

			  String curDate = ApplicationUtility.displayDateStringToFromattedDateString(current.toString(),WMSConstants.DATE_TIME_FORMAT_DATABASE,"dd_MM_yy_HH:mm");
			  LOGGER.debug("curDate : "+curDate);
			  /*String generatedDateTime = ApplicationUtility.displayDateStringToFromattedDateString(current.toString(),StockOrderConstants.DATE_TIME_FORMAT_DATABASE,"dd/MM/yy HH:mm");
				*/			
			  List<ZoneConsumptionDTO> zoneConsumptionDTOList = zoneConsumption.getZoneList(zoneConsumptionDTO, "Y");
			  
				//List<ShortageAlarmDTO> shortagealmdownloadList = shortageAlarm.getShortageAlmDownload(shortageAlarmDTO);
				LOGGER.debug("List Size : " +zoneConsumptionDTOList.size());
				
				if(null != zoneConsumptionDTOList && zoneConsumptionDTOList.size() > 0) {
	        		
				HSSFWorkbook workbook = new HSSFWorkbook();
					
		        	 HSSFSheet sheet1 = workbook.createSheet("Report");
		        	 //  sheet1.createFreezePane(0, 3);
		        	   int rowCount1 = 0;
		        	   int columnCount1 = 0;
		        	   Row headerRow1 = sheet1.createRow(rowCount1);
		        	   LOGGER.debug("headerRow1 : " +headerRow1);
		             //Applying Styles to the cells
		        	   CellStyle styleYellow = ExcelWorkBookUtil.getCustomizedStyle(workbook, "YELLOW",false,false,true);
		               CellStyle styleGreen = ExcelWorkBookUtil.getCustomizedStyle(workbook, "GREEN",false,false,true);
		               CellStyle styleRed = ExcelWorkBookUtil.getCustomizedStyle(workbook, "RED",false,false,true);
		               CellStyle styleGrey = ExcelWorkBookUtil.getCustomizedStyle(workbook, "GREY_50",false,false,true);
		               CellStyle styleAlignleft = ExcelWorkBookUtil.getCustomizedStyle(workbook, "",false,true,false);
		               CellStyle styleAlignright = ExcelWorkBookUtil.getCustomizedStyle(workbook, "",true,false,false);
		               CellStyle centerAlign = ExcelWorkBookUtil.getCustomizedStyle(workbook, "",false,false,true);
		               
		               
		               ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "LINE", styleGrey);
		               ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "SHOP", styleGrey);
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "ZONE", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "PART NO", styleGrey);
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "PART NAME", styleGrey);
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "SOURCE", styleGrey);
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "POF ZONE", styleGrey);
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "LAST PICKING LIST TIME", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "LAST PICKING LIST QTY", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "LAST PICKING LIST STATUS", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "LAST WH-OUT TIME", styleGrey);
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "LAST WH-OUT QTY", styleGrey);
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "TACT TIME", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "CONSUMPTION QTY", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "LINE STOCK", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "WH STOCK", styleGrey); 
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "CATS STOCK", styleGrey);
		        	   ExcelWorkBookUtil.createACell(sheet1, headerRow1, columnCount1++, "MISMATCH", styleGrey);
		        	   
	                  if(!zoneConsumptionDTOList.isEmpty() && zoneConsumptionDTOList.size() !=0){
		               for (ZoneConsumptionDTO shortAlmListDto : zoneConsumptionDTOList) {
		            	   Row row2 = sheet1.createRow(++rowCount1);
		                   int columnCountVO1 = 0;
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getLine(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getShop(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getZone(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPartNumber(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPartName(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getSource(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getPofZone(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getLastPickListTime(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getLastPickListQTY(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getLastPickListSTS(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getLastWHoutTIME(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getLastWhOUTQTY(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getZoneTactHISRY(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getOffLineQTY(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getLineStock(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getWhStock(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getCatsStock(), styleAlignleft);
		                   ExcelWorkBookUtil.createACell(sheet1, row2, columnCountVO1++, shortAlmListDto.getMismatch(), styleAlignleft);
		               }
	        	   }
				 
				    String fileName = null;
				    fileName = "ZoneConsumptionReport-"+curDate+".xls";
				    LOGGER.debug("fileName in Service class : "+fileName);	                
	                response.setContentType("application/vnd.ms-excel"); // Set up mime type
	                response.addHeader("x-filename", fileName);
	                response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
	                out = response.getOutputStream();
	                workbook.write(out);
	                out.flush();
	                out.close();   
	                
	                serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.SHORTAGEALARM_DOWNLOAD_SUCCESS, zoneConsumptionDTOList);
				} else {
	        		serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SHORTAGEALARM_DOWNLOAD_FAILURE);
	        	}
		}catch (Exception ex) {
            LOGGER.error("Error in download--->", ex);
     }
		finally {
			if(out!=null) {
				out.close();
			}
		}
		return serviceResponse;
}
}