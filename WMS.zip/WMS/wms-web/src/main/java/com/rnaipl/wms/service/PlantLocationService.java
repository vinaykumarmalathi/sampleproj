package com.rnaipl.wms.service;

import java.util.List;

import javax.ejb.EJBException;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import com.rnaipl.wms.bean.PartLocation;
import com.rnaipl.wms.dto.PartLocationDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

/**
 * This Restful service class to process the requests from html and call the
 * respective EJB methods of Parts
 * 
 * 
 * @CreatedBy TechM
 * @CreatedOn 08-Apr-2016 10:25:44 am
 */
@Path("/plantLocation")
@RequestScoped
public class PlantLocationService {

	private static final Logger LOGGER = Logger.getLogger(PlantLocationService.class);
	
    @Inject
    PartLocation plantLoc;

    /**
     * This method is used to fetch the all plant details from the table
     * 
     * @return List of Part
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/allLocations")
    public ServiceResponse getAllPlants() {
        ServiceResponse serviceReponse = null;
        List<PartLocationDTO> plantLocations = null;
        try {
           // plantLocations = plantLoc.getAllPartLocations();
            System.out.println("Location : " + plantLocations.size());
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.PLANT_FETCH_SUCCESS, plantLocations);
        } catch (Exception e) {
        	LOGGER.error("PlantLocationService -- > getAllPlants()  Exception : " , e);
            serviceReponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,ServiceConstants.SERVICE_RESPONSE_ERROR_COMMON_MESSAGE, e);
        }
      
        return serviceReponse;
    }
}
