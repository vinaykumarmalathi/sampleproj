package com.rnaipl.wms.service;

import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.PickingInOutStaging;
import com.rnaipl.wms.dto.PickingListDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.XMLServiceResponse;

@Path("/pickingList")
public class PickingListService {

	private static final Logger LOGGER = Logger.getLogger(PickingListService.class);
	
	@Inject
	PickingInOutStaging pickingInOutStaging;
	
	@POST
    @Produces(MediaType.APPLICATION_XML)
    @Path("/pickingListServiceFromDevice")
    public XMLServiceResponse pickingListServiceFromDevice(PickingListDTO pickingListInfo) {
		LOGGER.debug("picking list service from device enters");
    	String deviceID="";
    	if(pickingListInfo!=null){
    		 deviceID= pickingListInfo.getPickingLineDetailsDTO().get(0).getDeviceID();
    	}
    	long startTime= System.currentTimeMillis();
		XMLServiceResponse serviceResponse = new XMLServiceResponse();		
		try {
			if (pickingListInfo!=null) {	
				pickingInOutStaging.insertPickingListToStagingTable(pickingListInfo);
				serviceResponse.setStatusType(ServiceConstants.SERVICE_RESPONSE_SUCCESS);
				serviceResponse.setStatusCode(ServiceConstants.PICKLIST_INSERT_SUCCESS);
				serviceResponse.setStatusMessage("Records Inserted Successfully");
			} else {
				serviceResponse.setStatusCode(ServiceConstants.NO_INPUT_DATA);
				serviceResponse.setStatusMessage("No Input data found..");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			LOGGER.error("pickingListServiceFromDevice -- > insertPickingListToStagingTable()  Exception : " , ex);
			serviceResponse.setStatusType(ServiceConstants.SERVICE_RESPONSE_ERROR);
			//serviceResponse.setStatusCode(ServiceConstants.PICKLIST_INSERT_FAILURE);
			serviceResponse.setStatusMessage("Pick List Insert Failure");
		}
		 long timeTaken = System.currentTimeMillis() - startTime;
		 LOGGER.debug("Time taken for Pick List Service by Device," + deviceID +"," + timeTaken); 
		 LOGGER.debug("********************************************************************************"); 
		return serviceResponse;
    }
	
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/pickingListServiceFromDeviceAndroid")
    public XMLServiceResponse pickingListServiceFromDeviceAndroid(PickingListDTO pickingListInfo) {
		LOGGER.debug("picking list service from device enters");
    	String deviceID="";
    	if(pickingListInfo!=null){
    		 deviceID= pickingListInfo.getPickingLineDetailsDTO().get(0).getDeviceID();
    	}
    	long startTime= System.currentTimeMillis();
		XMLServiceResponse serviceResponse = new XMLServiceResponse();		
		try {
			if (pickingListInfo!=null) {	
				pickingInOutStaging.insertPickingListToStagingTable(pickingListInfo);
				serviceResponse.setStatusType(ServiceConstants.SERVICE_RESPONSE_SUCCESS);
				serviceResponse.setStatusCode(ServiceConstants.PICKLIST_INSERT_SUCCESS);
				serviceResponse.setStatusMessage("Records Inserted Successfully");
			} else {
				serviceResponse.setStatusCode(ServiceConstants.NO_INPUT_DATA);
				serviceResponse.setStatusMessage("No Input data found..");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			LOGGER.error("pickingListServiceFromDevice -- > insertPickingListToStagingTable()  Exception : " , ex);
			serviceResponse.setStatusType(ServiceConstants.SERVICE_RESPONSE_ERROR);
			//serviceResponse.setStatusCode(ServiceConstants.PICKLIST_INSERT_FAILURE);
			serviceResponse.setStatusMessage("Pick List Insert Failure");
		}
		 long timeTaken = System.currentTimeMillis() - startTime;
		 LOGGER.debug("Time taken for Pick List Service by Device," + deviceID +"," + timeTaken); 
		 LOGGER.debug("********************************************************************************"); 
		return serviceResponse;
    }
	
}
