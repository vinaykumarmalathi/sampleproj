package com.rnaipl.wms.service;

import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.rnaipl.wms.bean.AgedAudit;
import com.rnaipl.wms.dto.AgedAuditDTO;
import com.rnaipl.wms.dto.PartsInOutAuditSearchDTO;
import com.rnaipl.wms.service.util.ServiceConstants;
import com.rnaipl.wms.service.util.ServiceResponse;
import com.rnaipl.wms.service.util.ServiceResponseHandler;

@Path("/AgedAudit")
public class AgedAuditService {
	
	private static final Logger LOGGER = Logger.getLogger(AgedAuditService.class);
	
	@Inject
	AgedAudit agedAuditSearch;
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/agedAuditSearch")
	public ServiceResponse getAgedAuditDetails(PartsInOutAuditSearchDTO partsInOutAuditSearchDTO){
		
		ServiceResponse serviceResponse = null;
		LOGGER.debug("**IN Class->getAgedAuditDetails() entry");
		try{
			
			if(partsInOutAuditSearchDTO.getPartNumber()!=null){
				List<String> partList = Arrays.asList(partsInOutAuditSearchDTO.getPartNumber().split(","));
				partsInOutAuditSearchDTO.setPartList(partList);
			}
			if(partsInOutAuditSearchDTO.getLocation() != null) {
        		List<String> locationList = Arrays.asList(partsInOutAuditSearchDTO.getLocation().split(","));
        		partsInOutAuditSearchDTO.setLocationList(locationList);
        	}
        	
        	if(partsInOutAuditSearchDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(partsInOutAuditSearchDTO.getRan().split(","));        	
        		partsInOutAuditSearchDTO.setRanList(ranList);
        	}
        	List<AgedAuditDTO> agedAuditDTO = agedAuditSearch.getAgedAuditSearch(partsInOutAuditSearchDTO);
        	
        	if (!agedAuditDTO.isEmpty()
					|| agedAuditDTO.size() > 0) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.PARTS_FETCH_SUCCESS,
						agedAuditDTO);
			} else {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			}
		

		} catch (Exception ex) {
			LOGGER.error("AgedAuditService -- > getAgedAuditDetails()  Exception : " , ex);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.PARTS_FETCH_ERROR, ex);
		}
		LOGGER.debug("**IN Class->getAgedAuditDetails() Exit");
		return serviceResponse;
	}	
	
	@POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/agedAuditSearchCount")
	public ServiceResponse getAgedAuditCount(PartsInOutAuditSearchDTO partsInOutAuditSearchDTO){
		
		ServiceResponse serviceResponse = null;
		LOGGER.debug("**IN Class->getAgedAuditCount() entry");
		try {
			LOGGER.debug("IN getAgedAuditCount ENTRY");
			if(partsInOutAuditSearchDTO.getPartNumber() != null) {
        		List<String> partList = Arrays.asList(partsInOutAuditSearchDTO.getPartNumber().split(","));
        		partsInOutAuditSearchDTO.setPartList(partList);
        	}
        	if(partsInOutAuditSearchDTO.getLocation() != null) {
        		List<String> locationList = Arrays.asList(partsInOutAuditSearchDTO.getLocation().split(","));
        		partsInOutAuditSearchDTO.setLocationList(locationList);
        	}
        	if(partsInOutAuditSearchDTO.getRan() != null) {
        		List<String> ranList = Arrays.asList(partsInOutAuditSearchDTO.getRan().split(","));
        		partsInOutAuditSearchDTO.setRanList(ranList);
        	}
			int noOfRecords = agedAuditSearch
					.getAgedAuditSearchCount(partsInOutAuditSearchDTO);
			if (noOfRecords > 0) {
				serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,
						ServiceConstants.PARTS_FETCH_SUCCESS,
						noOfRecords);
			} else {
				serviceResponse = ServiceResponseHandler
						.prepareMessage(ServiceConstants.SERVICE_RESPONSE_SUCCESS,ServiceConstants.NO_DATA_FOUND);
			}
			LOGGER.debug("IN getPartsAuditSearch EXIT");

		} catch (Exception ex) {
			LOGGER.error("AgedAuditService -- > getAgedAuditCount()  Exception : " , ex);
			serviceResponse = ServiceResponseHandler.prepareMessage(ServiceConstants.SERVICE_RESPONSE_ERROR,
					ServiceConstants.PARTS_FETCH_ERROR, ex);
		}
		LOGGER.debug("**IN Class->getAgedAuditCount() Exit");
		return serviceResponse;
		
	}
}



